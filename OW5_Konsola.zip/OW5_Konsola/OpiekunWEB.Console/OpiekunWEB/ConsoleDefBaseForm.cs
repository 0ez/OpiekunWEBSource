﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB
{
	// Token: 0x02000003 RID: 3
	public partial class ConsoleDefBaseForm : RibbonBaseForm
	{
		// Token: 0x06000009 RID: 9 RVA: 0x00002258 File Offset: 0x00000458
		public ConsoleDefBaseForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002266 File Offset: 0x00000466
		public ConsoleDefBaseForm(FormsSettings formsSettings, IFormCreator formCreator) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00002276 File Offset: 0x00000476
		public ConsoleDefBaseForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x0000228D File Offset: 0x0000048D
		private void barButtonClose_ItemClick(object sender, ItemClickEventArgs e)
		{
			base.Close();
		}

		// Token: 0x04000005 RID: 5
		protected ApiClient _apiClient;
	}
}
