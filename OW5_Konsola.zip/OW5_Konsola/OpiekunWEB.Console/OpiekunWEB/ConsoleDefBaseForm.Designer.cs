﻿namespace OpiekunWEB
{
	// Token: 0x02000003 RID: 3
	public partial class ConsoleDefBaseForm : global::OpiekunWEB.Console.Forms.RibbonBaseForm
	{
		// Token: 0x0600000D RID: 13 RVA: 0x00002295 File Offset: 0x00000495
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600000E RID: 14 RVA: 0x000022B4 File Offset: 0x000004B4
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.ConsoleDefBaseForm));
			this.ribbonCommands = new global::DevExpress.XtraBars.Ribbon.RibbonControl();
			this.barButtonClose = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAdd = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonEdit = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonDelete = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonLaunch = new global::DevExpress.XtraBars.BarButtonItem();
			this.ribbonPageAction = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.ribbonPageGroupAction = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonCommands).BeginInit();
			base.SuspendLayout();
			this.ribbonCommands.AllowMdiChildButtons = false;
			this.ribbonCommands.AllowMinimizeRibbon = false;
			this.ribbonCommands.DrawGroupCaptions = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonCommands.ExpandCollapseItem.Id = 0;
			this.ribbonCommands.Items.AddRange(new global::DevExpress.XtraBars.BarItem[]
			{
				this.ribbonCommands.ExpandCollapseItem,
				this.barButtonClose,
				this.barButtonAdd,
				this.barButtonEdit,
				this.barButtonDelete,
				this.barButtonLaunch
			});
			resources.ApplyResources(this.ribbonCommands, "ribbonCommands");
			this.ribbonCommands.MaxItemId = 2;
			this.ribbonCommands.Name = "ribbonCommands";
			this.ribbonCommands.Pages.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPage[]
			{
				this.ribbonPageAction
			});
			this.ribbonCommands.ShowApplicationButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonCommands.ShowMoreCommandsButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonCommands.ShowPageHeadersInFormCaption = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonCommands.ShowPageHeadersMode = global::DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
			this.ribbonCommands.ShowQatLocationSelector = false;
			this.ribbonCommands.ShowToolbarCustomizeItem = false;
			this.ribbonCommands.Toolbar.ShowCustomizeItem = false;
			this.ribbonCommands.ToolbarLocation = global::DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
			resources.ApplyResources(this.barButtonClose, "barButtonClose");
			this.barButtonClose.Id = 1;
			this.barButtonClose.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.close_16x16;
			this.barButtonClose.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.close_32x32;
			this.barButtonClose.Name = "barButtonClose";
			this.barButtonClose.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonClose_ItemClick);
			resources.ApplyResources(this.barButtonAdd, "barButtonAdd");
			this.barButtonAdd.Id = 3;
			this.barButtonAdd.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.add_16x16;
			this.barButtonAdd.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.add_32x32;
			this.barButtonAdd.Name = "barButtonAdd";
			resources.ApplyResources(this.barButtonEdit, "barButtonEdit");
			this.barButtonEdit.Id = 4;
			this.barButtonEdit.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.edit_16x16;
			this.barButtonEdit.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.edit_32x32;
			this.barButtonEdit.Name = "barButtonEdit";
			resources.ApplyResources(this.barButtonDelete, "barButtonDelete");
			this.barButtonDelete.Id = 5;
			this.barButtonDelete.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.delete_16x16;
			this.barButtonDelete.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.delete_32x32;
			this.barButtonDelete.Name = "barButtonDelete";
			resources.ApplyResources(this.barButtonLaunch, "barButtonLaunch");
			this.barButtonLaunch.Id = 1;
			this.barButtonLaunch.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.media_16x16;
			this.barButtonLaunch.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.media_32x32;
			this.barButtonLaunch.Name = "barButtonLaunch";
			this.ribbonPageAction.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.ribbonPageGroupAction
			});
			this.ribbonPageAction.Name = "ribbonPageAction";
			resources.ApplyResources(this.ribbonPageAction, "ribbonPageAction");
			this.ribbonPageGroupAction.ItemLinks.Add(this.barButtonClose);
			this.ribbonPageGroupAction.ItemLinks.Add(this.barButtonAdd, true);
			this.ribbonPageGroupAction.ItemLinks.Add(this.barButtonEdit);
			this.ribbonPageGroupAction.ItemLinks.Add(this.barButtonDelete);
			this.ribbonPageGroupAction.ItemLinks.Add(this.barButtonLaunch, true);
			this.ribbonPageGroupAction.Name = "ribbonPageGroupAction";
			resources.ApplyResources(this.ribbonPageGroupAction, "ribbonPageGroupAction");
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.ribbonCommands);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ConsoleDefBaseForm";
			this.Ribbon = this.ribbonCommands;
			((global::System.ComponentModel.ISupportInitialize)this.ribbonCommands).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000006 RID: 6
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000007 RID: 7
		private global::DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageAction;

		// Token: 0x04000008 RID: 8
		protected global::DevExpress.XtraBars.Ribbon.RibbonControl ribbonCommands;

		// Token: 0x04000009 RID: 9
		protected global::DevExpress.XtraBars.BarButtonItem barButtonClose;

		// Token: 0x0400000A RID: 10
		protected global::DevExpress.XtraBars.BarButtonItem barButtonAdd;

		// Token: 0x0400000B RID: 11
		protected global::DevExpress.XtraBars.BarButtonItem barButtonEdit;

		// Token: 0x0400000C RID: 12
		protected global::DevExpress.XtraBars.BarButtonItem barButtonDelete;

		// Token: 0x0400000D RID: 13
		protected global::DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupAction;

		// Token: 0x0400000E RID: 14
		protected global::DevExpress.XtraBars.BarButtonItem barButtonLaunch;
	}
}
