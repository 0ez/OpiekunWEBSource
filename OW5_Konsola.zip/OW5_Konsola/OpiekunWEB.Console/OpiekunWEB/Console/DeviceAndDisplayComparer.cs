﻿using System;
using System.Collections.Generic;

namespace OpiekunWEB.Console
{
	// Token: 0x02000009 RID: 9
	public class DeviceAndDisplayComparer : IEqualityComparer<DeviceAndDisplay>
	{
		// Token: 0x0600002F RID: 47 RVA: 0x00002D6B File Offset: 0x00000F6B
		public bool Equals(DeviceAndDisplay x, DeviceAndDisplay y)
		{
			return x.DeviceItem == y.DeviceItem && x.DisplayItem == y.DisplayItem;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00002D8C File Offset: 0x00000F8C
		public int GetHashCode(DeviceAndDisplay obj)
		{
			if (obj == null)
			{
				return 0;
			}
			DeviceItem deviceItem = obj.DeviceItem;
			int num = (deviceItem != null) ? deviceItem.GetHashCode() : 0;
			DisplayItem displayItem = obj.DisplayItem;
			int h2 = (displayItem != null) ? displayItem.GetHashCode() : 0;
			return num + h2;
		}
	}
}
