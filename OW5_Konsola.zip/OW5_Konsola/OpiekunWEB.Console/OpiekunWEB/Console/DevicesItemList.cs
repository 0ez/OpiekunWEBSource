﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace OpiekunWEB.Console
{
	// Token: 0x0200000E RID: 14
	public class DevicesItemList : BindingList<DeviceTreeItemBase>
	{
		// Token: 0x06000058 RID: 88 RVA: 0x0000373F File Offset: 0x0000193F
		public DevicesItemList()
		{
			this._excludedList = new List<DeviceTreeItemBase>();
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000059 RID: 89 RVA: 0x00003754 File Offset: 0x00001954
		// (remove) Token: 0x0600005A RID: 90 RVA: 0x0000378C File Offset: 0x0000198C
		public event EventHandler<DeviceTreeItemBase> OnDetermineExcludedValue;

		// Token: 0x0600005B RID: 91 RVA: 0x000037C1 File Offset: 0x000019C1
		public new bool Remove(DeviceTreeItemBase item)
		{
			item.PropertyChanged -= this.ItemOnPropertyChanged;
			return this._excludedList.Remove(item) || base.Remove(item);
		}

		// Token: 0x0600005C RID: 92 RVA: 0x000037EC File Offset: 0x000019EC
		public List<DeviceTreeItemBase> WithExcluded()
		{
			List<DeviceTreeItemBase> list = new List<DeviceTreeItemBase>();
			list.AddRange(base.Items);
			list.AddRange(this._excludedList);
			return list;
		}

		// Token: 0x0600005D RID: 93 RVA: 0x0000380B File Offset: 0x00001A0B
		protected override void ClearItems()
		{
			base.ClearItems();
			this._excludedList.Clear();
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00003820 File Offset: 0x00001A20
		protected override void InsertItem(int index, DeviceTreeItemBase item)
		{
			item.PropertyChanged -= this.ItemOnPropertyChanged;
			EventHandler<DeviceTreeItemBase> onDetermineExcludedValue = this.OnDetermineExcludedValue;
			if (onDetermineExcludedValue != null)
			{
				onDetermineExcludedValue(this, item);
			}
			item.PropertyChanged += this.ItemOnPropertyChanged;
			if (item.Excluded)
			{
				if (this._excludedList.IndexOf(item) == -1)
				{
					this._excludedList.Add(item);
					return;
				}
			}
			else
			{
				base.InsertItem(index, item);
			}
		}

		// Token: 0x0600005F RID: 95 RVA: 0x00003890 File Offset: 0x00001A90
		private void ItemOnPropertyChanged(object sender, PropertyChangedEventArgs args)
		{
			if (args.PropertyName == "Excluded")
			{
				DeviceTreeItemBase item = sender as DeviceTreeItemBase;
				if (item != null)
				{
					if (item.Excluded)
					{
						this.Remove(item);
						if (this._excludedList.IndexOf(item) == -1)
						{
							this._excludedList.Add(item);
							return;
						}
					}
					else
					{
						if (base.IndexOf(item) == -1)
						{
							base.Add(item);
						}
						this._excludedList.Remove(item);
					}
				}
			}
		}

		// Token: 0x0400002F RID: 47
		private readonly List<DeviceTreeItemBase> _excludedList;
	}
}
