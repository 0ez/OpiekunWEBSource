﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Threading;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Observable;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x02000015 RID: 21
	public class DevicesTree
	{
		// Token: 0x060000A5 RID: 165 RVA: 0x0000479C File Offset: 0x0000299C
		public DevicesTree(ApiClient apiClient, ObservableAgregator observableAgregator)
		{
			this._apiClient = apiClient;
			this._observableAgregator = observableAgregator;
			this._itemsFilterList = new List<DeviceTreeItemBase>();
			this.Selection = new DevicesAndGroupsSelection();
			this.ItemList = new DevicesItemList();
			this.ItemList.OnDetermineExcludedValue += this.OnDetermineExcludedValue;
			this.SetAvailableDeviceGroups();
			this._apiClient.DevicesGroups.CollectionChanged += this.DevicesGroupsOnCollectionChanged;
			this._apiClient.Devices.CollectionChanged += this.DevicesOnCollectionChanged;
			this._apiClient.Settings.AfterUpdate += this.SettingsOnAfterUpdate;
			this._apiClient.Roles.AfterUpdate += this.RolesOnAfterUpdate;
			this._apiClient.Rules.AfterUpdate += this.RulesOnAfterUpdate;
			this._apiClient.DeviceConnectedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<System.ValueTuple<string, string, DeviceConnected>>(this.OnDeviceConnected));
			this._apiClient.AgentConnectedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentConnected));
			this._apiClient.AgentDisconnectedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentDisconnected));
			this._apiClient.AgentWindowsSessionChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentWindowsSessionChanged));
			this._apiClient.AgentPropertyChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentPropertyChangedStream));
			this._options = new DevicesTreeOptions
			{
				HideAgentItemIfPossible = true
			};
			this.LoadDevicesAndGroups();
			this.SetItemsFilter(null);
		}

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x060000A6 RID: 166 RVA: 0x0000496C File Offset: 0x00002B6C
		// (remove) Token: 0x060000A7 RID: 167 RVA: 0x000049A4 File Offset: 0x00002BA4
		public event EventHandler<EventArgs> RestrictionGroupChanged;

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060000A8 RID: 168 RVA: 0x000049D9 File Offset: 0x00002BD9
		// (set) Token: 0x060000A9 RID: 169 RVA: 0x000049E1 File Offset: 0x00002BE1
		public DeviceTreeItemBase FocusedItem { get; private set; }

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x060000AA RID: 170 RVA: 0x000049EA File Offset: 0x00002BEA
		public virtual DevicesItemList ItemList { get; }

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000AB RID: 171 RVA: 0x000049F2 File Offset: 0x00002BF2
		// (set) Token: 0x060000AC RID: 172 RVA: 0x000049FA File Offset: 0x00002BFA
		public string RootGroupId { get; private set; }

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x060000AD RID: 173 RVA: 0x00004A03 File Offset: 0x00002C03
		// (set) Token: 0x060000AE RID: 174 RVA: 0x00004A0B File Offset: 0x00002C0B
		public DevicesAndGroupsSelection Selection { get; set; }

		// Token: 0x060000AF RID: 175 RVA: 0x00004A14 File Offset: 0x00002C14
		public bool CanChangeParentForItem(DeviceTreeItemBase item, DeviceTreeItemBase newParent)
		{
			if (item.IsGroup)
			{
				if (item.Id == this.RootGroupId)
				{
					return false;
				}
				if (newParent == null)
				{
					return false;
				}
				if (item.Id == newParent.Id)
				{
					return false;
				}
			}
			return this.GetAllParentsForItem(newParent).Find((DeviceTreeItemBase x) => x.Id == item.Id) == null;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00004A90 File Offset: 0x00002C90
		public AgentItem FindAgentById(string id)
		{
			return this.ItemList.OfType<AgentItem>().FirstOrDefault((AgentItem x) => x.Id == id);
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00004AC8 File Offset: 0x00002CC8
		public AgentItem FindAgentByIdWithExcluded(string id)
		{
			return this.ItemList.WithExcluded().OfType<AgentItem>().FirstOrDefault((AgentItem x) => x.Id == id);
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00004B04 File Offset: 0x00002D04
		public DeviceItem FindDeviceById(string id)
		{
			return this.ItemList.OfType<DeviceItem>().FirstOrDefault((DeviceItem x) => x.Id == id);
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00004B3C File Offset: 0x00002D3C
		public DevicesGroupItem FindDeviceGroupById(string id)
		{
			return this.ItemList.OfType<DevicesGroupItem>().FirstOrDefault((DevicesGroupItem x) => x.Id == id);
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00004B74 File Offset: 0x00002D74
		public AgentItem FindDeviceSessionById(string id)
		{
			DeviceItem deviceItem = this.FindDeviceById(ApiUtils.DeviceIdFromAgentId(id));
			if (deviceItem == null)
			{
				return null;
			}
			return deviceItem.GetAgentItemsList().Find((AgentItem x) => x.Id == id);
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00004BBC File Offset: 0x00002DBC
		public DeviceTreeItemBase FindItemById(string id)
		{
			return this.ItemList.FirstOrDefault((DeviceTreeItemBase x) => x.Id == id);
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x00004BED File Offset: 0x00002DED
		public DevicesGroupItem FindItemParentGroup(DeviceTreeItemBase item)
		{
			return this.FindDeviceGroupById(item.ParentId);
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x00004BFC File Offset: 0x00002DFC
		public List<AgentItem> GetAgentsForGroupAndSubgroups(DevicesGroupItem group)
		{
			List<DevicesGroupItem> groups = this.GetSubGroupsForGroup(group);
			groups.Add(group);
			return this.GetAgentsForGroupList(groups);
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00004C20 File Offset: 0x00002E20
		public List<DeviceTreeItemBase> GetAllItemChildren(DeviceTreeItemBase item)
		{
			List<DeviceTreeItemBase> result = new List<DeviceTreeItemBase>();
			this.<GetAllItemChildren>g__addChildren|35_0(result, item);
			return result;
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00004C3C File Offset: 0x00002E3C
		public List<DeviceItem> GetAllVisibleDevices()
		{
			List<DeviceTreeItemBase> itemsFilterList = this._itemsFilterList;
			if (itemsFilterList != null && itemsFilterList.Any<DeviceTreeItemBase>())
			{
				return this._itemsFilterList.OfType<DeviceItem>().ToList<DeviceItem>();
			}
			return this.ItemList.OfType<DeviceItem>().ToList<DeviceItem>();
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00004C73 File Offset: 0x00002E73
		public List<DeviceItem> GetDevices()
		{
			return this.ItemList.OfType<DeviceItem>().ToList<DeviceItem>();
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00004C88 File Offset: 0x00002E88
		public List<DeviceItem> GetDevicesForGroupAndSubgroups(string groupId)
		{
			DevicesGroupItem group = this.GetGroups().FirstOrDefault((DevicesGroupItem x) => x.Id == groupId);
			if (group != null)
			{
				return this.GetDevicesForGroupAndSubgroups(group);
			}
			return new List<DeviceItem>();
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00004CCC File Offset: 0x00002ECC
		public List<DeviceItem> GetDevicesForGroupAndSubgroups(DevicesGroupItem group)
		{
			List<DevicesGroupItem> groups = this.GetSubGroupsForGroup(group);
			groups.Add(group);
			return this.GetDevicesForGroupList(groups);
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00004CEF File Offset: 0x00002EEF
		public List<DevicesGroupItem> GetGroups()
		{
			return this.ItemList.OfType<DevicesGroupItem>().ToList<DevicesGroupItem>();
		}

		// Token: 0x060000BE RID: 190 RVA: 0x00004D01 File Offset: 0x00002F01
		public string GetItemGroupName(DeviceTreeItemBase item)
		{
			if (item == null)
			{
				return string.Empty;
			}
			if (item is DevicesGroupItem)
			{
				return item.Name;
			}
			DevicesGroupItem devicesGroupItem = this.FindItemParentGroup(item);
			if (devicesGroupItem == null)
			{
				return null;
			}
			return devicesGroupItem.Name;
		}

		// Token: 0x060000BF RID: 191 RVA: 0x00004D2D File Offset: 0x00002F2D
		public DevicesAndGroupsSelection GetSelectionForItem(DeviceTreeItemBase item, bool onlyConnectedDevices = true, bool onlyConnectedSessions = false)
		{
			return this.GetSelection(new List<DeviceTreeItemBase>
			{
				item
			}, onlyConnectedDevices, onlyConnectedSessions);
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00004D44 File Offset: 0x00002F44
		public List<DevicesGroupItem> GetSubGroupsForGroup(DevicesGroupItem group)
		{
			List<DevicesGroupItem> result = new List<DevicesGroupItem>();
			foreach (DevicesGroupItem groupItem in this.GetGroups())
			{
				if (this.GetAllParentsForItem(groupItem).Contains(group))
				{
					result.Add(groupItem);
				}
			}
			return result;
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00004DB0 File Offset: 0x00002FB0
		public void SetFocusedItem(DeviceTreeItemBase focusedItem)
		{
			this.FocusedItem = focusedItem;
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x00004DB9 File Offset: 0x00002FB9
		public void SetItemsFilter(List<DeviceTreeItemBase> visibleItems)
		{
			this._itemsFilterList = visibleItems;
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x00004DC4 File Offset: 0x00002FC4
		public void SetSelectedItems(List<DeviceTreeItemBase> selectedItems, bool onlyConnectedDevices, bool onlyConnectedSessions)
		{
			DevicesAndGroupsSelection newSelection = this.GetSelection(selectedItems, onlyConnectedDevices, onlyConnectedSessions);
			if (!newSelection.ComputeChanges(this.Selection))
			{
				this.Selection.ItemsSelectedByUser = selectedItems;
				return;
			}
			this.Selection = newSelection;
			this._observableAgregator.SendSelectedDeviceChanged(this.Selection);
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x00004E10 File Offset: 0x00003010
		private bool DeleteItemById(string id)
		{
			DeviceTreeItemBase item = this.FindItemById(id);
			return item != null && this.ItemList.Remove(item);
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x00004E38 File Offset: 0x00003038
		private void DevicesGroupsOnCollectionChanged(object sender, NotifyCollectionChangedEventArgs args)
		{
			switch (args.Action)
			{
			case NotifyCollectionChangedAction.Add:
				using (IEnumerator enumerator = args.NewItems.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						DevicesGroup g = obj as DevicesGroup;
						if (this.FindDeviceGroupById(g.Id) == null)
						{
							this.ItemList.Add(new DevicesGroupItem(g));
						}
					}
					goto IL_150;
				}
				break;
			case NotifyCollectionChangedAction.Remove:
				break;
			case NotifyCollectionChangedAction.Replace:
				goto IL_CB;
			case NotifyCollectionChangedAction.Move:
				goto IL_150;
			case NotifyCollectionChangedAction.Reset:
				goto IL_145;
			default:
				goto IL_150;
			}
			using (IEnumerator enumerator = args.OldItems.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object group = enumerator.Current;
					DevicesGroup devicesGroup = group as DevicesGroup;
					this.DeleteItemById((devicesGroup != null) ? devicesGroup.Id : null);
				}
				goto IL_150;
			}
			IL_CB:
			using (IEnumerator enumerator = args.NewItems.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object obj2 = enumerator.Current;
					DevicesGroup updatedGrup = obj2 as DevicesGroup;
					DevicesGroupItem groupItem = this.FindDeviceGroupById(updatedGrup.Id);
					string groupItemOldParentId = groupItem.ParentId;
					if (groupItem != null)
					{
						groupItem.Update(updatedGrup);
						if (groupItem.ParentId != groupItemOldParentId)
						{
							this.UpdateAfterChangeDeviceOrGroupParent(groupItem.ParentId, groupItemOldParentId);
						}
					}
				}
				goto IL_150;
			}
			IL_145:
			this.ItemList.Clear();
			IL_150:
			this.UpdateSelection();
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x00004FC4 File Offset: 0x000031C4
		private void DevicesOnCollectionChanged(object sender, NotifyCollectionChangedEventArgs args)
		{
			switch (args.Action)
			{
			case NotifyCollectionChangedAction.Add:
				using (IEnumerator enumerator = args.NewItems.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						object obj = enumerator.Current;
						Device d = obj as Device;
						if (this.FindDeviceById(d.Id) == null)
						{
							this.ItemList.Add(new DeviceItem(d, this._apiClient.GetAppAccessForDevice(d.Id), this._apiClient.GetDeviceInetAccess(d.Id), this._apiClient.GetDeviceLockSettings(d.Id), this._apiClient.GetDeviceAppAccessDesktopOrCategoryId(d.Id), this._apiClient.GetDeviceInetStrictCategoryId(d.Id), this._options.HideAgentItemIfPossible));
						}
					}
					goto IL_1BD;
				}
				break;
			case NotifyCollectionChangedAction.Remove:
				break;
			case NotifyCollectionChangedAction.Replace:
				goto IL_131;
			case NotifyCollectionChangedAction.Move:
				goto IL_1BD;
			case NotifyCollectionChangedAction.Reset:
				goto IL_1B2;
			default:
				goto IL_1BD;
			}
			using (IEnumerator enumerator = args.OldItems.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object device = enumerator.Current;
					Device device2 = device as Device;
					this.DeleteItemById((device2 != null) ? device2.Id : null);
				}
				goto IL_1BD;
			}
			IL_131:
			using (IEnumerator enumerator = args.NewItems.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object obj2 = enumerator.Current;
					Device updatedDevice = obj2 as Device;
					DeviceItem deviceItem = this.FindDeviceById((updatedDevice != null) ? updatedDevice.Id : null);
					if (deviceItem != null)
					{
						string deviceItemOldParentId = deviceItem.ParentId;
						deviceItem.Update(updatedDevice);
						if (deviceItem.ParentId != deviceItemOldParentId)
						{
							this.UpdateAfterChangeDeviceOrGroupParent(deviceItem.Id, deviceItemOldParentId);
						}
					}
				}
				goto IL_1BD;
			}
			IL_1B2:
			this.ItemList.Clear();
			IL_1BD:
			this.UpdateSelection();
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x000051BC File Offset: 0x000033BC
		private List<AgentItem> GetAgents()
		{
			return this.ItemList.OfType<AgentItem>().ToList<AgentItem>();
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x000051D0 File Offset: 0x000033D0
		private List<AgentItem> GetAgentsForGroup(DevicesGroupItem group)
		{
			List<string> devicesId = (from x in this.GetDevicesForGroup(@group)
			select x.Id).ToList<string>();
			return (from x in this.GetAgents()
			where devicesId.Contains(x.ParentId)
			select x).ToList<AgentItem>();
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x00005238 File Offset: 0x00003438
		private List<AgentItem> GetAgentsForGroupList(List<DevicesGroupItem> groups)
		{
			List<AgentItem> result = new List<AgentItem>();
			foreach (DevicesGroupItem group in groups)
			{
				result = result.Union(this.GetAgentsForGroup(group)).ToList<AgentItem>();
			}
			return result;
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000529C File Offset: 0x0000349C
		private List<DeviceTreeItemBase> GetAllParentsForItem(DeviceTreeItemBase item)
		{
			List<DeviceTreeItemBase> result = new List<DeviceTreeItemBase>();
			for (;;)
			{
				DeviceTreeItemBase parentItem = this.FindItemById(item.ParentId);
				if (parentItem == null)
				{
					break;
				}
				result.Add(parentItem);
				item = parentItem;
			}
			return result;
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000052CC File Offset: 0x000034CC
		private List<DeviceItem> GetDevicesForGroup(DevicesGroupItem group)
		{
			return (from x in this.GetDevices()
			where x.ParentId == @group.Id
			select x).ToList<DeviceItem>();
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00005304 File Offset: 0x00003504
		private List<DeviceItem> GetDevicesForGroupList(List<DevicesGroupItem> groups)
		{
			List<DeviceItem> result = new List<DeviceItem>();
			foreach (DevicesGroupItem group in groups)
			{
				result = result.Union(this.GetDevicesForGroup(group)).ToList<DeviceItem>();
			}
			return result;
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00005368 File Offset: 0x00003568
		private DevicesAndGroupsSelection GetSelection(List<DeviceTreeItemBase> selectedItems, bool onlyConnectedDevices, bool onlyConnectedSessions)
		{
			List<DeviceItem> devicesList = new List<DeviceItem>();
			List<DevicesGroupItem> groupsList = new List<DevicesGroupItem>();
			DeviceAndDisplayList deviceAndDisplayList = new DeviceAndDisplayList();
			DevicesGroupItem rootGroupSelected = selectedItems.Find((DeviceTreeItemBase x) => x.Id == this.RootGroupId) as DevicesGroupItem;
			bool isRootGroupSelected = rootGroupSelected != null;
			bool isAllDevicesRootGroupSelected = false;
			if (rootGroupSelected != null)
			{
				isAllDevicesRootGroupSelected = (string.IsNullOrEmpty(rootGroupSelected.ParentId) && this._apiClient.GetDeviceGroupsSelectMode() == DeviceGroupsSelectMode.DeviceGroupsSelectAll);
				groupsList.AddRange(this.GetGroups());
				devicesList = this.GetDevices();
				using (List<DeviceItem>.Enumerator enumerator = devicesList.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						DeviceItem device = enumerator.Current;
						deviceAndDisplayList.AddDevice(device);
					}
					goto IL_20E;
				}
			}
			foreach (DeviceTreeItemBase item in selectedItems)
			{
				if (this.FindItemById(item.Id) != null)
				{
					DevicesGroupItem group = item as DevicesGroupItem;
					if (group == null)
					{
						DeviceItem device2 = item as DeviceItem;
						if (device2 == null)
						{
							AgentItem agent = item as AgentItem;
							if (agent == null)
							{
								DisplayItem display = item as DisplayItem;
								if (display != null)
								{
									devicesList.Add(display.AgentItem.DeviceItem);
									deviceAndDisplayList.AddDisplay(display);
								}
							}
							else
							{
								devicesList.Add(agent.DeviceItem);
								deviceAndDisplayList.AddAgent(agent);
							}
						}
						else
						{
							devicesList.Add(device2);
							deviceAndDisplayList.AddDevice(device2);
						}
					}
					else
					{
						groupsList.Add(group);
					}
				}
			}
			if (groupsList.Count > 0)
			{
				List<DevicesGroupItem> allSelectedGroups = new List<DevicesGroupItem>();
				allSelectedGroups.AddRange(groupsList);
				foreach (DevicesGroupItem group2 in groupsList)
				{
					allSelectedGroups = allSelectedGroups.Union(this.GetSubGroupsForGroup(group2)).ToList<DevicesGroupItem>();
				}
				devicesList.AddRange(this.GetDevicesForGroupList(allSelectedGroups));
				foreach (DeviceItem device3 in devicesList)
				{
					deviceAndDisplayList.AddDevice(device3);
				}
				groupsList.AddRange(allSelectedGroups);
			}
			IL_20E:
			devicesList = devicesList.Distinct<DeviceItem>().ToList<DeviceItem>();
			groupsList = groupsList.Distinct<DevicesGroupItem>().ToList<DevicesGroupItem>();
			if (this._itemsFilterList != null)
			{
				devicesList = devicesList.Intersect(this._itemsFilterList).OfType<DeviceItem>().ToList<DeviceItem>();
				deviceAndDisplayList.RemoveDevicesNotInFilter(devicesList);
				if (onlyConnectedSessions)
				{
					deviceAndDisplayList.RemoveNotActiveSessions();
				}
			}
			return new DevicesAndGroupsSelection(onlyConnectedDevices, onlyConnectedSessions, selectedItems, groupsList, devicesList, this.GetAllVisibleDevices(), deviceAndDisplayList, isRootGroupSelected, isAllDevicesRootGroupSelected);
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00005614 File Offset: 0x00003814
		private bool IsDeviceGroupAvailable(string groupId)
		{
			return !this._haveDeviceGroupsRestrictions || this._availableDeviceGroups.Contains(groupId);
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0000562C File Offset: 0x0000382C
		private bool IsGroupHasConnectedDevices(DevicesGroupItem group)
		{
			return this.GetDevicesForGroup(group).Any((DeviceItem x) => x.IsConnected);
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00005659 File Offset: 0x00003859
		private bool IsGroupHasConnectedSubgroups(DevicesGroupItem group)
		{
			return this.GetSubGroupsForGroup(group).Any((DevicesGroupItem x) => x.IsConnected);
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x00005688 File Offset: 0x00003888
		private void LoadDevicesAndGroups()
		{
			this.ItemList.Clear();
			foreach (DevicesGroup group in this._apiClient.DevicesGroups)
			{
				this.ItemList.Add(new DevicesGroupItem(group));
			}
			foreach (Device device in this._apiClient.Devices)
			{
				this.ItemList.Add(new DeviceItem(device, this._apiClient.GetAppAccessForDevice(device.Id), this._apiClient.GetDeviceInetAccess(device.Id), this._apiClient.GetDeviceLockSettings(device.Id), this._apiClient.GetDeviceAppAccessDesktopOrCategoryId(device.Id), this._apiClient.GetDeviceInetStrictCategoryId(device.Id), this._options.HideAgentItemIfPossible));
			}
			this._restrictionGroupId = this._apiClient.GetRestrictedRootDeviceGroupId();
			string rootGroupId;
			if ((rootGroupId = this._restrictionGroupId) == null)
			{
				DevicesGroupItem devicesGroupItem = this.ItemList.OfType<DevicesGroupItem>().FirstOrDefault((DevicesGroupItem x) => string.IsNullOrEmpty(x.ParentId));
				rootGroupId = ((devicesGroupItem != null) ? devicesGroupItem.Id : null);
			}
			this.RootGroupId = rootGroupId;
			this.SetGroupsInetAccessIcon();
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x000057FC File Offset: 0x000039FC
		private void OnAgentConnected(AgentClient agentClient)
		{
			AgentItem agentItem = this.FindAgentById(agentClient.AgentId);
			if (agentItem != null)
			{
				agentItem.AgentClient = agentClient;
				this.UpdateAgentDisplayItems(agentItem);
			}
			else
			{
				DeviceItem deviceItem = this.FindDeviceById(agentClient.DeviceId);
				if (deviceItem == null)
				{
					return;
				}
				agentItem = new AgentItem(deviceItem, agentClient);
				deviceItem.AddAgentItem(agentItem);
				this.ItemList.Add(agentItem);
				this.UpdateAgentDisplayItems(agentItem);
			}
			agentItem.IsConnected = true;
			this.SetIsConnectedForItemParents(agentItem);
			this._observableAgregator.SendAgentConnectionChangedEvent(agentClient);
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00005878 File Offset: 0x00003A78
		private void OnAgentDisconnected(AgentClient agentClient)
		{
			AgentItem agentItem = this.FindAgentByIdWithExcluded(agentClient.AgentId);
			if (agentItem != null)
			{
				agentItem.IsConnected = false;
				DeviceItem deviceItem = this.FindDeviceById(agentItem.ParentId);
				if (deviceItem != null)
				{
					deviceItem.RemoveAgentItem(agentItem);
				}
				foreach (DisplayItem displayItem in agentItem.GetDisplaysList())
				{
					this.ItemList.Remove(displayItem);
				}
				this.ItemList.Remove(agentItem);
				this.SetIsConnectedForItemParents(agentItem);
			}
			this._observableAgregator.SendAgentConnectionChangedEvent(agentClient);
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00005920 File Offset: 0x00003B20
		private void OnAgentPropertyChangedStream(AgentClient agentClient)
		{
			AgentItem agentItem = this.FindAgentByIdWithExcluded(agentClient.AgentId);
			if (agentItem != null)
			{
				agentItem.DeviceItem.AgentPropertyChanged();
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00005948 File Offset: 0x00003B48
		private void OnAgentWindowsSessionChanged(AgentClient agentClient)
		{
			AgentItem agentItem = this.FindAgentByIdWithExcluded(agentClient.AgentId);
			if (agentItem != null)
			{
				agentItem.WindowsUser = agentClient.WindowsUser;
				this.UpdateAgentDisplayItems(agentItem);
			}
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00005978 File Offset: 0x00003B78
		private void OnDetermineExcludedValue(object sender, DeviceTreeItemBase item)
		{
			if (item is DisplayItem || item is AgentItem)
			{
				return;
			}
			string restrictionGroupId = this._apiClient.GetRestrictedRootDeviceGroupId();
			if (!string.IsNullOrEmpty(restrictionGroupId))
			{
				List<string> visibleGroupsIdList = new List<string>();
				if (this.IsDeviceGroupAvailable(restrictionGroupId))
				{
					visibleGroupsIdList.Add(restrictionGroupId);
				}
				foreach (string groupId in this._apiClient.GetDeviceSubGroupsIdForGroup(restrictionGroupId))
				{
					if (this.IsDeviceGroupAvailable(groupId))
					{
						visibleGroupsIdList.Add(groupId);
					}
				}
				if (item is DevicesGroupItem)
				{
					item.Excluded = !visibleGroupsIdList.Contains(item.Id);
					return;
				}
				item.Excluded = !visibleGroupsIdList.Contains(item.ParentId);
				return;
			}
			else
			{
				if (item is DevicesGroupItem)
				{
					item.Excluded = !this.IsDeviceGroupAvailable(item.Id);
					return;
				}
				item.Excluded = !this.IsDeviceGroupAvailable(item.ParentId);
				return;
			}
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00005A80 File Offset: 0x00003C80
		private void OnDeviceConnected([System.Runtime.CompilerServices.TupleElementNames(new string[]
		{
			"deviceId",
			"agentId",
			"connectedMsg"
		})] System.ValueTuple<string, string, DeviceConnected> param)
		{
			if (this.FindDeviceById(param.Item1) == null)
			{
				return;
			}
			this._apiClient.StartAgentConnection(param.Item2);
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00005AA4 File Offset: 0x00003CA4
		private void RolesOnAfterUpdate(object sender, EventArgs eventArgs)
		{
			DevicesTree.<RolesOnAfterUpdate>d__67 <RolesOnAfterUpdate>d__;
			<RolesOnAfterUpdate>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<RolesOnAfterUpdate>d__.<>4__this = this;
			<RolesOnAfterUpdate>d__.<>1__state = -1;
			<RolesOnAfterUpdate>d__.<>t__builder.Start<DevicesTree.<RolesOnAfterUpdate>d__67>(ref <RolesOnAfterUpdate>d__);
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00005ADB File Offset: 0x00003CDB
		private void RulesOnAfterUpdate(object sender, EventArgs eventArgs)
		{
			this.RolesOnAfterUpdate(sender, eventArgs);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00005AE5 File Offset: 0x00003CE5
		private void SetAvailableDeviceGroups()
		{
			this._availableDeviceGroups = this._apiClient.GetAvailableDeviceGroupsId();
			this._haveDeviceGroupsRestrictions = !this._availableDeviceGroups.Contains("*");
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00005B14 File Offset: 0x00003D14
		private void SetGroupsInetAccessIcon()
		{
			foreach (DevicesGroupItem group in this.GetGroups())
			{
				int groupIcon = 12;
				IEnumerable<InetControlState> internetAccessInGroup = (from x in this.GetDevicesForGroupAndSubgroups(@group)
				select x.InetAccess).Distinct<InetControlState>();
				if (internetAccessInGroup.Any<InetControlState>())
				{
					if (internetAccessInGroup.Count<InetControlState>() == 1)
					{
						groupIcon = DeviceTreeIconIndexes.GetInetControlStateIndex(internetAccessInGroup.ElementAt(0));
					}
					else
					{
						groupIcon = 11;
					}
				}
				group.SetIconForDeviceInetAccess(groupIcon);
			}
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00005BC0 File Offset: 0x00003DC0
		private void SetIsConnectedForItemParents(DeviceTreeItemBase treeItem)
		{
			if (treeItem.IsConnected)
			{
				using (List<DeviceTreeItemBase>.Enumerator enumerator = this.GetAllParentsForItem(treeItem).GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						DeviceTreeItemBase deviceTreeItemBase = enumerator.Current;
						deviceTreeItemBase.IsConnected = true;
					}
					return;
				}
			}
			List<DevicesGroupItem> parents = this.GetAllParentsForItem(treeItem).OfType<DevicesGroupItem>().ToList<DevicesGroupItem>();
			if (treeItem is DevicesGroupItem)
			{
				parents.Add(treeItem as DevicesGroupItem);
			}
			foreach (DevicesGroupItem group in parents)
			{
				if (group != null && !this.IsGroupHasConnectedDevices(group) && group.IsConnected)
				{
					group.IsConnected = false;
				}
			}
			foreach (DevicesGroupItem group2 in parents)
			{
				if (group2 != null && this.IsGroupHasConnectedSubgroups(group2) && !group2.IsConnected)
				{
					group2.IsConnected = true;
					this.SetIsConnectedForItemParents(group2);
				}
			}
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00005CF4 File Offset: 0x00003EF4
		private void SettingsOnAfterUpdate(object sender, EventArgs eventArgs)
		{
			foreach (DeviceItem item in this.GetDevices())
			{
				item.AppAccess = this._apiClient.GetAppAccessForDevice(item.Id);
				item.InetAccess = this._apiClient.GetDeviceInetAccess(item.Id);
				item.DeviceLockSettings = this._apiClient.GetDeviceLockSettings(item.Id);
				item.AppAccessDesktopOrCategoryId = this._apiClient.GetDeviceAppAccessDesktopOrCategoryId(item.Id);
				item.InetStrictCategoryId = this._apiClient.GetDeviceInetStrictCategoryId(item.Id);
			}
			this.SetGroupsInetAccessIcon();
		}

		// Token: 0x060000DE RID: 222 RVA: 0x00005DBC File Offset: 0x00003FBC
		private void UpdateAfterChangeDeviceOrGroupParent(string itemId, string prevParentId)
		{
			DeviceTreeItemBase deviceItem = this.FindItemById(itemId);
			if (deviceItem != null)
			{
				this.SetIsConnectedForItemParents(deviceItem);
			}
			DeviceTreeItemBase oldGroup = this.FindItemById(prevParentId);
			if (oldGroup != null)
			{
				oldGroup.IsConnected = this.IsGroupHasConnectedDevices(oldGroup as DevicesGroupItem);
				this.SetIsConnectedForItemParents(oldGroup);
			}
		}

		// Token: 0x060000DF RID: 223 RVA: 0x00005E00 File Offset: 0x00004000
		private void UpdateAgentDisplayItems(AgentItem agentItem)
		{
			List<DisplayItem> currentDisplayItems = (from x in this.ItemList.WithExcluded().OfType<DisplayItem>()
			where x.AgentItem.Id == agentItem.Id
			select x).ToList<DisplayItem>();
			List<DisplayItem> newDisplayItems = agentItem.GetDisplaysList();
			if (currentDisplayItems.Count != newDisplayItems.Count)
			{
				foreach (DisplayItem displayItem in currentDisplayItems)
				{
					this.ItemList.Remove(displayItem);
				}
				foreach (DisplayItem displayItem2 in newDisplayItems)
				{
					this.ItemList.Add(displayItem2);
				}
			}
			this.UpdateSelection();
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x00005EF0 File Offset: 0x000040F0
		private void UpdateSelection()
		{
			this.SetSelectedItems(this.Selection.ItemsSelectedByUser, this.Selection.OnlyConnectedDevices, this.Selection.OnlyConnetedSessions);
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x00005F1C File Offset: 0x0000411C
		[CompilerGenerated]
		private void <GetAllItemChildren>g__addChildren|35_0(List<DeviceTreeItemBase> resultList, DeviceTreeItemBase itemToCheck)
		{
			IEnumerable<DeviceTreeItemBase> children = from x in this.ItemList
			where x.ParentId == itemToCheck.Id
			select x;
			resultList.AddRange(children);
			foreach (DeviceTreeItemBase c in children)
			{
				this.<GetAllItemChildren>g__addChildren|35_0(resultList, c);
			}
		}

		// Token: 0x0400004F RID: 79
		private readonly ApiClient _apiClient;

		// Token: 0x04000050 RID: 80
		private readonly ObservableAgregator _observableAgregator;

		// Token: 0x04000051 RID: 81
		private readonly DevicesTreeOptions _options;

		// Token: 0x04000052 RID: 82
		private List<string> _availableDeviceGroups;

		// Token: 0x04000053 RID: 83
		private bool _haveDeviceGroupsRestrictions;

		// Token: 0x04000054 RID: 84
		private List<DeviceTreeItemBase> _itemsFilterList;

		// Token: 0x04000055 RID: 85
		private string _restrictionGroupId;
	}
}
