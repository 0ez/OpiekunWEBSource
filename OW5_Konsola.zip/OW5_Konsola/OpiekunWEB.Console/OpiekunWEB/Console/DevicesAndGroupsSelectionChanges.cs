﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace OpiekunWEB.Console
{
	// Token: 0x0200000B RID: 11
	public class DevicesAndGroupsSelectionChanges
	{
		// Token: 0x06000039 RID: 57 RVA: 0x000030C0 File Offset: 0x000012C0
		public DevicesAndGroupsSelectionChanges()
		{
			this.GroupsChanged = 0;
			this.AgentItemsAdded = new List<AgentItem>();
			this.AgentItemsRemoved = new List<AgentItem>();
			this.DeviceAndDisplayAdded = new DeviceAndDisplayList();
			this.DeviceAndDisplayRemoved = new DeviceAndDisplayList();
			this.DevicesVisibledChanged = 0;
			this.DevicesAdded = new List<DeviceItem>();
			this.DevicesRemoved = new List<DeviceItem>();
			this.DevicesChanged = 0;
			this.DeviceAndDisplayAdded = new DeviceAndDisplayList();
			this.DeviceAndDisplayRemoved = new DeviceAndDisplayList();
			this.DeviceAndDisplaysChanged = 0;
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00003148 File Offset: 0x00001348
		public DevicesAndGroupsSelectionChanges(bool groupsChanged, List<AgentItem> agentItemAdded, List<AgentItem> agentItemRemoved, List<DeviceItem> devicesVisibledAdded, List<DeviceItem> devicesVisibledRemoved, List<DeviceItem> devicesAdded, List<DeviceItem> devicesRemoved, DeviceAndDisplayList deviceAndDisplayAdded, DeviceAndDisplayList deviceAndDisplayRemoved)
		{
			this.GroupsChanged = groupsChanged;
			this.AgentItemsAdded = agentItemAdded;
			this.AgentItemsRemoved = agentItemRemoved;
			this.DevicesVisibledAdded = devicesVisibledAdded;
			this.DevicesVisibledRemoved = devicesVisibledRemoved;
			this.DevicesVisibledChanged = (devicesVisibledAdded.Any<DeviceItem>() || devicesVisibledRemoved.Any<DeviceItem>());
			this.DevicesAdded = devicesAdded;
			this.DevicesRemoved = devicesRemoved;
			this.DevicesChanged = (devicesAdded.Any<DeviceItem>() || devicesRemoved.Any<DeviceItem>());
			this.DeviceAndDisplayAdded = deviceAndDisplayAdded;
			this.DeviceAndDisplayRemoved = deviceAndDisplayRemoved;
			this.DeviceAndDisplaysChanged = (deviceAndDisplayAdded.Any<DeviceAndDisplay>() || deviceAndDisplayRemoved.Any<DeviceAndDisplay>());
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x0600003B RID: 59 RVA: 0x000031EB File Offset: 0x000013EB
		public List<AgentItem> AgentItemsAdded { get; }

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600003C RID: 60 RVA: 0x000031F3 File Offset: 0x000013F3
		public List<AgentItem> AgentItemsRemoved { get; }

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x0600003D RID: 61 RVA: 0x000031FB File Offset: 0x000013FB
		public DeviceAndDisplayList DeviceAndDisplayAdded { get; }

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600003E RID: 62 RVA: 0x00003203 File Offset: 0x00001403
		public DeviceAndDisplayList DeviceAndDisplayRemoved { get; }

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x0600003F RID: 63 RVA: 0x0000320B File Offset: 0x0000140B
		public bool DeviceAndDisplaysChanged { get; }

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000040 RID: 64 RVA: 0x00003213 File Offset: 0x00001413
		public List<DeviceItem> DevicesAdded { get; }

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000041 RID: 65 RVA: 0x0000321B File Offset: 0x0000141B
		public bool DevicesChanged { get; }

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000042 RID: 66 RVA: 0x00003223 File Offset: 0x00001423
		public List<DeviceItem> DevicesRemoved { get; }

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000043 RID: 67 RVA: 0x0000322B File Offset: 0x0000142B
		public List<DeviceItem> DevicesVisibledAdded { get; }

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000044 RID: 68 RVA: 0x00003233 File Offset: 0x00001433
		public bool DevicesVisibledChanged { get; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000045 RID: 69 RVA: 0x0000323B File Offset: 0x0000143B
		public List<DeviceItem> DevicesVisibledRemoved { get; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000046 RID: 70 RVA: 0x00003243 File Offset: 0x00001443
		public bool GroupsChanged { get; }
	}
}
