﻿using System;

namespace OpiekunWEB.Console
{
	// Token: 0x02000007 RID: 7
	public static class DeviceConnectionTypeIconIndexes
	{
		// Token: 0x0400001C RID: 28
		public const int Proxy = 0;

		// Token: 0x0400001D RID: 29
		public const int SessionRdp = 1;
	}
}
