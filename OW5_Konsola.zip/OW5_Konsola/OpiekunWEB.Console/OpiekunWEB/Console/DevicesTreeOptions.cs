﻿using System;

namespace OpiekunWEB.Console
{
	// Token: 0x0200000F RID: 15
	public class DevicesTreeOptions
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000060 RID: 96 RVA: 0x00003903 File Offset: 0x00001B03
		// (set) Token: 0x06000061 RID: 97 RVA: 0x0000390B File Offset: 0x00001B0B
		public bool HideAgentItemIfPossible { get; set; }
	}
}
