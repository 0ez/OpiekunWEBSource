﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000025 RID: 37
	public enum RemoteDesktopSize
	{
		// Token: 0x0400010F RID: 271
		Fixed800x600,
		// Token: 0x04000110 RID: 272
		Fixed1024x768,
		// Token: 0x04000111 RID: 273
		Fixed1280x1024,
		// Token: 0x04000112 RID: 274
		Fixed1600x900,
		// Token: 0x04000113 RID: 275
		Fixed1920x1080,
		// Token: 0x04000114 RID: 276
		FitToWindow
	}
}
