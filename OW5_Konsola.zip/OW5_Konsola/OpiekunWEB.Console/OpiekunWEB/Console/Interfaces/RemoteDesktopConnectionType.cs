﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000023 RID: 35
	public enum RemoteDesktopConnectionType
	{
		// Token: 0x04000108 RID: 264
		VNC,
		// Token: 0x04000109 RID: 265
		RDP
	}
}
