﻿using System;
using System.Windows.Forms;
using DevExpress.XtraGrid.Views.Grid;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x0200002E RID: 46
	public interface IFormCreator
	{
		// Token: 0x1700024C RID: 588
		// (get) Token: 0x06000395 RID: 917
		IObservable<string> FormShowStream { get; }

		// Token: 0x06000396 RID: 918
		T CreateControl<T>() where T : Control;

		// Token: 0x06000397 RID: 919
		bool Show<T>() where T : Form;

		// Token: 0x06000398 RID: 920
		bool Show<T, TParam>(TParam param) where T : Form;

		// Token: 0x06000399 RID: 921
		bool Show<T>(FormAction action) where T : Form;

		// Token: 0x0600039A RID: 922
		bool Show<T, TParam>(FormAction action, TParam input) where T : Form;

		// Token: 0x0600039B RID: 923
		bool Show<T, TParam>(FormAction action, TParam input, out TParam output) where T : Form;

		// Token: 0x0600039C RID: 924
		bool ShowAndKeepGridPosition<T, TParam>(GridView gridView, FormAction action, TParam input) where T : Form;

		// Token: 0x0600039D RID: 925
		bool ShowAndKeepGridPosition<T, TParam>(GridView gridView, FormAction action, TParam input, out TParam output) where T : Form;

		// Token: 0x0600039E RID: 926
		void ShowError(string message);

		// Token: 0x0600039F RID: 927
		void ShowErrorF(string message, params object[] args);

		// Token: 0x060003A0 RID: 928
		void ShowInfo(string message);

		// Token: 0x060003A1 RID: 929
		void ShowInfoF(string message, params object[] args);

		// Token: 0x060003A2 RID: 930
		void ShowNonModal<T>() where T : Form;

		// Token: 0x060003A3 RID: 931
		void ShowNonModal<T>(IWin32Window owner) where T : Form;

		// Token: 0x060003A4 RID: 932
		void ShowNonModal<T, TParam>(TParam param) where T : Form;

		// Token: 0x060003A5 RID: 933
		void ShowNonModal<T, TParam>(TParam param, IWin32Window owner, FormClosingEventHandler formClosingEvent) where T : Form;

		// Token: 0x060003A6 RID: 934
		bool ShowYesNoQuestion(string message);

		// Token: 0x060003A7 RID: 935
		bool ShowYesNoQuestionF(string message, params object[] args);
	}
}
