﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x0200002D RID: 45
	public enum FormAction
	{
		// Token: 0x04000120 RID: 288
		Unknown,
		// Token: 0x04000121 RID: 289
		Create,
		// Token: 0x04000122 RID: 290
		Read,
		// Token: 0x04000123 RID: 291
		Update,
		// Token: 0x04000124 RID: 292
		Delete
	}
}
