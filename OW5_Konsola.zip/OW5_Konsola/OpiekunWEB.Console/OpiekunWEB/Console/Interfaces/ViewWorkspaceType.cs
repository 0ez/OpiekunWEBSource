﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x0200002F RID: 47
	public enum ViewWorkspaceType
	{
		// Token: 0x04000126 RID: 294
		Full,
		// Token: 0x04000127 RID: 295
		DeviceTree
	}
}
