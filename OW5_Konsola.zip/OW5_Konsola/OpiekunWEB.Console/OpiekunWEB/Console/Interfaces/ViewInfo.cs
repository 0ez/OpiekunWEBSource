﻿using System;
using System.Windows.Forms;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000032 RID: 50
	public class ViewInfo<T> : IViewInfo where T : Control
	{
		// Token: 0x060003B5 RID: 949 RVA: 0x0000DCFB File Offset: 0x0000BEFB
		public ViewInfo(IFormCreator formCreator, ViewWorkspaceType workspaceType)
		{
			this._viewControl = null;
			this._formCreator = formCreator;
			this.WorkspaceType = workspaceType;
			this.ControlDisposed = false;
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x060003B6 RID: 950 RVA: 0x0000DD1F File Offset: 0x0000BF1F
		public Control Control
		{
			get
			{
				if (this._viewControl == null)
				{
					this._viewControl = this._formCreator.CreateControl<T>();
				}
				return this._viewControl;
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x060003B7 RID: 951 RVA: 0x0000DD45 File Offset: 0x0000BF45
		public bool ControlCreated
		{
			get
			{
				return this._viewControl != null;
			}
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x060003B8 RID: 952 RVA: 0x0000DD50 File Offset: 0x0000BF50
		// (set) Token: 0x060003B9 RID: 953 RVA: 0x0000DD58 File Offset: 0x0000BF58
		public bool ControlDisposed { get; set; }

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x060003BA RID: 954 RVA: 0x0000DD61 File Offset: 0x0000BF61
		public string ViewTypeName
		{
			get
			{
				return typeof(!0).Name;
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x060003BB RID: 955 RVA: 0x0000DD72 File Offset: 0x0000BF72
		public ViewWorkspaceType WorkspaceType { get; }

		// Token: 0x0400012B RID: 299
		private readonly IFormCreator _formCreator;

		// Token: 0x0400012C RID: 300
		private Control _viewControl;
	}
}
