﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x0200002A RID: 42
	public enum PopupMenuKind
	{
		// Token: 0x0400011A RID: 282
		DevicesTree,
		// Token: 0x0400011B RID: 283
		DeviceScreenshot
	}
}
