﻿using System;
using DevExpress.XtraBars;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x0200002B RID: 43
	public interface IPopupMenuCreator
	{
		// Token: 0x0600037F RID: 895
		void FillPopupMenu(PopupMenu popupMenu, PopupMenuKind menuKind, ICommandTarget commandTarget);
	}
}
