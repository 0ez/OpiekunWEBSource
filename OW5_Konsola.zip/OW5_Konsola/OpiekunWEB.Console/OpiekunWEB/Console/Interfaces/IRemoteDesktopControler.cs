﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000027 RID: 39
	public interface IRemoteDesktopControler
	{
		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000367 RID: 871
		RemoteDesktopConnectionType ConnectionType { get; }

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x06000368 RID: 872
		DeviceItem DeviceItem { get; }

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x06000369 RID: 873
		// (set) Token: 0x0600036A RID: 874
		DisplayItem DisplayItem { get; set; }

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x0600036B RID: 875
		// (set) Token: 0x0600036C RID: 876
		RemoteDesktopInputMode InputMode { get; set; }

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x0600036D RID: 877
		// (set) Token: 0x0600036E RID: 878
		RemoteDesktopStretchMode StretchMode { get; set; }

		// Token: 0x0600036F RID: 879
		Task Connect();

		// Token: 0x06000370 RID: 880
		Task Disconnect();

		// Token: 0x06000371 RID: 881
		Control GetControl();

		// Token: 0x06000372 RID: 882
		Task RefreshWindow();

		// Token: 0x06000373 RID: 883
		Task SendCAD();

		// Token: 0x06000374 RID: 884
		void WindowClosing();
	}
}
