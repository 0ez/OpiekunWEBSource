﻿using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Console.Helpers;
using StructureMap;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x0200002C RID: 44
	public class FormCreator : IFormCreator
	{
		// Token: 0x06000380 RID: 896 RVA: 0x0000D556 File Offset: 0x0000B756
		public FormCreator(IContainer container, List<Type> singletonFormTypes)
		{
			this._container = container;
			this._singletonFormTypes = singletonFormTypes;
			this._formShowStreamSubject = new Subject<string>();
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x06000381 RID: 897 RVA: 0x0000D577 File Offset: 0x0000B777
		public IObservable<string> FormShowStream
		{
			get
			{
				return this._formShowStreamSubject.AsQbservable<string>();
			}
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0000D584 File Offset: 0x0000B784
		public T CreateControl<T>() where T : Control
		{
			return this._container.GetInstance<T>();
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0000D594 File Offset: 0x0000B794
		public bool Show<T>() where T : Form
		{
			if (this.IsSingletonForm<T>())
			{
				T form = this._container.GetInstance<T>();
				form.Icon = AppUtils.GetAppIcon();
				this._formShowStreamSubject.OnNext(form.Name);
				return form.ShowDialog() == DialogResult.OK;
			}
			bool result;
			using (T form2 = this._container.GetInstance<T>())
			{
				form2.Icon = AppUtils.GetAppIcon();
				this._formShowStreamSubject.OnNext(form2.Name);
				result = (form2.ShowDialog() == DialogResult.OK);
			}
			return result;
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0000D654 File Offset: 0x0000B854
		public bool Show<T, TParam>(TParam param) where T : Form
		{
			if (this.IsSingletonForm<T>())
			{
				T form = this._container.With<TParam>(param).GetInstance<T>();
				form.Icon = AppUtils.GetAppIcon();
				this._formShowStreamSubject.OnNext(form.Name);
				return form.ShowDialog() == DialogResult.OK;
			}
			bool result;
			using (T form2 = this._container.With<TParam>(param).GetInstance<T>())
			{
				form2.Icon = AppUtils.GetAppIcon();
				this._formShowStreamSubject.OnNext(form2.Name);
				result = (form2.ShowDialog() == DialogResult.OK);
			}
			return result;
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0000D720 File Offset: 0x0000B920
		public bool Show<T>(FormAction action) where T : Form
		{
			bool result = false;
			if (this.IsSingletonForm<T>())
			{
				T form = this._container.With("action").EqualTo(action).GetInstance<T>();
				form.Icon = AppUtils.GetAppIcon();
				this._formShowStreamSubject.OnNext(form.Name);
				result = (form.ShowDialog() == DialogResult.OK);
			}
			else
			{
				using (T form2 = this._container.With("action").EqualTo(action).GetInstance<T>())
				{
					form2.Icon = AppUtils.GetAppIcon();
					this._formShowStreamSubject.OnNext(form2.Name);
					result = (form2.ShowDialog() == DialogResult.OK);
				}
			}
			return result;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x0000D80C File Offset: 0x0000BA0C
		public bool Show<T, TParam>(FormAction action, TParam input) where T : Form
		{
			bool result = false;
			if (this.IsSingletonForm<T>())
			{
				T form = this._container.With("action").EqualTo(action).With<TParam>(input).GetInstance<T>();
				form.Icon = AppUtils.GetAppIcon();
				this._formShowStreamSubject.OnNext(form.Name);
				result = (form.ShowDialog() == DialogResult.OK);
			}
			else
			{
				using (T form2 = this._container.With("action").EqualTo(action).With<TParam>(input).GetInstance<T>())
				{
					form2.Icon = AppUtils.GetAppIcon();
					this._formShowStreamSubject.OnNext(form2.Name);
					result = (form2.ShowDialog() == DialogResult.OK);
				}
			}
			return result;
		}

		// Token: 0x06000387 RID: 903 RVA: 0x0000D904 File Offset: 0x0000BB04
		public bool Show<T, TParam>(FormAction action, TParam input, out TParam output) where T : Form
		{
			output = input;
			bool result = false;
			if (this.IsSingletonForm<T>())
			{
				T form = this._container.With("action").EqualTo(action).With<TParam>(output).GetInstance<T>();
				form.Icon = AppUtils.GetAppIcon();
				this._formShowStreamSubject.OnNext(form.Name);
				result = (form.ShowDialog() == DialogResult.OK);
			}
			else
			{
				using (T form2 = this._container.With("action").EqualTo(action).With<TParam>(output).GetInstance<T>())
				{
					form2.Icon = AppUtils.GetAppIcon();
					this._formShowStreamSubject.OnNext(form2.Name);
					result = (form2.ShowDialog() == DialogResult.OK);
				}
			}
			return result;
		}

		// Token: 0x06000388 RID: 904 RVA: 0x0000DA10 File Offset: 0x0000BC10
		public bool ShowAndKeepGridPosition<T, TParam>(GridView gridView, FormAction action, TParam input) where T : Form
		{
			int index = gridView.GetFocusedDataSourceRowIndex();
			bool flag = this.Show<T, TParam>(action, input);
			if (flag)
			{
				int handle = gridView.GetRowHandle(index);
				gridView.FocusedRowHandle = handle;
			}
			return flag;
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0000DA40 File Offset: 0x0000BC40
		public bool ShowAndKeepGridPosition<T, TParam>(GridView gridView, FormAction action, TParam input, out TParam output) where T : Form
		{
			int index = gridView.GetFocusedDataSourceRowIndex();
			bool flag = this.Show<T, TParam>(action, input, out output);
			if (flag)
			{
				int handle = gridView.GetRowHandle(index);
				gridView.FocusedRowHandle = handle;
			}
			return flag;
		}

		// Token: 0x0600038A RID: 906 RVA: 0x0000DA70 File Offset: 0x0000BC70
		public void ShowError(string message)
		{
			XtraMessageBox.Show(message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0600038B RID: 907 RVA: 0x0000DA81 File Offset: 0x0000BC81
		public void ShowErrorF(string message, params object[] args)
		{
			XtraMessageBox.Show(string.Format(message, args), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0000DA98 File Offset: 0x0000BC98
		public void ShowInfo(string message)
		{
			XtraMessageBox.Show(message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0000DAA9 File Offset: 0x0000BCA9
		public void ShowInfoF(string message, params object[] args)
		{
			XtraMessageBox.Show(string.Format(message, args), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x0600038E RID: 910 RVA: 0x0000DAC0 File Offset: 0x0000BCC0
		public void ShowNonModal<T>() where T : Form
		{
			T form = this._container.GetInstance<T>();
			form.Icon = AppUtils.GetAppIcon();
			this._formShowStreamSubject.OnNext(form.Name);
			form.Show();
		}

		// Token: 0x0600038F RID: 911 RVA: 0x0000DB0C File Offset: 0x0000BD0C
		public void ShowNonModal<T, TParam>(TParam param) where T : Form
		{
			T form = this._container.With<TParam>(param).GetInstance<T>();
			form.Icon = AppUtils.GetAppIcon();
			this._formShowStreamSubject.OnNext(form.Name);
			form.Show();
		}

		// Token: 0x06000390 RID: 912 RVA: 0x0000DB5C File Offset: 0x0000BD5C
		public void ShowNonModal<T>(IWin32Window owner) where T : Form
		{
			T form = this._container.GetInstance<T>();
			form.Icon = AppUtils.GetAppIcon();
			this._formShowStreamSubject.OnNext(form.Name);
			form.Show(owner);
		}

		// Token: 0x06000391 RID: 913 RVA: 0x0000DBA8 File Offset: 0x0000BDA8
		public void ShowNonModal<T, TParam>(TParam param, IWin32Window owner, FormClosingEventHandler formClosingEvent) where T : Form
		{
			T form = this._container.With<TParam>(param).GetInstance<T>();
			if (formClosingEvent != null)
			{
				form.FormClosing += formClosingEvent;
			}
			form.Icon = AppUtils.GetAppIcon();
			this._formShowStreamSubject.OnNext(form.Name);
			form.Show(owner);
		}

		// Token: 0x06000392 RID: 914 RVA: 0x0000DC08 File Offset: 0x0000BE08
		public bool ShowYesNoQuestion(string message)
		{
			return XtraMessageBox.Show(message, Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0000DC20 File Offset: 0x0000BE20
		public bool ShowYesNoQuestionF(string message, params object[] args)
		{
			return XtraMessageBox.Show(string.Format(message, args), Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
		}

		// Token: 0x06000394 RID: 916 RVA: 0x0000DC3E File Offset: 0x0000BE3E
		private bool IsSingletonForm<T>()
		{
			return this._singletonFormTypes.IndexOf(typeof(!!0)) >= 0;
		}

		// Token: 0x0400011C RID: 284
		private readonly IContainer _container;

		// Token: 0x0400011D RID: 285
		private readonly Subject<string> _formShowStreamSubject;

		// Token: 0x0400011E RID: 286
		private readonly List<Type> _singletonFormTypes;
	}
}
