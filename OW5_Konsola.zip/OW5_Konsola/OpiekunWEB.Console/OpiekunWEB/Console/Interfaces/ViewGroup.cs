﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000031 RID: 49
	public class ViewGroup
	{
		// Token: 0x060003AE RID: 942 RVA: 0x0000DC5B File Offset: 0x0000BE5B
		public ViewGroup(IViewInfo[] views, string name = null)
		{
			this.Views = views;
			this.CurrentView = views[0];
			this.Name = ((!string.IsNullOrEmpty(name)) ? name : this.CurrentView.ViewTypeName);
		}

		// Token: 0x060003AF RID: 943 RVA: 0x0000DC8F File Offset: 0x0000BE8F
		public ViewGroup(IViewInfo view, string name = null) : this(new IViewInfo[]
		{
			view
		}, name)
		{
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x060003B0 RID: 944 RVA: 0x0000DCA2 File Offset: 0x0000BEA2
		// (set) Token: 0x060003B1 RID: 945 RVA: 0x0000DCAA File Offset: 0x0000BEAA
		public IViewInfo CurrentView { get; set; }

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x060003B2 RID: 946 RVA: 0x0000DCB3 File Offset: 0x0000BEB3
		public string Name { get; }

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x060003B3 RID: 947 RVA: 0x0000DCBB File Offset: 0x0000BEBB
		public IViewInfo[] Views { get; }

		// Token: 0x060003B4 RID: 948 RVA: 0x0000DCC4 File Offset: 0x0000BEC4
		public IViewInfo FindView(string viewTypeName)
		{
			foreach (IViewInfo view in this.Views)
			{
				if (view.ViewTypeName == viewTypeName)
				{
					return view;
				}
			}
			return null;
		}
	}
}
