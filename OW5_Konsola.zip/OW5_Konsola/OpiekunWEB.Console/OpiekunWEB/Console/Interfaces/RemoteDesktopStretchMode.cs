﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000026 RID: 38
	public enum RemoteDesktopStretchMode
	{
		// Token: 0x04000116 RID: 278
		Disabled,
		// Token: 0x04000117 RID: 279
		FitToWindow,
		// Token: 0x04000118 RID: 280
		AspecRatio
	}
}
