﻿using System;
using System.Collections.Generic;
using Owpb;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000028 RID: 40
	public interface ICommandTarget
	{
		// Token: 0x06000375 RID: 885
		List<AgentItem> GetCommandTargetAsAgentItems();

		// Token: 0x06000376 RID: 886
		List<DeviceItem> GetCommandTargetAsDeviceItems();

		// Token: 0x06000377 RID: 887
		DeviceAndDisplayList GetCommandTargetAsDevicesAndDisplays();

		// Token: 0x06000378 RID: 888
		bool IsCommandEnabled(ConsoleEventType eventType);
	}
}
