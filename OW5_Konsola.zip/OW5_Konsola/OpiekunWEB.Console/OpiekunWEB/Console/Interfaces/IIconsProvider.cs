﻿using System;
using DevExpress.Utils;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000029 RID: 41
	public interface IIconsProvider
	{
		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000379 RID: 889
		ImageCollection AppCategoryTypeImages16x16 { get; }

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x0600037A RID: 890
		ImageCollection AppControlStateImages16x16 { get; }

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x0600037B RID: 891
		ImageCollection ConnectionTypeImages16x16 { get; }

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x0600037C RID: 892
		ImageCollection ConnectionTypeImages24x24 { get; }

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x0600037D RID: 893
		ImageCollection DevicesTreeImages24x24 { get; }

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x0600037E RID: 894
		ImageCollection InetControlStateImages16x16 { get; }
	}
}
