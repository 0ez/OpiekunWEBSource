﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000024 RID: 36
	public enum RemoteDesktopInputMode
	{
		// Token: 0x0400010B RID: 267
		AdminAndUser,
		// Token: 0x0400010C RID: 268
		Admin,
		// Token: 0x0400010D RID: 269
		User
	}
}
