﻿using System;
using System.Windows.Forms;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000030 RID: 48
	public interface IViewInfo
	{
		// Token: 0x1700024D RID: 589
		// (get) Token: 0x060003A8 RID: 936
		Control Control { get; }

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x060003A9 RID: 937
		bool ControlCreated { get; }

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x060003AA RID: 938
		// (set) Token: 0x060003AB RID: 939
		bool ControlDisposed { get; set; }

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x060003AC RID: 940
		string ViewTypeName { get; }

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x060003AD RID: 941
		ViewWorkspaceType WorkspaceType { get; }
	}
}
