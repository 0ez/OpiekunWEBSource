﻿using System;

namespace OpiekunWEB.Console.Interfaces
{
	// Token: 0x02000022 RID: 34
	public enum RemoteDesktopColorsDepth
	{
		// Token: 0x04000103 RID: 259
		Bits8,
		// Token: 0x04000104 RID: 260
		Bits16,
		// Token: 0x04000105 RID: 261
		Bits24,
		// Token: 0x04000106 RID: 262
		Bits32
	}
}
