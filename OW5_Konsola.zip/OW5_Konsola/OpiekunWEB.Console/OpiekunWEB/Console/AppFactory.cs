﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq.Expressions;
using System.Threading;
using System.Windows.Forms;
using CommandLine;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Choco;
using OpiekunWEB.Console.Forms;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using StructureMap;

namespace OpiekunWEB.Console
{
	// Token: 0x02000005 RID: 5
	public class AppFactory
	{
		// Token: 0x0600001D RID: 29 RVA: 0x000029B4 File Offset: 0x00000BB4
		public AppFactory(string apiAddr)
		{
			AppFactory.<>c__DisplayClass4_0 CS$<>8__locals1 = new AppFactory.<>c__DisplayClass4_0();
			CS$<>8__locals1.apiAddr = apiAddr;
			base..ctor();
			CS$<>8__locals1.<>4__this = this;
			AppFactory.<>c__DisplayClass4_1 CS$<>8__locals2 = new AppFactory.<>c__DisplayClass4_1();
			CS$<>8__locals2.CS$<>8__locals1 = CS$<>8__locals1;
			this._cmdLineParams = new CmdLineParams();
			Parser parser = new Parser(delegate(ParserSettings config)
			{
				config.IgnoreUnknownArguments = true;
				config.EnableDashDash = false;
			});
			parser.ParseArguments<CmdLineParams>(Environment.GetCommandLineArgs()).WithParsed(delegate(CmdLineParams opts)
			{
				CS$<>8__locals2.CS$<>8__locals1.<>4__this._cmdLineParams = opts;
			});
			if (this._cmdLineParams.ApiAddr != null)
			{
				CS$<>8__locals2.CS$<>8__locals1.apiAddr = this._cmdLineParams.ApiAddr;
			}
			this._singletonFormTypes = new List<Type>();
			this.ConfigureSingletonFormTypes();
			this._appConfiguration = new AppConfiguration();
			this._container = new Container();
			CS$<>8__locals2.verbose = (File.Exists(this._appConfiguration.AppDir + "verbose.cfg") || this._cmdLineParams.Verbose);
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				x.For<IFormCreator>(null).Singleton().Use<FormCreator>((IContext _) => new FormCreator(CS$<>8__locals2.CS$<>8__locals1.<>4__this._container, CS$<>8__locals2.CS$<>8__locals1.<>4__this._singletonFormTypes));
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				ParameterExpression parameterExpression;
				x.For<ApiClient>(null).Singleton().Use<ApiClient>(Expression.Lambda<Func<IContext, ApiClient>>(Expression.New(methodof(ApiClient..ctor(string, string, bool, SynchronizationContext, bool)), new Expression[]
				{
					Expression.Property(Expression.Field(Expression.Constant(CS$<>8__locals2.CS$<>8__locals1.<>4__this, typeof(AppFactory)), fieldof(AppFactory._appConfiguration)), methodof(AppConfiguration.get_DbDir())),
					Expression.Field(Expression.Field(Expression.Constant(CS$<>8__locals2, typeof(AppFactory.<>c__DisplayClass4_1)), fieldof(AppFactory.<>c__DisplayClass4_1.CS$<>8__locals1)), fieldof(AppFactory.<>c__DisplayClass4_0.apiAddr)),
					Expression.Not(Expression.Property(Expression.Field(Expression.Constant(CS$<>8__locals2.CS$<>8__locals1.<>4__this, typeof(AppFactory)), fieldof(AppFactory._cmdLineParams)), methodof(CmdLineParams.get_NoSSL()))),
					Expression.New(typeof(WindowsFormsSynchronizationContext)),
					Expression.Field(Expression.Constant(CS$<>8__locals2, typeof(AppFactory.<>c__DisplayClass4_1)), fieldof(AppFactory.<>c__DisplayClass4_1.verbose))
				}), new ParameterExpression[]
				{
					parameterExpression
				}));
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				ParameterExpression parameterExpression;
				x.For<ObservableAgregator>(null).Singleton().Use<ObservableAgregator>(Expression.Lambda<Func<IContext, ObservableAgregator>>(Expression.New(methodof(ObservableAgregator..ctor(ApiClient)), new Expression[]
				{
					Expression.Call(parameterExpression, methodof(IContext.GetInstance()), Array.Empty<Expression>())
				}), new ParameterExpression[]
				{
					parameterExpression
				}));
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				ParameterExpression parameterExpression;
				x.For<DevicesTree>(null).Singleton().Use<DevicesTree>(Expression.Lambda<Func<IContext, DevicesTree>>(Expression.New(methodof(DevicesTree..ctor(ApiClient, ObservableAgregator)), new Expression[]
				{
					Expression.Call(parameterExpression, methodof(IContext.GetInstance()), Array.Empty<Expression>()),
					Expression.Call(parameterExpression, methodof(IContext.GetInstance()), Array.Empty<Expression>())
				}), new ParameterExpression[]
				{
					parameterExpression
				}));
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				x.For<AppConfiguration>(null).Singleton().Use<AppConfiguration>((IContext _) => CS$<>8__locals2.CS$<>8__locals1.<>4__this._appConfiguration);
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				x.For<FormsSettings>(null).Singleton().Use<FormsSettings>((IContext _) => new FormsSettings(CS$<>8__locals2.CS$<>8__locals1.<>4__this._appConfiguration.AppDataDir, CS$<>8__locals2.CS$<>8__locals1.<>4__this._appConfiguration.UsersDataDir));
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				x.For<CmdLineParams>(null).Singleton().Use<CmdLineParams>((IContext _) => CS$<>8__locals2.CS$<>8__locals1.<>4__this._cmdLineParams);
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				ParameterExpression parameterExpression;
				x.For<IPopupMenuCreator>(null).Singleton().Use<MainForm>(Expression.Lambda<Func<IContext, MainForm>>(Expression.Call(parameterExpression, methodof(IContext.GetInstance()), Array.Empty<Expression>()), new ParameterExpression[]
				{
					parameterExpression
				}));
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				ParameterExpression parameterExpression;
				x.For<IChocolateyService>(null).Singleton().Use<ChocolateyService>(Expression.Lambda<Func<IContext, ChocolateyService>>(Expression.New(typeof(ChocolateyService)), new ParameterExpression[]
				{
					parameterExpression
				}));
			});
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				ParameterExpression parameterExpression;
				x.For<IIconsProvider>(null).Singleton().Use<IconsPrioviderForm>(Expression.Lambda<Func<IContext, IconsPrioviderForm>>(Expression.New(typeof(IconsPrioviderForm)), new ParameterExpression[]
				{
					parameterExpression
				}));
			});
			this.ConfigureContainer();
			parser.Dispose();
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002C17 File Offset: 0x00000E17
		public T GetInstance<T>()
		{
			return this._container.GetInstance<T>();
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002C24 File Offset: 0x00000E24
		private void ConfigureContainer()
		{
			this._container.Configure(delegate(ConfigurationExpression x)
			{
				x.For<SynchronizationContext>(null).Use<WindowsFormsSynchronizationContext>();
			});
			using (List<Type>.Enumerator enumerator = this._singletonFormTypes.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Type formType = enumerator.Current;
					this._container.Configure(delegate(ConfigurationExpression x)
					{
						x.For(formType, null).Singleton();
					});
				}
			}
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00002CBC File Offset: 0x00000EBC
		private void ConfigureSingletonFormTypes()
		{
			this._singletonFormTypes.Add(typeof(MainForm));
			this._singletonFormTypes.Add(typeof(VncViewerManagerForm));
		}

		// Token: 0x04000013 RID: 19
		private readonly AppConfiguration _appConfiguration;

		// Token: 0x04000014 RID: 20
		private readonly IContainer _container;

		// Token: 0x04000015 RID: 21
		private readonly List<Type> _singletonFormTypes;

		// Token: 0x04000016 RID: 22
		private CmdLineParams _cmdLineParams;
	}
}
