﻿using System;

namespace OpiekunWEB.Console
{
	// Token: 0x0200001A RID: 26
	internal class IconPositions
	{
		// Token: 0x040000A3 RID: 163
		public const int AppAccess = 1;

		// Token: 0x040000A4 RID: 164
		public const int DeviceLock = 2;

		// Token: 0x040000A5 RID: 165
		public const int InetAccess = 0;

		// Token: 0x040000A6 RID: 166
		public const int MaxIconsPerItem = 3;
	}
}
