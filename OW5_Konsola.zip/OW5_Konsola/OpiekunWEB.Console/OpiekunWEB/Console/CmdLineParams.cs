﻿using System;
using CommandLine;

namespace OpiekunWEB.Console
{
	// Token: 0x02000006 RID: 6
	public class CmdLineParams
	{
		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000021 RID: 33 RVA: 0x00002CE8 File Offset: 0x00000EE8
		// (set) Token: 0x06000022 RID: 34 RVA: 0x00002CF0 File Offset: 0x00000EF0
		[Option("apiaddr", Default = null)]
		public string ApiAddr { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000023 RID: 35 RVA: 0x00002CF9 File Offset: 0x00000EF9
		// (set) Token: 0x06000024 RID: 36 RVA: 0x00002D01 File Offset: 0x00000F01
		[Option("login", Default = null, HelpText = "User login email")]
		public string Login { get; set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000025 RID: 37 RVA: 0x00002D0A File Offset: 0x00000F0A
		// (set) Token: 0x06000026 RID: 38 RVA: 0x00002D12 File Offset: 0x00000F12
		[Option("noSSL", Default = null, HelpText = "Disable SSL")]
		public bool NoSSL { get; set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000027 RID: 39 RVA: 0x00002D1B File Offset: 0x00000F1B
		// (set) Token: 0x06000028 RID: 40 RVA: 0x00002D23 File Offset: 0x00000F23
		[Option("password", Default = null, HelpText = "User password")]
		public string Password { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000029 RID: 41 RVA: 0x00002D2C File Offset: 0x00000F2C
		// (set) Token: 0x0600002A RID: 42 RVA: 0x00002D34 File Offset: 0x00000F34
		[Option("Verbose", Default = false)]
		public bool Verbose { get; set; }
	}
}
