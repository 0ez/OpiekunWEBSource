﻿using System;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x02000016 RID: 22
	public static class DeviceTreeIconIndexes
	{
		// Token: 0x060000E3 RID: 227 RVA: 0x00005FA7 File Offset: 0x000041A7
		public static int DeviceLockIndex(int deviceLock)
		{
			if ((deviceLock & 7) == 7)
			{
				return 19;
			}
			if ((deviceLock & 3) > 0)
			{
				return 18;
			}
			return -1;
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x00005FBC File Offset: 0x000041BC
		public static int GetAppControlStateIndex(AppControlState appControlState)
		{
			switch (appControlState)
			{
			case AppControlState.AppCheck:
				return 20;
			case AppControlState.AppBlock:
				return 22;
			case AppControlState.AppStrictToDesktop:
				return 23;
			case AppControlState.AppUseBlackList:
				return 25;
			case AppControlState.AppUseWhiteList:
				return 24;
			}
			return -1;
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x00005FF2 File Offset: 0x000041F2
		public static int GetDeviceConnectedIndex(DeviceType deviceType)
		{
			switch (deviceType)
			{
			case DeviceType.Desktop:
				return 1;
			case DeviceType.TerminalServer:
				return 3;
			case DeviceType.TerminalClient:
				return 5;
			default:
				return -1;
			}
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x00006011 File Offset: 0x00004211
		public static int GetDeviceDisconnectedIndex(DeviceType deviceType)
		{
			switch (deviceType)
			{
			case DeviceType.Desktop:
				return 0;
			case DeviceType.TerminalServer:
				return 2;
			case DeviceType.TerminalClient:
				return 4;
			default:
				return -1;
			}
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x00006030 File Offset: 0x00004230
		public static int GetInetControlStateIndex(InetControlState controlState)
		{
			switch (controlState)
			{
			case InetControlState.InetCheck:
				return 12;
			case InetControlState.InetBlock:
				return 13;
			case InetControlState.InetAllow:
				return 14;
			case InetControlState.InetStrict:
				return 15;
			}
			return 12;
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x0000605C File Offset: 0x0000425C
		public static int GetSessionTypeIcon(DeviceSessionType sessionType, bool isProxyConnection)
		{
			if (sessionType == DeviceSessionType.Rdp)
			{
				return 0;
			}
			return -1;
		}

		// Token: 0x0400005B RID: 91
		public const int DeviceAppAllow = 21;

		// Token: 0x0400005C RID: 92
		public const int DeviceAppBlock = 22;

		// Token: 0x0400005D RID: 93
		public const int DeviceAppCheck = 20;

		// Token: 0x0400005E RID: 94
		public const int DeviceAppCheckBlackList = 25;

		// Token: 0x0400005F RID: 95
		public const int DeviceAppCheckWhiteList = 24;

		// Token: 0x04000060 RID: 96
		public const int DeviceAppStrict = 23;

		// Token: 0x04000061 RID: 97
		public const int DeviceDesktopConnected = 1;

		// Token: 0x04000062 RID: 98
		public const int DeviceDesktopDisconnected = 0;

		// Token: 0x04000063 RID: 99
		public const int DeviceDisplay = 16;

		// Token: 0x04000064 RID: 100
		public const int DeviceInetAllow = 14;

		// Token: 0x04000065 RID: 101
		public const int DeviceInetBlock = 13;

		// Token: 0x04000066 RID: 102
		public const int DeviceInetCheck = 12;

		// Token: 0x04000067 RID: 103
		public const int DeviceInetStrict = 15;

		// Token: 0x04000068 RID: 104
		public const int DeviceLockMouseKeyboard = 18;

		// Token: 0x04000069 RID: 105
		public const int DeviceLockMouseKeyboardMonitor = 19;

		// Token: 0x0400006A RID: 106
		public const int DeviceLockNone = 17;

		// Token: 0x0400006B RID: 107
		public const int DeviceSessionConnected = 7;

		// Token: 0x0400006C RID: 108
		public const int DeviceSessionDisconnected = 6;

		// Token: 0x0400006D RID: 109
		public const int DeviceSessioType = 10;

		// Token: 0x0400006E RID: 110
		public const int DeviceTerminalClientConnected = 5;

		// Token: 0x0400006F RID: 111
		public const int DeviceTerminalClientDisconnected = 4;

		// Token: 0x04000070 RID: 112
		public const int DeviceTerminalServerConnected = 3;

		// Token: 0x04000071 RID: 113
		public const int DeviceTerminalServerDisconnected = 2;

		// Token: 0x04000072 RID: 114
		public const int GroupConnected = 9;

		// Token: 0x04000073 RID: 115
		public const int GroupDisconnected = 8;

		// Token: 0x04000074 RID: 116
		public const int GroupInetCheck = 12;

		// Token: 0x04000075 RID: 117
		public const int GroupInetMultiple = 11;

		// Token: 0x04000076 RID: 118
		public const int GroupInetUnknown = 10;
	}
}
