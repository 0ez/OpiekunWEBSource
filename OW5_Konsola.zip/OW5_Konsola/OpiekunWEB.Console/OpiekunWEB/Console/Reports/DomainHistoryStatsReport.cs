﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using DevExpress.DataAccess.ObjectBinding;
using DevExpress.Utils;
using DevExpress.XtraPrinting;
using DevExpress.XtraReports.Localization;
using DevExpress.XtraReports.UI;
using Owpb;

namespace OpiekunWEB.Console.Reports
{
	// Token: 0x0200001D RID: 29
	public class DomainHistoryStatsReport : XtraReport
	{
		// Token: 0x06000172 RID: 370 RVA: 0x00009156 File Offset: 0x00007356
		public DomainHistoryStatsReport()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000173 RID: 371 RVA: 0x00009164 File Offset: 0x00007364
		public DomainHistoryStatsReport(string keyName, string description, object chartControl)
		{
			this.InitializeComponent();
			this._keyName = keyName;
			this._description = description;
			this.printableComponentChart.PrintableComponent = chartControl;
		}

		// Token: 0x06000174 RID: 372 RVA: 0x0000918C File Offset: 0x0000738C
		private void xrLabelDescription_BeforePrint(object sender, PrintEventArgs e)
		{
			(sender as XRLabel).Text = this._description;
		}

		// Token: 0x06000175 RID: 373 RVA: 0x0000919F File Offset: 0x0000739F
		private void xrLabelKeyName_BeforePrint(object sender, PrintEventArgs e)
		{
			(sender as XRLabel).Text = this._keyName;
		}

		// Token: 0x06000176 RID: 374 RVA: 0x000091B2 File Offset: 0x000073B2
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000177 RID: 375 RVA: 0x000091D4 File Offset: 0x000073D4
		private void InitializeComponent()
		{
			this.components = new Container();
			XRSummary xrSummary = new XRSummary();
			this.objectDataSource1 = new ObjectDataSource(this.components);
			this.Title = new XRControlStyle();
			this.DetailCaption1 = new XRControlStyle();
			this.DetailData1 = new XRControlStyle();
			this.DetailData3_Odd = new XRControlStyle();
			this.GrandTotalCaption1 = new XRControlStyle();
			this.GrandTotalData1 = new XRControlStyle();
			this.GrandTotalBackground1 = new XRControlStyle();
			this.PageInfo = new XRControlStyle();
			this.TopMargin = new TopMarginBand();
			this.BottomMargin = new BottomMarginBand();
			this.ReportHeader = new ReportHeaderBand();
			this.xrLabelKeyName = new XRLabel();
			this.xrLabelDescription = new XRLabel();
			this.GroupHeader1 = new GroupHeaderBand();
			this.table1 = new XRTable();
			this.tableRow1 = new XRTableRow();
			this.tableCell2 = new XRTableCell();
			this.tableCell1 = new XRTableCell();
			this.tableCell3 = new XRTableCell();
			this.Detail = new DetailBand();
			this.table2 = new XRTable();
			this.tableRow2 = new XRTableRow();
			this.tableCell5 = new XRTableCell();
			this.tableCell4 = new XRTableCell();
			this.tableCell6 = new XRTableCell();
			this.ReportFooter = new ReportFooterBand();
			this.panel1 = new XRPanel();
			this.label2 = new XRLabel();
			this.label3 = new XRLabel();
			this.GroupHeader2 = new GroupHeaderBand();
			this.printableComponentChart = new PrintableComponentContainer();
			((ISupportInitialize)this.objectDataSource1).BeginInit();
			((ISupportInitialize)this.table1).BeginInit();
			((ISupportInitialize)this.table2).BeginInit();
			((ISupportInitialize)this).BeginInit();
			this.objectDataSource1.DataSource = typeof(UrlDomainHistoryStatsItem);
			this.objectDataSource1.Name = "objectDataSource1";
			this.Title.BackColor = Color.Transparent;
			this.Title.BorderColor = Color.Black;
			this.Title.Borders = BorderSide.None;
			this.Title.BorderWidth = 1f;
			this.Title.Font = new Font("Arial", 14.25f);
			this.Title.ForeColor = Color.FromArgb(75, 75, 75);
			this.Title.Name = "Title";
			this.DetailCaption1.BackColor = Color.FromArgb(75, 75, 75);
			this.DetailCaption1.BorderColor = Color.White;
			this.DetailCaption1.Borders = BorderSide.Left;
			this.DetailCaption1.BorderWidth = 2f;
			this.DetailCaption1.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.DetailCaption1.ForeColor = Color.White;
			this.DetailCaption1.Name = "DetailCaption1";
			this.DetailCaption1.Padding = new PaddingInfo(15, 15, 0, 0, 254f);
			this.DetailCaption1.TextAlignment = TextAlignment.MiddleLeft;
			this.DetailData1.BorderColor = Color.Transparent;
			this.DetailData1.Borders = BorderSide.Left;
			this.DetailData1.BorderWidth = 2f;
			this.DetailData1.Font = new Font("Arial", 8.25f);
			this.DetailData1.ForeColor = Color.Black;
			this.DetailData1.Name = "DetailData1";
			this.DetailData1.Padding = new PaddingInfo(15, 15, 0, 0, 254f);
			this.DetailData1.TextAlignment = TextAlignment.MiddleLeft;
			this.DetailData3_Odd.BackColor = Color.FromArgb(231, 231, 231);
			this.DetailData3_Odd.BorderColor = Color.Transparent;
			this.DetailData3_Odd.Borders = BorderSide.None;
			this.DetailData3_Odd.BorderWidth = 1f;
			this.DetailData3_Odd.Font = new Font("Arial", 8.25f);
			this.DetailData3_Odd.ForeColor = Color.Black;
			this.DetailData3_Odd.Name = "DetailData3_Odd";
			this.DetailData3_Odd.Padding = new PaddingInfo(15, 15, 0, 0, 254f);
			this.DetailData3_Odd.TextAlignment = TextAlignment.MiddleLeft;
			this.GrandTotalCaption1.Borders = BorderSide.None;
			this.GrandTotalCaption1.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.GrandTotalCaption1.ForeColor = Color.FromArgb(147, 147, 147);
			this.GrandTotalCaption1.Name = "GrandTotalCaption1";
			this.GrandTotalCaption1.Padding = new PaddingInfo(15, 5, 0, 0, 254f);
			this.GrandTotalCaption1.TextAlignment = TextAlignment.MiddleLeft;
			this.GrandTotalData1.Borders = BorderSide.None;
			this.GrandTotalData1.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.GrandTotalData1.ForeColor = Color.FromArgb(75, 75, 75);
			this.GrandTotalData1.Name = "GrandTotalData1";
			this.GrandTotalData1.Padding = new PaddingInfo(5, 15, 0, 0, 254f);
			this.GrandTotalData1.TextAlignment = TextAlignment.MiddleLeft;
			this.GrandTotalBackground1.BackColor = Color.White;
			this.GrandTotalBackground1.BorderColor = Color.FromArgb(75, 75, 75);
			this.GrandTotalBackground1.Borders = BorderSide.Bottom;
			this.GrandTotalBackground1.BorderWidth = 2f;
			this.GrandTotalBackground1.Name = "GrandTotalBackground1";
			this.PageInfo.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.PageInfo.ForeColor = Color.FromArgb(75, 75, 75);
			this.PageInfo.Name = "PageInfo";
			this.PageInfo.Padding = new PaddingInfo(5, 5, 0, 0, 254f);
			this.TopMargin.Controls.AddRange(new XRControl[]
			{
				this.xrLabelDescription,
				this.xrLabelKeyName
			});
			this.TopMargin.Dpi = 254f;
			this.TopMargin.Name = "TopMargin";
			this.BottomMargin.Dpi = 254f;
			this.BottomMargin.Name = "BottomMargin";
			this.ReportHeader.Dpi = 254f;
			this.ReportHeader.Name = "ReportHeader";
			this.xrLabelKeyName.Dpi = 254f;
			this.xrLabelKeyName.Multiline = true;
			this.xrLabelKeyName.Name = "xrLabelKeyName";
			this.xrLabelKeyName.Padding = new PaddingInfo(5, 5, 0, 0, 254f);
			this.xrLabelKeyName.StylePriority.UseTextAlignment = false;
			this.xrLabelKeyName.TextAlignment = TextAlignment.MiddleCenter;
			this.xrLabelKeyName.BeforePrint += this.xrLabelKeyName_BeforePrint;
			this.xrLabelDescription.Dpi = 254f;
			this.xrLabelDescription.Multiline = true;
			this.xrLabelDescription.Name = "xrLabelDescription";
			this.xrLabelDescription.Padding = new PaddingInfo(5, 5, 0, 0, 254f);
			this.xrLabelDescription.StylePriority.UseTextAlignment = false;
			this.xrLabelDescription.TextAlignment = TextAlignment.MiddleCenter;
			this.xrLabelDescription.BeforePrint += this.xrLabelDescription_BeforePrint;
			this.GroupHeader1.Controls.AddRange(new XRControl[]
			{
				this.table1
			});
			this.GroupHeader1.Dpi = 254f;
			this.GroupHeader1.GroupUnion = GroupUnion.WithFirstDetail;
			this.GroupHeader1.Name = "GroupHeader1";
			this.table1.Dpi = 254f;
			this.table1.Name = "table1";
			this.table1.Rows.AddRange(new XRTableRow[]
			{
				this.tableRow1
			});
			this.tableRow1.Cells.AddRange(new XRTableCell[]
			{
				this.tableCell2,
				this.tableCell1,
				this.tableCell3
			});
			this.tableRow1.Dpi = 254f;
			this.tableRow1.Name = "tableRow1";
			this.tableCell2.Borders = BorderSide.None;
			this.tableCell2.Dpi = 254f;
			this.tableCell2.Name = "tableCell2";
			this.tableCell2.StyleName = "DetailCaption1";
			this.tableCell2.StylePriority.UseBorders = false;
			this.tableCell1.Borders = BorderSide.Left;
			this.tableCell1.Dpi = 254f;
			this.tableCell1.Name = "tableCell1";
			this.tableCell1.StyleName = "DetailCaption1";
			this.tableCell1.StylePriority.UseBorders = false;
			this.tableCell3.Dpi = 254f;
			this.tableCell3.Name = "tableCell3";
			this.tableCell3.StyleName = "DetailCaption1";
			this.tableCell3.StylePriority.UseTextAlignment = false;
			this.tableCell3.TextAlignment = TextAlignment.MiddleRight;
			this.Detail.Controls.AddRange(new XRControl[]
			{
				this.table2
			});
			this.Detail.Dpi = 254f;
			this.Detail.HierarchyPrintOptions.Indent = 50.8f;
			this.Detail.Name = "Detail";
			this.table2.Dpi = 254f;
			this.table2.Name = "table2";
			this.table2.OddStyleName = "DetailData3_Odd";
			this.table2.Rows.AddRange(new XRTableRow[]
			{
				this.tableRow2
			});
			this.tableRow2.Cells.AddRange(new XRTableCell[]
			{
				this.tableCell5,
				this.tableCell4,
				this.tableCell6
			});
			this.tableRow2.Dpi = 254f;
			this.tableRow2.Name = "tableRow2";
			this.tableCell5.Borders = BorderSide.None;
			this.tableCell5.Dpi = 254f;
			this.tableCell5.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "[UrlDomain]")
			});
			this.tableCell5.Name = "tableCell5";
			this.tableCell5.StyleName = "DetailData1";
			this.tableCell5.StylePriority.UseBorders = false;
			this.tableCell4.Borders = BorderSide.Left;
			this.tableCell4.Dpi = 254f;
			this.tableCell4.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "[Hint]")
			});
			this.tableCell4.Name = "tableCell4";
			this.tableCell4.StyleName = "DetailData1";
			this.tableCell4.StylePriority.UseBorders = false;
			this.tableCell6.Dpi = 254f;
			this.tableCell6.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "[Duration]")
			});
			this.tableCell6.Name = "tableCell6";
			this.tableCell6.StyleName = "DetailData1";
			this.tableCell6.StylePriority.UseTextAlignment = false;
			this.tableCell6.TextAlignment = TextAlignment.MiddleRight;
			this.ReportFooter.Controls.AddRange(new XRControl[]
			{
				this.panel1
			});
			this.ReportFooter.Dpi = 254f;
			this.ReportFooter.Name = "ReportFooter";
			this.panel1.Controls.AddRange(new XRControl[]
			{
				this.label2,
				this.label3
			});
			this.panel1.Dpi = 254f;
			this.panel1.Name = "panel1";
			this.panel1.StyleName = "GrandTotalBackground1";
			this.label2.Dpi = 254f;
			this.label2.Name = "label2";
			this.label2.StyleName = "GrandTotalCaption1";
			this.label3.CanGrow = false;
			this.label3.Dpi = 254f;
			this.label3.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "sumSum([Duration])")
			});
			this.label3.Name = "label3";
			this.label3.StyleName = "GrandTotalData1";
			this.label3.StylePriority.UseTextAlignment = false;
			xrSummary.Running = SummaryRunning.Report;
			this.label3.Summary = xrSummary;
			this.label3.TextAlignment = TextAlignment.MiddleRight;
			this.label3.WordWrap = false;
			this.GroupHeader2.Controls.AddRange(new XRControl[]
			{
				this.printableComponentChart
			});
			this.GroupHeader2.Dpi = 254f;
			this.GroupHeader2.Level = 1;
			this.GroupHeader2.Name = "GroupHeader2";
			this.printableComponentChart.Dpi = 254f;
			this.printableComponentChart.Name = "printableComponentChart";
			this.printableComponentChart.WindowControlOptions.PrintMode = WinControlPrintMode.AsBricks;
			base.Bands.AddRange(new Band[]
			{
				this.TopMargin,
				this.BottomMargin,
				this.ReportHeader,
				this.GroupHeader1,
				this.Detail,
				this.ReportFooter,
				this.GroupHeader2
			});
			base.ComponentStorage.AddRange(new IComponent[]
			{
				this.objectDataSource1
			});
			base.DataSource = this.objectDataSource1;
			this.Dpi = 254f;
			base.LocalizationItems.AddRange(new LocalizationItem[]
			{
				new LocalizationItem(this.BottomMargin, "Default", "HeightF", 254f),
				new LocalizationItem(this.Detail, "Default", "HeightF", 63.42f),
				new LocalizationItem(this, "Default", "Font", new Font("Arial", 9.75f)),
				new LocalizationItem(this, "Default", "Margins", new Margins(254, 254, 254, 254)),
				new LocalizationItem(this.GroupHeader1, "Default", "HeightF", 71.12f),
				new LocalizationItem(this.GroupHeader2, "Default", "HeightF", 254f),
				new LocalizationItem(this.label2, "Default", "LocationFloat", new PointFloat(1066.099f, 29.21f)),
				new LocalizationItem(this.label2, "pl", "LocationFloat", new PointFloat(1015.299f, 25.00002f)),
				new LocalizationItem(this.label2, "Default", "SizeF", new SizeF(84.67433f, 37.80647f)),
				new LocalizationItem(this.label2, "pl", "SizeF", new SizeF(116.4244f, 37.80647f)),
				new LocalizationItem(this.label2, "Default", "Text", "SUM"),
				new LocalizationItem(this.label2, "pl", "Text", "Suma"),
				new LocalizationItem(this.label3, "Default", "LocationFloat", new PointFloat(1150.773f, 29.21f)),
				new LocalizationItem(this.label3, "pl", "LocationFloat", new PointFloat(1150.773f, 25.00002f)),
				new LocalizationItem(this.label3, "Default", "SizeF", new SizeF(500.2268f, 37.80647f)),
				new LocalizationItem(this.panel1, "Default", "LocationFloat", new PointFloat(0f, 0f)),
				new LocalizationItem(this.panel1, "Default", "SizeF", new SizeF(1651f, 125.4365f)),
				new LocalizationItem(this.printableComponentChart, "Default", "LocationFloat", new PointFloat(0.999939f, 0f)),
				new LocalizationItem(this.printableComponentChart, "Default", "SizeF", new SizeF(1650f, 254f)),
				new LocalizationItem(this.ReportFooter, "Default", "HeightF", 125.4365f),
				new LocalizationItem(this.ReportHeader, "Default", "HeightF", 0f),
				new LocalizationItem(this.ReportHeader, "Default", "Visible", false),
				new LocalizationItem(this.table1, "Default", "LocationFloat", new PointFloat(0f, 0f)),
				new LocalizationItem(this.table1, "Default", "SizeF", new SizeF(1651f, 71.12f)),
				new LocalizationItem(this.table2, "Default", "LocationFloat", new PointFloat(0f, 0f)),
				new LocalizationItem(this.table2, "Default", "SizeF", new SizeF(1651f, 63.42f)),
				new LocalizationItem(this.tableCell1, "Default", "Text", "Duration"),
				new LocalizationItem(this.tableCell1, "pl", "Text", "Czas"),
				new LocalizationItem(this.tableCell1, "Default", "Weight", 0.401762566661777),
				new LocalizationItem(this.tableCell2, "Default", "Text", "Url Domain"),
				new LocalizationItem(this.tableCell2, "pl", "Text", "Domena"),
				new LocalizationItem(this.tableCell2, "Default", "Weight", 0.43567012830765445),
				new LocalizationItem(this.tableCell3, "Default", "Text", "Duration (sec)"),
				new LocalizationItem(this.tableCell3, "pl", "Text", "Czas (sek)"),
				new LocalizationItem(this.tableCell3, "Default", "Weight", 0.16256730503056857),
				new LocalizationItem(this.tableCell4, "Default", "Weight", 0.21005908912922092),
				new LocalizationItem(this.tableCell5, "Default", "Weight", 0.43567012830765445),
				new LocalizationItem(this.tableCell6, "Default", "Weight", 0.3542708195317232),
				new LocalizationItem(this.tableRow1, "Default", "Weight", 1.0),
				new LocalizationItem(this.tableRow2, "Default", "Weight", 11.683999633789062),
				new LocalizationItem(this.TopMargin, "Default", "HeightF", 254f),
				new LocalizationItem(this.xrLabelDescription, "Default", "LocationFloat", new PointFloat(0f, 195.58f)),
				new LocalizationItem(this.xrLabelDescription, "Default", "SizeF", new SizeF(1651f, 58.42001f)),
				new LocalizationItem(this.xrLabelDescription, "Default", "Text", "Description"),
				new LocalizationItem(this.xrLabelKeyName, "Default", "LocationFloat", new PointFloat(0f, 137.16f)),
				new LocalizationItem(this.xrLabelKeyName, "Default", "SizeF", new SizeF(1651f, 58.42001f)),
				new LocalizationItem(this.xrLabelKeyName, "Default", "Text", "KeyName")
			});
			base.PageHeight = 2794;
			base.PageWidth = 2159;
			base.ReportUnit = ReportUnit.TenthsOfAMillimeter;
			base.SnapGridSize = 25f;
			base.StyleSheet.AddRange(new XRControlStyle[]
			{
				this.Title,
				this.DetailCaption1,
				this.DetailData1,
				this.DetailData3_Odd,
				this.GrandTotalCaption1,
				this.GrandTotalData1,
				this.GrandTotalBackground1,
				this.PageInfo
			});
			base.Version = "20.1";
			((ISupportInitialize)this.objectDataSource1).EndInit();
			((ISupportInitialize)this.table1).EndInit();
			((ISupportInitialize)this.table2).EndInit();
			((ISupportInitialize)this).EndInit();
		}

		// Token: 0x040000D7 RID: 215
		private string _description;

		// Token: 0x040000D8 RID: 216
		private string _keyName;

		// Token: 0x040000D9 RID: 217
		private IContainer components;

		// Token: 0x040000DA RID: 218
		private ObjectDataSource objectDataSource1;

		// Token: 0x040000DB RID: 219
		private XRControlStyle Title;

		// Token: 0x040000DC RID: 220
		private XRControlStyle DetailCaption1;

		// Token: 0x040000DD RID: 221
		private XRControlStyle DetailData1;

		// Token: 0x040000DE RID: 222
		private XRControlStyle DetailData3_Odd;

		// Token: 0x040000DF RID: 223
		private XRControlStyle GrandTotalCaption1;

		// Token: 0x040000E0 RID: 224
		private XRControlStyle GrandTotalData1;

		// Token: 0x040000E1 RID: 225
		private XRControlStyle GrandTotalBackground1;

		// Token: 0x040000E2 RID: 226
		private XRControlStyle PageInfo;

		// Token: 0x040000E3 RID: 227
		private TopMarginBand TopMargin;

		// Token: 0x040000E4 RID: 228
		private BottomMarginBand BottomMargin;

		// Token: 0x040000E5 RID: 229
		private ReportHeaderBand ReportHeader;

		// Token: 0x040000E6 RID: 230
		private GroupHeaderBand GroupHeader1;

		// Token: 0x040000E7 RID: 231
		private XRTable table1;

		// Token: 0x040000E8 RID: 232
		private XRTableRow tableRow1;

		// Token: 0x040000E9 RID: 233
		private XRTableCell tableCell1;

		// Token: 0x040000EA RID: 234
		private XRTableCell tableCell2;

		// Token: 0x040000EB RID: 235
		private XRTableCell tableCell3;

		// Token: 0x040000EC RID: 236
		private DetailBand Detail;

		// Token: 0x040000ED RID: 237
		private XRTable table2;

		// Token: 0x040000EE RID: 238
		private XRTableRow tableRow2;

		// Token: 0x040000EF RID: 239
		private XRTableCell tableCell4;

		// Token: 0x040000F0 RID: 240
		private XRTableCell tableCell5;

		// Token: 0x040000F1 RID: 241
		private XRTableCell tableCell6;

		// Token: 0x040000F2 RID: 242
		private ReportFooterBand ReportFooter;

		// Token: 0x040000F3 RID: 243
		private XRPanel panel1;

		// Token: 0x040000F4 RID: 244
		private XRLabel label2;

		// Token: 0x040000F5 RID: 245
		private XRLabel label3;

		// Token: 0x040000F6 RID: 246
		private XRLabel xrLabelDescription;

		// Token: 0x040000F7 RID: 247
		private XRLabel xrLabelKeyName;

		// Token: 0x040000F8 RID: 248
		private GroupHeaderBand GroupHeader2;

		// Token: 0x040000F9 RID: 249
		private PrintableComponentContainer printableComponentChart;
	}
}
