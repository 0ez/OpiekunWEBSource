﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using DevExpress.DataAccess.ObjectBinding;
using DevExpress.Utils;
using DevExpress.XtraPrinting;
using DevExpress.XtraReports.Localization;
using DevExpress.XtraReports.UI;
using Owpb;

namespace OpiekunWEB.Console.Reports
{
	// Token: 0x0200001C RID: 28
	public class AppHistoryStatsReport : XtraReport
	{
		// Token: 0x0600016C RID: 364 RVA: 0x00007B16 File Offset: 0x00005D16
		public AppHistoryStatsReport()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600016D RID: 365 RVA: 0x00007B24 File Offset: 0x00005D24
		public AppHistoryStatsReport(string keyName, string description, object chartControl)
		{
			this.InitializeComponent();
			this._keyName = keyName;
			this._description = description;
			this.printableComponentChart.PrintableComponent = chartControl;
		}

		// Token: 0x0600016E RID: 366 RVA: 0x00007B4C File Offset: 0x00005D4C
		private void xrLabelDescription_BeforePrint(object sender, PrintEventArgs e)
		{
			(sender as XRLabel).Text = this._description;
		}

		// Token: 0x0600016F RID: 367 RVA: 0x00007B5F File Offset: 0x00005D5F
		private void xrLabelKeyName_BeforePrint(object sender, PrintEventArgs e)
		{
			(sender as XRLabel).Text = this._keyName;
		}

		// Token: 0x06000170 RID: 368 RVA: 0x00007B72 File Offset: 0x00005D72
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000171 RID: 369 RVA: 0x00007B94 File Offset: 0x00005D94
		private void InitializeComponent()
		{
			this.components = new Container();
			XRSummary xrSummary = new XRSummary();
			this.objectDataSource1 = new ObjectDataSource(this.components);
			this.Title = new XRControlStyle();
			this.DetailCaption1 = new XRControlStyle();
			this.DetailData1 = new XRControlStyle();
			this.DetailData3_Odd = new XRControlStyle();
			this.GrandTotalCaption1 = new XRControlStyle();
			this.GrandTotalData1 = new XRControlStyle();
			this.GrandTotalBackground1 = new XRControlStyle();
			this.PageInfo = new XRControlStyle();
			this.TopMargin = new TopMarginBand();
			this.BottomMargin = new BottomMarginBand();
			this.ReportHeader = new ReportHeaderBand();
			this.xrLabelKeyName = new XRLabel();
			this.xrLabelDescription = new XRLabel();
			this.GroupHeader1 = new GroupHeaderBand();
			this.table1 = new XRTable();
			this.tableRow1 = new XRTableRow();
			this.tableCell2 = new XRTableCell();
			this.tableCell1 = new XRTableCell();
			this.tableCell3 = new XRTableCell();
			this.Detail = new DetailBand();
			this.table2 = new XRTable();
			this.tableRow2 = new XRTableRow();
			this.tableCell5 = new XRTableCell();
			this.tableCell4 = new XRTableCell();
			this.tableCell6 = new XRTableCell();
			this.ReportFooter = new ReportFooterBand();
			this.panel1 = new XRPanel();
			this.label2 = new XRLabel();
			this.label3 = new XRLabel();
			this.GroupHeader2 = new GroupHeaderBand();
			this.printableComponentChart = new PrintableComponentContainer();
			((ISupportInitialize)this.objectDataSource1).BeginInit();
			((ISupportInitialize)this.table1).BeginInit();
			((ISupportInitialize)this.table2).BeginInit();
			((ISupportInitialize)this).BeginInit();
			this.objectDataSource1.DataSource = typeof(AppHistoryStatsItem);
			this.objectDataSource1.Name = "objectDataSource1";
			this.Title.BackColor = Color.Transparent;
			this.Title.BorderColor = Color.Black;
			this.Title.Borders = BorderSide.None;
			this.Title.BorderWidth = 1f;
			this.Title.Font = new Font("Arial", 14.25f);
			this.Title.ForeColor = Color.FromArgb(75, 75, 75);
			this.Title.Name = "Title";
			this.DetailCaption1.BackColor = Color.FromArgb(75, 75, 75);
			this.DetailCaption1.BorderColor = Color.White;
			this.DetailCaption1.Borders = BorderSide.Left;
			this.DetailCaption1.BorderWidth = 2f;
			this.DetailCaption1.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.DetailCaption1.ForeColor = Color.White;
			this.DetailCaption1.Name = "DetailCaption1";
			this.DetailCaption1.Padding = new PaddingInfo(15, 15, 0, 0, 254f);
			this.DetailCaption1.TextAlignment = TextAlignment.MiddleLeft;
			this.DetailData1.BorderColor = Color.Transparent;
			this.DetailData1.Borders = BorderSide.Left;
			this.DetailData1.BorderWidth = 2f;
			this.DetailData1.Font = new Font("Arial", 8.25f);
			this.DetailData1.ForeColor = Color.Black;
			this.DetailData1.Name = "DetailData1";
			this.DetailData1.Padding = new PaddingInfo(15, 15, 0, 0, 254f);
			this.DetailData1.TextAlignment = TextAlignment.MiddleLeft;
			this.DetailData3_Odd.BackColor = Color.FromArgb(231, 231, 231);
			this.DetailData3_Odd.BorderColor = Color.Transparent;
			this.DetailData3_Odd.Borders = BorderSide.None;
			this.DetailData3_Odd.BorderWidth = 1f;
			this.DetailData3_Odd.Font = new Font("Arial", 8.25f);
			this.DetailData3_Odd.ForeColor = Color.Black;
			this.DetailData3_Odd.Name = "DetailData3_Odd";
			this.DetailData3_Odd.Padding = new PaddingInfo(15, 15, 0, 0, 254f);
			this.DetailData3_Odd.TextAlignment = TextAlignment.MiddleLeft;
			this.GrandTotalCaption1.Borders = BorderSide.None;
			this.GrandTotalCaption1.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.GrandTotalCaption1.ForeColor = Color.FromArgb(147, 147, 147);
			this.GrandTotalCaption1.Name = "GrandTotalCaption1";
			this.GrandTotalCaption1.Padding = new PaddingInfo(15, 5, 0, 0, 254f);
			this.GrandTotalCaption1.TextAlignment = TextAlignment.MiddleLeft;
			this.GrandTotalData1.Borders = BorderSide.None;
			this.GrandTotalData1.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.GrandTotalData1.ForeColor = Color.FromArgb(75, 75, 75);
			this.GrandTotalData1.Name = "GrandTotalData1";
			this.GrandTotalData1.Padding = new PaddingInfo(5, 15, 0, 0, 254f);
			this.GrandTotalData1.TextAlignment = TextAlignment.MiddleLeft;
			this.GrandTotalBackground1.BackColor = Color.White;
			this.GrandTotalBackground1.BorderColor = Color.FromArgb(75, 75, 75);
			this.GrandTotalBackground1.Borders = BorderSide.Bottom;
			this.GrandTotalBackground1.BorderWidth = 2f;
			this.GrandTotalBackground1.Name = "GrandTotalBackground1";
			this.PageInfo.Font = new Font("Arial", 8.25f, FontStyle.Bold);
			this.PageInfo.ForeColor = Color.FromArgb(75, 75, 75);
			this.PageInfo.Name = "PageInfo";
			this.PageInfo.Padding = new PaddingInfo(5, 5, 0, 0, 254f);
			this.TopMargin.Controls.AddRange(new XRControl[]
			{
				this.xrLabelDescription,
				this.xrLabelKeyName
			});
			this.TopMargin.Dpi = 254f;
			this.TopMargin.Name = "TopMargin";
			this.BottomMargin.Dpi = 254f;
			this.BottomMargin.Name = "BottomMargin";
			this.ReportHeader.Dpi = 254f;
			this.ReportHeader.Name = "ReportHeader";
			this.xrLabelKeyName.Dpi = 254f;
			this.xrLabelKeyName.Multiline = true;
			this.xrLabelKeyName.Name = "xrLabelKeyName";
			this.xrLabelKeyName.Padding = new PaddingInfo(5, 5, 0, 0, 254f);
			this.xrLabelKeyName.StylePriority.UseTextAlignment = false;
			this.xrLabelKeyName.TextAlignment = TextAlignment.MiddleCenter;
			this.xrLabelKeyName.BeforePrint += this.xrLabelKeyName_BeforePrint;
			this.xrLabelDescription.Dpi = 254f;
			this.xrLabelDescription.Multiline = true;
			this.xrLabelDescription.Name = "xrLabelDescription";
			this.xrLabelDescription.Padding = new PaddingInfo(5, 5, 0, 0, 254f);
			this.xrLabelDescription.StylePriority.UseTextAlignment = false;
			this.xrLabelDescription.TextAlignment = TextAlignment.MiddleCenter;
			this.xrLabelDescription.BeforePrint += this.xrLabelDescription_BeforePrint;
			this.GroupHeader1.Controls.AddRange(new XRControl[]
			{
				this.table1
			});
			this.GroupHeader1.Dpi = 254f;
			this.GroupHeader1.GroupUnion = GroupUnion.WithFirstDetail;
			this.GroupHeader1.Name = "GroupHeader1";
			this.table1.Dpi = 254f;
			this.table1.Name = "table1";
			this.table1.Rows.AddRange(new XRTableRow[]
			{
				this.tableRow1
			});
			this.tableRow1.Cells.AddRange(new XRTableCell[]
			{
				this.tableCell2,
				this.tableCell1,
				this.tableCell3
			});
			this.tableRow1.Dpi = 254f;
			this.tableRow1.Name = "tableRow1";
			this.tableCell2.Dpi = 254f;
			this.tableCell2.Name = "tableCell2";
			this.tableCell2.StyleName = "DetailCaption1";
			this.tableCell1.Borders = (BorderSide.Left | BorderSide.Right);
			this.tableCell1.Dpi = 254f;
			this.tableCell1.Name = "tableCell1";
			this.tableCell1.StyleName = "DetailCaption1";
			this.tableCell1.StylePriority.UseBorders = false;
			this.tableCell3.Dpi = 254f;
			this.tableCell3.Name = "tableCell3";
			this.tableCell3.StyleName = "DetailCaption1";
			this.tableCell3.StylePriority.UseTextAlignment = false;
			this.tableCell3.TextAlignment = TextAlignment.MiddleRight;
			this.Detail.Controls.AddRange(new XRControl[]
			{
				this.table2
			});
			this.Detail.Dpi = 254f;
			this.Detail.HierarchyPrintOptions.Indent = 50.8f;
			this.Detail.Name = "Detail";
			this.table2.Dpi = 254f;
			this.table2.Name = "table2";
			this.table2.OddStyleName = "DetailData3_Odd";
			this.table2.Rows.AddRange(new XRTableRow[]
			{
				this.tableRow2
			});
			this.tableRow2.Cells.AddRange(new XRTableCell[]
			{
				this.tableCell5,
				this.tableCell4,
				this.tableCell6
			});
			this.tableRow2.Dpi = 254f;
			this.tableRow2.Name = "tableRow2";
			this.tableCell5.Dpi = 254f;
			this.tableCell5.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "[ExeDescription]")
			});
			this.tableCell5.Name = "tableCell5";
			this.tableCell5.StyleName = "DetailData1";
			this.tableCell4.Borders = (BorderSide.Left | BorderSide.Right);
			this.tableCell4.Dpi = 254f;
			this.tableCell4.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "[Hint]")
			});
			this.tableCell4.Name = "tableCell4";
			this.tableCell4.StyleName = "DetailData1";
			this.tableCell4.StylePriority.UseBorders = false;
			this.tableCell6.Dpi = 254f;
			this.tableCell6.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "[Duration]")
			});
			this.tableCell6.Name = "tableCell6";
			this.tableCell6.StyleName = "DetailData1";
			this.tableCell6.StylePriority.UseTextAlignment = false;
			this.tableCell6.TextAlignment = TextAlignment.MiddleRight;
			this.ReportFooter.Controls.AddRange(new XRControl[]
			{
				this.panel1
			});
			this.ReportFooter.Dpi = 254f;
			this.ReportFooter.Name = "ReportFooter";
			this.panel1.Controls.AddRange(new XRControl[]
			{
				this.label2,
				this.label3
			});
			this.panel1.Dpi = 254f;
			this.panel1.Name = "panel1";
			this.panel1.StyleName = "GrandTotalBackground1";
			this.label2.Dpi = 254f;
			this.label2.Name = "label2";
			this.label2.StyleName = "GrandTotalCaption1";
			this.label3.CanGrow = false;
			this.label3.Dpi = 254f;
			this.label3.ExpressionBindings.AddRange(new ExpressionBinding[]
			{
				new ExpressionBinding("BeforePrint", "Text", "sumSum([Duration])")
			});
			this.label3.Name = "label3";
			this.label3.StyleName = "GrandTotalData1";
			this.label3.StylePriority.UseTextAlignment = false;
			xrSummary.Running = SummaryRunning.Report;
			this.label3.Summary = xrSummary;
			this.label3.TextAlignment = TextAlignment.MiddleRight;
			this.label3.WordWrap = false;
			this.GroupHeader2.Controls.AddRange(new XRControl[]
			{
				this.printableComponentChart
			});
			this.GroupHeader2.Dpi = 254f;
			this.GroupHeader2.Level = 1;
			this.GroupHeader2.Name = "GroupHeader2";
			this.printableComponentChart.Dpi = 254f;
			this.printableComponentChart.Name = "printableComponentChart";
			this.printableComponentChart.WindowControlOptions.PrintMode = WinControlPrintMode.AsBricks;
			base.Bands.AddRange(new Band[]
			{
				this.TopMargin,
				this.BottomMargin,
				this.ReportHeader,
				this.GroupHeader1,
				this.Detail,
				this.ReportFooter,
				this.GroupHeader2
			});
			base.ComponentStorage.AddRange(new IComponent[]
			{
				this.objectDataSource1
			});
			base.DataSource = this.objectDataSource1;
			this.Dpi = 254f;
			base.LocalizationItems.AddRange(new LocalizationItem[]
			{
				new LocalizationItem(this, "Default", "Font", new Font("Arial", 9.75f)),
				new LocalizationItem(this, "Default", "Margins", new Margins(254, 254, 254, 645)),
				new LocalizationItem(this.BottomMargin, "Default", "HeightF", 645.16f),
				new LocalizationItem(this.Detail, "Default", "HeightF", 63.42f),
				new LocalizationItem(this.GroupHeader1, "Default", "HeightF", 71.12f),
				new LocalizationItem(this.GroupHeader2, "Default", "HeightF", 254f),
				new LocalizationItem(this.label2, "Default", "LocationFloat", new PointFloat(1141.51f, 29.21f)),
				new LocalizationItem(this.label2, "pl", "LocationFloat", new PointFloat(1101.293f, 29.20997f)),
				new LocalizationItem(this.label2, "Default", "SizeF", new SizeF(84.67433f, 37.80647f)),
				new LocalizationItem(this.label2, "pl", "SizeF", new SizeF(139.7078f, 37.80647f)),
				new LocalizationItem(this.label2, "Default", "Text", "SUM"),
				new LocalizationItem(this.label2, "pl", "Text", "Suma"),
				new LocalizationItem(this.label3, "Default", "LocationFloat", new PointFloat(1226.185f, 29.21f)),
				new LocalizationItem(this.label3, "pl", "LocationFloat", new PointFloat(1255.818f, 29.20997f)),
				new LocalizationItem(this.label3, "Default", "SizeF", new SizeF(424.8153f, 37.80647f)),
				new LocalizationItem(this.label3, "pl", "SizeF", new SizeF(395.1821f, 37.80647f)),
				new LocalizationItem(this.panel1, "Default", "LocationFloat", new PointFloat(0f, 0f)),
				new LocalizationItem(this.panel1, "Default", "SizeF", new SizeF(1651f, 125.4365f)),
				new LocalizationItem(this.printableComponentChart, "Default", "LocationFloat", new PointFloat(0f, 0f)),
				new LocalizationItem(this.printableComponentChart, "Default", "SizeF", new SizeF(1651f, 203.2f)),
				new LocalizationItem(this.ReportFooter, "Default", "HeightF", 125.4365f),
				new LocalizationItem(this.ReportHeader, "Default", "HeightF", 0f),
				new LocalizationItem(this.ReportHeader, "Default", "Visible", false),
				new LocalizationItem(this.table1, "Default", "LocationFloat", new PointFloat(0f, 0f)),
				new LocalizationItem(this.table1, "Default", "SizeF", new SizeF(1651f, 71.12f)),
				new LocalizationItem(this.table2, "Default", "LocationFloat", new PointFloat(0f, 0f)),
				new LocalizationItem(this.table2, "Default", "SizeF", new SizeF(1651f, 63.42f)),
				new LocalizationItem(this.tableCell1, "Default", "Text", "Duration"),
				new LocalizationItem(this.tableCell1, "pl", "Text", "Czas pracy"),
				new LocalizationItem(this.tableCell1, "Default", "Weight", 0.3227197102963166),
				new LocalizationItem(this.tableCell2, "Default", "Text", "Description"),
				new LocalizationItem(this.tableCell2, "pl", "Text", "Nazwa"),
				new LocalizationItem(this.tableCell2, "Default", "Weight", 0.5148395097017432),
				new LocalizationItem(this.tableCell3, "Default", "Text", "Duration (sec)"),
				new LocalizationItem(this.tableCell3, "pl", "Text", "Czas pracy (sec)"),
				new LocalizationItem(this.tableCell3, "Default", "Weight", 0.16244078000194015),
				new LocalizationItem(this.tableCell4, "Default", "Weight", 0.17656590862327728),
				new LocalizationItem(this.tableCell5, "Default", "Weight", 0.5148395095832546),
				new LocalizationItem(this.tableCell6, "Default", "Weight", 0.3085945633091687),
				new LocalizationItem(this.tableRow1, "Default", "Weight", 1.0),
				new LocalizationItem(this.tableRow2, "Default", "Weight", 11.683999633789062),
				new LocalizationItem(this.TopMargin, "Default", "HeightF", 254f),
				new LocalizationItem(this.xrLabelDescription, "Default", "LocationFloat", new PointFloat(0.0005167643f, 195.58f)),
				new LocalizationItem(this.xrLabelDescription, "Default", "SizeF", new SizeF(1651f, 58.42f)),
				new LocalizationItem(this.xrLabelDescription, "Default", "Text", "Descritpion"),
				new LocalizationItem(this.xrLabelDescription, "Default", "Visible", true),
				new LocalizationItem(this.xrLabelKeyName, "Default", "LocationFloat", new PointFloat(0.0005167643f, 137.16f)),
				new LocalizationItem(this.xrLabelKeyName, "Default", "SizeF", new SizeF(1651f, 58.42f)),
				new LocalizationItem(this.xrLabelKeyName, "Default", "Text", "KeyName")
			});
			base.PageHeight = 2794;
			base.PageWidth = 2159;
			base.ReportUnit = ReportUnit.TenthsOfAMillimeter;
			base.SnapGridSize = 25f;
			base.StyleSheet.AddRange(new XRControlStyle[]
			{
				this.Title,
				this.DetailCaption1,
				this.DetailData1,
				this.DetailData3_Odd,
				this.GrandTotalCaption1,
				this.GrandTotalData1,
				this.GrandTotalBackground1,
				this.PageInfo
			});
			base.Version = "20.1";
			((ISupportInitialize)this.objectDataSource1).EndInit();
			((ISupportInitialize)this.table1).EndInit();
			((ISupportInitialize)this.table2).EndInit();
			((ISupportInitialize)this).EndInit();
		}

		// Token: 0x040000B4 RID: 180
		private string _description;

		// Token: 0x040000B5 RID: 181
		private string _keyName;

		// Token: 0x040000B6 RID: 182
		private IContainer components;

		// Token: 0x040000B7 RID: 183
		private ObjectDataSource objectDataSource1;

		// Token: 0x040000B8 RID: 184
		private XRControlStyle Title;

		// Token: 0x040000B9 RID: 185
		private XRControlStyle DetailCaption1;

		// Token: 0x040000BA RID: 186
		private XRControlStyle DetailData1;

		// Token: 0x040000BB RID: 187
		private XRControlStyle DetailData3_Odd;

		// Token: 0x040000BC RID: 188
		private XRControlStyle GrandTotalCaption1;

		// Token: 0x040000BD RID: 189
		private XRControlStyle GrandTotalData1;

		// Token: 0x040000BE RID: 190
		private XRControlStyle GrandTotalBackground1;

		// Token: 0x040000BF RID: 191
		private XRControlStyle PageInfo;

		// Token: 0x040000C0 RID: 192
		private TopMarginBand TopMargin;

		// Token: 0x040000C1 RID: 193
		private BottomMarginBand BottomMargin;

		// Token: 0x040000C2 RID: 194
		private ReportHeaderBand ReportHeader;

		// Token: 0x040000C3 RID: 195
		private GroupHeaderBand GroupHeader1;

		// Token: 0x040000C4 RID: 196
		private XRTable table1;

		// Token: 0x040000C5 RID: 197
		private XRTableRow tableRow1;

		// Token: 0x040000C6 RID: 198
		private XRTableCell tableCell2;

		// Token: 0x040000C7 RID: 199
		private XRTableCell tableCell1;

		// Token: 0x040000C8 RID: 200
		private XRTableCell tableCell3;

		// Token: 0x040000C9 RID: 201
		private DetailBand Detail;

		// Token: 0x040000CA RID: 202
		private XRTable table2;

		// Token: 0x040000CB RID: 203
		private XRTableRow tableRow2;

		// Token: 0x040000CC RID: 204
		private XRTableCell tableCell4;

		// Token: 0x040000CD RID: 205
		private XRTableCell tableCell5;

		// Token: 0x040000CE RID: 206
		private XRTableCell tableCell6;

		// Token: 0x040000CF RID: 207
		private ReportFooterBand ReportFooter;

		// Token: 0x040000D0 RID: 208
		private XRPanel panel1;

		// Token: 0x040000D1 RID: 209
		private XRLabel label2;

		// Token: 0x040000D2 RID: 210
		private XRLabel label3;

		// Token: 0x040000D3 RID: 211
		private XRLabel xrLabelDescription;

		// Token: 0x040000D4 RID: 212
		private XRLabel xrLabelKeyName;

		// Token: 0x040000D5 RID: 213
		private GroupHeaderBand GroupHeader2;

		// Token: 0x040000D6 RID: 214
		private PrintableComponentContainer printableComponentChart;
	}
}
