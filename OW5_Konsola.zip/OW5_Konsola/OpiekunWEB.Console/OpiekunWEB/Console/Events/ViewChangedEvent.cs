﻿using System;
using System.Windows.Forms;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Events
{
	// Token: 0x02000020 RID: 32
	public class ViewChangedEvent
	{
		// Token: 0x0600035B RID: 859 RVA: 0x0000D473 File Offset: 0x0000B673
		public ViewChangedEvent(IViewInfo currentView)
		{
			this.CurrentView = currentView;
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x0600035C RID: 860 RVA: 0x0000D482 File Offset: 0x0000B682
		public IViewInfo CurrentView { get; }

		// Token: 0x0600035D RID: 861 RVA: 0x0000D48A File Offset: 0x0000B68A
		public bool IsCurrentView(Control view)
		{
			return this.CurrentView.Control == view;
		}
	}
}
