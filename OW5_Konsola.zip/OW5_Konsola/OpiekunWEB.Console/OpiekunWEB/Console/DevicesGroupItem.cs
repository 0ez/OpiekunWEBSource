﻿using System;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x0200000C RID: 12
	public class DevicesGroupItem : DeviceTreeItemBase
	{
		// Token: 0x06000047 RID: 71 RVA: 0x0000324B File Offset: 0x0000144B
		public DevicesGroupItem(DevicesGroup group)
		{
			base.IsGroup = true;
			base.Id = group.Id;
			this.Update(group);
			this._iconConnectedIndex = 9;
			this._iconDisconnectedIndex = 8;
			base.IconIndex = 8;
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003283 File Offset: 0x00001483
		public void Update(DevicesGroup group)
		{
			base.ParentId = (string.IsNullOrEmpty(group.ParentId) ? null : group.ParentId);
			base.Name = group.Name;
		}
	}
}
