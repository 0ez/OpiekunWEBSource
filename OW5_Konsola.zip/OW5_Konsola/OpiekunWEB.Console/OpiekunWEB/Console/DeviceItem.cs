﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x02000014 RID: 20
	public class DeviceItem : DeviceTreeItemBase
	{
		// Token: 0x06000092 RID: 146 RVA: 0x00004300 File Offset: 0x00002500
		public DeviceItem(Device device, AppControlState appAccess, InetControlState inetAccess, int hwAccess, string appDesktopOrCategoryId, string inetStrictCategoryId, bool hideAgentItemIfPossible) : this(device.Id, device.ParentId, device.Name, device.DeviceType, device.Macs, device.Description, null, appAccess, inetAccess, hwAccess, appDesktopOrCategoryId, inetStrictCategoryId, hideAgentItemIfPossible)
		{
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00004344 File Offset: 0x00002544
		public DeviceItem(string id, string parentId, string name, DeviceType deviceType, IList<string> macList, string description, WindowsUserInfo windowsUser, AppControlState appAcces, InetControlState inetAccess, int deviceLockSettings, string appDesktopOrCategoryId, string inetStrictCategoryId, bool hideAgentItemIfPossible)
		{
			this._hideAgentItemIfPossible = hideAgentItemIfPossible;
			this._agentsList = new List<AgentItem>();
			this._iconConnectedIndex = DeviceTreeIconIndexes.GetDeviceConnectedIndex(deviceType);
			this._iconDisconnectedIndex = DeviceTreeIconIndexes.GetDeviceDisconnectedIndex(deviceType);
			base.Id = id;
			base.Name = name;
			base.ParentId = parentId;
			base.DeviceType = deviceType;
			base.Description = description;
			this.MacList = new List<string>();
			if (macList != null)
			{
				this.MacList.AddRange(macList);
			}
			base.IsGroup = false;
			base.WindowsUser = windowsUser;
			base.IconIndex = this._iconDisconnectedIndex;
			base.AppAccess = appAcces;
			base.InetAccess = inetAccess;
			base.AppAccessDesktopOrCategoryId = appDesktopOrCategoryId;
			base.InetStrictCategoryId = inetStrictCategoryId;
			base.DeviceLockSettings = deviceLockSettings;
			base.ConnectionDescription = Resources.AgentConnection_None;
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000094 RID: 148 RVA: 0x00004413 File Offset: 0x00002613
		// (set) Token: 0x06000095 RID: 149 RVA: 0x0000441B File Offset: 0x0000261B
		public bool HideAgentItemIfPossible
		{
			get
			{
				return this._hideAgentItemIfPossible;
			}
			set
			{
				if (value != this._hideAgentItemIfPossible)
				{
					this._hideAgentItemIfPossible = value;
					this.CheckState();
				}
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000096 RID: 150 RVA: 0x00004433 File Offset: 0x00002633
		public List<string> MacList { get; }

		// Token: 0x06000097 RID: 151 RVA: 0x0000443B File Offset: 0x0000263B
		public void AddAgentItem(AgentItem agentItem)
		{
			this._agentsList.Add(agentItem);
			agentItem.PropertyChanged += this.AgentItemOnPropertyChanged;
			this.CheckState();
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00004461 File Offset: 0x00002661
		public void AgentPropertyChanged()
		{
			this.CheckState();
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00004469 File Offset: 0x00002669
		public List<AgentItem> GetAgentItemsList()
		{
			return new List<AgentItem>(this._agentsList);
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00004476 File Offset: 0x00002676
		public List<AgentItem> GetConnectedAgentItemsList()
		{
			return (from x in new List<AgentItem>(this._agentsList)
			where x.IsConnected
			select x).ToList<AgentItem>();
		}

		// Token: 0x0600009B RID: 155 RVA: 0x000044AC File Offset: 0x000026AC
		public override string GetDeviceName()
		{
			return base.Name;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x000044B4 File Offset: 0x000026B4
		public List<DisplayItem> GetDisplaysList()
		{
			List<DisplayItem> result = new List<DisplayItem>();
			foreach (AgentItem agentItem in this._agentsList)
			{
				result.AddRange(agentItem.GetDisplaysList());
			}
			return result;
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00004514 File Offset: 0x00002714
		public AgentItem GetOnlyOneAgentItem()
		{
			if (this._agentsList.Count == 1)
			{
				return this._agentsList[0];
			}
			return null;
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00004532 File Offset: 0x00002732
		public bool IsDeviceAgentItem(AgentItem agentItem)
		{
			return this._agentsList.Contains(agentItem);
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00004540 File Offset: 0x00002740
		public bool IsOnlyOneDeviceAgentItem(AgentItem agentItem)
		{
			return this._agentsList.Contains(agentItem) && this._agentsList.Count == 1;
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00004560 File Offset: 0x00002760
		public void RemoveAgentItem(AgentItem agentItem)
		{
			agentItem.PropertyChanged -= this.AgentItemOnPropertyChanged;
			agentItem.ItemsRemoved();
			this._agentsList.Remove(agentItem);
			this.CheckState();
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x0000458D File Offset: 0x0000278D
		public void Update(Device device)
		{
			base.ParentId = device.ParentId;
			base.Name = device.Name;
			this.MacList.Clear();
			this.MacList.AddRange(device.Macs);
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x000045C3 File Offset: 0x000027C3
		protected override void SetIsConnected(bool value)
		{
			base.SetIsConnected(value);
			if (this._hideAgentItemIfPossible && !this._checkInProgress)
			{
				this.CheckState();
			}
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x000045E2 File Offset: 0x000027E2
		private void AgentItemOnPropertyChanged(object sender, PropertyChangedEventArgs args)
		{
			if (args.PropertyName == "WindowsUser")
			{
				this.CheckState();
			}
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x000045FC File Offset: 0x000027FC
		private void CheckState()
		{
			this._checkInProgress = true;
			try
			{
				IEnumerable<AgentItem> connectedAgents = from x in this._agentsList
				where x.IsConnected
				select x;
				int connectedCount = connectedAgents.Count<AgentItem>();
				string connectionDescription = Resources.AgentConnection_None;
				WindowsUserInfo firstUserInfo = null;
				base.IsConnected = (connectedCount > 0);
				if (base.IsConnected)
				{
					AgentClient agentClient = connectedAgents.ElementAt(0).AgentClient;
					base.AppVersion = ((agentClient != null) ? agentClient.AppVersion : null);
					AgentClient agentClient2 = connectedAgents.ElementAt(0).AgentClient;
					firstUserInfo = ((agentClient2 != null) ? agentClient2.WindowsUser : null);
					connectionDescription = connectedAgents.ElementAt(0).ConnectionDescription;
					base.IsProxyConnection = (connectedAgents.Count((AgentItem x) => x.IsProxyConnection) > 0);
					base.ConnectionDescription = (base.IsProxyConnection ? Resources.AgentConnection_Indirect : Resources.AgentConnection_Direct);
				}
				else
				{
					base.IsProxyConnection = false;
				}
				bool showAgents = true;
				if (this.HideAgentItemIfPossible && connectedCount == 1 && firstUserInfo.SessionState <= 2U)
				{
					showAgents = false;
					base.WindowsUser = firstUserInfo;
				}
				else
				{
					base.WindowsUser = null;
				}
				base.ConnectionDescription = connectionDescription;
				foreach (AgentItem agentItem in this._agentsList)
				{
					agentItem.Excluded = !showAgents;
				}
			}
			finally
			{
				this._checkInProgress = false;
			}
		}

		// Token: 0x0400004B RID: 75
		private readonly List<AgentItem> _agentsList;

		// Token: 0x0400004C RID: 76
		private bool _checkInProgress;

		// Token: 0x0400004D RID: 77
		private bool _hideAgentItemIfPossible;
	}
}
