﻿using System;
using System.IO;
using System.Security.Cryptography;
using Microsoft.Win32;
using Newtonsoft.Json;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;

namespace OpiekunWEB.Console
{
	// Token: 0x02000004 RID: 4
	public class AppConfiguration
	{
		// Token: 0x0600000F RID: 15 RVA: 0x0000277C File Offset: 0x0000097C
		public AppConfiguration()
		{
			this.AppDir = SsStringUtils.GetAppDir();
			this.AppDataDir = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData).TrimEnd(new char[]
			{
				'\\'
			}) + "\\OpiekunWEB\\";
			this.CreateTime = DateTime.Now;
			if (!Directory.Exists(this.DbDir))
			{
				Directory.CreateDirectory(this.DbDir);
			}
			if (!Directory.Exists(this.UsersDataDir))
			{
				Directory.CreateDirectory(this.UsersDataDir);
			}
			if (!Directory.Exists(this.ExceptionLogsDir))
			{
				Directory.CreateDirectory(this.ExceptionLogsDir);
			}
			if (!Directory.Exists(this.LayoutsDir))
			{
				Directory.CreateDirectory(this.LayoutsDir);
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000010 RID: 16 RVA: 0x00002830 File Offset: 0x00000A30
		public string AppDataDir { get; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000011 RID: 17 RVA: 0x00002838 File Offset: 0x00000A38
		public string AppDir { get; }

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000012 RID: 18 RVA: 0x00002840 File Offset: 0x00000A40
		public DateTime CreateTime { get; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000013 RID: 19 RVA: 0x00002848 File Offset: 0x00000A48
		public string DbDir
		{
			get
			{
				return this.AppDataDir + "DB\\";
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000014 RID: 20 RVA: 0x0000285A File Offset: 0x00000A5A
		public string ExceptionLogsDir
		{
			get
			{
				return this.AppDataDir + "ExceptionLogs\\";
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000015 RID: 21 RVA: 0x0000286C File Offset: 0x00000A6C
		public string LayoutsDir
		{
			get
			{
				return this.AppDataDir + "Layouts\\";
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000016 RID: 22 RVA: 0x0000287E File Offset: 0x00000A7E
		public string UsersDataDir
		{
			get
			{
				return this.AppDataDir + "Users\\";
			}
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00002890 File Offset: 0x00000A90
		public T ReadEncrytedObjectFromUserRegistry<T>(string key)
		{
			return JsonConvert.DeserializeObject<T>(DataProtection.Unprotect(this.ReadStringFromUserRegistry(key), DataProtectionScope.CurrentUser));
		}

		// Token: 0x06000018 RID: 24 RVA: 0x000028A4 File Offset: 0x00000AA4
		public T ReadObjectFromUserRegistry<T>(string key)
		{
			return JsonConvert.DeserializeObject<T>(this.ReadStringFromUserRegistry(key));
		}

		// Token: 0x06000019 RID: 25 RVA: 0x000028B4 File Offset: 0x00000AB4
		public string ReadStringFromUserRegistry(string key)
		{
			string str = string.Empty;
			string result;
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\OpiekunWEB\\Console"))
			{
				if (registryKey != null)
				{
					object value = registryKey.GetValue(key);
					if (value != null)
					{
						str = value.ToString();
					}
					registryKey.Close();
				}
				result = str;
			}
			return result;
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00002914 File Offset: 0x00000B14
		public bool WriteEncryptedObjectToUserRegistry<T>(string key, T obj)
		{
			string json = JsonConvert.SerializeObject(obj);
			return this.WriteStringToUserRegistry(key, DataProtection.Protect(json, DataProtectionScope.CurrentUser));
		}

		// Token: 0x0600001B RID: 27 RVA: 0x0000293C File Offset: 0x00000B3C
		public bool WriteObjectToUserRegistry<T>(string key, T obj)
		{
			string json = JsonConvert.SerializeObject(obj);
			return this.WriteStringToUserRegistry(key, json);
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00002960 File Offset: 0x00000B60
		public bool WriteStringToUserRegistry(string key, string value)
		{
			using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\OpiekunWEB\\Console"))
			{
				if (registryKey != null)
				{
					registryKey.SetValue(key, value);
					registryKey.Close();
					return true;
				}
			}
			return false;
		}

		// Token: 0x0400000F RID: 15
		private const string RegistrySubKey = "Software\\OpiekunWEB\\Console";
	}
}
