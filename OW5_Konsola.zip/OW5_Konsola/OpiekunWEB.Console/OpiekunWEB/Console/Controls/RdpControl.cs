﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using AxMSTSCLib;
using DevExpress.XtraEditors;
using MSTSCLib;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.FullScreenDockManager;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Controls
{
	// Token: 0x020000B3 RID: 179
	public class RdpControl : XtraUserControl, IRemoteDesktopControler
	{
		// Token: 0x06000913 RID: 2323 RVA: 0x00052281 File Offset: 0x00050481
		public RdpControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000914 RID: 2324 RVA: 0x00052290 File Offset: 0x00050490
		public RdpControl(DeviceItem deviceItem, DisplayItem displayItem, FullScreenDockPanel parentPanel, RdpParams rdpParams)
		{
			this.DeviceItem = deviceItem;
			this.DisplayItem = displayItem;
			this._rdpParams = rdpParams;
			this.InitializeComponent();
			parentPanel.Text = deviceItem.Name + " (RDP)";
			this.Dock = DockStyle.Fill;
			this._connecting = false;
			try
			{
				this._rdpClient = new AxMsRdpClient6NotSafeForScripting();
				this._rdpClient.OnConnected += this.RdpClientOnConnected;
				this._rdpClient.OnDisconnected += this.RdpClientOnDisconnected;
				this._rdpClient.OnFatalError += this.RdpClientOnFatalError;
				this._rdpClient.OnLogonError += this.RdpClientOnLogonError;
				this.ConfigureRdpClientControl();
				this._rdpClient.DisconnectedText = string.Format(Resources.VncControl_DisconnectedText, this.DeviceItem.Name);
			}
			catch (Exception ex)
			{
				this._rdpClient.DisconnectedText = string.Format(Resources.RdpControl_Exception, ex.Message);
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x06000915 RID: 2325 RVA: 0x0001815B File Offset: 0x0001635B
		public RemoteDesktopConnectionType ConnectionType
		{
			get
			{
				return RemoteDesktopConnectionType.RDP;
			}
		}

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x06000916 RID: 2326 RVA: 0x000523A0 File Offset: 0x000505A0
		public DeviceItem DeviceItem { get; }

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x06000917 RID: 2327 RVA: 0x000523A8 File Offset: 0x000505A8
		// (set) Token: 0x06000918 RID: 2328 RVA: 0x000523B0 File Offset: 0x000505B0
		public DisplayItem DisplayItem
		{
			get
			{
				return this._displayItem;
			}
			set
			{
				if (this._displayItem != null)
				{
					throw new Exception("can't change value");
				}
				this._displayItem = value;
			}
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x06000919 RID: 2329 RVA: 0x000523CC File Offset: 0x000505CC
		// (set) Token: 0x0600091A RID: 2330 RVA: 0x000523D4 File Offset: 0x000505D4
		public RemoteDesktopInputMode InputMode
		{
			get
			{
				return this._inputMode;
			}
			set
			{
				this._inputMode = value;
			}
		}

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x0600091B RID: 2331 RVA: 0x000523DD File Offset: 0x000505DD
		// (set) Token: 0x0600091C RID: 2332 RVA: 0x000523E5 File Offset: 0x000505E5
		public RemoteDesktopStretchMode StretchMode
		{
			get
			{
				return this._streetchMode;
			}
			set
			{
				this._streetchMode = value;
			}
		}

		// Token: 0x0600091D RID: 2333 RVA: 0x000523F0 File Offset: 0x000505F0
		public Task Connect()
		{
			if (this._connecting || this._rdpClient.Connected == 1)
			{
				return Task.CompletedTask;
			}
			DisplayItem displayItem = this.DisplayItem;
			AgentClient agentClient2;
			if (displayItem == null)
			{
				agentClient2 = null;
			}
			else
			{
				AgentItem agentItem = displayItem.AgentItem;
				agentClient2 = ((agentItem != null) ? agentItem.AgentClient : null);
			}
			AgentClient agentClient = agentClient2;
			if (agentClient == null || !agentClient.IsConnected)
			{
				this._rdpClient.DisconnectedText = string.Format(Resources.VncControl_DisconnectedText, this.DeviceItem.Name);
				return Task.CompletedTask;
			}
			if (!agentClient.IsDirectConnection)
			{
				this._rdpClient.DisconnectedText = "W tej wersji programu operacja możliwa jest tylko dla agenta połączonego bezpośrednio";
				return Task.CompletedTask;
			}
			this.ConfigureConnection(agentClient.ConnectedIP);
			this._connecting = true;
			this._rdpClient.ConnectingText = string.Format(Resources.RdpControl_ConnectingText, this.DeviceItem.Name);
			this._rdpClient.DisconnectedText = string.Format(Resources.RdpControl_DisconnectedText, this.DeviceItem.Name);
			this._rdpClient.Connect();
			return Task.CompletedTask;
		}

		// Token: 0x0600091E RID: 2334 RVA: 0x000524EA File Offset: 0x000506EA
		public Task Disconnect()
		{
			if (this._rdpClient.Connected == 1)
			{
				this._rdpClient.Disconnect();
			}
			return Task.CompletedTask;
		}

		// Token: 0x0600091F RID: 2335 RVA: 0x0005250A File Offset: 0x0005070A
		public Control GetControl()
		{
			return this;
		}

		// Token: 0x06000920 RID: 2336 RVA: 0x0005250D File Offset: 0x0005070D
		public Task RefreshWindow()
		{
			this._rdpClient.Refresh();
			return Task.CompletedTask;
		}

		// Token: 0x06000921 RID: 2337 RVA: 0x00052520 File Offset: 0x00050720
		public Task SendCAD()
		{
			try
			{
				if (this._rdpNonScriptable != null)
				{
					new MsRdpClientNonScriptableWrapper(this._rdpNonScriptable).SendKeys(new int[]
					{
						29,
						56,
						83,
						83,
						56,
						29
					}, new bool[]
					{
						false,
						false,
						false,
						true,
						true,
						true
					});
				}
			}
			catch (Exception)
			{
			}
			return Task.CompletedTask;
		}

		// Token: 0x06000922 RID: 2338 RVA: 0x00052584 File Offset: 0x00050784
		public void WindowClosing()
		{
			RdpControl.<WindowClosing>d__28 <WindowClosing>d__;
			<WindowClosing>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<WindowClosing>d__.<>4__this = this;
			<WindowClosing>d__.<>1__state = -1;
			<WindowClosing>d__.<>t__builder.Start<RdpControl.<WindowClosing>d__28>(ref <WindowClosing>d__);
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x000525BC File Offset: 0x000507BC
		private void ConfigureConnection(string ipAddr)
		{
			this._rdpClient.Server = ipAddr;
			this._rdpClient.AdvancedSettings3.RDPPort = this._rdpParams.Port;
			this._rdpClient.AdvancedSettings3.ContainerHandledFullScreen = -1;
			this._rdpClient.AdvancedSettings3.ConnectToServerConsole = false;
			this._rdpClient.AdvancedSettings3.allowBackgroundInput = 1;
			this._rdpClient.AdvancedSettings5.AuthenticationLevel = 2U;
			this._rdpNonScriptable.EnableCredSspSupport = true;
			this._rdpClient.AdvancedSettings7.ConnectToAdministerServer = this._rdpParams.ConnectToConsole;
			switch (this._rdpParams.ColorsDepth)
			{
			case RemoteDesktopColorsDepth.Bits8:
				this._rdpClient.ColorDepth = 8;
				break;
			case RemoteDesktopColorsDepth.Bits16:
				this._rdpClient.ColorDepth = 16;
				break;
			case RemoteDesktopColorsDepth.Bits24:
				this._rdpClient.ColorDepth = 24;
				break;
			case RemoteDesktopColorsDepth.Bits32:
				this._rdpClient.ColorDepth = 32;
				break;
			}
			this._rdpClient.SecuredSettings2.AudioRedirectionMode = 0;
			this._rdpClient.UserName = this._rdpParams.UserName;
			this._rdpClient.Domain = this._rdpParams.DomainName;
			try
			{
				if (this._rdpNonScriptable != null)
				{
					this._rdpNonScriptable.ClearTextPassword = this._rdpParams.Password;
				}
			}
			catch (Exception ex)
			{
				this._rdpClient.DisconnectedText = string.Format(Resources.RdpControl_Exception, ex.Message);
			}
		}

		// Token: 0x06000924 RID: 2340 RVA: 0x00052744 File Offset: 0x00050944
		private void ConfigureRdpClientControl()
		{
			Control clientControl = this._rdpClient;
			base.Controls.Add(clientControl);
			this._rdpClient.CreateControl();
			this._rdpClient.BringToFront();
			base.BringToFront();
			this._rdpClient.Parent = this.panelMain;
			this._rdpClient.AllowDrop = true;
			this._rdpClient.Dock = DockStyle.Fill;
			this._rdpNonScriptable = (this._rdpClient.GetOcx() as IMsRdpClientNonScriptable4);
			switch (this._rdpParams.DesktopSize)
			{
			case RemoteDesktopSize.Fixed800x600:
				this._rdpClient.DesktopWidth = 800;
				this._rdpClient.DesktopHeight = 600;
				return;
			case RemoteDesktopSize.Fixed1024x768:
				this._rdpClient.DesktopWidth = 1024;
				this._rdpClient.DesktopHeight = 768;
				return;
			case RemoteDesktopSize.Fixed1280x1024:
				this._rdpClient.DesktopWidth = 1280;
				this._rdpClient.DesktopHeight = 1024;
				return;
			case RemoteDesktopSize.Fixed1600x900:
				this._rdpClient.DesktopWidth = 1600;
				this._rdpClient.DesktopHeight = 900;
				return;
			case RemoteDesktopSize.Fixed1920x1080:
				this._rdpClient.DesktopWidth = 1920;
				this._rdpClient.DesktopHeight = 1080;
				return;
			case RemoteDesktopSize.FitToWindow:
				this._rdpClient.DesktopWidth = Screen.PrimaryScreen.Bounds.Width;
				this._rdpClient.DesktopHeight = Screen.PrimaryScreen.Bounds.Height;
				this._rdpClient.AdvancedSettings3.SmartSizing = true;
				return;
			default:
				return;
			}
		}

		// Token: 0x06000925 RID: 2341 RVA: 0x000528DA File Offset: 0x00050ADA
		private void RdpClientOnConnected(object sender, EventArgs e)
		{
			this._connecting = false;
		}

		// Token: 0x06000926 RID: 2342 RVA: 0x000528E4 File Offset: 0x00050AE4
		private void RdpClientOnDisconnected(object sender, IMsTscAxEvents_OnDisconnectedEvent e)
		{
			int discReason = e.discReason;
			if (discReason != 1)
			{
				if (discReason != 4)
				{
					if (discReason != 516)
					{
						this._rdpClient.DisconnectedText = string.Format(Resources.RdpControl_ConnectionErrorWithReason, e.discReason.ToString());
					}
					else
					{
						this._rdpClient.DisconnectedText = Resources.RdpControl_ConnectionErrorX204;
					}
				}
				else
				{
					this._rdpClient.DisconnectedText = string.Format(Resources.RdpControl_ConnectionErrorInvalidPassword, this._rdpParams.DomainName + "@" + this._rdpParams.UserName);
				}
			}
			else
			{
				this._rdpClient.DisconnectedText = Resources.RdpControl_ConnectionEnded;
			}
			this._connecting = false;
		}

		// Token: 0x06000927 RID: 2343 RVA: 0x000528DA File Offset: 0x00050ADA
		private void RdpClientOnFatalError(object sender, IMsTscAxEvents_OnFatalErrorEvent e)
		{
			this._connecting = false;
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x000528DA File Offset: 0x00050ADA
		private void RdpClientOnLogonError(object sender, IMsTscAxEvents_OnLogonErrorEvent e)
		{
			this._connecting = false;
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x0005298C File Offset: 0x00050B8C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x000529AC File Offset: 0x00050BAC
		private void InitializeComponent()
		{
			this.panelMain = new Panel();
			base.SuspendLayout();
			this.panelMain.Dock = DockStyle.Fill;
			this.panelMain.Location = new Point(0, 0);
			this.panelMain.Name = "panelMain";
			this.panelMain.Size = new Size(727, 414);
			this.panelMain.TabIndex = 0;
			base.AutoScaleDimensions = new SizeF(7f, 16f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.panelMain);
			base.Name = "RdpControl";
			base.Size = new Size(727, 414);
			base.ResumeLayout(false);
		}

		// Token: 0x04000707 RID: 1799
		private bool _connecting;

		// Token: 0x04000708 RID: 1800
		private DisplayItem _displayItem;

		// Token: 0x04000709 RID: 1801
		private RemoteDesktopInputMode _inputMode;

		// Token: 0x0400070A RID: 1802
		private AxMsRdpClient6NotSafeForScripting _rdpClient;

		// Token: 0x0400070B RID: 1803
		private IMsRdpClientNonScriptable4 _rdpNonScriptable;

		// Token: 0x0400070C RID: 1804
		private RdpParams _rdpParams;

		// Token: 0x0400070D RID: 1805
		private RemoteDesktopStretchMode _streetchMode;

		// Token: 0x0400070F RID: 1807
		private IContainer components;

		// Token: 0x04000710 RID: 1808
		private Panel panelMain;
	}
}
