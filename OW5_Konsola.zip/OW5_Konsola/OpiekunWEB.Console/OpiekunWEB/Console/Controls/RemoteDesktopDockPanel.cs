﻿using System;
using DevExpress.XtraBars.Docking;
using OpiekunWEB.Console.Forms.FullScreenDockManager;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Controls
{
	// Token: 0x020000B6 RID: 182
	public class RemoteDesktopDockPanel : FullScreenDockPanel
	{
		// Token: 0x06000954 RID: 2388 RVA: 0x00054006 File Offset: 0x00052206
		public RemoteDesktopDockPanel() : this(false, DockingStyle.Float, null)
		{
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x00054011 File Offset: 0x00052211
		public RemoteDesktopDockPanel(bool createControlContainer, DockingStyle dock, DockManager dockManager) : base(createControlContainer, dock, dockManager)
		{
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x06000956 RID: 2390 RVA: 0x0005401C File Offset: 0x0005221C
		// (set) Token: 0x06000957 RID: 2391 RVA: 0x00054024 File Offset: 0x00052224
		public IRemoteDesktopControler Controler { get; private set; }

		// Token: 0x06000958 RID: 2392 RVA: 0x0005402D File Offset: 0x0005222D
		public void Initialize(IRemoteDesktopControler controler)
		{
			this.Controler = controler;
			base.ControlContainer.Controls.Add(controler.GetControl());
		}
	}
}
