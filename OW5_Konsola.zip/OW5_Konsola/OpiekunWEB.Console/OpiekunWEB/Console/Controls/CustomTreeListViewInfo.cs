﻿using System;
using System.Drawing;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.ViewInfo;

namespace OpiekunWEB.Console.Controls
{
	// Token: 0x020000B2 RID: 178
	public class CustomTreeListViewInfo : TreeListViewInfo
	{
		// Token: 0x06000910 RID: 2320 RVA: 0x0005223C File Offset: 0x0005043C
		public CustomTreeListViewInfo(TreeList treeList) : base(treeList)
		{
		}

		// Token: 0x06000911 RID: 2321 RVA: 0x00052245 File Offset: 0x00050445
		protected override void CalcSelectImageBounds(RowInfo rInfo, Rectangle indentBounds)
		{
			base.CalcSelectImageBounds(rInfo, indentBounds);
			if (rInfo.SelectImageIndex < 0)
			{
				rInfo.SelectImageBounds = Rectangle.Empty;
			}
		}

		// Token: 0x06000912 RID: 2322 RVA: 0x00052263 File Offset: 0x00050463
		protected override void CalcStateImageBounds(RowInfo rInfo, Rectangle indentBounds)
		{
			base.CalcStateImageBounds(rInfo, indentBounds);
			if (rInfo.StateImageIndex < 0)
			{
				rInfo.StateImageBounds = Rectangle.Empty;
			}
		}
	}
}
