﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using AxViewerX;
using DevExpress.XtraEditors;
using OpiekunWEB.Console.Forms.FullScreenDockManager;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;
using ViewerX;

namespace OpiekunWEB.Console.Controls
{
	// Token: 0x020000B5 RID: 181
	public class VncControl : XtraUserControl, IRemoteDesktopControler
	{
		// Token: 0x0600093D RID: 2365 RVA: 0x00053B00 File Offset: 0x00051D00
		public VncControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x00053B10 File Offset: 0x00051D10
		public VncControl(DeviceItem deviceItem, DisplayItem displayItem, FullScreenDockPanel parentPanel)
		{
			this.DeviceItem = deviceItem;
			this.DisplayItem = displayItem;
			this.InitializeComponent();
			parentPanel.Text = deviceItem.Name;
			this.Dock = DockStyle.Fill;
			this.ViewerX.ConnectingText = string.Format(Resources.VncControl_ConnectingText, deviceItem.Name);
			this.ViewerX.DisconnectedText = Resources.VncControl_BeforeConnectionText;
			this._inputMode = RemoteDesktopInputMode.AdminAndUser;
			this._connecting = false;
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x0600093F RID: 2367 RVA: 0x00053B83 File Offset: 0x00051D83
		public RemoteDesktopConnectionType ConnectionType
		{
			get
			{
				return RemoteDesktopConnectionType.VNC;
			}
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06000940 RID: 2368 RVA: 0x00053B86 File Offset: 0x00051D86
		public DeviceItem DeviceItem { get; }

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06000941 RID: 2369 RVA: 0x00053B8E File Offset: 0x00051D8E
		// (set) Token: 0x06000942 RID: 2370 RVA: 0x00053B96 File Offset: 0x00051D96
		public DisplayItem DisplayItem
		{
			get
			{
				return this._displayItem;
			}
			set
			{
				if (this._displayItem != null)
				{
					throw new Exception("can't change value");
				}
				this._displayItem = value;
			}
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x06000943 RID: 2371 RVA: 0x00053BB2 File Offset: 0x00051DB2
		// (set) Token: 0x06000944 RID: 2372 RVA: 0x00053BBC File Offset: 0x00051DBC
		public RemoteDesktopInputMode InputMode
		{
			get
			{
				return this._inputMode;
			}
			set
			{
				if (this.IsConnected())
				{
					this._inputMode = value;
					switch (value)
					{
					case RemoteDesktopInputMode.AdminAndUser:
						this.ViewerX.remoteInputEnabled = true;
						this.ViewerX.ViewOnly = false;
						return;
					case RemoteDesktopInputMode.Admin:
						this.ViewerX.ViewOnly = false;
						this.ViewerX.remoteInputEnabled = false;
						return;
					case RemoteDesktopInputMode.User:
						this.ViewerX.remoteInputEnabled = true;
						this.ViewerX.ViewOnly = true;
						break;
					default:
						return;
					}
				}
			}
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x06000945 RID: 2373 RVA: 0x00053C35 File Offset: 0x00051E35
		// (set) Token: 0x06000946 RID: 2374 RVA: 0x00053C40 File Offset: 0x00051E40
		public RemoteDesktopStretchMode StretchMode
		{
			get
			{
				return this._streetchMode;
			}
			set
			{
				this._streetchMode = value;
				switch (this._streetchMode)
				{
				case RemoteDesktopStretchMode.Disabled:
					this.ViewerX.StretchMode = ScreenStretchMode.SSM_NONE;
					return;
				case RemoteDesktopStretchMode.FitToWindow:
					this.ViewerX.StretchMode = ScreenStretchMode.SSM_FREE;
					return;
				case RemoteDesktopStretchMode.AspecRatio:
					this.ViewerX.StretchMode = ScreenStretchMode.SSM_ASPECT;
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x06000947 RID: 2375 RVA: 0x00053C94 File Offset: 0x00051E94
		public Task Connect()
		{
			VncControl.<Connect>d__27 <Connect>d__;
			<Connect>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Connect>d__.<>4__this = this;
			<Connect>d__.<>1__state = -1;
			<Connect>d__.<>t__builder.Start<VncControl.<Connect>d__27>(ref <Connect>d__);
			return <Connect>d__.<>t__builder.Task;
		}

		// Token: 0x06000948 RID: 2376 RVA: 0x00053CD7 File Offset: 0x00051ED7
		public Task Disconnect()
		{
			this._attemptNo = 3;
			this._connecting = false;
			if (this.IsConnected())
			{
				this._showDiconnectedMsg = true;
				this.ViewerX.Disconnect();
			}
			return Task.CompletedTask;
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x0005250A File Offset: 0x0005070A
		public Control GetControl()
		{
			return this;
		}

		// Token: 0x0600094A RID: 2378 RVA: 0x00053D06 File Offset: 0x00051F06
		public Task RefreshWindow()
		{
			if (this.IsConnected())
			{
				this.ViewerX.RequestRefresh();
			}
			return Task.CompletedTask;
		}

		// Token: 0x0600094B RID: 2379 RVA: 0x00053D20 File Offset: 0x00051F20
		public Task SendCAD()
		{
			if (this.IsConnected())
			{
				this.ViewerX.SendCAD();
			}
			return Task.CompletedTask;
		}

		// Token: 0x0600094C RID: 2380 RVA: 0x00053D3A File Offset: 0x00051F3A
		public void WindowClosing()
		{
			this._vncProxyChannelId = null;
			this.Disconnect();
		}

		// Token: 0x0600094D RID: 2381 RVA: 0x00053D4C File Offset: 0x00051F4C
		private Task InternalVncConnect()
		{
			VncControl.<InternalVncConnect>d__33 <InternalVncConnect>d__;
			<InternalVncConnect>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<InternalVncConnect>d__.<>4__this = this;
			<InternalVncConnect>d__.<>1__state = -1;
			<InternalVncConnect>d__.<>t__builder.Start<VncControl.<InternalVncConnect>d__33>(ref <InternalVncConnect>d__);
			return <InternalVncConnect>d__.<>t__builder.Task;
		}

		// Token: 0x0600094E RID: 2382 RVA: 0x00053D8F File Offset: 0x00051F8F
		private bool IsConnected()
		{
			return this.ViewerX.GetConnectionState() == VncConnectionState.VCS_CONNECTED;
		}

		// Token: 0x0600094F RID: 2383 RVA: 0x00053DA0 File Offset: 0x00051FA0
		private void ProxyChannelOpened(object sender, ProxyChannelOpened proxyChannelOpenedMsg)
		{
			if (proxyChannelOpenedMsg.RequestId == this._vncProxyChannelId)
			{
				string[] addrParts = proxyChannelOpenedMsg.ProxyAddrs[0].Split(new char[]
				{
					':'
				});
				if (addrParts.Length != 2)
				{
					return;
				}
				int proxyPort;
				if (!int.TryParse(addrParts[1], out proxyPort))
				{
					return;
				}
				this.ViewerX.ProxyIP = addrParts[0];
				this.ViewerX.ProxyPort = proxyPort;
				this.ViewerX.ProxyType = ConnectionProxyType.VPT_HTTP;
				this._ip = proxyChannelOpenedMsg.ChannelId + ".proxy.opiekunweb.pl";
				this.ViewerX.ConnectAsyncEx(this._ip, this._vncPort, this._vncPassword);
			}
		}

		// Token: 0x06000950 RID: 2384 RVA: 0x00003A2C File Offset: 0x00001C2C
		private void ViewerX_ConnectedEvent(object sender, EventArgs e)
		{
		}

		// Token: 0x06000951 RID: 2385 RVA: 0x00053E50 File Offset: 0x00052050
		private void ViewerX_Disconnected(object sender, EventArgs e)
		{
			VncControl.<ViewerX_Disconnected>d__37 <ViewerX_Disconnected>d__;
			<ViewerX_Disconnected>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ViewerX_Disconnected>d__.<>4__this = this;
			<ViewerX_Disconnected>d__.<>1__state = -1;
			<ViewerX_Disconnected>d__.<>t__builder.Start<VncControl.<ViewerX_Disconnected>d__37>(ref <ViewerX_Disconnected>d__);
		}

		// Token: 0x06000952 RID: 2386 RVA: 0x00053E87 File Offset: 0x00052087
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000953 RID: 2387 RVA: 0x00053EA8 File Offset: 0x000520A8
		private void InitializeComponent()
		{
			ComponentResourceManager resources = new ComponentResourceManager(typeof(VncControl));
			this.ViewerX = new AxCSC_ViewerXControl();
			((ISupportInitialize)this.ViewerX).BeginInit();
			base.SuspendLayout();
			this.ViewerX.Dock = DockStyle.Fill;
			this.ViewerX.Enabled = true;
			this.ViewerX.Location = new Point(0, 0);
			this.ViewerX.Margin = new Padding(0);
			this.ViewerX.Name = "ViewerX";
			this.ViewerX.OcxState = (AxHost.State)resources.GetObject("ViewerX.OcxState");
			this.ViewerX.Size = new Size(503, 358);
			this.ViewerX.TabIndex = 7;
			this.ViewerX.ConnectedEvent += this.ViewerX_ConnectedEvent;
			this.ViewerX.Disconnected += this.ViewerX_Disconnected;
			base.AutoScaleDimensions = new SizeF(7f, 16f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.ViewerX);
			base.Margin = new Padding(0);
			base.Name = "VncControl";
			base.Size = new Size(503, 358);
			((ISupportInitialize)this.ViewerX).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000728 RID: 1832
		private const int maxConnectAtempt = 3;

		// Token: 0x04000729 RID: 1833
		private int _attemptNo;

		// Token: 0x0400072A RID: 1834
		private bool _connecting;

		// Token: 0x0400072B RID: 1835
		private DisplayItem _displayItem;

		// Token: 0x0400072C RID: 1836
		private RemoteDesktopInputMode _inputMode;

		// Token: 0x0400072D RID: 1837
		private string _ip;

		// Token: 0x0400072E RID: 1838
		private bool _showDiconnectedMsg;

		// Token: 0x0400072F RID: 1839
		private RemoteDesktopStretchMode _streetchMode;

		// Token: 0x04000730 RID: 1840
		private string _vncPassword;

		// Token: 0x04000731 RID: 1841
		private int _vncPort;

		// Token: 0x04000732 RID: 1842
		private string _vncProxyChannelId;

		// Token: 0x04000734 RID: 1844
		private IContainer components;

		// Token: 0x04000735 RID: 1845
		private AxCSC_ViewerXControl ViewerX;
	}
}
