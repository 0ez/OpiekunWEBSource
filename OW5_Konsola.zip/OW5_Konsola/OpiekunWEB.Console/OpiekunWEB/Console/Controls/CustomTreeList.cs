﻿using System;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.ViewInfo;

namespace OpiekunWEB.Console.Controls
{
	// Token: 0x020000B1 RID: 177
	public class CustomTreeList : TreeList
	{
		// Token: 0x0600090E RID: 2318 RVA: 0x0005222C File Offset: 0x0005042C
		protected override TreeListViewInfo CreateViewInfo()
		{
			return new CustomTreeListViewInfo(this);
		}
	}
}
