﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reactive.Linq;
using System.Windows.Forms;
using System.Windows.Threading;
using DevExpress.Images;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraTreeList.ViewInfo;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Controls
{
	// Token: 0x020000B7 RID: 183
	public class DevicesTreePanel : BaseUserControl, ICommandTarget
	{
		// Token: 0x06000959 RID: 2393 RVA: 0x0005404C File Offset: 0x0005224C
		public DevicesTreePanel()
		{
			this.InitializeComponent();
			this._previousSelection = new List<TreeListNode>();
		}

		// Token: 0x0600095A RID: 2394 RVA: 0x00054068 File Offset: 0x00052268
		public void CheckProjectorColumn()
		{
			bool showColumn = this._devicesTree.Selection.DevicesVisibledList.Any((DeviceItem x) => x.ProjectorStatus != 0);
			if (this.columnProjectorStatus.VisibleIndex < 0)
			{
				this.columnProjectorStatus.VisibleIndex = 0;
			}
			this.columnProjectorStatus.Visible = showColumn;
		}

		// Token: 0x0600095B RID: 2395 RVA: 0x000540D0 File Offset: 0x000522D0
		public bool FocusItem(string id)
		{
			TreeListNode node = this.treeDevicesList.FindNodeByKeyID(id);
			if (node != null)
			{
				this.treeDevicesList.FocusedNode = node;
			}
			return node != null;
		}

		// Token: 0x0600095C RID: 2396 RVA: 0x000540FD File Offset: 0x000522FD
		public List<AgentItem> GetCommandTargetAsAgentItems()
		{
			if (this._itemSelectedByPopupMenuBelongsToSelection)
			{
				return this._devicesTree.Selection.GetAgentItemList(false);
			}
			return this._devicesTree.GetSelectionForItem(this._itemSelectedByPopupMenu, true, false).GetAgentItemList(false);
		}

		// Token: 0x0600095D RID: 2397 RVA: 0x00054132 File Offset: 0x00052332
		public List<DeviceItem> GetCommandTargetAsDeviceItems()
		{
			if (this._itemSelectedByPopupMenuBelongsToSelection)
			{
				return this._devicesTree.Selection.DevicesList;
			}
			return this._devicesTree.GetSelectionForItem(this._itemSelectedByPopupMenu, true, false).DevicesList;
		}

		// Token: 0x0600095E RID: 2398 RVA: 0x00054165 File Offset: 0x00052365
		public DeviceAndDisplayList GetCommandTargetAsDevicesAndDisplays()
		{
			if (this._itemSelectedByPopupMenuBelongsToSelection)
			{
				return this._devicesTree.Selection.DeviceAndDisplayList;
			}
			return this._devicesTree.GetSelectionForItem(this._itemSelectedByPopupMenu, true, false).DeviceAndDisplayList;
		}

		// Token: 0x0600095F RID: 2399 RVA: 0x00054198 File Offset: 0x00052398
		public void InitializeTree(ApiClient apiClient, DevicesTree devicesTree, FormsSettings formsSettings, ObservableAgregator observableAgregator, IPopupMenuCreator popupMenuCreator, IIconsProvider iconsProvider)
		{
			this._apiClient = apiClient;
			this._devicesTree = devicesTree;
			this._formsSettings = formsSettings;
			this._observableAgregator = observableAgregator;
			this._iconsProvider = iconsProvider;
			this._devicesTree.RestrictionGroupChanged += this.DevicesTreeOnRestrictionGroupChanged;
			this._treeImages = ((iconsProvider != null) ? iconsProvider.DevicesTreeImages24x24 : null);
			this.treeDevicesList.SelectImageList = this._treeImages;
			if (popupMenuCreator != null)
			{
				popupMenuCreator.FillPopupMenu(this.popupMenu, PopupMenuKind.DevicesTree, this);
			}
			this._observableAgregator.AgentConnectionChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentConnectionChanged));
			this._formsSettings.RestoreObjectState(base.Name, this.barEditShowDevicesFilter, null);
			this._formsSettings.RestoreObjectState(base.Name, this.barCheckShowAutoFilter, null);
			if (string.IsNullOrEmpty(this.barEditShowDevicesFilter.EditValue as string))
			{
				this.barEditShowDevicesFilter.EditValue = this.repositoryComboBoxShowDevices.Items[0];
			}
		}

		// Token: 0x06000960 RID: 2400 RVA: 0x000542A3 File Offset: 0x000524A3
		public bool IsCommandEnabled(ConsoleEventType eventType)
		{
			if (this._itemSelectedByPopupMenuBelongsToSelection)
			{
				return true;
			}
			if (eventType == ConsoleEventType.RpcWakeOnLan)
			{
				return !this._itemSelectedByPopupMenu.IsConnected;
			}
			return this._itemSelectedByPopupMenu.IsConnected;
		}

		// Token: 0x06000961 RID: 2401 RVA: 0x000542D1 File Offset: 0x000524D1
		public void RefreshDataSource()
		{
			this.treeDevicesList.RefreshDataSource();
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x000542DE File Offset: 0x000524DE
		protected override void OnHandleDestroyed(EventArgs e)
		{
			if (!base.DesignMode)
			{
				FormsSettings formsSettings = this._formsSettings;
				if (formsSettings != null)
				{
					formsSettings.SaveObjectState(base.Name, this.treeDevicesList);
				}
			}
			base.OnHandleDestroyed(e);
		}

		// Token: 0x06000963 RID: 2403 RVA: 0x0005430C File Offset: 0x0005250C
		private void barCheckShowAutoFilter_CheckedChanged(object sender, ItemClickEventArgs e)
		{
			this.treeDevicesList.OptionsView.ShowAutoFilterRow = this.barCheckShowAutoFilter.Checked;
			this._formsSettings.SaveObjectState(base.Name, this.barCheckShowAutoFilter);
		}

		// Token: 0x06000964 RID: 2404 RVA: 0x00054340 File Offset: 0x00052540
		private void barEditShowDevicesFilter_EditValueChanged(object sender, EventArgs e)
		{
			bool showAll = this.barEditShowDevicesFilter.EditValue == this.repositoryComboBoxShowDevices.Items[0];
			this._showOnlyConnectedDevices = !showAll;
			this._showOnlyConnectedSessions = (this.barEditShowDevicesFilter.EditValue == this.repositoryComboBoxShowDevices.Items[2]);
			this.treeDevicesList.RefreshDataSource();
			this.SetSelectedItems();
			this._formsSettings.SaveObjectState(base.Name, this.barEditShowDevicesFilter);
		}

		// Token: 0x06000965 RID: 2405 RVA: 0x000543C4 File Offset: 0x000525C4
		private void CustomDrawNodeCellImage(CustomDrawNodeCellEventArgs e, int[] connectionTypeIconIndexes, int[] deviceIconIndexes)
		{
			if (this._iconsProvider == null)
			{
				return;
			}
			int iconsWidth = 0;
			if (connectionTypeIconIndexes != null)
			{
				for (int i = 0; i < connectionTypeIconIndexes.Length; i++)
				{
					if (connectionTypeIconIndexes[i] != -1)
					{
						iconsWidth += 16;
					}
				}
			}
			if (deviceIconIndexes != null)
			{
				for (int i = 0; i < deviceIconIndexes.Length; i++)
				{
					if (deviceIconIndexes[i] != -1)
					{
						iconsWidth += 24;
					}
				}
			}
			Rectangle originalRect = e.EditViewInfo.Bounds;
			Rectangle editorRect = new Rectangle(e.EditViewInfo.Bounds.Left + iconsWidth, e.EditViewInfo.Bounds.Top, e.EditViewInfo.Bounds.Width - iconsWidth, e.EditViewInfo.Bounds.Height);
			e.EditViewInfo.Bounds = editorRect;
			e.EditViewInfo.CalcViewInfo(e.Cache.Graphics);
			this.treeDevicesList.Painter.DefaultPaintHelper.DrawNodeCell(e);
			e.EditViewInfo.Bounds = originalRect;
			e.EditViewInfo.CalcViewInfo(e.Cache.Graphics);
			int x = e.Bounds.X;
			if (connectionTypeIconIndexes != null)
			{
				foreach (int iconIdx in connectionTypeIconIndexes)
				{
					if (iconIdx != -1 && iconIdx < this._iconsProvider.ConnectionTypeImages16x16.Images.Count)
					{
						Image image = this._iconsProvider.ConnectionTypeImages16x16.Images[iconIdx];
						e.Cache.DrawImage(image, x, e.Bounds.Y + e.Bounds.Height / 2 - 8, 16, 16);
						x += 16;
					}
				}
			}
			if (deviceIconIndexes != null)
			{
				foreach (int iconIdx2 in deviceIconIndexes)
				{
					if (iconIdx2 > -1 && iconIdx2 < this._treeImages.Images.Count)
					{
						Image image2 = this._treeImages.Images[iconIdx2];
						e.Cache.DrawImage(image2, x, e.Bounds.Y + e.Bounds.Height / 2 - 12, 24, 24);
						x += 24;
					}
				}
			}
			e.Handled = true;
		}

		// Token: 0x06000966 RID: 2406 RVA: 0x00054622 File Offset: 0x00052822
		private void DevicesTreeOnRestrictionGroupChanged(object sender, EventArgs eventArgs)
		{
			this.RefreshDataSource();
		}

		// Token: 0x06000967 RID: 2407 RVA: 0x0005462C File Offset: 0x0005282C
		private void DevicesTreePanel_Load(object sender, EventArgs e)
		{
			if (base.DesignMode)
			{
				return;
			}
			if (!this._panelLoaded)
			{
				this._panelLoaded = true;
				TreeList treeList = this.treeDevicesList;
				DevicesTree devicesTree = this._devicesTree;
				treeList.DataSource = ((devicesTree != null) ? devicesTree.ItemList : null);
				FormsSettings formsSettings = this._formsSettings;
				if (formsSettings != null)
				{
					formsSettings.RestoreObjectState(base.Name, this.treeDevicesList, null);
				}
				this._columnWithUserInetAccessIcon = this.FindColumnWithUserInetAccessIcon();
				this.columnTypeName.Visible = false;
			}
		}

		// Token: 0x06000968 RID: 2408 RVA: 0x000546A4 File Offset: 0x000528A4
		private TreeListColumn FindColumnWithUserInetAccessIcon()
		{
			foreach (TreeListColumn column in from x in this.treeDevicesList.Columns
			where x.VisibleIndex > -1
			orderby x.VisibleIndex
			select x)
			{
				if (column == this.columnUserName || column == this.columnFullName || column == this.columnDomainAndUserName)
				{
					return column;
				}
			}
			return this.columnDomainAndUserName;
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x00054760 File Offset: 0x00052960
		private string GetAppDesktopOrCategoryName(AppControlState appAccess, string desktopOrCategoryId)
		{
			if (!appAccess.IsDesktopOrCategoryAccess())
			{
				return string.Empty;
			}
			if (appAccess == AppControlState.AppStrictToDesktop)
			{
				Desktop desktop = this._apiClient.Desktops.FindItemById(desktopOrCategoryId);
				if (desktop == null)
				{
					return null;
				}
				return desktop.Name;
			}
			else
			{
				AppCategory appCategory = this._apiClient.AppCategories.FindItemById(desktopOrCategoryId);
				if (appCategory == null)
				{
					return null;
				}
				return appCategory.Name;
			}
		}

		// Token: 0x0600096A RID: 2410 RVA: 0x000547B8 File Offset: 0x000529B8
		private List<DeviceTreeItemBase> GetSelectedItems()
		{
			return (from x in (from x in this.treeDevicesList.Selection
			where x.Visible
			select x).Select(new Func<TreeListNode, DeviceTreeItemBase>(this.GetTreeItemForNode))
			where x != null
			select x).ToList<DeviceTreeItemBase>();
		}

		// Token: 0x0600096B RID: 2411 RVA: 0x0005482E File Offset: 0x00052A2E
		private DeviceTreeItemBase GetTreeItemForNode(TreeListNode node)
		{
			return this.treeDevicesList.GetDataRecordByNode(node) as DeviceTreeItemBase;
		}

		// Token: 0x0600096C RID: 2412 RVA: 0x00054844 File Offset: 0x00052A44
		private bool IsAllNodeChildrenSelected(TreeListNode node)
		{
			if (node == null || node.Nodes.Count == 0)
			{
				return false;
			}
			for (int i = 0; i < node.Nodes.Count; i++)
			{
				if (!node.Nodes[i].Selected)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x0600096D RID: 2413 RVA: 0x00054890 File Offset: 0x00052A90
		private bool IsAllNodeChildrensSelected(TreeListNode node)
		{
			for (int i = 0; i < node.Nodes.Count; i++)
			{
				if (node.Nodes[i].Visible && !node.Nodes[i].Selected)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x0600096E RID: 2414 RVA: 0x000548DC File Offset: 0x00052ADC
		private void OnAgentConnectionChanged(AgentClient agentClient)
		{
			this.SetSelectedItems();
		}

		// Token: 0x0600096F RID: 2415 RVA: 0x000548E4 File Offset: 0x00052AE4
		private void SelectAllNodeChildren(TreeListNode node)
		{
			if (node != null && node.HasChildren && node.Visible)
			{
				for (int i = 0; i < node.Nodes.Count; i++)
				{
					if (node.Nodes[i].Visible)
					{
						node.Nodes[i].Selected = true;
					}
					this.SelectAllNodeChildren(node.Nodes[i]);
				}
			}
		}

		// Token: 0x06000970 RID: 2416 RVA: 0x00054951 File Offset: 0x00052B51
		private void SelectNodeIfAllChildrenSelected(TreeListNode node)
		{
			if (node != null && this.IsAllNodeChildrenSelected(node))
			{
				node.Selected = true;
				this.SelectNodeIfAllChildrenSelected(node.ParentNode);
			}
		}

		// Token: 0x06000971 RID: 2417 RVA: 0x00054974 File Offset: 0x00052B74
		private void SetSelectedItems()
		{
			if (!this._panelLoaded)
			{
				return;
			}
			if (!string.IsNullOrEmpty(this.treeDevicesList.ActiveFilterString) || this._showOnlyConnectedDevices || this._showOnlyConnectedSessions)
			{
				this._devicesTree.SetItemsFilter((from x in this.treeDevicesList.GetNodeList()
				where x.Visible
				select x).Select(new Func<TreeListNode, DeviceTreeItemBase>(this.GetTreeItemForNode)).ToList<DeviceTreeItemBase>());
			}
			else
			{
				this._devicesTree.SetItemsFilter(null);
			}
			this._devicesTree.SetSelectedItems(this.GetSelectedItems(), this._showOnlyConnectedDevices, this._showOnlyConnectedSessions);
		}

		// Token: 0x06000972 RID: 2418 RVA: 0x00054A28 File Offset: 0x00052C28
		private void toolTipController_BeforeShow(object sender, ToolTipControllerShowEventArgs e)
		{
			if (this.toolTipTreeItem == null)
			{
				return;
			}
			e.SuperTip = new SuperToolTip();
			if (!this.toolTipTreeItem.IsGroup)
			{
				AgentItem agentItem = this.toolTipTreeItem as AgentItem;
				DeviceTreeItemBase deviceTreeItemBase = this.toolTipTreeItem;
				DisplayItem displayItem = this.toolTipTreeItem as DisplayItem;
				if (displayItem != null)
				{
					agentItem = displayItem.AgentItem;
					DeviceItem deviceItem = displayItem.AgentItem.DeviceItem;
				}
				else if (this.toolTipTreeItem is AgentItem)
				{
					DeviceItem deviceItem2 = agentItem.DeviceItem;
				}
				ToolTipTitleItem nameLine = new ToolTipTitleItem();
				nameLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceName, this.toolTipTreeItem.GetDeviceName());
				e.SuperTip.Items.Add(nameLine);
				ToolTipItem connectionTypeLine = new ToolTipItem();
				connectionTypeLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceConnection, this.toolTipTreeItem.ConnectionDescription);
				int idx = this.toolTipTreeItem.ConnectionTypeIconIdex;
				if (agentItem != null)
				{
					connectionTypeLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceConnection, agentItem.DeviceItem.ConnectionDescription);
					idx = agentItem.DeviceItem.ConnectionTypeIconIdex;
				}
				if (idx != -1)
				{
					connectionTypeLine.Image = this._iconsProvider.ConnectionTypeImages24x24.Images[idx];
				}
				e.SuperTip.Items.Add(connectionTypeLine);
				if (this.toolTipTreeItem.WindowsUser != null)
				{
					ToolTipItem sessionTypeLine = new ToolTipItem();
					idx = this.toolTipTreeItem.SessionTypeIconIndex;
					if (idx != -1)
					{
						sessionTypeLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceSession, this.toolTipTreeItem.WindowsUser.SessionType.GetDescription());
						sessionTypeLine.Image = this._iconsProvider.ConnectionTypeImages24x24.Images[idx];
						e.SuperTip.Items.Add(sessionTypeLine);
					}
				}
				ToolTipItem inetAccessLine = new ToolTipItem();
				inetAccessLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceInetAccess, this.toolTipTreeItem.InetAccess.GetDescription());
				if (this.toolTipTreeItem.InetAccess == InetControlState.InetStrict)
				{
					URLCategory category = this._apiClient.URLCategories.FindItemById(this.toolTipTreeItem.InetStrictCategoryId);
					ToolTipItem toolTipItem = inetAccessLine;
					toolTipItem.Text = toolTipItem.Text + " " + ((category != null) ? category.Name : null);
				}
				inetAccessLine.Image = this._treeImages.Images[this.toolTipTreeItem.DeviceIconWithDefaultIndexes[0]];
				e.SuperTip.Items.Add(inetAccessLine);
				ToolTipItem appAccessLine = new ToolTipItem();
				appAccessLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceAppAccess, this.toolTipTreeItem.AppAccess.GetDescription());
				string dcName = this.GetAppDesktopOrCategoryName(this.toolTipTreeItem.AppAccess, this.toolTipTreeItem.CurrentAppCategoryOrDesktopId);
				if (!string.IsNullOrEmpty(dcName))
				{
					ToolTipItem toolTipItem2 = appAccessLine;
					toolTipItem2.Text = toolTipItem2.Text + " (" + dcName + ")";
				}
				appAccessLine.Image = this._treeImages.Images[this.toolTipTreeItem.DeviceIconWithDefaultIndexes[1]];
				e.SuperTip.Items.Add(appAccessLine);
				ToolTipItem deviceAccessLine = new ToolTipItem();
				deviceAccessLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceAccess, OwpbExtensions.DeviceLockDescription(this.toolTipTreeItem.DeviceLockSettings));
				deviceAccessLine.Image = this._treeImages.Images[this.toolTipTreeItem.DeviceIconWithDefaultIndexes[2]];
				e.SuperTip.Items.Add(deviceAccessLine);
				if (this.toolTipTreeItem.WindowsUser != null)
				{
					e.SuperTip.Items.Add(new ToolTipItem());
					ToolTipTitleItem userNameLine = new ToolTipTitleItem();
					string userName = this.toolTipTreeItem.WindowsUser.DomainName + "\\" + this.toolTipTreeItem.WindowsUser.UserName;
					if (!string.IsNullOrEmpty(this.toolTipTreeItem.WindowsUser.FullName))
					{
						userName = userName + " (" + this.toolTipTreeItem.WindowsUser.FullName + ")";
					}
					userNameLine.Text = string.Format(Resources.DevicesTree_TooltipUserName, userName);
					e.SuperTip.Items.Add(userNameLine);
					ToolTipItem roleNameLine = new ToolTipItem();
					Role role = this._apiClient.Roles.FindItemById(this.toolTipTreeItem.WindowsUser.UserSettings.RoleId);
					roleNameLine.Text = string.Format(Resources.DevicesTree_TooltipUserRoleName, (role != null) ? role.Name : null);
					roleNameLine.Image = this._iconsProvider.DevicesTreeImages24x24.Images[7];
					e.SuperTip.Items.Add(roleNameLine);
					WindowsUserSettings userSettings = this.toolTipTreeItem.WindowsUser.UserSettings;
					ToolTipItem userInetAccessLine = new ToolTipItem();
					InetControlState roleInetAccess = this._apiClient.GetWindowsRoleInetAccess(role.Id);
					userInetAccessLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceInetAccess, roleInetAccess.GetDescriptionForPermissionValue());
					userInetAccessLine.Image = this._iconsProvider.DevicesTreeImages24x24.Images[DeviceTreeIconIndexes.GetInetControlStateIndex(userSettings.InetAccess)];
					if (userSettings.InetAccess == InetControlState.InetStrict)
					{
						URLCategory category2 = this._apiClient.URLCategories.FindItemById(userSettings.InetStrictCategoryId);
						ToolTipItem toolTipItem3 = userInetAccessLine;
						toolTipItem3.Text = toolTipItem3.Text + " " + ((category2 != null) ? category2.Name : null);
					}
					e.SuperTip.Items.Add(userInetAccessLine);
					ToolTipItem userAppAccessLine = new ToolTipItem();
					AppControlState roleAppAccess = this._apiClient.GetWindowsRoleAppAccess(role.Id);
					userAppAccessLine.Text = string.Format(Resources.DevicesTree_TooltipDeviceAppAccess, roleAppAccess.GetDescriptionForPermissionValue());
					string userDcName = this.GetAppDesktopOrCategoryName(userSettings.AppAccess, userSettings.AppAccessDesktopOrCategoryId);
					if (!string.IsNullOrEmpty(userDcName))
					{
						ToolTipItem toolTipItem4 = appAccessLine;
						toolTipItem4.Text = toolTipItem4.Text + " (" + userDcName + ")";
					}
					userAppAccessLine.Image = this._treeImages.Images[this.toolTipTreeItem.UserIconWithDefaultIndexes[1]];
					e.SuperTip.Items.Add(userAppAccessLine);
				}
				return;
			}
			List<DeviceItem> devices = this._devicesTree.GetDevicesForGroupAndSubgroups(this.toolTipTreeItem as DevicesGroupItem);
			int devicesConnected = (from x in devices
			where x.IsConnected
			select x).Count<DeviceItem>();
			ToolTipTitleItem groupNameLine = new ToolTipTitleItem();
			groupNameLine.Text = string.Format(Resources.DevicesTree_TooltipGroupName, this.toolTipTreeItem.Name);
			e.SuperTip.Items.Add(groupNameLine);
			ToolTipItem groupDevicesCountLine = new ToolTipItem();
			groupDevicesCountLine.Text = string.Format(Resources.DevicesTree_TooltipGroupDevicesCount, devices.Count);
			e.SuperTip.Items.Add(groupDevicesCountLine);
			ToolTipItem groupDevicesConnectedCountLine = new ToolTipItem();
			groupDevicesConnectedCountLine.Text = string.Format(Resources.DevicesTree_TooltipGroupDevicesConnected, devicesConnected);
			e.SuperTip.Items.Add(groupDevicesConnectedCountLine);
			if (devicesConnected == 0)
			{
				groupDevicesCountLine.Image = this._treeImages.Images[8];
				groupDevicesConnectedCountLine.Image = this._treeImages.Images[0];
				return;
			}
			groupDevicesCountLine.Image = this._treeImages.Images[9];
			groupDevicesConnectedCountLine.Image = this._treeImages.Images[1];
		}

		// Token: 0x06000973 RID: 2419 RVA: 0x00055188 File Offset: 0x00053388
		private void toolTipController_GetActiveObjectInfo(object sender, ToolTipControllerGetActiveObjectInfoEventArgs e)
		{
			if (e.SelectedControl is TreeList)
			{
				TreeListHitInfo hit = ((TreeList)e.SelectedControl).CalcHitInfo(e.ControlMousePosition);
				this.toolTipTreeItem = this.GetTreeItemForNode(hit.Node);
				if (this.toolTipTreeItem != null)
				{
					object cellInfo = new TreeListCellToolTipInfo(hit.Node, hit.Column, null);
					e.Info = new ToolTipControlInfo(cellInfo, "");
					e.Info.ToolTipType = ToolTipType.SuperTip;
					SuperToolTip superTooltip = new SuperToolTip();
					e.Info.SuperTip = superTooltip;
					ToolTipTitleItem toolTipFakeLine = new ToolTipTitleItem();
					toolTipFakeLine.Text = "!";
					superTooltip.Items.Add(toolTipFakeLine);
					return;
				}
			}
			else
			{
				this.toolTipTreeItem = null;
			}
		}

		// Token: 0x06000974 RID: 2420 RVA: 0x000548DC File Offset: 0x00052ADC
		private void treeDeviceItemList_ColumnFilterChanged(object sender, EventArgs e)
		{
			this.SetSelectedItems();
		}

		// Token: 0x06000975 RID: 2421 RVA: 0x00055240 File Offset: 0x00053440
		private void treeDeviceItemList_CustomRowFilter(object sender, CustomRowFilterEventArgs e)
		{
			if (e.Node != null && this._showOnlyConnectedDevices)
			{
				DeviceTreeItemBase item = e.Row as DeviceTreeItemBase;
				if (item.Id == this._devicesTree.RootGroupId && string.IsNullOrEmpty(this.treeDevicesList.ActiveFilterString))
				{
					e.Visible = true;
					e.Handled = true;
					return;
				}
				if (e.IsFitDefaultFilter)
				{
					e.Visible = item.IsConnected;
					if (this._showOnlyConnectedSessions && e.Row is AgentItem)
					{
						e.Visible = (item.IsConnected && item.WindowsUser.IsSessionActive());
					}
					e.Handled = true;
				}
			}
		}

		// Token: 0x06000976 RID: 2422 RVA: 0x000552F4 File Offset: 0x000534F4
		private void treeDeviceItemList_FocusedNodeChanged(object sender, FocusedNodeChangedEventArgs e)
		{
			this._devicesTree.SetFocusedItem((e.Node == null) ? null : this.GetTreeItemForNode(e.Node));
		}

		// Token: 0x06000977 RID: 2423 RVA: 0x00055318 File Offset: 0x00053518
		private void treeDeviceItemList_NodeChanged(object sender, NodeChangedEventArgs e)
		{
			if (e.ChangeType == NodeChangeTypeEnum.HasChildren)
			{
				if (e.Node.HasChildren && this.GetTreeItemForNode(e.Node.FirstNode) is DisplayItem)
				{
					return;
				}
				e.Node.Expand();
			}
		}

		// Token: 0x06000978 RID: 2424 RVA: 0x00055354 File Offset: 0x00053554
		private void treeDeviceItemList_SelectionChanged(object sender, EventArgs e)
		{
			if (this._inSelectionChanged)
			{
				return;
			}
			this._inSelectionChanged = true;
			try
			{
				List<TreeListNode> currentSelection = this.treeDevicesList.Selection.ToList<TreeListNode>();
				if (currentSelection.Count > 1)
				{
					bool unselectGroup = false;
					if (currentSelection.Count == this._previousSelection.Count - 1)
					{
						IEnumerable<TreeListNode> unselected = from x in this._previousSelection
						where !currentSelection.Any((TreeListNode x2) => x2.Id == x.Id)
						select x;
						if (unselected.Count<TreeListNode>() == 1)
						{
							DeviceTreeItemBase unselectedItem = this.GetTreeItemForNode(unselected.ElementAt(0));
							if (unselectedItem != null)
							{
								unselectGroup = unselectedItem.IsGroup;
							}
						}
					}
					foreach (TreeListNode node in from x in currentSelection
					where !this._previousSelection.Any((TreeListNode x2) => x2.Id == x.Id)
					select x)
					{
						this.SelectAllNodeChildren(node);
					}
					foreach (TreeListNode node2 in currentSelection)
					{
						DeviceTreeItemBase item = this.GetTreeItemForNode(node2);
						if (item != null)
						{
							if (item.IsGroup)
							{
								this.UnselectNodeIfNotAllChildrenSelected(node2);
							}
							if (!unselectGroup)
							{
								this.SelectNodeIfAllChildrenSelected(node2.ParentNode);
							}
						}
					}
				}
				this._previousSelection = this.treeDevicesList.Selection.ToList<TreeListNode>();
				this.SetSelectedItems();
			}
			finally
			{
				this._inSelectionChanged = false;
			}
		}

		// Token: 0x06000979 RID: 2425 RVA: 0x00055510 File Offset: 0x00053710
		private void treeDevicesList_ColumnChanged(object sender, ColumnChangedEventArgs e)
		{
			this._columnWithUserInetAccessIcon = this.FindColumnWithUserInetAccessIcon();
		}

		// Token: 0x0600097A RID: 2426 RVA: 0x00055520 File Offset: 0x00053720
		private void treeDevicesList_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			if (e.Column == this.columnInetStrictCategory)
			{
				URLCategory category = this._apiClient.URLCategories.FindItemById(e.Value as string);
				e.DisplayText = ((category != null) ? category.Name : null);
				return;
			}
			if (e.Column == this.columnCurrentStrictDesktopId)
			{
				Desktop desktop = this._apiClient.Desktops.FindItemById(e.Value as string);
				e.DisplayText = ((desktop != null) ? desktop.Name : null);
				return;
			}
			if (e.Column == this.columnAppAccess)
			{
				AppControlState? appAccess = e.Value as AppControlState?;
				e.DisplayText = appAccess.Value.GetDescription();
				DeviceTreeItemBase node = this.GetTreeItemForNode(e.Node);
				if (node != null)
				{
					string catName = this.GetAppDesktopOrCategoryName(appAccess.Value, node.CurrentAppCategoryOrDesktopId);
					if (!string.IsNullOrEmpty(catName))
					{
						e.DisplayText = e.DisplayText + " (" + catName + ")";
					}
				}
			}
		}

		// Token: 0x0600097B RID: 2427 RVA: 0x00055624 File Offset: 0x00053824
		private void treeDevicesList_CustomDrawEmptyArea(object sender, CustomDrawEmptyAreaEventArgs e)
		{
			if (this.treeDevicesList.VisibleNodesCount == 0)
			{
				StringFormatInfo drawFormat = new StringFormatInfo(new StringFormat
				{
					Alignment = StringAlignment.Center,
					LineAlignment = StringAlignment.Center
				});
				e.Cache.DrawString(Resources.DevicesTreePanel_Empty, e.Appearance.Font, SystemBrushes.ControlDark, new Rectangle(e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height), drawFormat);
				e.Handled = true;
			}
		}

		// Token: 0x0600097C RID: 2428 RVA: 0x000556BC File Offset: 0x000538BC
		private void treeDevicesList_CustomDrawNodeCell(object sender, CustomDrawNodeCellEventArgs e)
		{
			if (e.Column == this.columnName)
			{
				DeviceTreeItemBase treeItem = this.GetTreeItemForNode(e.Node);
				if (treeItem != null)
				{
					if (treeItem is DeviceItem)
					{
						this.CustomDrawNodeCellImage(e, treeItem.ConnectionTypeIconIndexes, treeItem.DeviceIconIndexes);
						return;
					}
					if (treeItem is AgentItem)
					{
						this.CustomDrawNodeCellImage(e, treeItem.ConnectionTypeIconIndexes, null);
						return;
					}
					if (treeItem is DisplayItem)
					{
						this.CustomDrawNodeCellImage(e, null, null);
						return;
					}
					this.CustomDrawNodeCellImage(e, null, treeItem.DeviceIconIndexes);
					return;
				}
			}
			else if (e.Column == this._columnWithUserInetAccessIcon)
			{
				DeviceTreeItemBase treeItem2 = this.GetTreeItemForNode(e.Node);
				if (((treeItem2 != null) ? treeItem2.WindowsUser : null) == null || treeItem2 is DisplayItem)
				{
					return;
				}
				this.CustomDrawNodeCellImage(e, null, treeItem2.UserIconIndexes);
			}
		}

		// Token: 0x0600097D RID: 2429 RVA: 0x00055780 File Offset: 0x00053980
		private void treeDevicesList_MouseUp(object sender, MouseEventArgs e)
		{
			TreeList treeList = sender as TreeList;
			if (e.Button == MouseButtons.Right && Control.ModifierKeys == Keys.None && treeList.State == TreeListState.Regular)
			{
				Point pt = treeList.PointToClient(Control.MousePosition);
				TreeListHitInfo info = treeList.CalcHitInfo(pt);
				if (info.HitInfoType == HitInfoType.Cell)
				{
					this._itemSelectedByPopupMenuBelongsToSelection = info.Node.IsSelected;
					this._itemSelectedByPopupMenu = this.GetTreeItemForNode(info.Node);
					if (!this._itemSelectedByPopupMenuBelongsToSelection && this._itemSelectedByPopupMenu == null)
					{
						return;
					}
					if (this._itemSelectedByPopupMenuBelongsToSelection)
					{
						this.popupMenu.MenuCaption = this._devicesTree.Selection.Description;
					}
					else if (this._itemSelectedByPopupMenu != null)
					{
						string name = this._itemSelectedByPopupMenu.Name;
						DisplayItem displayItem = this._itemSelectedByPopupMenu as DisplayItem;
						if (displayItem != null)
						{
							name = ((displayItem != null) ? displayItem.AgentItem.DeviceItem.Name : null);
						}
						else
						{
							AgentItem agentItem = this._itemSelectedByPopupMenu as AgentItem;
							if (agentItem != null)
							{
								name = agentItem.DeviceItem.Name;
							}
						}
						this.popupMenu.MenuCaption = string.Format(Resources.DevicesTree_SelectionDescriptionForOneDevice, name);
					}
					this.popupMenu.ShowPopup(Control.MousePosition);
				}
			}
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x000558B7 File Offset: 0x00053AB7
		private void UnselectNodeIfNotAllChildrenSelected(TreeListNode node)
		{
			if (node != null && node.HasChildren && !this.IsAllNodeChildrensSelected(node))
			{
				node.Selected = false;
				this.UnselectNodeIfNotAllChildrenSelected(node.ParentNode);
			}
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x000558E0 File Offset: 0x00053AE0
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				IContainer container = this.components;
				if (container != null)
				{
					container.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x00055900 File Offset: 0x00053B00
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager resources = new ComponentResourceManager(typeof(DevicesTreePanel));
			this.barManager = new BarManager(this.components);
			this.barMainMenu = new Bar();
			this.barButtonSettings = new BarButtonItem();
			this.barEditShowDevicesFilter = new BarEditItem();
			this.repositoryComboBoxShowDevices = new RepositoryItemComboBox();
			this.barCheckShowAutoFilter = new BarCheckItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControlRight = new BarDockControl();
			this.treeDevicesList = new CustomTreeList();
			this.columnName = new TreeListColumn();
			this.columnUserName = new TreeListColumn();
			this.columnDomainName = new TreeListColumn();
			this.columnFullName = new TreeListColumn();
			this.columnDomainAndUserName = new TreeListColumn();
			this.columnAppVersion = new TreeListColumn();
			this.columnConnectionDescription = new TreeListColumn();
			this.columnOsVersion = new TreeListColumn();
			this.columnProjectorStatus = new TreeListColumn();
			this.repositoryImageComboBoxProjectorStatus = new RepositoryItemImageComboBox();
			this.imagesProjector = new ImageCollection(this.components);
			this.columnTypeName = new TreeListColumn();
			this.columnInetStrictCategory = new TreeListColumn();
			this.columnDescription = new TreeListColumn();
			this.columnCurrentStrictDesktopId = new TreeListColumn();
			this.columnAppAccess = new TreeListColumn();
			this.deviceItemBindingSource = new BindingSource(this.components);
			this.toolTipController = new ToolTipController(this.components);
			this.popupMenu = new PopupMenu(this.components);
			((ISupportInitialize)this.barManager).BeginInit();
			((ISupportInitialize)this.repositoryComboBoxShowDevices).BeginInit();
			((ISupportInitialize)this.treeDevicesList).BeginInit();
			((ISupportInitialize)this.repositoryImageComboBoxProjectorStatus).BeginInit();
			((ISupportInitialize)this.imagesProjector).BeginInit();
			((ISupportInitialize)this.deviceItemBindingSource).BeginInit();
			((ISupportInitialize)this.popupMenu).BeginInit();
			base.SuspendLayout();
			this.barManager.AllowCustomization = false;
			this.barManager.AllowQuickCustomization = false;
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.barMainMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.barButtonSettings,
				this.barCheckShowAutoFilter,
				this.barEditShowDevicesFilter
			});
			this.barManager.MainMenu = this.barMainMenu;
			this.barManager.MaxItemId = 19;
			this.barManager.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryComboBoxShowDevices
			});
			this.barMainMenu.BarName = "Main menu";
			this.barMainMenu.DockCol = 0;
			this.barMainMenu.DockRow = 0;
			this.barMainMenu.DockStyle = BarDockStyle.Top;
			this.barMainMenu.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barButtonSettings),
				new LinkPersistInfo(BarLinkUserDefines.Width, this.barEditShowDevicesFilter, "", false, true, true, 163),
				new LinkPersistInfo(this.barCheckShowAutoFilter)
			});
			this.barMainMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMainMenu.OptionsBar.DrawBorder = false;
			this.barMainMenu.OptionsBar.DrawDragBorder = false;
			this.barMainMenu.OptionsBar.MultiLine = true;
			this.barMainMenu.OptionsBar.UseWholeRow = true;
			resources.ApplyResources(this.barMainMenu, "barMainMenu");
			this.barButtonSettings.Alignment = BarItemLinkAlignment.Right;
			resources.ApplyResources(this.barButtonSettings, "barButtonSettings");
			this.barButtonSettings.Id = 0;
			this.barButtonSettings.ImageOptions.Image = (Image)resources.GetObject("barButtonSettings.ImageOptions.Image");
			this.barButtonSettings.ImageOptions.LargeImage = (Image)resources.GetObject("barButtonSettings.ImageOptions.LargeImage");
			this.barButtonSettings.Name = "barButtonSettings";
			this.barButtonSettings.Visibility = BarItemVisibility.Never;
			resources.ApplyResources(this.barEditShowDevicesFilter, "barEditShowDevicesFilter");
			this.barEditShowDevicesFilter.Edit = this.repositoryComboBoxShowDevices;
			this.barEditShowDevicesFilter.Id = 18;
			this.barEditShowDevicesFilter.Name = "barEditShowDevicesFilter";
			this.barEditShowDevicesFilter.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barEditShowDevicesFilter.EditValueChanged += this.barEditShowDevicesFilter_EditValueChanged;
			resources.ApplyResources(this.repositoryComboBoxShowDevices, "repositoryComboBoxShowDevices");
			this.repositoryComboBoxShowDevices.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryComboBoxShowDevices.Buttons"))
			});
			this.repositoryComboBoxShowDevices.Items.AddRange(new object[]
			{
				resources.GetString("repositoryComboBoxShowDevices.Items"),
				resources.GetString("repositoryComboBoxShowDevices.Items1"),
				resources.GetString("repositoryComboBoxShowDevices.Items2")
			});
			this.repositoryComboBoxShowDevices.Name = "repositoryComboBoxShowDevices";
			this.repositoryComboBoxShowDevices.TextEditStyle = TextEditStyles.DisableTextEditor;
			resources.ApplyResources(this.barCheckShowAutoFilter, "barCheckShowAutoFilter");
			this.barCheckShowAutoFilter.Id = 8;
			this.barCheckShowAutoFilter.ImageOptions.Image = (Image)resources.GetObject("barCheckShowAutoFilter.ImageOptions.Image");
			this.barCheckShowAutoFilter.ImageOptions.LargeImage = (Image)resources.GetObject("barCheckShowAutoFilter.ImageOptions.LargeImage");
			this.barCheckShowAutoFilter.Name = "barCheckShowAutoFilter";
			this.barCheckShowAutoFilter.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barCheckShowAutoFilter.CheckedChanged += this.barCheckShowAutoFilter_CheckedChanged;
			this.barDockControlTop.CausesValidation = false;
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlBottom.CausesValidation = false;
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlLeft.CausesValidation = false;
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControlRight.CausesValidation = false;
			resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
			this.barDockControlRight.Manager = this.barManager;
			this.treeDevicesList.Columns.AddRange(new TreeListColumn[]
			{
				this.columnName,
				this.columnUserName,
				this.columnDomainName,
				this.columnFullName,
				this.columnDomainAndUserName,
				this.columnAppVersion,
				this.columnConnectionDescription,
				this.columnOsVersion,
				this.columnProjectorStatus,
				this.columnTypeName,
				this.columnInetStrictCategory,
				this.columnDescription,
				this.columnCurrentStrictDesktopId,
				this.columnAppAccess
			});
			this.treeDevicesList.CustomizationFormBounds = new Rectangle(2510, 231, 250, 212);
			this.treeDevicesList.DataSource = this.deviceItemBindingSource;
			resources.ApplyResources(this.treeDevicesList, "treeDevicesList");
			this.treeDevicesList.ImageIndexFieldName = "IconIndex";
			this.treeDevicesList.KeyFieldName = "Id";
			this.treeDevicesList.Name = "treeDevicesList";
			this.treeDevicesList.OptionsBehavior.AutoChangeParent = false;
			this.treeDevicesList.OptionsBehavior.Editable = false;
			this.treeDevicesList.OptionsFilter.AllowAutoFilterConditionChange = DefaultBoolean.False;
			this.treeDevicesList.OptionsFilter.FilterMode = FilterMode.Matches;
			this.treeDevicesList.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.treeDevicesList.OptionsSelection.KeepSelectedOnClick = false;
			this.treeDevicesList.OptionsSelection.MultiSelect = true;
			this.treeDevicesList.OptionsView.ShowHorzLines = false;
			this.treeDevicesList.OptionsView.ShowVertLines = false;
			this.treeDevicesList.ParentFieldName = "ParentId";
			this.treeDevicesList.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryImageComboBoxProjectorStatus
			});
			this.treeDevicesList.ToolTipController = this.toolTipController;
			this.treeDevicesList.UseDirectXPaint = DefaultBoolean.False;
			this.treeDevicesList.ColumnChanged += this.treeDevicesList_ColumnChanged;
			this.treeDevicesList.NodeChanged += this.treeDeviceItemList_NodeChanged;
			this.treeDevicesList.FocusedNodeChanged += this.treeDeviceItemList_FocusedNodeChanged;
			this.treeDevicesList.CustomColumnDisplayText += this.treeDevicesList_CustomColumnDisplayText;
			this.treeDevicesList.SelectionChanged += this.treeDeviceItemList_SelectionChanged;
			this.treeDevicesList.CustomDrawNodeCell += this.treeDevicesList_CustomDrawNodeCell;
			this.treeDevicesList.CustomDrawEmptyArea += this.treeDevicesList_CustomDrawEmptyArea;
			this.treeDevicesList.CustomRowFilter += this.treeDeviceItemList_CustomRowFilter;
			this.treeDevicesList.ColumnFilterChanged += this.treeDeviceItemList_ColumnFilterChanged;
			this.treeDevicesList.MouseUp += this.treeDevicesList_MouseUp;
			this.columnName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnName, "columnName");
			this.columnName.FieldName = "Name";
			this.columnName.Name = "columnName";
			this.columnName.OptionsColumn.AllowMoveToCustomizationForm = false;
			this.columnName.OptionsColumn.ShowInCustomizationForm = false;
			this.columnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUserName, "columnUserName");
			this.columnUserName.FieldName = "UserName";
			this.columnUserName.Name = "columnUserName";
			this.columnDomainName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDomainName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDomainName, "columnDomainName");
			this.columnDomainName.FieldName = "DomainName";
			this.columnDomainName.Name = "columnDomainName";
			this.columnFullName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnFullName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnFullName, "columnFullName");
			this.columnFullName.FieldName = "UserFullName";
			this.columnFullName.Name = "columnFullName";
			this.columnDomainAndUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDomainAndUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDomainAndUserName, "columnDomainAndUserName");
			this.columnDomainAndUserName.FieldName = "DomainAndUserName";
			this.columnDomainAndUserName.Name = "columnDomainAndUserName";
			this.columnAppVersion.AppearanceHeader.Options.UseTextOptions = true;
			this.columnAppVersion.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnAppVersion, "columnAppVersion");
			this.columnAppVersion.FieldName = "AppVersion";
			this.columnAppVersion.Name = "columnAppVersion";
			this.columnConnectionDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnConnectionDescription.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnConnectionDescription, "columnConnectionDescription");
			this.columnConnectionDescription.FieldName = "ConnectionDescription";
			this.columnConnectionDescription.Name = "columnConnectionDescription";
			this.columnOsVersion.AppearanceHeader.Options.UseTextOptions = true;
			this.columnOsVersion.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnOsVersion, "columnOsVersion");
			this.columnOsVersion.FieldName = "OsVersion";
			this.columnOsVersion.Name = "columnOsVersion";
			this.columnProjectorStatus.AppearanceHeader.Options.UseTextOptions = true;
			this.columnProjectorStatus.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Far;
			resources.ApplyResources(this.columnProjectorStatus, "columnProjectorStatus");
			this.columnProjectorStatus.ColumnEdit = this.repositoryImageComboBoxProjectorStatus;
			this.columnProjectorStatus.FieldName = "ProjectorStatus";
			this.columnProjectorStatus.Name = "columnProjectorStatus";
			this.columnProjectorStatus.OptionsColumn.AllowEdit = false;
			this.columnProjectorStatus.OptionsColumn.AllowFocus = false;
			this.columnProjectorStatus.OptionsColumn.AllowMove = false;
			this.columnProjectorStatus.OptionsColumn.AllowMoveToCustomizationForm = false;
			this.columnProjectorStatus.OptionsColumn.AllowSize = false;
			this.columnProjectorStatus.OptionsColumn.AllowSort = false;
			this.columnProjectorStatus.OptionsColumn.FixedWidth = true;
			this.columnProjectorStatus.OptionsColumn.ReadOnly = true;
			this.columnProjectorStatus.OptionsColumn.ShowInCustomizationForm = false;
			this.columnProjectorStatus.OptionsColumn.ShowInExpressionEditor = false;
			this.columnProjectorStatus.OptionsFilter.AllowAutoFilter = false;
			this.columnProjectorStatus.OptionsFilter.AllowFilter = false;
			resources.ApplyResources(this.repositoryImageComboBoxProjectorStatus, "repositoryImageComboBoxProjectorStatus");
			this.repositoryImageComboBoxProjectorStatus.Items.AddRange(new ImageComboBoxItem[]
			{
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxProjectorStatus.Items"), resources.GetObject("repositoryImageComboBoxProjectorStatus.Items1"), (int)resources.GetObject("repositoryImageComboBoxProjectorStatus.Items2")),
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxProjectorStatus.Items3"), resources.GetObject("repositoryImageComboBoxProjectorStatus.Items4"), (int)resources.GetObject("repositoryImageComboBoxProjectorStatus.Items5")),
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxProjectorStatus.Items6"), resources.GetObject("repositoryImageComboBoxProjectorStatus.Items7"), (int)resources.GetObject("repositoryImageComboBoxProjectorStatus.Items8")),
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxProjectorStatus.Items9"), resources.GetObject("repositoryImageComboBoxProjectorStatus.Items10"), (int)resources.GetObject("repositoryImageComboBoxProjectorStatus.Items11")),
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxProjectorStatus.Items12"), resources.GetObject("repositoryImageComboBoxProjectorStatus.Items13"), (int)resources.GetObject("repositoryImageComboBoxProjectorStatus.Items14")),
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxProjectorStatus.Items15"), resources.GetObject("repositoryImageComboBoxProjectorStatus.Items16"), (int)resources.GetObject("repositoryImageComboBoxProjectorStatus.Items17")),
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxProjectorStatus.Items18"), resources.GetObject("repositoryImageComboBoxProjectorStatus.Items19"), (int)resources.GetObject("repositoryImageComboBoxProjectorStatus.Items20"))
			});
			this.repositoryImageComboBoxProjectorStatus.LargeImages = this.imagesProjector;
			this.repositoryImageComboBoxProjectorStatus.Name = "repositoryImageComboBoxProjectorStatus";
			this.imagesProjector.ImageStream = (ImageCollectionStreamer)resources.GetObject("imagesProjector.ImageStream");
			this.imagesProjector.InsertGalleryImage("pause_16x16.png", "images/arrows/pause_16x16.png", ImageResourceCache.Default.GetImage("images/arrows/pause_16x16.png"), 0);
			this.imagesProjector.Images.SetKeyName(0, "pause_16x16.png");
			this.imagesProjector.InsertGalleryImage("play_16x16.png", "images/arrows/play_16x16.png", ImageResourceCache.Default.GetImage("images/arrows/play_16x16.png"), 1);
			this.imagesProjector.Images.SetKeyName(1, "play_16x16.png");
			this.imagesProjector.InsertGalleryImage("close_16x16.png", "images/actions/close_16x16.png", ImageResourceCache.Default.GetImage("images/actions/close_16x16.png"), 2);
			this.imagesProjector.Images.SetKeyName(2, "close_16x16.png");
			this.imagesProjector.InsertGalleryImage("deletelist_16x16.png", "images/actions/deletelist_16x16.png", ImageResourceCache.Default.GetImage("images/actions/deletelist_16x16.png"), 3);
			this.imagesProjector.Images.SetKeyName(3, "deletelist_16x16.png");
			this.imagesProjector.InsertGalleryImage("windows_16x16.png", "images/miscellaneous/windows_16x16.png", ImageResourceCache.Default.GetImage("images/miscellaneous/windows_16x16.png"), 4);
			this.imagesProjector.Images.SetKeyName(4, "windows_16x16.png");
			this.imagesProjector.InsertGalleryImage("convert_16x16.png", "images/actions/convert_16x16.png", ImageResourceCache.Default.GetImage("images/actions/convert_16x16.png"), 5);
			this.imagesProjector.Images.SetKeyName(5, "convert_16x16.png");
			this.columnTypeName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnTypeName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnTypeName, "columnTypeName");
			this.columnTypeName.FieldName = "TypeName";
			this.columnTypeName.Name = "columnTypeName";
			this.columnTypeName.OptionsColumn.AllowMoveToCustomizationForm = false;
			this.columnTypeName.OptionsColumn.ShowInCustomizationForm = false;
			this.columnTypeName.OptionsColumn.ShowInExpressionEditor = false;
			this.columnInetStrictCategory.AppearanceHeader.Options.UseTextOptions = true;
			this.columnInetStrictCategory.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnInetStrictCategory, "columnInetStrictCategory");
			this.columnInetStrictCategory.FieldName = "CurrentInetStrictCategoryId";
			this.columnInetStrictCategory.Name = "columnInetStrictCategory";
			this.columnDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDescription.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDescription, "columnDescription");
			this.columnDescription.FieldName = "Description";
			this.columnDescription.Name = "columnDescription";
			this.columnCurrentStrictDesktopId.AppearanceHeader.Options.UseTextOptions = true;
			this.columnCurrentStrictDesktopId.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnCurrentStrictDesktopId, "columnCurrentStrictDesktopId");
			this.columnCurrentStrictDesktopId.FieldName = "CurrentAppStrictDesktopId";
			this.columnCurrentStrictDesktopId.Name = "columnCurrentStrictDesktopId";
			resources.ApplyResources(this.columnAppAccess, "columnAppAccess");
			this.columnAppAccess.FieldName = "AppAccess";
			this.columnAppAccess.Name = "columnAppAccess";
			this.deviceItemBindingSource.AllowNew = true;
			this.deviceItemBindingSource.DataSource = typeof(DeviceTreeItemBase);
			this.toolTipController.InitialDelay = 1000;
			this.toolTipController.ReshowDelay = 1000;
			this.toolTipController.GetActiveObjectInfo += this.toolTipController_GetActiveObjectInfo;
			this.toolTipController.BeforeShow += this.toolTipController_BeforeShow;
			this.popupMenu.Manager = this.barManager;
			this.popupMenu.Name = "popupMenu";
			this.popupMenu.ShowCaption = true;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.treeDevicesList);
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "DevicesTreePanel";
			base.Load += this.DevicesTreePanel_Load;
			((ISupportInitialize)this.barManager).EndInit();
			((ISupportInitialize)this.repositoryComboBoxShowDevices).EndInit();
			((ISupportInitialize)this.treeDevicesList).EndInit();
			((ISupportInitialize)this.repositoryImageComboBoxProjectorStatus).EndInit();
			((ISupportInitialize)this.imagesProjector).EndInit();
			((ISupportInitialize)this.deviceItemBindingSource).EndInit();
			((ISupportInitialize)this.popupMenu).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000737 RID: 1847
		private ApiClient _apiClient;

		// Token: 0x04000738 RID: 1848
		private TreeListColumn _columnWithUserInetAccessIcon;

		// Token: 0x04000739 RID: 1849
		private DevicesTree _devicesTree;

		// Token: 0x0400073A RID: 1850
		private FormsSettings _formsSettings;

		// Token: 0x0400073B RID: 1851
		private IIconsProvider _iconsProvider;

		// Token: 0x0400073C RID: 1852
		private bool _inSelectionChanged;

		// Token: 0x0400073D RID: 1853
		private DeviceTreeItemBase _itemSelectedByPopupMenu;

		// Token: 0x0400073E RID: 1854
		private bool _itemSelectedByPopupMenuBelongsToSelection;

		// Token: 0x0400073F RID: 1855
		private ObservableAgregator _observableAgregator;

		// Token: 0x04000740 RID: 1856
		private bool _panelLoaded;

		// Token: 0x04000741 RID: 1857
		private List<TreeListNode> _previousSelection;

		// Token: 0x04000742 RID: 1858
		private bool _showOnlyConnectedDevices;

		// Token: 0x04000743 RID: 1859
		private bool _showOnlyConnectedSessions;

		// Token: 0x04000744 RID: 1860
		private ImageCollection _treeImages;

		// Token: 0x04000745 RID: 1861
		private DeviceTreeItemBase toolTipTreeItem;

		// Token: 0x04000746 RID: 1862
		private IContainer components;

		// Token: 0x04000747 RID: 1863
		private BarManager barManager;

		// Token: 0x04000748 RID: 1864
		private Bar barMainMenu;

		// Token: 0x04000749 RID: 1865
		private BarDockControl barDockControlTop;

		// Token: 0x0400074A RID: 1866
		private BarDockControl barDockControlBottom;

		// Token: 0x0400074B RID: 1867
		private BarDockControl barDockControlLeft;

		// Token: 0x0400074C RID: 1868
		private BarDockControl barDockControlRight;

		// Token: 0x0400074D RID: 1869
		private CustomTreeList treeDevicesList;

		// Token: 0x0400074E RID: 1870
		private BarButtonItem barButtonSettings;

		// Token: 0x0400074F RID: 1871
		private BindingSource deviceItemBindingSource;

		// Token: 0x04000750 RID: 1872
		private TreeListColumn columnName;

		// Token: 0x04000751 RID: 1873
		private TreeListColumn columnAppVersion;

		// Token: 0x04000752 RID: 1874
		private TreeListColumn columnConnectionDescription;

		// Token: 0x04000753 RID: 1875
		private TreeListColumn columnOsVersion;

		// Token: 0x04000754 RID: 1876
		private TreeListColumn columnFullName;

		// Token: 0x04000755 RID: 1877
		private TreeListColumn columnDomainAndUserName;

		// Token: 0x04000756 RID: 1878
		private TreeListColumn columnUserName;

		// Token: 0x04000757 RID: 1879
		private TreeListColumn columnDomainName;

		// Token: 0x04000758 RID: 1880
		private ImageCollection imagesProjector;

		// Token: 0x04000759 RID: 1881
		private TreeListColumn columnProjectorStatus;

		// Token: 0x0400075A RID: 1882
		private RepositoryItemImageComboBox repositoryImageComboBoxProjectorStatus;

		// Token: 0x0400075B RID: 1883
		private BarCheckItem barCheckShowAutoFilter;

		// Token: 0x0400075C RID: 1884
		private TreeListColumn columnTypeName;

		// Token: 0x0400075D RID: 1885
		private PopupMenu popupMenu;

		// Token: 0x0400075E RID: 1886
		private BarEditItem barEditShowDevicesFilter;

		// Token: 0x0400075F RID: 1887
		private RepositoryItemComboBox repositoryComboBoxShowDevices;

		// Token: 0x04000760 RID: 1888
		private TreeListColumn columnInetStrictCategory;

		// Token: 0x04000761 RID: 1889
		private TreeListColumn columnDescription;

		// Token: 0x04000762 RID: 1890
		private TreeListColumn columnCurrentStrictDesktopId;

		// Token: 0x04000763 RID: 1891
		private TreeListColumn columnAppAccess;

		// Token: 0x04000764 RID: 1892
		private ToolTipController toolTipController;
	}
}
