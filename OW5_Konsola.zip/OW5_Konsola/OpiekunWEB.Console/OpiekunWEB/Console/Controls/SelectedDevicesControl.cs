﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Data;
using DevExpress.XtraTreeList.Nodes;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Controls
{
	// Token: 0x020000B4 RID: 180
	public class SelectedDevicesControl : BaseUserControl
	{
		// Token: 0x0600092B RID: 2347 RVA: 0x00052A72 File Offset: 0x00050C72
		public SelectedDevicesControl()
		{
			this.InitializeComponent();
			this._additionalItemData = new Dictionary<string, SelectedDevicesControl.AdditionalItemData>();
			this.Devices = new BindingList<DeviceTreeItemBase>();
			this._messageForDeviceTypeShowed = new List<DeviceType>();
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x0600092C RID: 2348 RVA: 0x00052AA1 File Offset: 0x00050CA1
		public List<DeviceTreeItemBase> DevicesSelected
		{
			get
			{
				return (from x in this.Devices
				where x.IsSelected
				select x).ToList<DeviceTreeItemBase>();
			}
		}

		// Token: 0x0600092D RID: 2349 RVA: 0x00052AD2 File Offset: 0x00050CD2
		public void ClearDevicesSelected()
		{
			this.SetDevicesSelected(null);
		}

		// Token: 0x0600092E RID: 2350 RVA: 0x00052ADB File Offset: 0x00050CDB
		public object GetDeviceObject(string deviceId)
		{
			SelectedDevicesControl.AdditionalItemData additionalItemData = this.GetAdditionalItemData(deviceId, false);
			if (additionalItemData == null)
			{
				return null;
			}
			return additionalItemData.Object;
		}

		// Token: 0x0600092F RID: 2351 RVA: 0x00052AF0 File Offset: 0x00050CF0
		public string GetMessageForDevice(string deviceId)
		{
			SelectedDevicesControl.AdditionalItemData ad = this.GetAdditionalItemData(deviceId, false);
			if (ad == null)
			{
				return string.Empty;
			}
			return ad.Message;
		}

		// Token: 0x06000930 RID: 2352 RVA: 0x00052B18 File Offset: 0x00050D18
		public void SetDevices(List<DeviceItem> devicesList, bool showOnlyConnected, bool showDesktop, bool showTerminalServer, bool showTerminalClient, bool showSectionColumn)
		{
			this.columnIsSelected.Visible = showSectionColumn;
			this.Devices.Clear();
			this._messageForDeviceTypeShowed.Clear();
			foreach (DeviceItem device in devicesList)
			{
				if ((!showOnlyConnected || device.IsConnected) && !this.IsMessageForDeviceTypeShowed(device.DeviceType))
				{
					switch (device.DeviceType)
					{
					case DeviceType.UnknownDeviceType:
						continue;
					case DeviceType.Desktop:
						if (!showDesktop)
						{
							LabelControl labelControl = this.labelInfo;
							labelControl.Text = labelControl.Text + "\r\n- " + device.DeviceType.GetDescription();
							this.panelInfo.Visible = true;
							this._messageForDeviceTypeShowed.Add(device.DeviceType);
							continue;
						}
						break;
					case DeviceType.TerminalServer:
						if (!showTerminalServer)
						{
							LabelControl labelControl2 = this.labelInfo;
							labelControl2.Text = labelControl2.Text + "\r\n- " + device.DeviceType.GetDescription();
							this.panelInfo.Visible = true;
							this._messageForDeviceTypeShowed.Add(device.DeviceType);
							continue;
						}
						break;
					case DeviceType.TerminalClient:
						if (!showTerminalClient)
						{
							LabelControl labelControl3 = this.labelInfo;
							labelControl3.Text = labelControl3.Text + "\r\n- " + device.DeviceType.GetDescription();
							this.panelInfo.Visible = true;
							this._messageForDeviceTypeShowed.Add(device.DeviceType);
							continue;
						}
						break;
					}
					this.Devices.Add(device);
				}
			}
			this.treeDevicesList.DataSource = this.Devices;
		}

		// Token: 0x06000931 RID: 2353 RVA: 0x00052CD8 File Offset: 0x00050ED8
		public void SetDevicesSelected(List<DeviceItem> selectedDevices)
		{
			foreach (DeviceTreeItemBase device in this.Devices)
			{
				device.IsSelected = (selectedDevices != null && selectedDevices.Contains(device));
			}
		}

		// Token: 0x06000932 RID: 2354 RVA: 0x00052D34 File Offset: 0x00050F34
		public void SetDevicesTreeReadOnly(bool value)
		{
			this.treeDevicesList.OptionsBehavior.ReadOnly = value;
		}

		// Token: 0x06000933 RID: 2355 RVA: 0x00052D47 File Offset: 0x00050F47
		public void SetIconsProvider(IIconsProvider iconsProvider)
		{
			this.treeDevicesList.SelectImageList = iconsProvider.DevicesTreeImages24x24;
		}

		// Token: 0x06000934 RID: 2356 RVA: 0x00052D5A File Offset: 0x00050F5A
		public void SetMessageForDevice(string deviceId, string message)
		{
			this.GetAdditionalItemData(deviceId, true).Message = message;
			this.treeDevicesList.RefreshDataSource();
		}

		// Token: 0x06000935 RID: 2357 RVA: 0x00052D75 File Offset: 0x00050F75
		public void SetObjectForDevice(string deviceId, object obj)
		{
			this.GetAdditionalItemData(deviceId, true).Object = obj;
		}

		// Token: 0x06000936 RID: 2358 RVA: 0x00052D85 File Offset: 0x00050F85
		public void SetStatusImageForDevice(string deviceId, Bitmap image)
		{
			this.GetAdditionalItemData(deviceId, true).StatusImage = image;
			this.treeDevicesList.RefreshDataSource();
		}

		// Token: 0x06000937 RID: 2359 RVA: 0x00052DA0 File Offset: 0x00050FA0
		private SelectedDevicesControl.AdditionalItemData GetAdditionalItemData(string deviceId, bool createNew)
		{
			SelectedDevicesControl.AdditionalItemData result;
			this._additionalItemData.TryGetValue(deviceId, out result);
			if (result == null && createNew)
			{
				result = new SelectedDevicesControl.AdditionalItemData();
				this._additionalItemData[deviceId] = result;
			}
			return result;
		}

		// Token: 0x06000938 RID: 2360 RVA: 0x00052DD8 File Offset: 0x00050FD8
		private DeviceTreeItemBase GetTreeItemForNode(TreeListNode node)
		{
			return this.treeDevicesList.GetDataRecordByNode(node) as DeviceTreeItemBase;
		}

		// Token: 0x06000939 RID: 2361 RVA: 0x00052DEC File Offset: 0x00050FEC
		private bool IsMessageForDeviceTypeShowed(DeviceType deviceType)
		{
			using (List<DeviceType>.Enumerator enumerator = this._messageForDeviceTypeShowed.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current == deviceType)
					{
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x0600093A RID: 2362 RVA: 0x00052E44 File Offset: 0x00051044
		private void treeDevicesList_CustomUnboundColumnData(object sender, TreeListCustomColumnDataEventArgs e)
		{
			if (!e.IsGetData)
			{
				return;
			}
			DeviceTreeItemBase treeItem = e.Row as DeviceTreeItemBase;
			if (treeItem == null)
			{
				return;
			}
			SelectedDevicesControl.AdditionalItemData ad = this.GetAdditionalItemData(treeItem.Id, false);
			if (ad == null)
			{
				e.Value = null;
				return;
			}
			if (e.Column == this.columnMessage)
			{
				e.Value = ad.Message;
				return;
			}
			if (e.Column == this.columnStatusImage)
			{
				e.Value = ad.StatusImage;
			}
		}

		// Token: 0x0600093B RID: 2363 RVA: 0x00052EB8 File Offset: 0x000510B8
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600093C RID: 2364 RVA: 0x00052ED8 File Offset: 0x000510D8
		private void InitializeComponent()
		{
			ComponentResourceManager resources = new ComponentResourceManager(typeof(SelectedDevicesControl));
			this.treeDevicesList = new TreeList();
			this.columnName = new TreeListColumn();
			this.columnStatusImage = new TreeListColumn();
			this.repositoryItemPictureEditStatusImage = new RepositoryItemPictureEdit();
			this.columnUserName = new TreeListColumn();
			this.columnDomainName = new TreeListColumn();
			this.columnFullName = new TreeListColumn();
			this.columnDomainAndUserName = new TreeListColumn();
			this.columnAgentVersion = new TreeListColumn();
			this.columnConnectionDescription = new TreeListColumn();
			this.columnOsVersion = new TreeListColumn();
			this.columnProjectorStatus = new TreeListColumn();
			this.repositoryImageComboBoxProjectorStatus = new RepositoryItemImageComboBox();
			this.columnMessage = new TreeListColumn();
			this.columnIsSelected = new TreeListColumn();
			this.repositoryItemCheckEditIsSelected = new RepositoryItemCheckEdit();
			this.columnId = new TreeListColumn();
			this.panelInfo = new PanelControl();
			this.labelInfo = new LabelControl();
			((ISupportInitialize)this.treeDevicesList).BeginInit();
			((ISupportInitialize)this.repositoryItemPictureEditStatusImage).BeginInit();
			((ISupportInitialize)this.repositoryImageComboBoxProjectorStatus).BeginInit();
			((ISupportInitialize)this.repositoryItemCheckEditIsSelected).BeginInit();
			((ISupportInitialize)this.panelInfo).BeginInit();
			this.panelInfo.SuspendLayout();
			base.SuspendLayout();
			this.treeDevicesList.Appearance.Caption.Options.UseTextOptions = true;
			this.treeDevicesList.Appearance.Caption.TextOptions.HAlignment = HorzAlignment.Near;
			this.treeDevicesList.Columns.AddRange(new TreeListColumn[]
			{
				this.columnName,
				this.columnStatusImage,
				this.columnUserName,
				this.columnDomainName,
				this.columnFullName,
				this.columnDomainAndUserName,
				this.columnAgentVersion,
				this.columnConnectionDescription,
				this.columnOsVersion,
				this.columnProjectorStatus,
				this.columnMessage,
				this.columnIsSelected,
				this.columnId
			});
			this.treeDevicesList.Cursor = Cursors.Default;
			this.treeDevicesList.CustomizationFormBounds = new Rectangle(2510, 231, 250, 212);
			resources.ApplyResources(this.treeDevicesList, "treeDevicesList");
			this.treeDevicesList.ImageIndexFieldName = "IconIndex";
			this.treeDevicesList.KeyFieldName = "Id";
			this.treeDevicesList.Name = "treeDevicesList";
			this.treeDevicesList.OptionsFilter.AllowAutoFilterConditionChange = DefaultBoolean.False;
			this.treeDevicesList.OptionsFilter.FilterMode = FilterMode.Matches;
			this.treeDevicesList.OptionsMenu.EnableColumnMenu = false;
			this.treeDevicesList.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.treeDevicesList.OptionsSelection.MultiSelect = true;
			this.treeDevicesList.OptionsView.AnimationType = TreeListAnimationType.AnimateAllContent;
			this.treeDevicesList.OptionsView.ShowHorzLines = false;
			this.treeDevicesList.OptionsView.ShowVertLines = false;
			this.treeDevicesList.ParentFieldName = "ParentId";
			this.treeDevicesList.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryImageComboBoxProjectorStatus,
				this.repositoryItemPictureEditStatusImage,
				this.repositoryItemCheckEditIsSelected
			});
			this.treeDevicesList.CustomUnboundColumnData += this.treeDevicesList_CustomUnboundColumnData;
			this.columnName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnName, "columnName");
			this.columnName.FieldName = "Name";
			this.columnName.Name = "columnName";
			this.columnName.OptionsColumn.AllowEdit = false;
			this.columnName.OptionsFilter.AllowAutoFilter = false;
			this.columnName.OptionsFilter.AllowFilter = false;
			this.columnStatusImage.AppearanceHeader.Options.UseTextOptions = true;
			this.columnStatusImage.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnStatusImage, "columnStatusImage");
			this.columnStatusImage.ColumnEdit = this.repositoryItemPictureEditStatusImage;
			this.columnStatusImage.FieldName = "StatusImage";
			this.columnStatusImage.Name = "columnStatusImage";
			this.columnStatusImage.OptionsColumn.AllowEdit = false;
			this.columnStatusImage.OptionsFilter.AllowAutoFilter = false;
			this.columnStatusImage.OptionsFilter.AllowFilter = false;
			this.columnStatusImage.UnboundType = UnboundColumnType.Object;
			this.repositoryItemPictureEditStatusImage.Name = "repositoryItemPictureEditStatusImage";
			resources.ApplyResources(this.repositoryItemPictureEditStatusImage, "repositoryItemPictureEditStatusImage");
			this.columnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUserName, "columnUserName");
			this.columnUserName.FieldName = "WindowsUser.UserName";
			this.columnUserName.Name = "columnUserName";
			this.columnUserName.OptionsColumn.AllowEdit = false;
			this.columnUserName.OptionsFilter.AllowAutoFilter = false;
			this.columnUserName.OptionsFilter.AllowFilter = false;
			this.columnDomainName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDomainName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDomainName, "columnDomainName");
			this.columnDomainName.FieldName = "WindowsUser.DomainName";
			this.columnDomainName.Name = "columnDomainName";
			this.columnDomainName.OptionsColumn.AllowEdit = false;
			this.columnDomainName.OptionsFilter.AllowAutoFilter = false;
			this.columnDomainName.OptionsFilter.AllowFilter = false;
			this.columnFullName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnFullName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnFullName, "columnFullName");
			this.columnFullName.FieldName = "WindowsUser.FullName";
			this.columnFullName.Name = "columnFullName";
			this.columnFullName.OptionsColumn.AllowEdit = false;
			this.columnFullName.OptionsFilter.AllowAutoFilter = false;
			this.columnFullName.OptionsFilter.AllowFilter = false;
			this.columnDomainAndUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDomainAndUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDomainAndUserName, "columnDomainAndUserName");
			this.columnDomainAndUserName.FieldName = "DomainAndUserName";
			this.columnDomainAndUserName.Name = "columnDomainAndUserName";
			this.columnDomainAndUserName.OptionsColumn.AllowEdit = false;
			this.columnDomainAndUserName.OptionsFilter.AllowAutoFilter = false;
			this.columnDomainAndUserName.OptionsFilter.AllowFilter = false;
			this.columnAgentVersion.AppearanceHeader.Options.UseTextOptions = true;
			this.columnAgentVersion.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnAgentVersion, "columnAgentVersion");
			this.columnAgentVersion.FieldName = "AppVersion";
			this.columnAgentVersion.Name = "columnAgentVersion";
			this.columnAgentVersion.OptionsColumn.AllowEdit = false;
			this.columnAgentVersion.OptionsFilter.AllowAutoFilter = false;
			this.columnAgentVersion.OptionsFilter.AllowFilter = false;
			this.columnConnectionDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnConnectionDescription.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnConnectionDescription, "columnConnectionDescription");
			this.columnConnectionDescription.FieldName = "ConnectionDescription";
			this.columnConnectionDescription.Name = "columnConnectionDescription";
			this.columnConnectionDescription.OptionsColumn.AllowEdit = false;
			this.columnConnectionDescription.OptionsFilter.AllowAutoFilter = false;
			this.columnConnectionDescription.OptionsFilter.AllowFilter = false;
			this.columnOsVersion.AppearanceHeader.Options.UseTextOptions = true;
			this.columnOsVersion.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnOsVersion, "columnOsVersion");
			this.columnOsVersion.FieldName = "OsVersion";
			this.columnOsVersion.Name = "columnOsVersion";
			this.columnOsVersion.OptionsColumn.AllowEdit = false;
			this.columnOsVersion.OptionsFilter.AllowAutoFilter = false;
			this.columnOsVersion.OptionsFilter.AllowFilter = false;
			this.columnProjectorStatus.AppearanceHeader.Options.UseTextOptions = true;
			this.columnProjectorStatus.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Far;
			resources.ApplyResources(this.columnProjectorStatus, "columnProjectorStatus");
			this.columnProjectorStatus.ColumnEdit = this.repositoryImageComboBoxProjectorStatus;
			this.columnProjectorStatus.FieldName = "ProjectorStatus";
			this.columnProjectorStatus.Name = "columnProjectorStatus";
			this.columnProjectorStatus.OptionsColumn.AllowEdit = false;
			this.columnProjectorStatus.OptionsColumn.AllowFocus = false;
			this.columnProjectorStatus.OptionsColumn.AllowMove = false;
			this.columnProjectorStatus.OptionsColumn.AllowMoveToCustomizationForm = false;
			this.columnProjectorStatus.OptionsColumn.AllowSize = false;
			this.columnProjectorStatus.OptionsColumn.AllowSort = false;
			this.columnProjectorStatus.OptionsColumn.FixedWidth = true;
			this.columnProjectorStatus.OptionsColumn.ReadOnly = true;
			this.columnProjectorStatus.OptionsColumn.ShowInCustomizationForm = false;
			this.columnProjectorStatus.OptionsColumn.ShowInExpressionEditor = false;
			this.columnProjectorStatus.OptionsFilter.AllowAutoFilter = false;
			this.columnProjectorStatus.OptionsFilter.AllowFilter = false;
			resources.ApplyResources(this.repositoryImageComboBoxProjectorStatus, "repositoryImageComboBoxProjectorStatus");
			this.repositoryImageComboBoxProjectorStatus.Name = "repositoryImageComboBoxProjectorStatus";
			this.columnMessage.AppearanceHeader.Options.UseTextOptions = true;
			this.columnMessage.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnMessage, "columnMessage");
			this.columnMessage.FieldName = "Message";
			this.columnMessage.Name = "columnMessage";
			this.columnMessage.OptionsColumn.AllowEdit = false;
			this.columnMessage.OptionsFilter.AllowAutoFilter = false;
			this.columnMessage.OptionsFilter.AllowFilter = false;
			this.columnMessage.UnboundType = UnboundColumnType.String;
			resources.ApplyResources(this.columnIsSelected, "columnIsSelected");
			this.columnIsSelected.ColumnEdit = this.repositoryItemCheckEditIsSelected;
			this.columnIsSelected.FieldName = "IsSelected";
			this.columnIsSelected.Name = "columnIsSelected";
			resources.ApplyResources(this.repositoryItemCheckEditIsSelected, "repositoryItemCheckEditIsSelected");
			this.repositoryItemCheckEditIsSelected.Name = "repositoryItemCheckEditIsSelected";
			this.repositoryItemCheckEditIsSelected.NullStyle = StyleIndeterminate.Unchecked;
			this.columnId.FieldName = "Id";
			this.columnId.Name = "columnId";
			this.panelInfo.Controls.Add(this.labelInfo);
			resources.ApplyResources(this.panelInfo, "panelInfo");
			this.panelInfo.Name = "panelInfo";
			resources.ApplyResources(this.labelInfo, "labelInfo");
			this.labelInfo.ImageAlignToText = ImageAlignToText.LeftTop;
			this.labelInfo.ImageOptions.Image = Resources.question_32x32;
			this.labelInfo.Name = "labelInfo";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.panelInfo);
			base.Controls.Add(this.treeDevicesList);
			base.Name = "SelectedDevicesControl";
			((ISupportInitialize)this.treeDevicesList).EndInit();
			((ISupportInitialize)this.repositoryItemPictureEditStatusImage).EndInit();
			((ISupportInitialize)this.repositoryImageComboBoxProjectorStatus).EndInit();
			((ISupportInitialize)this.repositoryItemCheckEditIsSelected).EndInit();
			((ISupportInitialize)this.panelInfo).EndInit();
			this.panelInfo.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x04000711 RID: 1809
		public BindingList<DeviceTreeItemBase> Devices;

		// Token: 0x04000712 RID: 1810
		private readonly Dictionary<string, SelectedDevicesControl.AdditionalItemData> _additionalItemData;

		// Token: 0x04000713 RID: 1811
		private List<DeviceType> _messageForDeviceTypeShowed;

		// Token: 0x04000714 RID: 1812
		private IContainer components;

		// Token: 0x04000715 RID: 1813
		public TreeListColumn columnStatusImage;

		// Token: 0x04000716 RID: 1814
		public TreeListColumn columnName;

		// Token: 0x04000717 RID: 1815
		public TreeListColumn columnUserName;

		// Token: 0x04000718 RID: 1816
		public TreeListColumn columnDomainName;

		// Token: 0x04000719 RID: 1817
		public TreeListColumn columnFullName;

		// Token: 0x0400071A RID: 1818
		public TreeListColumn columnDomainAndUserName;

		// Token: 0x0400071B RID: 1819
		public TreeListColumn columnAgentVersion;

		// Token: 0x0400071C RID: 1820
		public TreeListColumn columnConnectionDescription;

		// Token: 0x0400071D RID: 1821
		public TreeListColumn columnOsVersion;

		// Token: 0x0400071E RID: 1822
		public TreeListColumn columnProjectorStatus;

		// Token: 0x0400071F RID: 1823
		public TreeListColumn columnMessage;

		// Token: 0x04000720 RID: 1824
		public TreeList treeDevicesList;

		// Token: 0x04000721 RID: 1825
		protected RepositoryItemImageComboBox repositoryImageComboBoxProjectorStatus;

		// Token: 0x04000722 RID: 1826
		protected PanelControl panelInfo;

		// Token: 0x04000723 RID: 1827
		protected LabelControl labelInfo;

		// Token: 0x04000724 RID: 1828
		protected RepositoryItemPictureEdit repositoryItemPictureEditStatusImage;

		// Token: 0x04000725 RID: 1829
		private TreeListColumn columnIsSelected;

		// Token: 0x04000726 RID: 1830
		private RepositoryItemCheckEdit repositoryItemCheckEditIsSelected;

		// Token: 0x04000727 RID: 1831
		private TreeListColumn columnId;

		// Token: 0x020001D0 RID: 464
		private class AdditionalItemData
		{
			// Token: 0x1700031C RID: 796
			// (get) Token: 0x06000C7C RID: 3196 RVA: 0x000666DA File Offset: 0x000648DA
			// (set) Token: 0x06000C7D RID: 3197 RVA: 0x000666E2 File Offset: 0x000648E2
			public string Message { get; set; }

			// Token: 0x1700031D RID: 797
			// (get) Token: 0x06000C7E RID: 3198 RVA: 0x000666EB File Offset: 0x000648EB
			// (set) Token: 0x06000C7F RID: 3199 RVA: 0x000666F3 File Offset: 0x000648F3
			public object Object { get; set; }

			// Token: 0x1700031E RID: 798
			// (get) Token: 0x06000C80 RID: 3200 RVA: 0x000666FC File Offset: 0x000648FC
			// (set) Token: 0x06000C81 RID: 3201 RVA: 0x00066704 File Offset: 0x00064904
			public Bitmap StatusImage { get; set; }
		}
	}
}
