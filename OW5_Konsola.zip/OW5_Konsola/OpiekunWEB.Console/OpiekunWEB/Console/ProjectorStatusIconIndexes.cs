﻿using System;

namespace OpiekunWEB.Console
{
	// Token: 0x02000012 RID: 18
	public static class ProjectorStatusIconIndexes
	{
		// Token: 0x04000037 RID: 55
		public const int None = 0;

		// Token: 0x04000038 RID: 56
		public const int Pause = 1;

		// Token: 0x04000039 RID: 57
		public const int Play = 2;

		// Token: 0x0400003A RID: 58
		public const int Stop = 3;

		// Token: 0x0400003B RID: 59
		public const int Error = 4;

		// Token: 0x0400003C RID: 60
		public const int SetAsReceiver = 5;

		// Token: 0x0400003D RID: 61
		public const int Connecting = 6;

		// Token: 0x0400003E RID: 62
		public const int ControledByOther = 7;
	}
}
