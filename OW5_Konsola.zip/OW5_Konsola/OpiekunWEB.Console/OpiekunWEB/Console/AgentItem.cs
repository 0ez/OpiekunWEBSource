﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x0200000D RID: 13
	public class AgentItem : DeviceTreeItemBase
	{
		// Token: 0x06000049 RID: 73 RVA: 0x000032B0 File Offset: 0x000014B0
		public AgentItem(DeviceItem deviceItem, AgentClient agentClient)
		{
			this._iconConnectedIndex = 7;
			this._iconDisconnectedIndex = 6;
			this._displaysList = new List<DisplayItem>();
			this.DeviceItem = deviceItem;
			base.Id = agentClient.AgentId;
			base.ParentId = agentClient.DeviceId;
			base.DeviceType = deviceItem.DeviceType;
			this.DeviceItem.PropertyChanged += this.DeviceItemOnPropertyChanged;
			base.CopyCommonProperities(this.DeviceItem);
			this.AgentClient = agentClient;
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600004A RID: 74 RVA: 0x00003331 File Offset: 0x00001531
		// (set) Token: 0x0600004B RID: 75 RVA: 0x00003339 File Offset: 0x00001539
		public AgentClient AgentClient
		{
			get
			{
				return this._agentClient;
			}
			set
			{
				this._agentClient = value;
				base.IsConnected = this._agentClient.IsConnected;
				base.WindowsUser = this._agentClient.WindowsUser;
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600004C RID: 76 RVA: 0x00003364 File Offset: 0x00001564
		public new string AppVersion
		{
			get
			{
				return string.Empty;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x0600004D RID: 77 RVA: 0x0000336B File Offset: 0x0000156B
		public DeviceItem DeviceItem { get; }

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x0600004E RID: 78 RVA: 0x00003373 File Offset: 0x00001573
		public int DisplaysCount
		{
			get
			{
				return this._displaysList.Count;
			}
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00003380 File Offset: 0x00001580
		public override string GetDeviceName()
		{
			DeviceItem deviceItem = this.DeviceItem;
			if (deviceItem == null)
			{
				return null;
			}
			return deviceItem.GetDeviceName();
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00003393 File Offset: 0x00001593
		public List<DisplayItem> GetDisplaysList()
		{
			List<DisplayItem> list = new List<DisplayItem>();
			list.AddRange(this._displaysList);
			return list;
		}

		// Token: 0x06000051 RID: 81 RVA: 0x000033A6 File Offset: 0x000015A6
		public override void ItemsRemoved()
		{
			base.ItemsRemoved();
			this.DeviceItem.PropertyChanged -= this.DeviceItemOnPropertyChanged;
		}

		// Token: 0x06000052 RID: 82 RVA: 0x000033C8 File Offset: 0x000015C8
		protected override void SetExcluded(bool value)
		{
			base.SetExcluded(value);
			foreach (DisplayItem displayItem in this._displaysList)
			{
				displayItem.ParentId = this.GetParentIdForDisplay();
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00003428 File Offset: 0x00001628
		protected override void SetIsConnected(bool value)
		{
			base.SetIsConnected(value);
			if (!value)
			{
				base.ConnectionDescription = Resources.AgentConnection_None;
				base.IsProxyConnection = false;
				return;
			}
			if (this._agentClient.IsDirectConnection)
			{
				base.ConnectionDescription = Resources.AgentConnection_Direct;
				base.IsProxyConnection = false;
				return;
			}
			base.ConnectionDescription = Resources.AgentConnection_Indirect;
			base.IsProxyConnection = true;
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00003484 File Offset: 0x00001684
		protected override void SetWindowsUser(WindowsUserInfo value)
		{
			base.SetWindowsUser(value);
			this._iconConnectedIndex = (base.WindowsUser.IsSessionActive() ? 7 : 6);
			this.SetConnectedIcon();
			if (base.IsConnected)
			{
				WindowsUserInfo windowsUser = base.WindowsUser;
				this.ShowSessionRdpIcon(windowsUser != null && windowsUser.SessionType == DeviceSessionType.Rdp);
			}
			else
			{
				this.ShowSessionRdpIcon(false);
			}
			this.CheckDisplays();
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000034E8 File Offset: 0x000016E8
		private void CheckDisplays()
		{
			if (this._agentClient == null || base.WindowsUser == null)
			{
				return;
			}
			bool userIsActive = base.WindowsUser.SessionState == 0U;
			if ((ulong)this._agentClient.WindowsUser.DisplaysCount != (ulong)((long)this._displaysList.Count))
			{
				if ((ulong)this._agentClient.WindowsUser.DisplaysCount > (ulong)((long)this._displaysList.Count))
				{
					int i = this._displaysList.Count;
					while ((long)i < (long)((ulong)this.AgentClient.WindowsUser.DisplaysCount))
					{
						this._displaysList.Add(new DisplayItem(this, this.GetParentIdForDisplay(), i, true, this._agentClient.WindowsUser.DisplaysCount > 1U));
						i++;
					}
				}
				else
				{
					uint j = this.AgentClient.WindowsUser.DisplaysCount;
					while ((ulong)j < (ulong)((long)this._displaysList.Count))
					{
						DisplayItem displayItem = this._displaysList.Last<DisplayItem>();
						displayItem.ItemsRemoved();
						this._displaysList.Remove(displayItem);
						j += 1U;
					}
				}
				foreach (DisplayItem displayItem2 in this._displaysList)
				{
					displayItem2.IsOnlyOneDisplay = (this._displaysList.Count == 1);
				}
			}
			foreach (DisplayItem displayItem3 in this._displaysList)
			{
				displayItem3.IsEnabled = true;
			}
			if (!userIsActive)
			{
				for (int k = 1; k < this._displaysList.Count; k++)
				{
					this._displaysList[k].IsEnabled = false;
				}
			}
			bool showDisplays = this._displaysList.Count > 1;
			if (!userIsActive)
			{
				showDisplays = false;
			}
			foreach (DisplayItem displayItem4 in this._displaysList)
			{
				displayItem4.Excluded = !showDisplays;
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00003710 File Offset: 0x00001910
		private void DeviceItemOnPropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			base.CopyCommonProperities(sender as DeviceItem);
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0000371E File Offset: 0x0000191E
		private string GetParentIdForDisplay()
		{
			if (base.Excluded)
			{
				return this.AgentClient.DeviceId;
			}
			return this.AgentClient.AgentId;
		}

		// Token: 0x0400002C RID: 44
		private readonly List<DisplayItem> _displaysList;

		// Token: 0x0400002D RID: 45
		private AgentClient _agentClient;
	}
}
