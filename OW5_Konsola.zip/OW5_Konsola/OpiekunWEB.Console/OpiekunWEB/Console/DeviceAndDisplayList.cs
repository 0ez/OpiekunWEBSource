﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpiekunWEB.Api;

namespace OpiekunWEB.Console
{
	// Token: 0x0200000A RID: 10
	public class DeviceAndDisplayList : List<DeviceAndDisplay>
	{
		// Token: 0x06000032 RID: 50 RVA: 0x00002DC5 File Offset: 0x00000FC5
		public DeviceAndDisplayList()
		{
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00002DCD File Offset: 0x00000FCD
		public DeviceAndDisplayList(IEnumerable<DeviceAndDisplay> collection) : base(collection)
		{
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00002DD8 File Offset: 0x00000FD8
		public void AddAgent(AgentItem agentItem)
		{
			using (List<DisplayItem>.Enumerator enumerator = agentItem.GetDisplaysList().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					DisplayItem display = enumerator.Current;
					if (!this.Any((DeviceAndDisplay x) => x.DeviceItem == agentItem.DeviceItem && x.DisplayItem == display))
					{
						base.Add(new DeviceAndDisplay(agentItem.DeviceItem, display));
					}
				}
			}
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00002E80 File Offset: 0x00001080
		public void AddDevice(DeviceItem deviceItem)
		{
			List<AgentItem> agents = deviceItem.GetAgentItemsList();
			if (agents.Count == 0)
			{
				if (!this.Any((DeviceAndDisplay x) => x.DeviceItem == deviceItem && x.DisplayItem == null))
				{
					base.Add(new DeviceAndDisplay(deviceItem, null));
					return;
				}
			}
			else
			{
				foreach (AgentItem agentItem in agents)
				{
					using (IEnumerator<DisplayItem> enumerator2 = (from x in agentItem.GetDisplaysList()
					where x.IsEnabled
					select x).GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							DisplayItem display = enumerator2.Current;
							if (!this.Any((DeviceAndDisplay x) => x.DeviceItem == deviceItem && x.DisplayItem == display))
							{
								base.Add(new DeviceAndDisplay(deviceItem, display));
							}
						}
					}
				}
			}
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00002FB8 File Offset: 0x000011B8
		public void AddDisplay(DisplayItem displayItem)
		{
			if (!this.Any((DeviceAndDisplay x) => x.DeviceItem == displayItem.AgentItem.DeviceItem && x.DisplayItem == displayItem))
			{
				base.Add(new DeviceAndDisplay(displayItem.AgentItem.DeviceItem, displayItem));
			}
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00003008 File Offset: 0x00001208
		public void RemoveDevicesNotInFilter(List<DeviceItem> itemsFilterList)
		{
			int i;
			Predicate<DeviceItem> <>9__0;
			int j;
			for (i = base.Count - 1; i >= 0; i = j - 1)
			{
				Predicate<DeviceItem> match;
				if ((match = <>9__0) == null)
				{
					match = (<>9__0 = ((DeviceItem x) => x.Id == this[i].DeviceItem.Id));
				}
				if (itemsFilterList.Find(match) == null)
				{
					base.RemoveAt(i);
				}
				j = i;
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00003080 File Offset: 0x00001280
		public void RemoveNotActiveSessions()
		{
			for (int i = base.Count - 1; i >= 0; i--)
			{
				if (!base[i].DisplayItem.WindowsUser.IsSessionActive())
				{
					base.RemoveAt(i);
				}
			}
		}
	}
}
