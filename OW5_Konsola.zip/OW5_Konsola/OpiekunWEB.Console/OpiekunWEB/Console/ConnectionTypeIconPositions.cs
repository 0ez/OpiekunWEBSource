﻿using System;

namespace OpiekunWEB.Console
{
	// Token: 0x02000019 RID: 25
	internal class ConnectionTypeIconPositions
	{
		// Token: 0x040000A0 RID: 160
		public const int ConnectionType = 0;

		// Token: 0x040000A1 RID: 161
		public const int MaxIconsPerItem = 2;

		// Token: 0x040000A2 RID: 162
		public const int SessionType = 1;
	}
}
