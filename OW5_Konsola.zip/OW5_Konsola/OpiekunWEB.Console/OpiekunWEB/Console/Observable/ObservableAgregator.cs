﻿using System;
using System.ComponentModel;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Windows.Threading;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Events;

namespace OpiekunWEB.Console.Observable
{
	// Token: 0x02000021 RID: 33
	public class ObservableAgregator
	{
		// Token: 0x0600035E RID: 862 RVA: 0x0000D49C File Offset: 0x0000B69C
		public ObservableAgregator(ApiClient apiClient)
		{
			this._viewChangedSubject = new Subject<ViewChangedEvent>();
			this._selectedDeviceChangedStream = new Subject<DevicesAndGroupsSelection>();
			this._agentConnectionChangedSubject = new Subject<AgentClient>();
			this.DeviceEventsLog = new BindingList<DeviceEvent>();
			apiClient.DeviceEventsLog.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<DeviceEvent>(this.OnApiDeviceEventsLog));
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x0600035F RID: 863 RVA: 0x0000D4FE File Offset: 0x0000B6FE
		public IObservable<AgentClient> AgentConnectionChangedStream
		{
			get
			{
				return this._agentConnectionChangedSubject;
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000360 RID: 864 RVA: 0x0000D506 File Offset: 0x0000B706
		public BindingList<DeviceEvent> DeviceEventsLog { get; }

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000361 RID: 865 RVA: 0x0000D50E File Offset: 0x0000B70E
		public IObservable<DevicesAndGroupsSelection> SelectedDeviceChangedStream
		{
			get
			{
				return this._selectedDeviceChangedStream;
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000362 RID: 866 RVA: 0x0000D516 File Offset: 0x0000B716
		public IObservable<ViewChangedEvent> ViewChangedStream
		{
			get
			{
				return this._viewChangedSubject;
			}
		}

		// Token: 0x06000363 RID: 867 RVA: 0x0000D51E File Offset: 0x0000B71E
		public void SendAgentConnectionChangedEvent(AgentClient agent)
		{
			this._agentConnectionChangedSubject.OnNext(agent);
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0000D52C File Offset: 0x0000B72C
		public void SendSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			this._selectedDeviceChangedStream.OnNext(selection);
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0000D53A File Offset: 0x0000B73A
		public void SendViewChangedEvent(ViewChangedEvent @event)
		{
			this._viewChangedSubject.OnNext(@event);
		}

		// Token: 0x06000366 RID: 870 RVA: 0x0000D548 File Offset: 0x0000B748
		protected virtual void OnApiDeviceEventsLog(DeviceEvent deviceEvent)
		{
			this.DeviceEventsLog.Add(deviceEvent);
		}

		// Token: 0x040000FE RID: 254
		private readonly Subject<AgentClient> _agentConnectionChangedSubject;

		// Token: 0x040000FF RID: 255
		private readonly Subject<DevicesAndGroupsSelection> _selectedDeviceChangedStream;

		// Token: 0x04000100 RID: 256
		private readonly Subject<ViewChangedEvent> _viewChangedSubject;
	}
}
