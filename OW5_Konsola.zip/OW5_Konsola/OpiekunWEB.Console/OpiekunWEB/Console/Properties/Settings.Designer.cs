﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace OpiekunWEB.Console.Properties
{
	// Token: 0x0200001F RID: 31
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "15.7.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000358 RID: 856 RVA: 0x0000D44E File Offset: 0x0000B64E
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x040000FC RID: 252
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
