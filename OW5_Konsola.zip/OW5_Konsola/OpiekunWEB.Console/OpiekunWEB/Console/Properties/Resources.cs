﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace OpiekunWEB.Console.Properties
{
	// Token: 0x0200001E RID: 30
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000178 RID: 376 RVA: 0x00002D3D File Offset: 0x00000F3D
		internal Resources()
		{
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000179 RID: 377 RVA: 0x0000A784 File Offset: 0x00008984
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("OpiekunWEB.Console.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600017A RID: 378 RVA: 0x0000A7B0 File Offset: 0x000089B0
		// (set) Token: 0x0600017B RID: 379 RVA: 0x0000A7B7 File Offset: 0x000089B7
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600017C RID: 380 RVA: 0x0000A7BF File Offset: 0x000089BF
		internal static Bitmap access_allow_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_allow_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x0600017D RID: 381 RVA: 0x0000A7DA File Offset: 0x000089DA
		internal static Bitmap access_allow_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_allow_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x0600017E RID: 382 RVA: 0x0000A7F5 File Offset: 0x000089F5
		internal static Bitmap access_allow_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_allow_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x0600017F RID: 383 RVA: 0x0000A810 File Offset: 0x00008A10
		internal static Bitmap access_block_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_block_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000180 RID: 384 RVA: 0x0000A82B File Offset: 0x00008A2B
		internal static Bitmap access_block_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_block_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000181 RID: 385 RVA: 0x0000A846 File Offset: 0x00008A46
		internal static Bitmap access_block_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_block_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x06000182 RID: 386 RVA: 0x0000A861 File Offset: 0x00008A61
		internal static Bitmap access_check_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_check_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06000183 RID: 387 RVA: 0x0000A87C File Offset: 0x00008A7C
		internal static Bitmap access_check_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_check_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06000184 RID: 388 RVA: 0x0000A897 File Offset: 0x00008A97
		internal static Bitmap access_check_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_check_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000185 RID: 389 RVA: 0x0000A8B2 File Offset: 0x00008AB2
		internal static Bitmap access_multi_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_multi_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000186 RID: 390 RVA: 0x0000A8CD File Offset: 0x00008ACD
		internal static Bitmap access_none_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_none_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000187 RID: 391 RVA: 0x0000A8E8 File Offset: 0x00008AE8
		internal static Bitmap access_strict_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_strict_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000188 RID: 392 RVA: 0x0000A903 File Offset: 0x00008B03
		internal static Bitmap access_strict_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_strict_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000189 RID: 393 RVA: 0x0000A91E File Offset: 0x00008B1E
		internal static Bitmap access_strict_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("access_strict_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600018A RID: 394 RVA: 0x0000A939 File Offset: 0x00008B39
		internal static Bitmap add_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("add_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600018B RID: 395 RVA: 0x0000A954 File Offset: 0x00008B54
		internal static Bitmap add_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("add_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x0600018C RID: 396 RVA: 0x0000A96F File Offset: 0x00008B6F
		internal static Bitmap addheader_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("addheader_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x0600018D RID: 397 RVA: 0x0000A98A File Offset: 0x00008B8A
		internal static Bitmap addheader_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("addheader_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x0600018E RID: 398 RVA: 0x0000A9A5 File Offset: 0x00008BA5
		internal static string AgentConnection_Direct
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentConnection_Direct", Resources.resourceCulture);
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x0600018F RID: 399 RVA: 0x0000A9BB File Offset: 0x00008BBB
		internal static string AgentConnection_Indirect
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentConnection_Indirect", Resources.resourceCulture);
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000190 RID: 400 RVA: 0x0000A9D1 File Offset: 0x00008BD1
		internal static string AgentConnection_None
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentConnection_None", Resources.resourceCulture);
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000191 RID: 401 RVA: 0x0000A9E7 File Offset: 0x00008BE7
		internal static string AgentUpdateForm_DeviceNotConnected
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentUpdateForm_DeviceNotConnected", Resources.resourceCulture);
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x06000192 RID: 402 RVA: 0x0000A9FD File Offset: 0x00008BFD
		internal static string AgentUpdateForm_DevicesNotConnected
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentUpdateForm_DevicesNotConnected", Resources.resourceCulture);
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000193 RID: 403 RVA: 0x0000AA13 File Offset: 0x00008C13
		internal static string AgentUpdateForm_DevicesNotSelected
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentUpdateForm_DevicesNotSelected", Resources.resourceCulture);
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000194 RID: 404 RVA: 0x0000AA29 File Offset: 0x00008C29
		internal static string AgentUpdateForm_UpdateError
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentUpdateForm_UpdateError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000195 RID: 405 RVA: 0x0000AA3F File Offset: 0x00008C3F
		internal static string AgentUpdateForm_UpdateProgress
		{
			get
			{
				return Resources.ResourceManager.GetString("AgentUpdateForm_UpdateProgress", Resources.resourceCulture);
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000196 RID: 406 RVA: 0x0000AA55 File Offset: 0x00008C55
		internal static Bitmap app_access_allow_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_allow_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000197 RID: 407 RVA: 0x0000AA70 File Offset: 0x00008C70
		internal static Bitmap app_access_allow_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_allow_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000198 RID: 408 RVA: 0x0000AA8B File Offset: 0x00008C8B
		internal static Bitmap app_access_allow_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_allow_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000199 RID: 409 RVA: 0x0000AAA6 File Offset: 0x00008CA6
		internal static Bitmap app_access_blocked_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_blocked_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x0600019A RID: 410 RVA: 0x0000AAC1 File Offset: 0x00008CC1
		internal static Bitmap app_access_blocked_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_blocked_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x0600019B RID: 411 RVA: 0x0000AADC File Offset: 0x00008CDC
		internal static Bitmap app_access_blocked_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_blocked_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600019C RID: 412 RVA: 0x0000AAF7 File Offset: 0x00008CF7
		internal static Bitmap app_access_check_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_check_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x0600019D RID: 413 RVA: 0x0000AB12 File Offset: 0x00008D12
		internal static Bitmap app_access_check_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_check_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x0600019E RID: 414 RVA: 0x0000AB2D File Offset: 0x00008D2D
		internal static Bitmap app_access_check_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_check_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x0600019F RID: 415 RVA: 0x0000AB48 File Offset: 0x00008D48
		internal static Bitmap app_access_check_blacklist_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_check_blacklist_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x0000AB63 File Offset: 0x00008D63
		internal static Bitmap app_access_check_blacklist_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_check_blacklist_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060001A1 RID: 417 RVA: 0x0000AB7E File Offset: 0x00008D7E
		internal static Bitmap app_access_check_whitelist_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_check_whitelist_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x0000AB99 File Offset: 0x00008D99
		internal static Bitmap app_access_check_whitelist_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_check_whitelist_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060001A3 RID: 419 RVA: 0x0000ABB4 File Offset: 0x00008DB4
		internal static Bitmap app_access_strict_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_strict_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x0000ABCF File Offset: 0x00008DCF
		internal static Bitmap app_access_strict_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_strict_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060001A5 RID: 421 RVA: 0x0000ABEA File Offset: 0x00008DEA
		internal static Bitmap app_access_strict_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("app_access_strict_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x0000AC05 File Offset: 0x00008E05
		internal static string AppCategoriesForm_DoYouWantDeleteCategory
		{
			get
			{
				return Resources.ResourceManager.GetString("AppCategoriesForm_DoYouWantDeleteCategory", Resources.resourceCulture);
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x0000AC1B File Offset: 0x00008E1B
		internal static string AppCategoriesForm_DoYouWantDeleteFilter
		{
			get
			{
				return Resources.ResourceManager.GetString("AppCategoriesForm_DoYouWantDeleteFilter", Resources.resourceCulture);
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x0000AC31 File Offset: 0x00008E31
		internal static string AppHistoryView_AllDevices
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_AllDevices", Resources.resourceCulture);
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x0000AC47 File Offset: 0x00008E47
		internal static string AppHistoryView_AllUsers
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_AllUsers", Resources.resourceCulture);
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060001AA RID: 426 RVA: 0x0000AC5D File Offset: 0x00008E5D
		internal static string AppHistoryView_AppIdleTime
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_AppIdleTime", Resources.resourceCulture);
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060001AB RID: 427 RVA: 0x0000AC73 File Offset: 0x00008E73
		internal static string AppHistoryView_AppTotalWorkTime
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_AppTotalWorkTime", Resources.resourceCulture);
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060001AC RID: 428 RVA: 0x0000AC89 File Offset: 0x00008E89
		internal static string AppHistoryView_ClickAndDownloadInfo
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_ClickAndDownloadInfo", Resources.resourceCulture);
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060001AD RID: 429 RVA: 0x0000AC9F File Offset: 0x00008E9F
		internal static string AppHistoryView_ReportDescription
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_ReportDescription", Resources.resourceCulture);
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060001AE RID: 430 RVA: 0x0000ACB5 File Offset: 0x00008EB5
		internal static string AppHistoryView_SelectedDevices
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_SelectedDevices", Resources.resourceCulture);
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060001AF RID: 431 RVA: 0x0000ACCB File Offset: 0x00008ECB
		internal static string AppHistoryView_SitesTotalWorkTime
		{
			get
			{
				return Resources.ResourceManager.GetString("AppHistoryView_SitesTotalWorkTime", Resources.resourceCulture);
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060001B0 RID: 432 RVA: 0x0000ACE1 File Offset: 0x00008EE1
		internal static Bitmap apply_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("apply_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060001B1 RID: 433 RVA: 0x0000ACFC File Offset: 0x00008EFC
		internal static Bitmap apply_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("apply_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x0000AD17 File Offset: 0x00008F17
		internal static string AppUpdateForm_DownloadSucceeded
		{
			get
			{
				return Resources.ResourceManager.GetString("AppUpdateForm_DownloadSucceeded", Resources.resourceCulture);
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060001B3 RID: 435 RVA: 0x0000AD2D File Offset: 0x00008F2D
		internal static string AppUpdateForm_FolderBrowserTitle
		{
			get
			{
				return Resources.ResourceManager.GetString("AppUpdateForm_FolderBrowserTitle", Resources.resourceCulture);
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x0000AD43 File Offset: 0x00008F43
		internal static string AvailableDeviceGoupsEmpty
		{
			get
			{
				return Resources.ResourceManager.GetString("AvailableDeviceGoupsEmpty", Resources.resourceCulture);
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x0000AD59 File Offset: 0x00008F59
		internal static Bitmap cancel_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("cancel_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x0000AD74 File Offset: 0x00008F74
		internal static Bitmap cancel_16x161
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("cancel_16x161", Resources.resourceCulture);
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x0000AD8F File Offset: 0x00008F8F
		internal static Bitmap cancel_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("cancel_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060001B8 RID: 440 RVA: 0x0000ADAA File Offset: 0x00008FAA
		internal static Bitmap cancel_32x321
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("cancel_32x321", Resources.resourceCulture);
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x0000ADC5 File Offset: 0x00008FC5
		internal static string ChangePasswordForm_PasswordChanged
		{
			get
			{
				return Resources.ResourceManager.GetString("ChangePasswordForm_PasswordChanged", Resources.resourceCulture);
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060001BA RID: 442 RVA: 0x0000ADDB File Offset: 0x00008FDB
		internal static string ChangePasswordForm_PasswordsDoNotMatch
		{
			get
			{
				return Resources.ResourceManager.GetString("ChangePasswordForm_PasswordsDoNotMatch", Resources.resourceCulture);
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060001BB RID: 443 RVA: 0x0000ADF1 File Offset: 0x00008FF1
		internal static Bitmap chocolatey
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("chocolatey", Resources.resourceCulture);
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060001BC RID: 444 RVA: 0x0000AE0C File Offset: 0x0000900C
		internal static Bitmap close_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("close_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060001BD RID: 445 RVA: 0x0000AE27 File Offset: 0x00009027
		internal static Bitmap close_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("close_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060001BE RID: 446 RVA: 0x0000AE42 File Offset: 0x00009042
		internal static Bitmap collectfiles_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("collectfiles_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060001BF RID: 447 RVA: 0x0000AE5D File Offset: 0x0000905D
		internal static Bitmap collectfiles_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("collectfiles_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060001C0 RID: 448 RVA: 0x0000AE78 File Offset: 0x00009078
		internal static string CommandExecutor_ActiveXNotInstalled
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_ActiveXNotInstalled", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060001C1 RID: 449 RVA: 0x0000AE8E File Offset: 0x0000908E
		internal static string CommandExecutor_DoYouWantLockUsers
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_DoYouWantLockUsers", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060001C2 RID: 450 RVA: 0x0000AEA4 File Offset: 0x000090A4
		internal static string CommandExecutor_DoYouWantLogoutUsers
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_DoYouWantLogoutUsers", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060001C3 RID: 451 RVA: 0x0000AEBA File Offset: 0x000090BA
		internal static string CommandExecutor_DoYouWantRestartSelectedDevices
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_DoYouWantRestartSelectedDevices", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060001C4 RID: 452 RVA: 0x0000AED0 File Offset: 0x000090D0
		internal static string CommandExecutor_DoYouWantShutdownSelectedDevices
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_DoYouWantShutdownSelectedDevices", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060001C5 RID: 453 RVA: 0x0000AEE6 File Offset: 0x000090E6
		internal static string CommandExecutor_MustSelectConnectedDeviceForFileManager
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_MustSelectConnectedDeviceForFileManager", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060001C6 RID: 454 RVA: 0x0000AEFC File Offset: 0x000090FC
		internal static string CommandExecutor_NeedInstallActiveXAsAdmin
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_NeedInstallActiveXAsAdmin", Resources.resourceCulture);
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x0000AF12 File Offset: 0x00009112
		internal static string CommandExecutor_NoActiveDevicesForOperation
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_NoActiveDevicesForOperation", Resources.resourceCulture);
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060001C8 RID: 456 RVA: 0x0000AF28 File Offset: 0x00009128
		internal static string CommandExecutor_NoLoggedUserForPerformOperation
		{
			get
			{
				return Resources.ResourceManager.GetString("CommandExecutor_NoLoggedUserForPerformOperation", Resources.resourceCulture);
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060001C9 RID: 457 RVA: 0x0000AF3E File Offset: 0x0000913E
		internal static Bitmap computer_access_all_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_all_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060001CA RID: 458 RVA: 0x0000AF59 File Offset: 0x00009159
		internal static Bitmap computer_access_all_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_all_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060001CB RID: 459 RVA: 0x0000AF74 File Offset: 0x00009174
		internal static Bitmap computer_access_all_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_all_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060001CC RID: 460 RVA: 0x0000AF8F File Offset: 0x0000918F
		internal static Bitmap computer_access_deny_all_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_deny_all_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x060001CD RID: 461 RVA: 0x0000AFAA File Offset: 0x000091AA
		internal static Bitmap computer_access_deny_all_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_deny_all_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x060001CE RID: 462 RVA: 0x0000AFC5 File Offset: 0x000091C5
		internal static Bitmap computer_access_deny_all_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_deny_all_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x060001CF RID: 463 RVA: 0x0000AFE0 File Offset: 0x000091E0
		internal static Bitmap computer_access_deny_key_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_deny_key_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x060001D0 RID: 464 RVA: 0x0000AFFB File Offset: 0x000091FB
		internal static Bitmap computer_access_deny_key_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_deny_key_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060001D1 RID: 465 RVA: 0x0000B016 File Offset: 0x00009216
		internal static Bitmap computer_access_deny_key_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_access_deny_key_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060001D2 RID: 466 RVA: 0x0000B031 File Offset: 0x00009231
		internal static Bitmap computer_rdp_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("computer_rdp_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060001D3 RID: 467 RVA: 0x0000B04C File Offset: 0x0000924C
		internal static Bitmap connection_proxy_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("connection_proxy_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060001D4 RID: 468 RVA: 0x0000B067 File Offset: 0x00009267
		internal static Bitmap connection_proxy_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("connection_proxy_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060001D5 RID: 469 RVA: 0x0000B082 File Offset: 0x00009282
		internal static Bitmap connection_rdp_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("connection_rdp_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060001D6 RID: 470 RVA: 0x0000B09D File Offset: 0x0000929D
		internal static Bitmap connection_rdp_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("connection_rdp_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060001D7 RID: 471 RVA: 0x0000B0B8 File Offset: 0x000092B8
		internal static string ContentFilterForm_CanSelectMax3Categories
		{
			get
			{
				return Resources.ResourceManager.GetString("ContentFilterForm_CanSelectMax3Categories", Resources.resourceCulture);
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x0000B0CE File Offset: 0x000092CE
		internal static string ContentFilterForm_ForPhraseCanSelectMax1Category
		{
			get
			{
				return Resources.ResourceManager.GetString("ContentFilterForm_ForPhraseCanSelectMax1Category", Resources.resourceCulture);
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060001D9 RID: 473 RVA: 0x0000B0E4 File Offset: 0x000092E4
		internal static string ContentFilterForm_MustSelectCategory
		{
			get
			{
				return Resources.ResourceManager.GetString("ContentFilterForm_MustSelectCategory", Resources.resourceCulture);
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060001DA RID: 474 RVA: 0x0000B0FA File Offset: 0x000092FA
		internal static string ContentFilterForm_PhraseFilterHelp
		{
			get
			{
				return Resources.ResourceManager.GetString("ContentFilterForm_PhraseFilterHelp", Resources.resourceCulture);
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060001DB RID: 475 RVA: 0x0000B110 File Offset: 0x00009310
		internal static string ContentFilterForm_UrlFilterHelp
		{
			get
			{
				return Resources.ResourceManager.GetString("ContentFilterForm_UrlFilterHelp", Resources.resourceCulture);
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060001DC RID: 476 RVA: 0x0000B126 File Offset: 0x00009326
		internal static string ContentFilterForm_UrlRegexFilterHelp
		{
			get
			{
				return Resources.ResourceManager.GetString("ContentFilterForm_UrlRegexFilterHelp", Resources.resourceCulture);
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060001DD RID: 477 RVA: 0x0000B13C File Offset: 0x0000933C
		internal static Bitmap customer_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("customer_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x060001DE RID: 478 RVA: 0x0000B157 File Offset: 0x00009357
		internal static Bitmap delete_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("delete_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x060001DF RID: 479 RVA: 0x0000B172 File Offset: 0x00009372
		internal static Bitmap delete_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("delete_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060001E0 RID: 480 RVA: 0x0000B18D File Offset: 0x0000938D
		internal static Bitmap delete_user_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("delete_user_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060001E1 RID: 481 RVA: 0x0000B1A8 File Offset: 0x000093A8
		internal static Bitmap delete_user_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("delete_user_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060001E2 RID: 482 RVA: 0x0000B1C3 File Offset: 0x000093C3
		internal static Bitmap delete_usergroup_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("delete_usergroup_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x060001E3 RID: 483 RVA: 0x0000B1DE File Offset: 0x000093DE
		internal static Bitmap delete_usergroup_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("delete_usergroup_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x0000B1F9 File Offset: 0x000093F9
		internal static string DeleteHistoryForm_MustSelectTypeOfDataToDelete
		{
			get
			{
				return Resources.ResourceManager.GetString("DeleteHistoryForm_MustSelectTypeOfDataToDelete", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060001E5 RID: 485 RVA: 0x0000B20F File Offset: 0x0000940F
		internal static Bitmap deletelist_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("deletelist_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x0000B22A File Offset: 0x0000942A
		internal static Bitmap deletelist_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("deletelist_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060001E7 RID: 487 RVA: 0x0000B245 File Offset: 0x00009445
		internal static Bitmap depend_on_user_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("depend_on_user_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x0000B260 File Offset: 0x00009460
		internal static string DesktopItem_OpenFileDialogFilter
		{
			get
			{
				return Resources.ResourceManager.GetString("DesktopItem_OpenFileDialogFilter", Resources.resourceCulture);
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060001E9 RID: 489 RVA: 0x0000B276 File Offset: 0x00009476
		internal static string DesktopItemForm_InvalidIconSizeError
		{
			get
			{
				return Resources.ResourceManager.GetString("DesktopItemForm_InvalidIconSizeError", Resources.resourceCulture);
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060001EA RID: 490 RVA: 0x0000B28C File Offset: 0x0000948C
		internal static string DesktopItemForm_LoadIconError
		{
			get
			{
				return Resources.ResourceManager.GetString("DesktopItemForm_LoadIconError", Resources.resourceCulture);
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060001EB RID: 491 RVA: 0x0000B2A2 File Offset: 0x000094A2
		internal static string DesktopItemForm_OpenFileDialogTitle
		{
			get
			{
				return Resources.ResourceManager.GetString("DesktopItemForm_OpenFileDialogTitle", Resources.resourceCulture);
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060001EC RID: 492 RVA: 0x0000B2B8 File Offset: 0x000094B8
		internal static string DesktopsListForm_DoYouWantDeleteDesktop
		{
			get
			{
				return Resources.ResourceManager.GetString("DesktopsListForm_DoYouWantDeleteDesktop", Resources.resourceCulture);
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060001ED RID: 493 RVA: 0x0000B2CE File Offset: 0x000094CE
		internal static string DesktopsListForm_DoYouWantDeleteDesktopItem
		{
			get
			{
				return Resources.ResourceManager.GetString("DesktopsListForm_DoYouWantDeleteDesktopItem", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060001EE RID: 494 RVA: 0x0000B2E4 File Offset: 0x000094E4
		internal static Bitmap device_desktop_off_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_desktop_off_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060001EF RID: 495 RVA: 0x0000B2FF File Offset: 0x000094FF
		internal static Bitmap device_desktop_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_desktop_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060001F0 RID: 496 RVA: 0x0000B31A File Offset: 0x0000951A
		internal static Bitmap device_display_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_display_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060001F1 RID: 497 RVA: 0x0000B335 File Offset: 0x00009535
		internal static Bitmap device_server_off_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_server_off_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x0000B350 File Offset: 0x00009550
		internal static Bitmap device_server_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_server_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060001F3 RID: 499 RVA: 0x0000B36B File Offset: 0x0000956B
		internal static Bitmap device_terminal_off_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_terminal_off_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x0000B386 File Offset: 0x00009586
		internal static Bitmap device_terminal_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_terminal_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060001F5 RID: 501 RVA: 0x0000B3A1 File Offset: 0x000095A1
		internal static Bitmap device_unknown_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("device_unknown_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060001F6 RID: 502 RVA: 0x0000B3BC File Offset: 0x000095BC
		internal static string DeviceDisconnectedError
		{
			get
			{
				return Resources.ResourceManager.GetString("DeviceDisconnectedError", Resources.resourceCulture);
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060001F7 RID: 503 RVA: 0x0000B3D2 File Offset: 0x000095D2
		internal static string DeviceGroupSelectionForm_SelectGroup
		{
			get
			{
				return Resources.ResourceManager.GetString("DeviceGroupSelectionForm_SelectGroup", Resources.resourceCulture);
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060001F8 RID: 504 RVA: 0x0000B3E8 File Offset: 0x000095E8
		internal static string DeviceLoggedUserRequiredError
		{
			get
			{
				return Resources.ResourceManager.GetString("DeviceLoggedUserRequiredError", Resources.resourceCulture);
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060001F9 RID: 505 RVA: 0x0000B3FE File Offset: 0x000095FE
		internal static Bitmap devices_group_off_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("devices_group_off_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060001FA RID: 506 RVA: 0x0000B419 File Offset: 0x00009619
		internal static Bitmap devices_group_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("devices_group_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060001FB RID: 507 RVA: 0x0000B434 File Offset: 0x00009634
		internal static string DevicesTree_SelectionDescriptionForGroupsAndDevices
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_SelectionDescriptionForGroupsAndDevices", Resources.resourceCulture);
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060001FC RID: 508 RVA: 0x0000B44A File Offset: 0x0000964A
		internal static string DevicesTree_SelectionDescriptionForManyDevices
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_SelectionDescriptionForManyDevices", Resources.resourceCulture);
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060001FD RID: 509 RVA: 0x0000B460 File Offset: 0x00009660
		internal static string DevicesTree_SelectionDescriptionForOneDevice
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_SelectionDescriptionForOneDevice", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060001FE RID: 510 RVA: 0x0000B476 File Offset: 0x00009676
		internal static string DevicesTree_TooltipDeviceAccess
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipDeviceAccess", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060001FF RID: 511 RVA: 0x0000B48C File Offset: 0x0000968C
		internal static string DevicesTree_TooltipDeviceAppAccess
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipDeviceAppAccess", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000200 RID: 512 RVA: 0x0000B4A2 File Offset: 0x000096A2
		internal static string DevicesTree_TooltipDeviceConnection
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipDeviceConnection", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000201 RID: 513 RVA: 0x0000B4B8 File Offset: 0x000096B8
		internal static string DevicesTree_TooltipDeviceInetAccess
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipDeviceInetAccess", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000202 RID: 514 RVA: 0x0000B4CE File Offset: 0x000096CE
		internal static string DevicesTree_TooltipDeviceName
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipDeviceName", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000203 RID: 515 RVA: 0x0000B4E4 File Offset: 0x000096E4
		internal static string DevicesTree_TooltipDeviceSession
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipDeviceSession", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000204 RID: 516 RVA: 0x0000B4FA File Offset: 0x000096FA
		internal static string DevicesTree_TooltipGroupDevicesConnected
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipGroupDevicesConnected", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000205 RID: 517 RVA: 0x0000B510 File Offset: 0x00009710
		internal static string DevicesTree_TooltipGroupDevicesCount
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipGroupDevicesCount", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000206 RID: 518 RVA: 0x0000B526 File Offset: 0x00009726
		internal static string DevicesTree_TooltipGroupName
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipGroupName", Resources.resourceCulture);
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06000207 RID: 519 RVA: 0x0000B53C File Offset: 0x0000973C
		internal static string DevicesTree_TooltipUserName
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipUserName", Resources.resourceCulture);
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000208 RID: 520 RVA: 0x0000B552 File Offset: 0x00009752
		internal static string DevicesTree_TooltipUserRoleName
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTree_TooltipUserRoleName", Resources.resourceCulture);
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000209 RID: 521 RVA: 0x0000B568 File Offset: 0x00009768
		internal static string DevicesTreePanel_Empty
		{
			get
			{
				return Resources.ResourceManager.GetString("DevicesTreePanel_Empty", Resources.resourceCulture);
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x0600020A RID: 522 RVA: 0x0000B57E File Offset: 0x0000977E
		internal static Bitmap distributefiles_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("distributefiles_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x0600020B RID: 523 RVA: 0x0000B599 File Offset: 0x00009799
		internal static Bitmap distributefiles_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("distributefiles_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x0600020C RID: 524 RVA: 0x0000B5B4 File Offset: 0x000097B4
		internal static string DistributeFilesForm_CancelTransfer
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_CancelTransfer", Resources.resourceCulture);
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600020D RID: 525 RVA: 0x0000B5CA File Offset: 0x000097CA
		internal static string DistributeFilesForm_CloseButtonText
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_CloseButtonText", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600020E RID: 526 RVA: 0x0000B5E0 File Offset: 0x000097E0
		internal static string DistributeFilesForm_CollectButtonText
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_CollectButtonText", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x0600020F RID: 527 RVA: 0x0000B5F6 File Offset: 0x000097F6
		internal static string DistributeFilesForm_CollectingFilesTitle
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_CollectingFilesTitle", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000210 RID: 528 RVA: 0x0000B60C File Offset: 0x0000980C
		internal static string DistributeFilesForm_FileAlreadyExists
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_FileAlreadyExists", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000211 RID: 529 RVA: 0x0000B622 File Offset: 0x00009822
		internal static string DistributeFilesForm_FileSkiped
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_FileSkiped", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000212 RID: 530 RVA: 0x0000B638 File Offset: 0x00009838
		internal static string DistributeFilesForm_FormClosing
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_FormClosing", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000213 RID: 531 RVA: 0x0000B64E File Offset: 0x0000984E
		internal static string DistributeFilesForm_GroupFilesToTrasferText
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_GroupFilesToTrasferText", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000214 RID: 532 RVA: 0x0000B664 File Offset: 0x00009864
		internal static string DistributeFilesForm_StartReceivingFile
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_StartReceivingFile", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x06000215 RID: 533 RVA: 0x0000B67A File Offset: 0x0000987A
		internal static string DistributeFilesForm_StartSendingFile
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_StartSendingFile", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x06000216 RID: 534 RVA: 0x0000B690 File Offset: 0x00009890
		internal static string DistributeFilesForm_TransferError
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFilesForm_TransferError", Resources.resourceCulture);
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x06000217 RID: 535 RVA: 0x0000B6A6 File Offset: 0x000098A6
		internal static string DistributeFileStatusInfo_Canceled
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_Canceled", Resources.resourceCulture);
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000218 RID: 536 RVA: 0x0000B6BC File Offset: 0x000098BC
		internal static string DistributeFileStatusInfo_Error
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_Error", Resources.resourceCulture);
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000219 RID: 537 RVA: 0x0000B6D2 File Offset: 0x000098D2
		internal static string DistributeFileStatusInfo_ReceiveSuccess
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_ReceiveSuccess", Resources.resourceCulture);
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x0600021A RID: 538 RVA: 0x0000B6E8 File Offset: 0x000098E8
		internal static string DistributeFileStatusInfo_Receiving
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_Receiving", Resources.resourceCulture);
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x0600021B RID: 539 RVA: 0x0000B6FE File Offset: 0x000098FE
		internal static string DistributeFileStatusInfo_Sending
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_Sending", Resources.resourceCulture);
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x0600021C RID: 540 RVA: 0x0000B714 File Offset: 0x00009914
		internal static string DistributeFileStatusInfo_SendSuccess
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_SendSuccess", Resources.resourceCulture);
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x0600021D RID: 541 RVA: 0x0000B72A File Offset: 0x0000992A
		internal static string DistributeFileStatusInfo_Skipped
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_Skipped", Resources.resourceCulture);
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600021E RID: 542 RVA: 0x0000B740 File Offset: 0x00009940
		internal static string DistributeFileStatusInfo_Waiting
		{
			get
			{
				return Resources.ResourceManager.GetString("DistributeFileStatusInfo_Waiting", Resources.resourceCulture);
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x0600021F RID: 543 RVA: 0x0000B756 File Offset: 0x00009956
		internal static string DomainUsersImportForm_AllGroups
		{
			get
			{
				return Resources.ResourceManager.GetString("DomainUsersImportForm_AllGroups", Resources.resourceCulture);
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000220 RID: 544 RVA: 0x0000B76C File Offset: 0x0000996C
		internal static string DomainUsersImportForm_ErrorReadingDomainData
		{
			get
			{
				return Resources.ResourceManager.GetString("DomainUsersImportForm_ErrorReadingDomainData", Resources.resourceCulture);
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06000221 RID: 545 RVA: 0x0000B782 File Offset: 0x00009982
		internal static string DomainUsersImportForm_MustSelectGroupToImport
		{
			get
			{
				return Resources.ResourceManager.GetString("DomainUsersImportForm_MustSelectGroupToImport", Resources.resourceCulture);
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000222 RID: 546 RVA: 0x0000B798 File Offset: 0x00009998
		internal static string DomainUsersImportForm_MustSelectUsers
		{
			get
			{
				return Resources.ResourceManager.GetString("DomainUsersImportForm_MustSelectUsers", Resources.resourceCulture);
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000223 RID: 547 RVA: 0x0000B7AE File Offset: 0x000099AE
		internal static string DomainUsersImportForm_UsersImported
		{
			get
			{
				return Resources.ResourceManager.GetString("DomainUsersImportForm_UsersImported", Resources.resourceCulture);
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x06000224 RID: 548 RVA: 0x0000B7C4 File Offset: 0x000099C4
		internal static string DomainUsersImportForm_UsersSkippedBecauseExists
		{
			get
			{
				return Resources.ResourceManager.GetString("DomainUsersImportForm_UsersSkippedBecauseExists", Resources.resourceCulture);
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x06000225 RID: 549 RVA: 0x0000B7DA File Offset: 0x000099DA
		internal static Bitmap doublenext_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("doublenext_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x06000226 RID: 550 RVA: 0x0000B7F5 File Offset: 0x000099F5
		internal static Bitmap doubleprev_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("doubleprev_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x06000227 RID: 551 RVA: 0x0000B810 File Offset: 0x00009A10
		internal static Bitmap edit_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("edit_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x06000228 RID: 552 RVA: 0x0000B82B File Offset: 0x00009A2B
		internal static Bitmap edit_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("edit_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x06000229 RID: 553 RVA: 0x0000B846 File Offset: 0x00009A46
		internal static string ElementCanBeEditedOrDeletedOnlyByAdmin
		{
			get
			{
				return Resources.ResourceManager.GetString("ElementCanBeEditedOrDeletedOnlyByAdmin", Resources.resourceCulture);
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x0600022A RID: 554 RVA: 0x0000B85C File Offset: 0x00009A5C
		internal static Bitmap exporttoxls_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("exporttoxls_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x0600022B RID: 555 RVA: 0x0000B877 File Offset: 0x00009A77
		internal static Bitmap exporttoxls_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("exporttoxls_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x0600022C RID: 556 RVA: 0x0000B892 File Offset: 0x00009A92
		internal static Bitmap feature_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("feature_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600022D RID: 557 RVA: 0x0000B8AD File Offset: 0x00009AAD
		internal static string FileManagerForm_CreateFolder
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_CreateFolder", Resources.resourceCulture);
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600022E RID: 558 RVA: 0x0000B8C3 File Offset: 0x00009AC3
		internal static string FileManagerForm_DoYouWantToDeleteFile
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DoYouWantToDeleteFile", Resources.resourceCulture);
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x0600022F RID: 559 RVA: 0x0000B8D9 File Offset: 0x00009AD9
		internal static string FileManagerForm_DoYouWantToDeleteSelectedFiles
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DoYouWantToDeleteSelectedFiles", Resources.resourceCulture);
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000230 RID: 560 RVA: 0x0000B8EF File Offset: 0x00009AEF
		internal static string FileManagerForm_DriveTypeCDROM
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DriveTypeCDROM", Resources.resourceCulture);
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000231 RID: 561 RVA: 0x0000B905 File Offset: 0x00009B05
		internal static string FileManagerForm_DriveTypeDirectory
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DriveTypeDirectory", Resources.resourceCulture);
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000232 RID: 562 RVA: 0x0000B91B File Offset: 0x00009B1B
		internal static string FileManagerForm_DriveTypeFixed
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DriveTypeFixed", Resources.resourceCulture);
			}
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x06000233 RID: 563 RVA: 0x0000B931 File Offset: 0x00009B31
		internal static string FileManagerForm_DriveTypeRamdisk
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DriveTypeRamdisk", Resources.resourceCulture);
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x06000234 RID: 564 RVA: 0x0000B947 File Offset: 0x00009B47
		internal static string FileManagerForm_DriveTypeRemote
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DriveTypeRemote", Resources.resourceCulture);
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x06000235 RID: 565 RVA: 0x0000B95D File Offset: 0x00009B5D
		internal static string FileManagerForm_DriveTypeRemovable
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DriveTypeRemovable", Resources.resourceCulture);
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x06000236 RID: 566 RVA: 0x0000B973 File Offset: 0x00009B73
		internal static string FileManagerForm_DriveTypeUnknown
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_DriveTypeUnknown", Resources.resourceCulture);
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000237 RID: 567 RVA: 0x0000B989 File Offset: 0x00009B89
		internal static string FileManagerForm_FolderName
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_FolderName", Resources.resourceCulture);
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000238 RID: 568 RVA: 0x0000B99F File Offset: 0x00009B9F
		internal static string FileManagerForm_MustSelectFileOrFolder
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_MustSelectFileOrFolder", Resources.resourceCulture);
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000239 RID: 569 RVA: 0x0000B9B5 File Offset: 0x00009BB5
		internal static string FileManagerForm_MustSelectLocalFileToSend
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_MustSelectLocalFileToSend", Resources.resourceCulture);
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x0600023A RID: 570 RVA: 0x0000B9CB File Offset: 0x00009BCB
		internal static string FileManagerForm_MustSelectLocalFolderForReceiving
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_MustSelectLocalFolderForReceiving", Resources.resourceCulture);
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x0600023B RID: 571 RVA: 0x0000B9E1 File Offset: 0x00009BE1
		internal static string FileManagerForm_MustSelectRemoteFileToReceive
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_MustSelectRemoteFileToReceive", Resources.resourceCulture);
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600023C RID: 572 RVA: 0x0000B9F7 File Offset: 0x00009BF7
		internal static string FileManagerForm_MustSelectRemotelFolderForSending
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerForm_MustSelectRemotelFolderForSending", Resources.resourceCulture);
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x0600023D RID: 573 RVA: 0x0000BA0D File Offset: 0x00009C0D
		internal static string FileManagerViewModel_InvalidFolderNameDirNotSelected
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_InvalidFolderNameDirNotSelected", Resources.resourceCulture);
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x0600023E RID: 574 RVA: 0x0000BA23 File Offset: 0x00009C23
		internal static string FileManagerViewModel_LocalFileDeleted
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_LocalFileDeleted", Resources.resourceCulture);
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x0600023F RID: 575 RVA: 0x0000BA39 File Offset: 0x00009C39
		internal static string FileManagerViewModel_LocalFileDeletionError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_LocalFileDeletionError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06000240 RID: 576 RVA: 0x0000BA4F File Offset: 0x00009C4F
		internal static string FileManagerViewModel_LocalFolderCreated
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_LocalFolderCreated", Resources.resourceCulture);
			}
		}

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06000241 RID: 577 RVA: 0x0000BA65 File Offset: 0x00009C65
		internal static string FileManagerViewModel_LocalFolderCreatingError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_LocalFolderCreatingError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000242 RID: 578 RVA: 0x0000BA7B File Offset: 0x00009C7B
		internal static string FileManagerViewModel_LocalFolderDeleted
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_LocalFolderDeleted", Resources.resourceCulture);
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000243 RID: 579 RVA: 0x0000BA91 File Offset: 0x00009C91
		internal static string FileManagerViewModel_LocalFolderReadError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_LocalFolderReadError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000244 RID: 580 RVA: 0x0000BAA7 File Offset: 0x00009CA7
		internal static string FileManagerViewModel_RemoteDrivesReadError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteDrivesReadError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000245 RID: 581 RVA: 0x0000BABD File Offset: 0x00009CBD
		internal static string FileManagerViewModel_RemoteFileDeleted
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteFileDeleted", Resources.resourceCulture);
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x06000246 RID: 582 RVA: 0x0000BAD3 File Offset: 0x00009CD3
		internal static string FileManagerViewModel_RemoteFileDeletionError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteFileDeletionError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x06000247 RID: 583 RVA: 0x0000BAE9 File Offset: 0x00009CE9
		internal static string FileManagerViewModel_RemoteFileListReadError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteFileListReadError", Resources.resourceCulture);
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x06000248 RID: 584 RVA: 0x0000BAFF File Offset: 0x00009CFF
		internal static string FileManagerViewModel_RemoteFolderCreated
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteFolderCreated", Resources.resourceCulture);
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x06000249 RID: 585 RVA: 0x0000BB15 File Offset: 0x00009D15
		internal static string FileManagerViewModel_RemoteFolderCreatingError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteFolderCreatingError", Resources.resourceCulture);
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x0600024A RID: 586 RVA: 0x0000BB2B File Offset: 0x00009D2B
		internal static string FileManagerViewModel_RemoteFolderDeleted
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteFolderDeleted", Resources.resourceCulture);
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x0600024B RID: 587 RVA: 0x0000BB41 File Offset: 0x00009D41
		internal static string FileManagerViewModel_RemoteFolderDeletionError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileManagerViewModel_RemoteFolderDeletionError", Resources.resourceCulture);
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x0600024C RID: 588 RVA: 0x0000BB57 File Offset: 0x00009D57
		internal static string FileOverrideQuestionForm_FileInfo
		{
			get
			{
				return Resources.ResourceManager.GetString("FileOverrideQuestionForm_FileInfo", Resources.resourceCulture);
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x0600024D RID: 589 RVA: 0x0000BB6D File Offset: 0x00009D6D
		internal static string FileOverrideQuestionForm_LocalFile
		{
			get
			{
				return Resources.ResourceManager.GetString("FileOverrideQuestionForm_LocalFile", Resources.resourceCulture);
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x0600024E RID: 590 RVA: 0x0000BB83 File Offset: 0x00009D83
		internal static string FileOverrideQuestionForm_RemoteFile
		{
			get
			{
				return Resources.ResourceManager.GetString("FileOverrideQuestionForm_RemoteFile", Resources.resourceCulture);
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600024F RID: 591 RVA: 0x0000BB99 File Offset: 0x00009D99
		internal static string FileTransferForm_CalculatingFileHash
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_CalculatingFileHash", Resources.resourceCulture);
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000250 RID: 592 RVA: 0x0000BBAF File Offset: 0x00009DAF
		internal static string FileTransferForm_FileReceivingStarted
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_FileReceivingStarted", Resources.resourceCulture);
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000251 RID: 593 RVA: 0x0000BBC5 File Offset: 0x00009DC5
		internal static string FileTransferForm_FileSendingStarted
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_FileSendingStarted", Resources.resourceCulture);
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000252 RID: 594 RVA: 0x0000BBDB File Offset: 0x00009DDB
		internal static string FileTransferForm_FileTransferCompleted
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_FileTransferCompleted", Resources.resourceCulture);
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000253 RID: 595 RVA: 0x0000BBF1 File Offset: 0x00009DF1
		internal static string FileTransferForm_FileTransferError
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_FileTransferError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000254 RID: 596 RVA: 0x0000BC07 File Offset: 0x00009E07
		internal static string FileTransferForm_MultipleFileInfo
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_MultipleFileInfo", Resources.resourceCulture);
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x06000255 RID: 597 RVA: 0x0000BC1D File Offset: 0x00009E1D
		internal static string FileTransferForm_ReceivingFiles
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_ReceivingFiles", Resources.resourceCulture);
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x06000256 RID: 598 RVA: 0x0000BC33 File Offset: 0x00009E33
		internal static string FileTransferForm_SendFiles
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_SendFiles", Resources.resourceCulture);
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x06000257 RID: 599 RVA: 0x0000BC49 File Offset: 0x00009E49
		internal static string FileTransferForm_SingleFileInfo
		{
			get
			{
				return Resources.ResourceManager.GetString("FileTransferForm_SingleFileInfo", Resources.resourceCulture);
			}
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x06000258 RID: 600 RVA: 0x0000BC5F File Offset: 0x00009E5F
		internal static Bitmap filter_add_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("filter_add_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000259 RID: 601 RVA: 0x0000BC7A File Offset: 0x00009E7A
		internal static string FormAction_Create
		{
			get
			{
				return Resources.ResourceManager.GetString("FormAction_Create", Resources.resourceCulture);
			}
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x0600025A RID: 602 RVA: 0x0000BC90 File Offset: 0x00009E90
		internal static string FormAction_Delete
		{
			get
			{
				return Resources.ResourceManager.GetString("FormAction_Delete", Resources.resourceCulture);
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x0600025B RID: 603 RVA: 0x0000BCA6 File Offset: 0x00009EA6
		internal static string FormAction_Read
		{
			get
			{
				return Resources.ResourceManager.GetString("FormAction_Read", Resources.resourceCulture);
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x0600025C RID: 604 RVA: 0x0000BCBC File Offset: 0x00009EBC
		internal static string FormAction_Unknown
		{
			get
			{
				return Resources.ResourceManager.GetString("FormAction_Unknown", Resources.resourceCulture);
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600025D RID: 605 RVA: 0x0000BCD2 File Offset: 0x00009ED2
		internal static string FormAction_Update
		{
			get
			{
				return Resources.ResourceManager.GetString("FormAction_Update", Resources.resourceCulture);
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x0600025E RID: 606 RVA: 0x0000BCE8 File Offset: 0x00009EE8
		internal static Bitmap gettingstarted_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("gettingstarted_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x0600025F RID: 607 RVA: 0x0000BD03 File Offset: 0x00009F03
		internal static Bitmap gettingstarted_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("gettingstarted_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x06000260 RID: 608 RVA: 0x0000BD1E File Offset: 0x00009F1E
		internal static string HistoryView_DownloadDayBegin
		{
			get
			{
				return Resources.ResourceManager.GetString("HistoryView_DownloadDayBegin", Resources.resourceCulture);
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x06000261 RID: 609 RVA: 0x0000BD34 File Offset: 0x00009F34
		internal static string HistoryView_DownloadHistoryError
		{
			get
			{
				return Resources.ResourceManager.GetString("HistoryView_DownloadHistoryError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x06000262 RID: 610 RVA: 0x0000BD4A File Offset: 0x00009F4A
		internal static string HistoryView_InvalidDateRange
		{
			get
			{
				return Resources.ResourceManager.GetString("HistoryView_InvalidDateRange", Resources.resourceCulture);
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x06000263 RID: 611 RVA: 0x0000BD60 File Offset: 0x00009F60
		internal static string HistoryView_MustEnterValidDates
		{
			get
			{
				return Resources.ResourceManager.GetString("HistoryView_MustEnterValidDates", Resources.resourceCulture);
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x06000264 RID: 612 RVA: 0x0000BD76 File Offset: 0x00009F76
		internal static string HttpDowloadForm_Downloaded
		{
			get
			{
				return Resources.ResourceManager.GetString("HttpDowloadForm_Downloaded", Resources.resourceCulture);
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x06000265 RID: 613 RVA: 0x0000BD8C File Offset: 0x00009F8C
		internal static string HttpDownloadForm_DownloadError
		{
			get
			{
				return Resources.ResourceManager.GetString("HttpDownloadForm_DownloadError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x06000266 RID: 614 RVA: 0x0000BDA2 File Offset: 0x00009FA2
		internal static Bitmap hyperlink_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("hyperlink_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x06000267 RID: 615 RVA: 0x0000BDBD File Offset: 0x00009FBD
		internal static Bitmap hyperlink_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("hyperlink_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x06000268 RID: 616 RVA: 0x0000BDD8 File Offset: 0x00009FD8
		internal static Bitmap iconsetsymbols3_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("iconsetsymbols3_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x06000269 RID: 617 RVA: 0x0000BDF3 File Offset: 0x00009FF3
		internal static Bitmap insert_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("insert_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x0600026A RID: 618 RVA: 0x0000BE0E File Offset: 0x0000A00E
		internal static Bitmap insert_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("insert_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x0600026B RID: 619 RVA: 0x0000BE29 File Offset: 0x0000A029
		internal static string LoginForm_ForgotenPasswordMessageSend
		{
			get
			{
				return Resources.ResourceManager.GetString("LoginForm_ForgotenPasswordMessageSend", Resources.resourceCulture);
			}
		}

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x0600026C RID: 620 RVA: 0x0000BE3F File Offset: 0x0000A03F
		internal static string LoginForm_MustEnterLogin
		{
			get
			{
				return Resources.ResourceManager.GetString("LoginForm_MustEnterLogin", Resources.resourceCulture);
			}
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x0600026D RID: 621 RVA: 0x0000BE55 File Offset: 0x0000A055
		internal static string LogonSessionFormParams_MustEnterUserName
		{
			get
			{
				return Resources.ResourceManager.GetString("LogonSessionFormParams_MustEnterUserName", Resources.resourceCulture);
			}
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x0600026E RID: 622 RVA: 0x0000BE6B File Offset: 0x0000A06B
		internal static string MacroDescription_AnyDirectory
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_AnyDirectory", Resources.resourceCulture);
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x0600026F RID: 623 RVA: 0x0000BE81 File Offset: 0x0000A081
		internal static string MacroDescription_DESKTOP_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_DESKTOP_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000270 RID: 624 RVA: 0x0000BE97 File Offset: 0x0000A097
		internal static string MacroDescription_DOCUMENTS_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_DOCUMENTS_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000271 RID: 625 RVA: 0x0000BEAD File Offset: 0x0000A0AD
		internal static string MacroDescription_DOWNLOAD_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_DOWNLOAD_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000272 RID: 626 RVA: 0x0000BEC3 File Offset: 0x0000A0C3
		internal static string MacroDescription_PF_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_PF_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000273 RID: 627 RVA: 0x0000BED9 File Offset: 0x0000A0D9
		internal static string MacroDescription_PF86_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_PF86_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000274 RID: 628 RVA: 0x0000BEEF File Offset: 0x0000A0EF
		internal static string MacroDescription_SYS_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_SYS_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x06000275 RID: 629 RVA: 0x0000BF05 File Offset: 0x0000A105
		internal static string MacroDescription_USERPROFILE_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_USERPROFILE_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x06000276 RID: 630 RVA: 0x0000BF1B File Offset: 0x0000A11B
		internal static string MacroDescription_WIN_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroDescription_WIN_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x06000277 RID: 631 RVA: 0x0000BF31 File Offset: 0x0000A131
		internal static string MacroShortDescription_DESKTOP_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroShortDescription_DESKTOP_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000278 RID: 632 RVA: 0x0000BF47 File Offset: 0x0000A147
		internal static string MacroShortDescription_DOCUMENTS_DIR
		{
			get
			{
				return Resources.ResourceManager.GetString("MacroShortDescription_DOCUMENTS_DIR", Resources.resourceCulture);
			}
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x06000279 RID: 633 RVA: 0x0000BF5D File Offset: 0x0000A15D
		internal static string MainForm_ApiServerConnected
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_ApiServerConnected", Resources.resourceCulture);
			}
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x0600027A RID: 634 RVA: 0x0000BF73 File Offset: 0x0000A173
		internal static string MainForm_ApiServerDisconnected
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_ApiServerDisconnected", Resources.resourceCulture);
			}
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x0600027B RID: 635 RVA: 0x0000BF89 File Offset: 0x0000A189
		internal static string MainForm_AppIsUptoDate
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_AppIsUptoDate", Resources.resourceCulture);
			}
		}

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x0600027C RID: 636 RVA: 0x0000BF9F File Offset: 0x0000A19F
		internal static string MainForm_AppUpdateRunError
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_AppUpdateRunError", Resources.resourceCulture);
			}
		}

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x0600027D RID: 637 RVA: 0x0000BFB5 File Offset: 0x0000A1B5
		internal static string MainForm_CantDeleteConnectedDevice
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_CantDeleteConnectedDevice", Resources.resourceCulture);
			}
		}

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x0600027E RID: 638 RVA: 0x0000BFCB File Offset: 0x0000A1CB
		internal static string MainForm_CantMoveNestedGroups
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_CantMoveNestedGroups", Resources.resourceCulture);
			}
		}

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x0600027F RID: 639 RVA: 0x0000BFE1 File Offset: 0x0000A1E1
		internal static string MainForm_CheckAppUpdatesTitle
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_CheckAppUpdatesTitle", Resources.resourceCulture);
			}
		}

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x06000280 RID: 640 RVA: 0x0000BFF7 File Offset: 0x0000A1F7
		internal static string MainForm_DeviceAccessControlMenu
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_DeviceAccessControlMenu", Resources.resourceCulture);
			}
		}

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x06000281 RID: 641 RVA: 0x0000C00D File Offset: 0x0000A20D
		internal static string MainForm_DiagnosticWndCaption
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_DiagnosticWndCaption", Resources.resourceCulture);
			}
		}

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x06000282 RID: 642 RVA: 0x0000C023 File Offset: 0x0000A223
		internal static string MainForm_DiagnosticWndErrorCaption
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_DiagnosticWndErrorCaption", Resources.resourceCulture);
			}
		}

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x06000283 RID: 643 RVA: 0x0000C039 File Offset: 0x0000A239
		internal static string MainForm_DoYouWantDeleteDevice
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_DoYouWantDeleteDevice", Resources.resourceCulture);
			}
		}

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000284 RID: 644 RVA: 0x0000C04F File Offset: 0x0000A24F
		internal static string MainForm_DoYouWantDeleteDevicesGroup
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_DoYouWantDeleteDevicesGroup", Resources.resourceCulture);
			}
		}

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x06000285 RID: 645 RVA: 0x0000C065 File Offset: 0x0000A265
		internal static string MainForm_DoYouWantDeleteSelectedDevicesAndGroups
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_DoYouWantDeleteSelectedDevicesAndGroups", Resources.resourceCulture);
			}
		}

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x06000286 RID: 646 RVA: 0x0000C07B File Offset: 0x0000A27B
		internal static string MainForm_DoYouWantMoveDevicesToGroup
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_DoYouWantMoveDevicesToGroup", Resources.resourceCulture);
			}
		}

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000287 RID: 647 RVA: 0x0000C091 File Offset: 0x0000A291
		internal static string MainForm_InetAccessControlMenu
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_InetAccessControlMenu", Resources.resourceCulture);
			}
		}

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x06000288 RID: 648 RVA: 0x0000C0A7 File Offset: 0x0000A2A7
		internal static string MainForm_MustSelectDeviceOrGroupToDelete
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_MustSelectDeviceOrGroupToDelete", Resources.resourceCulture);
			}
		}

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x06000289 RID: 649 RVA: 0x0000C0BD File Offset: 0x0000A2BD
		internal static string MainForm_MustSelectDeviceOrGroupToEdit
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_MustSelectDeviceOrGroupToEdit", Resources.resourceCulture);
			}
		}

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x0600028A RID: 650 RVA: 0x0000C0D3 File Offset: 0x0000A2D3
		internal static string MainForm_NewVersionOfAgentAvaliableCaption
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_NewVersionOfAgentAvaliableCaption", Resources.resourceCulture);
			}
		}

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x0600028B RID: 651 RVA: 0x0000C0E9 File Offset: 0x0000A2E9
		internal static string MainForm_NewVersionOfAgentAvaliableMessage
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_NewVersionOfAgentAvaliableMessage", Resources.resourceCulture);
			}
		}

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x0600028C RID: 652 RVA: 0x0000C0FF File Offset: 0x0000A2FF
		internal static string MainForm_OnOffDeviceMenu
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_OnOffDeviceMenu", Resources.resourceCulture);
			}
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x0600028D RID: 653 RVA: 0x0000C115 File Offset: 0x0000A315
		internal static string MainForm_RemoteDesktopMenu
		{
			get
			{
				return Resources.ResourceManager.GetString("MainForm_RemoteDesktopMenu", Resources.resourceCulture);
			}
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x0600028E RID: 654 RVA: 0x0000C12B File Offset: 0x0000A32B
		internal static Bitmap media_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("media_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x0600028F RID: 655 RVA: 0x0000C146 File Offset: 0x0000A346
		internal static Bitmap media_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("media_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x06000290 RID: 656 RVA: 0x0000C161 File Offset: 0x0000A361
		internal static Bitmap newcomment_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("newcomment_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x06000291 RID: 657 RVA: 0x0000C17C File Offset: 0x0000A37C
		internal static Bitmap newcomment_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("newcomment_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x06000292 RID: 658 RVA: 0x0000C197 File Offset: 0x0000A397
		internal static Bitmap opiekun_logo_120x125
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("opiekun_logo_120x125", Resources.resourceCulture);
			}
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000293 RID: 659 RVA: 0x0000C1B2 File Offset: 0x0000A3B2
		internal static Bitmap pause_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("pause_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000294 RID: 660 RVA: 0x0000C1CD File Offset: 0x0000A3CD
		internal static Bitmap pause_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("pause_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x06000295 RID: 661 RVA: 0x0000C1E8 File Offset: 0x0000A3E8
		internal static Bitmap play_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("play_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x06000296 RID: 662 RVA: 0x0000C203 File Offset: 0x0000A403
		internal static Bitmap play_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("play_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x06000297 RID: 663 RVA: 0x0000C21E File Offset: 0x0000A41E
		internal static Bitmap process_hacker
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("process_hacker", Resources.resourceCulture);
			}
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000298 RID: 664 RVA: 0x0000C239 File Offset: 0x0000A439
		internal static string ProcessDefForm_InvalidPath
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessDefForm_InvalidPath", Resources.resourceCulture);
			}
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000299 RID: 665 RVA: 0x0000C24F File Offset: 0x0000A44F
		internal static string ProcessDefForm_InvalidUserName
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessDefForm_InvalidUserName", Resources.resourceCulture);
			}
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x0600029A RID: 666 RVA: 0x0000C265 File Offset: 0x0000A465
		internal static string ProcessDefForm_OpenFileDialogFilter
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessDefForm_OpenFileDialogFilter", Resources.resourceCulture);
			}
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x0600029B RID: 667 RVA: 0x0000C27B File Offset: 0x0000A47B
		internal static string ProcessDefForm_OpenFileDialogTitle
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessDefForm_OpenFileDialogTitle", Resources.resourceCulture);
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x0600029C RID: 668 RVA: 0x0000C291 File Offset: 0x0000A491
		internal static string ProcessDefForm_StartProcessTitle
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessDefForm_StartProcessTitle", Resources.resourceCulture);
			}
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x0600029D RID: 669 RVA: 0x0000C2A7 File Offset: 0x0000A4A7
		internal static string ProcessDefListForm_DoYouWantDeleteItem
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessDefListForm_DoYouWantDeleteItem", Resources.resourceCulture);
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x0600029E RID: 670 RVA: 0x0000C2BD File Offset: 0x0000A4BD
		internal static string ProcessessView_DoYouWantToTerminateProcesses
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessessView_DoYouWantToTerminateProcesses", Resources.resourceCulture);
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x0600029F RID: 671 RVA: 0x0000C2D3 File Offset: 0x0000A4D3
		internal static string ProcessessView_MustSelectProcessToTerminate
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessessView_MustSelectProcessToTerminate", Resources.resourceCulture);
			}
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x060002A0 RID: 672 RVA: 0x0000C2E9 File Offset: 0x0000A4E9
		internal static string ProcessType_Application
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessType_Application", Resources.resourceCulture);
			}
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x060002A1 RID: 673 RVA: 0x0000C2FF File Offset: 0x0000A4FF
		internal static string ProcessType_Background
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessType_Background", Resources.resourceCulture);
			}
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x060002A2 RID: 674 RVA: 0x0000C315 File Offset: 0x0000A515
		internal static string ProcessType_System
		{
			get
			{
				return Resources.ResourceManager.GetString("ProcessType_System", Resources.resourceCulture);
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x060002A3 RID: 675 RVA: 0x0000C32B File Offset: 0x0000A52B
		internal static Bitmap progress_animated
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("progress_animated", Resources.resourceCulture);
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x060002A4 RID: 676 RVA: 0x0000C346 File Offset: 0x0000A546
		internal static Bitmap properties_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("properties_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x060002A5 RID: 677 RVA: 0x0000C361 File Offset: 0x0000A561
		internal static Bitmap properties_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("properties_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x060002A6 RID: 678 RVA: 0x0000C37C File Offset: 0x0000A57C
		internal static Bitmap question_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("question_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x060002A7 RID: 679 RVA: 0x0000C397 File Offset: 0x0000A597
		internal static string RdpControl_ConnectingText
		{
			get
			{
				return Resources.ResourceManager.GetString("RdpControl_ConnectingText", Resources.resourceCulture);
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x060002A8 RID: 680 RVA: 0x0000C3AD File Offset: 0x0000A5AD
		internal static string RdpControl_ConnectionEnded
		{
			get
			{
				return Resources.ResourceManager.GetString("RdpControl_ConnectionEnded", Resources.resourceCulture);
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x060002A9 RID: 681 RVA: 0x0000C3C3 File Offset: 0x0000A5C3
		internal static string RdpControl_ConnectionErrorInvalidPassword
		{
			get
			{
				return Resources.ResourceManager.GetString("RdpControl_ConnectionErrorInvalidPassword", Resources.resourceCulture);
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x060002AA RID: 682 RVA: 0x0000C3D9 File Offset: 0x0000A5D9
		internal static string RdpControl_ConnectionErrorWithReason
		{
			get
			{
				return Resources.ResourceManager.GetString("RdpControl_ConnectionErrorWithReason", Resources.resourceCulture);
			}
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x060002AB RID: 683 RVA: 0x0000C3EF File Offset: 0x0000A5EF
		internal static string RdpControl_ConnectionErrorX204
		{
			get
			{
				return Resources.ResourceManager.GetString("RdpControl_ConnectionErrorX204", Resources.resourceCulture);
			}
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x060002AC RID: 684 RVA: 0x0000C405 File Offset: 0x0000A605
		internal static string RdpControl_DisconnectedText
		{
			get
			{
				return Resources.ResourceManager.GetString("RdpControl_DisconnectedText", Resources.resourceCulture);
			}
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x060002AD RID: 685 RVA: 0x0000C41B File Offset: 0x0000A61B
		internal static string RdpControl_Exception
		{
			get
			{
				return Resources.ResourceManager.GetString("RdpControl_Exception", Resources.resourceCulture);
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x060002AE RID: 686 RVA: 0x0000C431 File Offset: 0x0000A631
		internal static string ReceiveFilesLocalPathType_DirectoryPerDeviceName
		{
			get
			{
				return Resources.ResourceManager.GetString("ReceiveFilesLocalPathType_DirectoryPerDeviceName", Resources.resourceCulture);
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x060002AF RID: 687 RVA: 0x0000C447 File Offset: 0x0000A647
		internal static string ReceiveFilesLocalPathType_DirectoryPerUserFullName
		{
			get
			{
				return Resources.ResourceManager.GetString("ReceiveFilesLocalPathType_DirectoryPerUserFullName", Resources.resourceCulture);
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x060002B0 RID: 688 RVA: 0x0000C45D File Offset: 0x0000A65D
		internal static string ReceiveFilesLocalPathType_DirectoryPerUserLogin
		{
			get
			{
				return Resources.ResourceManager.GetString("ReceiveFilesLocalPathType_DirectoryPerUserLogin", Resources.resourceCulture);
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x060002B1 RID: 689 RVA: 0x0000C473 File Offset: 0x0000A673
		internal static string ReceiveFilesLocalPathType_OneDirectoryForAll
		{
			get
			{
				return Resources.ResourceManager.GetString("ReceiveFilesLocalPathType_OneDirectoryForAll", Resources.resourceCulture);
			}
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x060002B2 RID: 690 RVA: 0x0000C489 File Offset: 0x0000A689
		internal static Bitmap refresh_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("refresh_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x060002B3 RID: 691 RVA: 0x0000C4A4 File Offset: 0x0000A6A4
		internal static Bitmap refresh2_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("refresh2_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x060002B4 RID: 692 RVA: 0x0000C4BF File Offset: 0x0000A6BF
		internal static Bitmap refresh2_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("refresh2_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x060002B5 RID: 693 RVA: 0x0000C4DA File Offset: 0x0000A6DA
		internal static Bitmap refreshallpivottable_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("refreshallpivottable_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x0000C4F5 File Offset: 0x0000A6F5
		internal static Bitmap refreshallpivottable_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("refreshallpivottable_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x060002B7 RID: 695 RVA: 0x0000C510 File Offset: 0x0000A710
		internal static string RefreshTime_10s
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_10s", Resources.resourceCulture);
			}
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x060002B8 RID: 696 RVA: 0x0000C526 File Offset: 0x0000A726
		internal static string RefreshTime_15s
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_15s", Resources.resourceCulture);
			}
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x060002B9 RID: 697 RVA: 0x0000C53C File Offset: 0x0000A73C
		internal static string RefreshTime_30s
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_30s", Resources.resourceCulture);
			}
		}

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x060002BA RID: 698 RVA: 0x0000C552 File Offset: 0x0000A752
		internal static string RefreshTime_45s
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_45s", Resources.resourceCulture);
			}
		}

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x060002BB RID: 699 RVA: 0x0000C568 File Offset: 0x0000A768
		internal static string RefreshTime_5s
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_5s", Resources.resourceCulture);
			}
		}

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x060002BC RID: 700 RVA: 0x0000C57E File Offset: 0x0000A77E
		internal static string RefreshTime_60s
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_60s", Resources.resourceCulture);
			}
		}

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x060002BD RID: 701 RVA: 0x0000C594 File Offset: 0x0000A794
		internal static string RefreshTime_90s
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_90s", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x060002BE RID: 702 RVA: 0x0000C5AA File Offset: 0x0000A7AA
		internal static string RefreshTime_Disabled
		{
			get
			{
				return Resources.ResourceManager.GetString("RefreshTime_Disabled", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x060002BF RID: 703 RVA: 0x0000C5C0 File Offset: 0x0000A7C0
		internal static Bitmap remotedesktop_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("remotedesktop_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x060002C0 RID: 704 RVA: 0x0000C5DB File Offset: 0x0000A7DB
		internal static Bitmap remotedesktop_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("remotedesktop_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x060002C1 RID: 705 RVA: 0x0000C5F6 File Offset: 0x0000A7F6
		internal static string RemoteDesktopColorsDepth_Bits16
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopColorsDepth_Bits16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x060002C2 RID: 706 RVA: 0x0000C60C File Offset: 0x0000A80C
		internal static string RemoteDesktopColorsDepth_Bits24
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopColorsDepth_Bits24", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x060002C3 RID: 707 RVA: 0x0000C622 File Offset: 0x0000A822
		internal static string RemoteDesktopColorsDepth_Bits32
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopColorsDepth_Bits32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x060002C4 RID: 708 RVA: 0x0000C638 File Offset: 0x0000A838
		internal static string RemoteDesktopColorsDepth_Bits8
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopColorsDepth_Bits8", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x060002C5 RID: 709 RVA: 0x0000C64E File Offset: 0x0000A84E
		internal static string RemoteDesktopSize_FitToWindow
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopSize_FitToWindow", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x060002C6 RID: 710 RVA: 0x0000C664 File Offset: 0x0000A864
		internal static string RemoteDesktopSize_Fixed1024x768
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopSize_Fixed1024x768", Resources.resourceCulture);
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x060002C7 RID: 711 RVA: 0x0000C67A File Offset: 0x0000A87A
		internal static string RemoteDesktopSize_Fixed1280x1024
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopSize_Fixed1280x1024", Resources.resourceCulture);
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x060002C8 RID: 712 RVA: 0x0000C690 File Offset: 0x0000A890
		internal static string RemoteDesktopSize_Fixed1600x900
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopSize_Fixed1600x900", Resources.resourceCulture);
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x060002C9 RID: 713 RVA: 0x0000C6A6 File Offset: 0x0000A8A6
		internal static string RemoteDesktopSize_Fixed1920x1080
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopSize_Fixed1920x1080", Resources.resourceCulture);
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x060002CA RID: 714 RVA: 0x0000C6BC File Offset: 0x0000A8BC
		internal static string RemoteDesktopSize_Fixed800x600
		{
			get
			{
				return Resources.ResourceManager.GetString("RemoteDesktopSize_Fixed800x600", Resources.resourceCulture);
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x060002CB RID: 715 RVA: 0x0000C6D2 File Offset: 0x0000A8D2
		internal static string Resources_ScreenshotsView_ScreenshotHint
		{
			get
			{
				return Resources.ResourceManager.GetString("Resources.ScreenshotsView_ScreenshotHint", Resources.resourceCulture);
			}
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x060002CC RID: 716 RVA: 0x0000C6E8 File Offset: 0x0000A8E8
		internal static Bitmap richtext_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("richtext_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x060002CD RID: 717 RVA: 0x0000C703 File Offset: 0x0000A903
		internal static Bitmap richtext_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("richtext_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x060002CE RID: 718 RVA: 0x0000C71E File Offset: 0x0000A91E
		internal static Bitmap roles_add_api_user32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("roles_add_api_user32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x060002CF RID: 719 RVA: 0x0000C739 File Offset: 0x0000A939
		internal static Bitmap roles_add_api_usersgroup_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("roles_add_api_usersgroup_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x060002D0 RID: 720 RVA: 0x0000C754 File Offset: 0x0000A954
		internal static Bitmap roles_add_user_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("roles_add_user_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x060002D1 RID: 721 RVA: 0x0000C76F File Offset: 0x0000A96F
		internal static Bitmap roles_add_usersgroup_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("roles_add_usersgroup_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x060002D2 RID: 722 RVA: 0x0000C78A File Offset: 0x0000A98A
		internal static Bitmap roles_import_users_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("roles_import_users_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x060002D3 RID: 723 RVA: 0x0000C7A5 File Offset: 0x0000A9A5
		internal static string RolesForm_ClickToChangeValue
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_ClickToChangeValue", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x060002D4 RID: 724 RVA: 0x0000C7BB File Offset: 0x0000A9BB
		internal static string RolesForm_DeleteGroupQuestion
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_DeleteGroupQuestion", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x060002D5 RID: 725 RVA: 0x0000C7D1 File Offset: 0x0000A9D1
		internal static string RolesForm_DeleteManyUsersQuestion
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_DeleteManyUsersQuestion", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x060002D6 RID: 726 RVA: 0x0000C7E7 File Offset: 0x0000A9E7
		internal static string RolesForm_DeleteOneUserQuestion
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_DeleteOneUserQuestion", Resources.resourceCulture);
			}
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x060002D7 RID: 727 RVA: 0x0000C7FD File Offset: 0x0000A9FD
		internal static string RolesForm_EditUserGroupCaption
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_EditUserGroupCaption", Resources.resourceCulture);
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x060002D8 RID: 728 RVA: 0x0000C813 File Offset: 0x0000AA13
		internal static string RolesForm_EditUserGroupDescription
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_EditUserGroupDescription", Resources.resourceCulture);
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x060002D9 RID: 729 RVA: 0x0000C829 File Offset: 0x0000AA29
		internal static string RolesForm_Permissions
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_Permissions", Resources.resourceCulture);
			}
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x060002DA RID: 730 RVA: 0x0000C83F File Offset: 0x0000AA3F
		internal static string RolesForm_RestrictionsAndSettings
		{
			get
			{
				return Resources.ResourceManager.GetString("RolesForm_RestrictionsAndSettings", Resources.resourceCulture);
			}
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x060002DB RID: 731 RVA: 0x0000C855 File Offset: 0x0000AA55
		internal static string RoleUserForm_HelpForCreatingApiUser
		{
			get
			{
				return Resources.ResourceManager.GetString("RoleUserForm_HelpForCreatingApiUser", Resources.resourceCulture);
			}
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x060002DC RID: 732 RVA: 0x0000C86B File Offset: 0x0000AA6B
		internal static string RoleUserForm_MustEnterValidEmail
		{
			get
			{
				return Resources.ResourceManager.GetString("RoleUserForm_MustEnterValidEmail", Resources.resourceCulture);
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x060002DD RID: 733 RVA: 0x0000C881 File Offset: 0x0000AA81
		internal static string RoleUserForm_UserIdCanContainsOneAsterisk
		{
			get
			{
				return Resources.ResourceManager.GetString("RoleUserForm_UserIdCanContainsOneAsterisk", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x060002DE RID: 734 RVA: 0x0000C897 File Offset: 0x0000AA97
		internal static string RoleUserForm_UserIdHasIllegalCharacters
		{
			get
			{
				return Resources.ResourceManager.GetString("RoleUserForm_UserIdHasIllegalCharacters", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x060002DF RID: 735 RVA: 0x0000C8AD File Offset: 0x0000AAAD
		internal static string RulesDefListForm_DoYouWantDeleteRule
		{
			get
			{
				return Resources.ResourceManager.GetString("RulesDefListForm_DoYouWantDeleteRule", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x060002E0 RID: 736 RVA: 0x0000C8C3 File Offset: 0x0000AAC3
		internal static Bitmap screenshot_background
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("screenshot_background", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x060002E1 RID: 737 RVA: 0x0000C8DE File Offset: 0x0000AADE
		internal static Bitmap screenshot_shadow
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("screenshot_shadow", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x060002E2 RID: 738 RVA: 0x0000C8F9 File Offset: 0x0000AAF9
		internal static string ScreenshotItemDescription_DeviceDescription
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemDescription_DeviceDescription", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x060002E3 RID: 739 RVA: 0x0000C90F File Offset: 0x0000AB0F
		internal static string ScreenshotItemDescription_DeviceName
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemDescription_DeviceName", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x060002E4 RID: 740 RVA: 0x0000C925 File Offset: 0x0000AB25
		internal static string ScreenshotItemDescription_DomainAndUserName
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemDescription_DomainAndUserName", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x060002E5 RID: 741 RVA: 0x0000C93B File Offset: 0x0000AB3B
		internal static string ScreenshotItemDescription_None
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemDescription_None", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x060002E6 RID: 742 RVA: 0x0000C951 File Offset: 0x0000AB51
		internal static string ScreenshotItemDescription_UserFullName
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemDescription_UserFullName", Resources.resourceCulture);
			}
		}

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x060002E7 RID: 743 RVA: 0x0000C967 File Offset: 0x0000AB67
		internal static string ScreenshotItemDescription_UserName
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemDescription_UserName", Resources.resourceCulture);
			}
		}

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x060002E8 RID: 744 RVA: 0x0000C97D File Offset: 0x0000AB7D
		internal static string ScreenshotItemFrameSize_Medium
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemFrameSize_Medium", Resources.resourceCulture);
			}
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x060002E9 RID: 745 RVA: 0x0000C993 File Offset: 0x0000AB93
		internal static string ScreenshotItemFrameSize_Thick
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemFrameSize_Thick", Resources.resourceCulture);
			}
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x060002EA RID: 746 RVA: 0x0000C9A9 File Offset: 0x0000ABA9
		internal static string ScreenshotItemFrameSize_Thin
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemFrameSize_Thin", Resources.resourceCulture);
			}
		}

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x060002EB RID: 747 RVA: 0x0000C9BF File Offset: 0x0000ABBF
		internal static string ScreenshotItemSortMode_DeviceItemAscending
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemSortMode_DeviceItemAscending", Resources.resourceCulture);
			}
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x060002EC RID: 748 RVA: 0x0000C9D5 File Offset: 0x0000ABD5
		internal static string ScreenshotItemSortMode_DeviceItemInGroupAscending
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotItemSortMode_DeviceItemInGroupAscending", Resources.resourceCulture);
			}
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x060002ED RID: 749 RVA: 0x0000C9EB File Offset: 0x0000ABEB
		internal static string ScreenshotsView_DeviceNotConnected
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotsView_DeviceNotConnected", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x060002EE RID: 750 RVA: 0x0000CA01 File Offset: 0x0000AC01
		internal static string ScreenshotsView_DisplayDisabledError
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotsView_DisplayDisabledError", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x060002EF RID: 751 RVA: 0x0000CA17 File Offset: 0x0000AC17
		internal static string ScreenshotsView_TakingScreenshot
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotsView_TakingScreenshot", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x060002F0 RID: 752 RVA: 0x0000CA2D File Offset: 0x0000AC2D
		internal static string ScreenshotsView_UserNotActiveError
		{
			get
			{
				return Resources.ResourceManager.GetString("ScreenshotsView_UserNotActiveError", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x060002F1 RID: 753 RVA: 0x0000CA43 File Offset: 0x0000AC43
		internal static string SelectConsoleGroupsOnDeviceRuleForm_MustSelectDevice
		{
			get
			{
				return Resources.ResourceManager.GetString("SelectConsoleGroupsOnDeviceRuleForm_MustSelectDevice", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x060002F2 RID: 754 RVA: 0x0000CA59 File Offset: 0x0000AC59
		internal static string SelectRemoteFileForm_FileModeCaption
		{
			get
			{
				return Resources.ResourceManager.GetString("SelectRemoteFileForm_FileModeCaption", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x060002F3 RID: 755 RVA: 0x0000CA6F File Offset: 0x0000AC6F
		internal static string SelectRemoteFileForm_FolderModeCaption
		{
			get
			{
				return Resources.ResourceManager.GetString("SelectRemoteFileForm_FolderModeCaption", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x060002F4 RID: 756 RVA: 0x0000CA85 File Offset: 0x0000AC85
		internal static Bitmap server_rdp_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("server_rdp_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x060002F5 RID: 757 RVA: 0x0000CAA0 File Offset: 0x0000ACA0
		internal static string ServicesToShow_All
		{
			get
			{
				return Resources.ResourceManager.GetString("ServicesToShow_All", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x060002F6 RID: 758 RVA: 0x0000CAB6 File Offset: 0x0000ACB6
		internal static string ServicesToShow_OnlyStartedServices
		{
			get
			{
				return Resources.ResourceManager.GetString("ServicesToShow_OnlyStartedServices", Resources.resourceCulture);
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x060002F7 RID: 759 RVA: 0x0000CACC File Offset: 0x0000ACCC
		internal static string ServicesToShow_Services
		{
			get
			{
				return Resources.ResourceManager.GetString("ServicesToShow_Services", Resources.resourceCulture);
			}
		}

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x060002F8 RID: 760 RVA: 0x0000CAE2 File Offset: 0x0000ACE2
		internal static string ServicesView_DoYouWantToControlSelectedServices
		{
			get
			{
				return Resources.ResourceManager.GetString("ServicesView_DoYouWantToControlSelectedServices", Resources.resourceCulture);
			}
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x060002F9 RID: 761 RVA: 0x0000CAF8 File Offset: 0x0000ACF8
		internal static string ServicesView_MustSelectServiceToControl
		{
			get
			{
				return Resources.ResourceManager.GetString("ServicesView_MustSelectServiceToControl", Resources.resourceCulture);
			}
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x060002FA RID: 762 RVA: 0x0000CB0E File Offset: 0x0000AD0E
		internal static Bitmap session_lock_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("session_lock_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x060002FB RID: 763 RVA: 0x0000CB29 File Offset: 0x0000AD29
		internal static Bitmap session_lock_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("session_lock_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x060002FC RID: 764 RVA: 0x0000CB44 File Offset: 0x0000AD44
		internal static Bitmap session_logon_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("session_logon_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x060002FD RID: 765 RVA: 0x0000CB5F File Offset: 0x0000AD5F
		internal static Bitmap session_logon_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("session_logon_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x060002FE RID: 766 RVA: 0x0000CB7A File Offset: 0x0000AD7A
		internal static Bitmap session_logout_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("session_logout_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x060002FF RID: 767 RVA: 0x0000CB95 File Offset: 0x0000AD95
		internal static Bitmap session_logout_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("session_logout_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x06000300 RID: 768 RVA: 0x0000CBB0 File Offset: 0x0000ADB0
		internal static Bitmap settings_appcategory_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_appcategory_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x06000301 RID: 769 RVA: 0x0000CBCB File Offset: 0x0000ADCB
		internal static Bitmap settings_appcategory_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_appcategory_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x06000302 RID: 770 RVA: 0x0000CBE6 File Offset: 0x0000ADE6
		internal static Bitmap settings_desktops_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_desktops_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x06000303 RID: 771 RVA: 0x0000CC01 File Offset: 0x0000AE01
		internal static Bitmap settings_desktops_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_desktops_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x06000304 RID: 772 RVA: 0x0000CC1C File Offset: 0x0000AE1C
		internal static Bitmap settings_device_move_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_device_move_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000305 RID: 773 RVA: 0x0000CC37 File Offset: 0x0000AE37
		internal static Bitmap settings_device_move_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_device_move_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000306 RID: 774 RVA: 0x0000CC52 File Offset: 0x0000AE52
		internal static Bitmap settings_devicegroup_add_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_devicegroup_add_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000307 RID: 775 RVA: 0x0000CC6D File Offset: 0x0000AE6D
		internal static Bitmap settings_devicegroup_add_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_devicegroup_add_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000308 RID: 776 RVA: 0x0000CC88 File Offset: 0x0000AE88
		internal static Bitmap settings_license_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_license_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06000309 RID: 777 RVA: 0x0000CCA3 File Offset: 0x0000AEA3
		internal static Bitmap settings_license_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_license_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x0600030A RID: 778 RVA: 0x0000CCBE File Offset: 0x0000AEBE
		internal static Bitmap settings_password_change_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_password_change_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x0600030B RID: 779 RVA: 0x0000CCD9 File Offset: 0x0000AED9
		internal static Bitmap settings_password_change_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_password_change_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x0600030C RID: 780 RVA: 0x0000CCF4 File Offset: 0x0000AEF4
		internal static Bitmap settings_roles_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_roles_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x0600030D RID: 781 RVA: 0x0000CD0F File Offset: 0x0000AF0F
		internal static Bitmap settings_roles_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_roles_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x0600030E RID: 782 RVA: 0x0000CD2A File Offset: 0x0000AF2A
		internal static Bitmap settings_rules_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_rules_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x0600030F RID: 783 RVA: 0x0000CD45 File Offset: 0x0000AF45
		internal static Bitmap settings_rules_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_rules_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x06000310 RID: 784 RVA: 0x0000CD60 File Offset: 0x0000AF60
		internal static Bitmap settings_update_agents_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_update_agents_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x06000311 RID: 785 RVA: 0x0000CD7B File Offset: 0x0000AF7B
		internal static Bitmap settings_update_agents_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_update_agents_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x06000312 RID: 786 RVA: 0x0000CD96 File Offset: 0x0000AF96
		internal static Bitmap settings_update_console_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_update_console_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x06000313 RID: 787 RVA: 0x0000CDB1 File Offset: 0x0000AFB1
		internal static Bitmap settings_update_console_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_update_console_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000314 RID: 788 RVA: 0x0000CDCC File Offset: 0x0000AFCC
		internal static Bitmap settings_webcategory_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_webcategory_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000315 RID: 789 RVA: 0x0000CDE7 File Offset: 0x0000AFE7
		internal static Bitmap settings_webcategory_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("settings_webcategory_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x06000316 RID: 790 RVA: 0x0000CE02 File Offset: 0x0000B002
		internal static string ShowMessageDefForm_SendMssageTitle
		{
			get
			{
				return Resources.ResourceManager.GetString("ShowMessageDefForm_SendMssageTitle", Resources.resourceCulture);
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x06000317 RID: 791 RVA: 0x0000CE18 File Offset: 0x0000B018
		internal static string ShowMessageDefListForm_DoYouWantDeleteItem
		{
			get
			{
				return Resources.ResourceManager.GetString("ShowMessageDefListForm_DoYouWantDeleteItem", Resources.resourceCulture);
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x06000318 RID: 792 RVA: 0x0000CE2E File Offset: 0x0000B02E
		internal static Bitmap spacer_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("spacer_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x06000319 RID: 793 RVA: 0x0000CE49 File Offset: 0x0000B049
		internal static Bitmap stop_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("stop_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x0600031A RID: 794 RVA: 0x0000CE64 File Offset: 0x0000B064
		internal static Bitmap stop_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("stop_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x0600031B RID: 795 RVA: 0x0000CE7F File Offset: 0x0000B07F
		internal static Bitmap technology_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("technology_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x0600031C RID: 796 RVA: 0x0000CE9A File Offset: 0x0000B09A
		internal static Bitmap technology_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("technology_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x0600031D RID: 797 RVA: 0x0000CEB5 File Offset: 0x0000B0B5
		internal static Bitmap terminal_rdp_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("terminal_rdp_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x0600031E RID: 798 RVA: 0x0000CED0 File Offset: 0x0000B0D0
		internal static string TimeDays
		{
			get
			{
				return Resources.ResourceManager.GetString("TimeDays", Resources.resourceCulture);
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x0600031F RID: 799 RVA: 0x0000CEE6 File Offset: 0x0000B0E6
		internal static string TimeHours
		{
			get
			{
				return Resources.ResourceManager.GetString("TimeHours", Resources.resourceCulture);
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000320 RID: 800 RVA: 0x0000CEFC File Offset: 0x0000B0FC
		internal static string TimeMinutes
		{
			get
			{
				return Resources.ResourceManager.GetString("TimeMinutes", Resources.resourceCulture);
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000321 RID: 801 RVA: 0x0000CF12 File Offset: 0x0000B112
		internal static string TimePeriods_CustomRange
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_CustomRange", Resources.resourceCulture);
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000322 RID: 802 RVA: 0x0000CF28 File Offset: 0x0000B128
		internal static string TimePeriods_FromBeginningOfData
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_FromBeginningOfData", Resources.resourceCulture);
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000323 RID: 803 RVA: 0x0000CF3E File Offset: 0x0000B13E
		internal static string TimePeriods_Last30Days
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_Last30Days", Resources.resourceCulture);
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000324 RID: 804 RVA: 0x0000CF54 File Offset: 0x0000B154
		internal static string TimePeriods_Last7Days
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_Last7Days", Resources.resourceCulture);
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000325 RID: 805 RVA: 0x0000CF6A File Offset: 0x0000B16A
		internal static string TimePeriods_LastMonth
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_LastMonth", Resources.resourceCulture);
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000326 RID: 806 RVA: 0x0000CF80 File Offset: 0x0000B180
		internal static string TimePeriods_LastWeek
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_LastWeek", Resources.resourceCulture);
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000327 RID: 807 RVA: 0x0000CF96 File Offset: 0x0000B196
		internal static string TimePeriods_ThisMonth
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_ThisMonth", Resources.resourceCulture);
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x06000328 RID: 808 RVA: 0x0000CFAC File Offset: 0x0000B1AC
		internal static string TimePeriods_ThisWeek
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_ThisWeek", Resources.resourceCulture);
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000329 RID: 809 RVA: 0x0000CFC2 File Offset: 0x0000B1C2
		internal static string TimePeriods_ThisYear
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_ThisYear", Resources.resourceCulture);
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x0600032A RID: 810 RVA: 0x0000CFD8 File Offset: 0x0000B1D8
		internal static string TimePeriods_Today
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_Today", Resources.resourceCulture);
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x0600032B RID: 811 RVA: 0x0000CFEE File Offset: 0x0000B1EE
		internal static string TimePeriods_Yesterday
		{
			get
			{
				return Resources.ResourceManager.GetString("TimePeriods_Yesterday", Resources.resourceCulture);
			}
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x0600032C RID: 812 RVA: 0x0000D004 File Offset: 0x0000B204
		internal static string TimeSeconds
		{
			get
			{
				return Resources.ResourceManager.GetString("TimeSeconds", Resources.resourceCulture);
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x0600032D RID: 813 RVA: 0x0000D01A File Offset: 0x0000B21A
		internal static Bitmap up_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("up_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x0600032E RID: 814 RVA: 0x0000D035 File Offset: 0x0000B235
		internal static Bitmap up_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("up_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x0600032F RID: 815 RVA: 0x0000D050 File Offset: 0x0000B250
		internal static string UrlCategoriesForm_CategorySelectionInfo
		{
			get
			{
				return Resources.ResourceManager.GetString("UrlCategoriesForm_CategorySelectionInfo", Resources.resourceCulture);
			}
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000330 RID: 816 RVA: 0x0000D066 File Offset: 0x0000B266
		internal static string UrlCategoriesForm_DoYouWantDeleteCategory
		{
			get
			{
				return Resources.ResourceManager.GetString("UrlCategoriesForm_DoYouWantDeleteCategory", Resources.resourceCulture);
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000331 RID: 817 RVA: 0x0000D07C File Offset: 0x0000B27C
		internal static string UrlCategoriesForm_DoYouWantDeleteFilter
		{
			get
			{
				return Resources.ResourceManager.GetString("UrlCategoriesForm_DoYouWantDeleteFilter", Resources.resourceCulture);
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000332 RID: 818 RVA: 0x0000D092 File Offset: 0x0000B292
		internal static string UrlCategoriesForm_FilterSelectionInfo
		{
			get
			{
				return Resources.ResourceManager.GetString("UrlCategoriesForm_FilterSelectionInfo", Resources.resourceCulture);
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000333 RID: 819 RVA: 0x0000D0A8 File Offset: 0x0000B2A8
		internal static Bitmap user_off_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("user_off_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000334 RID: 820 RVA: 0x0000D0C3 File Offset: 0x0000B2C3
		internal static Bitmap user_on_24x24
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("user_on_24x24", Resources.resourceCulture);
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000335 RID: 821 RVA: 0x0000D0DE File Offset: 0x0000B2DE
		internal static Bitmap usergroup_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("usergroup_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000336 RID: 822 RVA: 0x0000D0F9 File Offset: 0x0000B2F9
		internal static Bitmap usergroup_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("usergroup_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000337 RID: 823 RVA: 0x0000D114 File Offset: 0x0000B314
		internal static Bitmap view_apphistory_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_apphistory_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000338 RID: 824 RVA: 0x0000D12F File Offset: 0x0000B32F
		internal static Bitmap view_apphistory_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_apphistory_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000339 RID: 825 RVA: 0x0000D14A File Offset: 0x0000B34A
		internal static Bitmap view_diagnostic_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_diagnostic_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x0600033A RID: 826 RVA: 0x0000D165 File Offset: 0x0000B365
		internal static Bitmap view_diagnostic_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_diagnostic_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x0600033B RID: 827 RVA: 0x0000D180 File Offset: 0x0000B380
		internal static Bitmap view_historylog_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_historylog_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x0600033C RID: 828 RVA: 0x0000D19B File Offset: 0x0000B39B
		internal static Bitmap view_historylog_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_historylog_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x0600033D RID: 829 RVA: 0x0000D1B6 File Offset: 0x0000B3B6
		internal static Bitmap view_screenshot_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_screenshot_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x0600033E RID: 830 RVA: 0x0000D1D1 File Offset: 0x0000B3D1
		internal static Bitmap view_screenshot_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("view_screenshot_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x0600033F RID: 831 RVA: 0x0000D1EC File Offset: 0x0000B3EC
		internal static Bitmap viewonweb_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("viewonweb_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000340 RID: 832 RVA: 0x0000D207 File Offset: 0x0000B407
		internal static Bitmap viewonweb_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("viewonweb_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000341 RID: 833 RVA: 0x0000D222 File Offset: 0x0000B422
		internal static string VncControl_BeforeConnectionText
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_BeforeConnectionText", Resources.resourceCulture);
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000342 RID: 834 RVA: 0x0000D238 File Offset: 0x0000B438
		internal static string VncControl_ConnectingText
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_ConnectingText", Resources.resourceCulture);
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x06000343 RID: 835 RVA: 0x0000D24E File Offset: 0x0000B44E
		internal static string VncControl_ConnectionAttempt
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_ConnectionAttempt", Resources.resourceCulture);
			}
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x06000344 RID: 836 RVA: 0x0000D264 File Offset: 0x0000B464
		internal static string VncControl_ConnectionEnded
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_ConnectionEnded", Resources.resourceCulture);
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000345 RID: 837 RVA: 0x0000D27A File Offset: 0x0000B47A
		internal static string VncControl_ConnectionError
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_ConnectionError", Resources.resourceCulture);
			}
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000346 RID: 838 RVA: 0x0000D290 File Offset: 0x0000B490
		internal static string VncControl_DisconnectedText
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_DisconnectedText", Resources.resourceCulture);
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000347 RID: 839 RVA: 0x0000D2A6 File Offset: 0x0000B4A6
		internal static string VncControl_RunVncError
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_RunVncError", Resources.resourceCulture);
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000348 RID: 840 RVA: 0x0000D2BC File Offset: 0x0000B4BC
		internal static string VncControl_UnknownDeviceIPError
		{
			get
			{
				return Resources.ResourceManager.GetString("VncControl_UnknownDeviceIPError", Resources.resourceCulture);
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000349 RID: 841 RVA: 0x0000D2D2 File Offset: 0x0000B4D2
		internal static Bitmap warning_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("warning_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x0600034A RID: 842 RVA: 0x0000D2ED File Offset: 0x0000B4ED
		internal static Bitmap warning_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("warning_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x0600034B RID: 843 RVA: 0x0000D308 File Offset: 0x0000B508
		internal static Bitmap windows_reboot_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windows_reboot_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x0600034C RID: 844 RVA: 0x0000D323 File Offset: 0x0000B523
		internal static Bitmap windows_reboot_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windows_reboot_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x0600034D RID: 845 RVA: 0x0000D33E File Offset: 0x0000B53E
		internal static Bitmap windows_shutdown_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windows_shutdown_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x0600034E RID: 846 RVA: 0x0000D359 File Offset: 0x0000B559
		internal static Bitmap windows_shutdown_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windows_shutdown_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x0600034F RID: 847 RVA: 0x0000D374 File Offset: 0x0000B574
		internal static Bitmap windows_wakeon_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windows_wakeon_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000350 RID: 848 RVA: 0x0000D38F File Offset: 0x0000B58F
		internal static Bitmap windows_wakeon_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windows_wakeon_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000351 RID: 849 RVA: 0x0000D3AA File Offset: 0x0000B5AA
		internal static string WindowShowMode_Hide
		{
			get
			{
				return Resources.ResourceManager.GetString("WindowShowMode_Hide", Resources.resourceCulture);
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000352 RID: 850 RVA: 0x0000D3C0 File Offset: 0x0000B5C0
		internal static string WindowShowMode_Maximize
		{
			get
			{
				return Resources.ResourceManager.GetString("WindowShowMode_Maximize", Resources.resourceCulture);
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000353 RID: 851 RVA: 0x0000D3D6 File Offset: 0x0000B5D6
		internal static string WindowShowMode_Minimize
		{
			get
			{
				return Resources.ResourceManager.GetString("WindowShowMode_Minimize", Resources.resourceCulture);
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x06000354 RID: 852 RVA: 0x0000D3EC File Offset: 0x0000B5EC
		internal static string WindowShowMode_Show
		{
			get
			{
				return Resources.ResourceManager.GetString("WindowShowMode_Show", Resources.resourceCulture);
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000355 RID: 853 RVA: 0x0000D402 File Offset: 0x0000B602
		internal static Bitmap windowsrdp_16x16
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windowsrdp_16x16", Resources.resourceCulture);
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000356 RID: 854 RVA: 0x0000D41D File Offset: 0x0000B61D
		internal static Bitmap windowsrdp_32x32
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject("windowsrdp_32x32", Resources.resourceCulture);
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000357 RID: 855 RVA: 0x0000D438 File Offset: 0x0000B638
		internal static string WindowsUserNotLogged
		{
			get
			{
				return Resources.ResourceManager.GetString("WindowsUserNotLogged", Resources.resourceCulture);
			}
		}

		// Token: 0x040000FA RID: 250
		private static ResourceManager resourceMan;

		// Token: 0x040000FB RID: 251
		private static CultureInfo resourceCulture;
	}
}
