﻿using System;
using System.ComponentModel;

namespace OpiekunWEB.Console
{
	// Token: 0x02000010 RID: 16
	public class DisplayItem : DeviceTreeItemBase
	{
		// Token: 0x06000063 RID: 99 RVA: 0x00003914 File Offset: 0x00001B14
		public DisplayItem(AgentItem agentItem, string parentId, int displayNo, bool isEnabled, bool isOnlyOneDisplay)
		{
			this.AgentItem = agentItem;
			this.DisplayNo = displayNo;
			base.IsConnected = agentItem.IsConnected;
			this.IsEnabled = isEnabled;
			this.IsOnlyOneDisplay = isOnlyOneDisplay;
			base.Id = this.AgentItem.AgentClient.AgentId + "-" + displayNo.ToString();
			base.ParentId = parentId;
			base.Name = string.Format("monitor: {0}", displayNo + 1);
			this.AgentItem.PropertyChanged += this.AgentItemOnPropertyChanged;
			base.CopyCommonProperities(agentItem);
			base.IconIndex = 16;
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000064 RID: 100 RVA: 0x000039BD File Offset: 0x00001BBD
		public AgentItem AgentItem { get; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000065 RID: 101 RVA: 0x000039C5 File Offset: 0x00001BC5
		public int DisplayNo { get; }

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x06000066 RID: 102 RVA: 0x000039CD File Offset: 0x00001BCD
		// (set) Token: 0x06000067 RID: 103 RVA: 0x000039D5 File Offset: 0x00001BD5
		public bool IsEnabled { get; set; }

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000068 RID: 104 RVA: 0x000039DE File Offset: 0x00001BDE
		// (set) Token: 0x06000069 RID: 105 RVA: 0x000039E6 File Offset: 0x00001BE6
		public bool IsOnlyOneDisplay { get; set; }

		// Token: 0x0600006A RID: 106 RVA: 0x000039EF File Offset: 0x00001BEF
		public override string GetDeviceName()
		{
			AgentItem agentItem = this.AgentItem;
			if (agentItem == null)
			{
				return null;
			}
			DeviceItem deviceItem = agentItem.DeviceItem;
			if (deviceItem == null)
			{
				return null;
			}
			return deviceItem.GetDeviceName();
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00003A0D File Offset: 0x00001C0D
		public override void ItemsRemoved()
		{
			base.ItemsRemoved();
			this.AgentItem.PropertyChanged -= this.AgentItemOnPropertyChanged;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected override void SetDomainAndUserName(string value)
		{
		}

		// Token: 0x0600006D RID: 109 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected override void SetDomainName(string value)
		{
		}

		// Token: 0x0600006E RID: 110 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected override void SetUserFullName(string value)
		{
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected override void SetUserName(string value)
		{
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00003A30 File Offset: 0x00001C30
		private void AgentItemOnPropertyChanged(object sender, PropertyChangedEventArgs args)
		{
			if (args.PropertyName == "WindowsUser")
			{
				base.WindowsUser = (sender as AgentItem).WindowsUser;
				return;
			}
			if (args.PropertyName == "IsConnected")
			{
				base.IsConnected = (sender as AgentItem).IsConnected;
				return;
			}
			base.CopyCommonProperities(sender as AgentItem);
		}
	}
}
