﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x0200001B RID: 27
	public partial class ShowMessageDefListForm : ConsoleDefBaseForm
	{
		// Token: 0x0600015F RID: 351 RVA: 0x00006B22 File Offset: 0x00004D22
		public ShowMessageDefListForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000160 RID: 352 RVA: 0x00006B30 File Offset: 0x00004D30
		public ShowMessageDefListForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient, ShowMessageDefListFormParams @params) : base(formsSettings, formCreator, apiClient)
		{
			this.InitializeComponent();
			this._params = @params;
			this.gridShowMessageDefs.DataSource = this._apiClient.ConsoleDefs;
		}

		// Token: 0x06000161 RID: 353 RVA: 0x00006B5F File Offset: 0x00004D5F
		private void barButtonAdd_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<ShowMessageDefForm>(FormAction.Create);
		}

		// Token: 0x06000162 RID: 354 RVA: 0x00006B70 File Offset: 0x00004D70
		private void barButtonDelete_ItemClick(object sender, ItemClickEventArgs e)
		{
			ShowMessageDefListForm.<barButtonDelete_ItemClick>d__4 <barButtonDelete_ItemClick>d__;
			<barButtonDelete_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<barButtonDelete_ItemClick>d__.<>4__this = this;
			<barButtonDelete_ItemClick>d__.<>1__state = -1;
			<barButtonDelete_ItemClick>d__.<>t__builder.Start<ShowMessageDefListForm.<barButtonDelete_ItemClick>d__4>(ref <barButtonDelete_ItemClick>d__);
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00006BA8 File Offset: 0x00004DA8
		private void barButtonEdit_ItemClick(object sender, ItemClickEventArgs e)
		{
			ConsoleDef consoleDef = this.GetFocusedConsoleDef();
			if (consoleDef == null)
			{
				return;
			}
			ShowMessageDefFormParams @params = new ShowMessageDefFormParams
			{
				ShowMessageDef = consoleDef.AsShowMessageDef(),
				DefinitionId = consoleDef.Id
			};
			if (@params.ShowMessageDef.IsAvailableForAllUsers() && !this._apiClient.IsLoggedUserHasAdminPermission())
			{
				this._formCreator.ShowError(Resources.ElementCanBeEditedOrDeletedOnlyByAdmin);
				return;
			}
			this._formCreator.ShowAndKeepGridPosition<ShowMessageDefForm, ShowMessageDefFormParams>(this.gridViewShowMessageDefs, FormAction.Update, @params);
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00006C20 File Offset: 0x00004E20
		private void barButtonLaunch_ItemClick(object sender, ItemClickEventArgs e)
		{
			ConsoleDef consoleDef = this.GetFocusedConsoleDef();
			if (consoleDef == null)
			{
				return;
			}
			this._params.ShowMessageDef = consoleDef.AsShowMessageDef();
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x06000165 RID: 357 RVA: 0x00006C50 File Offset: 0x00004E50
		private ConsoleDef GetFocusedConsoleDef()
		{
			return this.gridViewShowMessageDefs.GetFocusedRow() as ConsoleDef;
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00006C64 File Offset: 0x00004E64
		private void gridViewMessagesDefs_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			ColumnView columnView = sender as ColumnView;
			e.Visible = false;
			string id = columnView.GetListSourceRowCellValue(e.ListSourceRow, "Id") as string;
			if (!string.IsNullOrEmpty(id))
			{
				ConsoleDef consoleDef = this._apiClient.ConsoleDefs.FindItemById(id);
				if (consoleDef != null && consoleDef.Type == ConsoleDefType.ShowMessage)
				{
					ShowMessageDef showMessageDef = consoleDef.AsShowMessageDef();
					e.Visible = (showMessageDef != null && showMessageDef.IsAvailableForUser(this._apiClient.UserId));
				}
			}
			e.Handled = true;
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00006CE8 File Offset: 0x00004EE8
		private void gridViewMessagesDefs_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			ShowMessageDef showMessageDef = (e.Row as ConsoleDef).AsShowMessageDef();
			if (e.Column.FieldName == "DisplayName")
			{
				e.Value = ((showMessageDef != null) ? showMessageDef.DisplayName : null);
			}
			if (e.Column.FieldName == "IsFavorite")
			{
				e.Value = ((showMessageDef != null) ? new bool?(showMessageDef.IsFavorite) : null);
			}
			if (e.Column.FieldName == "AvailableForAll")
			{
				e.Value = ((showMessageDef != null) ? new bool?(showMessageDef.IsAvailableForAllUsers()) : null);
			}
		}

		// Token: 0x06000168 RID: 360 RVA: 0x00006DA5 File Offset: 0x00004FA5
		private void gridViewShowMessageDefs_DoubleClick(object sender, EventArgs e)
		{
			this.barButtonLaunch.PerformClick();
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00006DB4 File Offset: 0x00004FB4
		private void gridViewShowMessageDefs_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this.barButtonDelete.Enabled = this.gridViewShowMessageDefs.IsDataRow(e.FocusedRowHandle);
			this.barButtonEdit.Enabled = this.gridViewShowMessageDefs.IsDataRow(e.FocusedRowHandle);
			this.barButtonLaunch.Enabled = this.gridViewShowMessageDefs.IsDataRow(e.FocusedRowHandle);
		}

		// Token: 0x040000A7 RID: 167
		private ShowMessageDefListFormParams _params;
	}
}
