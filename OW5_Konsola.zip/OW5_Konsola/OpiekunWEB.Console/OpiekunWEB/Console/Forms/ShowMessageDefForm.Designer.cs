﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000075 RID: 117
	public partial class ShowMessageDefForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x0600062B RID: 1579 RVA: 0x0002E2D6 File Offset: 0x0002C4D6
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x0002E2F8 File Offset: 0x0002C4F8
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ShowMessageDefForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.checkEditAvailableForAll = new global::DevExpress.XtraEditors.CheckEdit();
			this.imageComboBoxIconNo = new global::DevExpress.XtraEditors.ImageComboBoxEdit();
			this.imageCollectionIcons = new global::DevExpress.Utils.ImageCollection(this.components);
			this.textEditDisplayName = new global::DevExpress.XtraEditors.TextEdit();
			this.checkIsFavorite = new global::DevExpress.XtraEditors.CheckEdit();
			this.spinEditTime = new global::DevExpress.XtraEditors.SpinEdit();
			this.comboBoxShowMode = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.memoEditMessage = new global::DevExpress.XtraEditors.MemoEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlTime = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlShowMode = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlMessage = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlDisplayName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlIconNo = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlIsFavorite = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlAvailableForAll = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditAvailableForAll.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxIconNo.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionIcons).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDisplayName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkIsFavorite.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.spinEditTime.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxShowMode.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.memoEditMessage.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlTime).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlShowMode).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMessage).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDisplayName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIconNo).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIsFavorite).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlAvailableForAll).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.layoutControlMain.Controls.Add(this.checkEditAvailableForAll);
			this.layoutControlMain.Controls.Add(this.imageComboBoxIconNo);
			this.layoutControlMain.Controls.Add(this.textEditDisplayName);
			this.layoutControlMain.Controls.Add(this.checkIsFavorite);
			this.layoutControlMain.Controls.Add(this.spinEditTime);
			this.layoutControlMain.Controls.Add(this.comboBoxShowMode);
			this.layoutControlMain.Controls.Add(this.memoEditMessage);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2853, 142, 812, 500));
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.checkEditAvailableForAll, "checkEditAvailableForAll");
			this.checkEditAvailableForAll.Name = "checkEditAvailableForAll";
			this.checkEditAvailableForAll.Properties.Caption = resources.GetString("checkEditAvailableForAll.Properties.Caption");
			this.checkEditAvailableForAll.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.imageComboBoxIconNo, "imageComboBoxIconNo");
			this.imageComboBoxIconNo.Name = "imageComboBoxIconNo";
			this.imageComboBoxIconNo.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxIconNo.Properties.Buttons"))
			});
			this.imageComboBoxIconNo.Properties.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items"), resources.GetString("imageComboBoxIconNo.Properties.Items1"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items3"), resources.GetString("imageComboBoxIconNo.Properties.Items4"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items5")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items6"), resources.GetString("imageComboBoxIconNo.Properties.Items7"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items8")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items9"), resources.GetString("imageComboBoxIconNo.Properties.Items10"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items11")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items12"), resources.GetString("imageComboBoxIconNo.Properties.Items13"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items14")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items15"), resources.GetString("imageComboBoxIconNo.Properties.Items16"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items17")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items18"), resources.GetString("imageComboBoxIconNo.Properties.Items19"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items20")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items21"), resources.GetString("imageComboBoxIconNo.Properties.Items22"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items23")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items24"), resources.GetString("imageComboBoxIconNo.Properties.Items25"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items26")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items27"), resources.GetString("imageComboBoxIconNo.Properties.Items28"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items29")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items30"), resources.GetString("imageComboBoxIconNo.Properties.Items31"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items32")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxIconNo.Properties.Items33"), resources.GetString("imageComboBoxIconNo.Properties.Items34"), (int)resources.GetObject("imageComboBoxIconNo.Properties.Items35"))
			});
			this.imageComboBoxIconNo.Properties.SmallImages = this.imageCollectionIcons;
			this.imageComboBoxIconNo.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.imageCollectionIcons, "imageCollectionIcons");
			this.imageCollectionIcons.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imageCollectionIcons.ImageStream");
			this.imageCollectionIcons.Images.SetKeyName(0, "messageicon1.ico");
			this.imageCollectionIcons.Images.SetKeyName(1, "messageicon2.ico");
			this.imageCollectionIcons.Images.SetKeyName(2, "messageicon3.ico");
			this.imageCollectionIcons.Images.SetKeyName(3, "messageicon4.ico");
			this.imageCollectionIcons.Images.SetKeyName(4, "messageicon5.ico");
			this.imageCollectionIcons.Images.SetKeyName(5, "messageicon6.ico");
			this.imageCollectionIcons.Images.SetKeyName(6, "messageicon7.ico");
			this.imageCollectionIcons.Images.SetKeyName(7, "messageicon8.ico");
			this.imageCollectionIcons.Images.SetKeyName(8, "messageicon9.ico");
			this.imageCollectionIcons.Images.SetKeyName(9, "messageicon10.ico");
			this.imageCollectionIcons.Images.SetKeyName(10, "messageicon11.ico");
			resources.ApplyResources(this.textEditDisplayName, "textEditDisplayName");
			this.textEditDisplayName.Name = "textEditDisplayName";
			this.textEditDisplayName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditDisplayName.Properties.Mask.BeepOnError");
			this.textEditDisplayName.Properties.Mask.EditMask = resources.GetString("textEditDisplayName.Properties.Mask.EditMask");
			this.textEditDisplayName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditDisplayName.Properties.Mask.IgnoreMaskBlank");
			this.textEditDisplayName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditDisplayName.Properties.Mask.MaskType");
			this.textEditDisplayName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditDisplayName.Properties.Mask.ShowPlaceHolders");
			this.textEditDisplayName.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.checkIsFavorite, "checkIsFavorite");
			this.checkIsFavorite.Name = "checkIsFavorite";
			this.checkIsFavorite.Properties.Caption = resources.GetString("checkIsFavorite.Properties.Caption");
			this.checkIsFavorite.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.spinEditTime, "spinEditTime");
			this.spinEditTime.Name = "spinEditTime";
			this.spinEditTime.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("spinEditTime.Properties.Buttons"))
			});
			this.spinEditTime.Properties.IsFloatValue = false;
			this.spinEditTime.Properties.Mask.EditMask = resources.GetString("spinEditTime.Properties.Mask.EditMask");
			global::DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit properties = this.spinEditTime.Properties;
			int[] array = new int[4];
			array[0] = 300;
			properties.MaxValue = new decimal(array);
			this.spinEditTime.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxShowMode, "comboBoxShowMode");
			this.comboBoxShowMode.Name = "comboBoxShowMode";
			this.comboBoxShowMode.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxShowMode.Properties.Buttons"))
			});
			this.comboBoxShowMode.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxShowMode.StyleController = this.layoutControlMain;
			this.comboBoxShowMode.SelectedIndexChanged += new global::System.EventHandler(this.comboBoxShowMode_SelectedIndexChanged);
			resources.ApplyResources(this.memoEditMessage, "memoEditMessage");
			this.memoEditMessage.Name = "memoEditMessage";
			this.memoEditMessage.StyleController = this.layoutControlMain;
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlGroupMain
			});
			this.Root.Name = "Root";
			this.Root.ShowInCustomizationForm = false;
			this.Root.Size = new global::System.Drawing.Size(471, 341);
			this.Root.TextVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlTime,
				this.layoutControlShowMode,
				this.layoutControlMessage,
				this.layoutControlDisplayName,
				this.layoutControlIconNo,
				this.emptySpaceItem1,
				this.layoutControlIsFavorite,
				this.layoutControlAvailableForAll
			});
			this.layoutControlGroupMain.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(451, 321);
			resources.ApplyResources(this.layoutControlGroupMain, "layoutControlGroupMain");
			this.layoutControlTime.Control = this.spinEditTime;
			this.layoutControlTime.Location = new global::System.Drawing.Point(315, 172);
			this.layoutControlTime.Name = "layoutControlTime";
			this.layoutControlTime.Size = new global::System.Drawing.Size(112, 45);
			resources.ApplyResources(this.layoutControlTime, "layoutControlTime");
			this.layoutControlTime.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlTime.TextSize = new global::System.Drawing.Size(73, 16);
			this.layoutControlShowMode.Control = this.comboBoxShowMode;
			this.layoutControlShowMode.Location = new global::System.Drawing.Point(0, 172);
			this.layoutControlShowMode.Name = "layoutControlShowMode";
			this.layoutControlShowMode.Size = new global::System.Drawing.Size(315, 45);
			resources.ApplyResources(this.layoutControlShowMode, "layoutControlShowMode");
			this.layoutControlShowMode.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlShowMode.TextSize = new global::System.Drawing.Size(73, 16);
			this.layoutControlMessage.Control = this.memoEditMessage;
			this.layoutControlMessage.Location = new global::System.Drawing.Point(0, 48);
			this.layoutControlMessage.Name = "layoutControlMessage";
			this.layoutControlMessage.Size = new global::System.Drawing.Size(427, 124);
			resources.ApplyResources(this.layoutControlMessage, "layoutControlMessage");
			this.layoutControlMessage.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlMessage.TextSize = new global::System.Drawing.Size(73, 16);
			this.layoutControlDisplayName.Control = this.textEditDisplayName;
			this.layoutControlDisplayName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlDisplayName.Name = "layoutControlDisplayName";
			this.layoutControlDisplayName.Size = new global::System.Drawing.Size(254, 48);
			resources.ApplyResources(this.layoutControlDisplayName, "layoutControlDisplayName");
			this.layoutControlDisplayName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDisplayName.TextSize = new global::System.Drawing.Size(73, 16);
			this.layoutControlIconNo.Control = this.imageComboBoxIconNo;
			this.layoutControlIconNo.Location = new global::System.Drawing.Point(0, 217);
			this.layoutControlIconNo.Name = "layoutControlIconNo";
			this.layoutControlIconNo.Size = new global::System.Drawing.Size(112, 57);
			resources.ApplyResources(this.layoutControlIconNo, "layoutControlIconNo");
			this.layoutControlIconNo.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlIconNo.TextSize = new global::System.Drawing.Size(73, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(112, 217);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(315, 57);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlIsFavorite.Control = this.checkIsFavorite;
			this.layoutControlIsFavorite.Location = new global::System.Drawing.Point(254, 0);
			this.layoutControlIsFavorite.Name = "layoutControlIsFavorite";
			this.layoutControlIsFavorite.Size = new global::System.Drawing.Size(173, 24);
			resources.ApplyResources(this.layoutControlIsFavorite, "layoutControlIsFavorite");
			this.layoutControlIsFavorite.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlIsFavorite.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlIsFavorite.TextVisible = false;
			this.layoutControlAvailableForAll.Control = this.checkEditAvailableForAll;
			this.layoutControlAvailableForAll.Location = new global::System.Drawing.Point(254, 24);
			this.layoutControlAvailableForAll.Name = "layoutControlAvailableForAll";
			this.layoutControlAvailableForAll.Size = new global::System.Drawing.Size(173, 24);
			resources.ApplyResources(this.layoutControlAvailableForAll, "layoutControlAvailableForAll");
			this.layoutControlAvailableForAll.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlAvailableForAll.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlAvailableForAll.TextVisible = false;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("ShowMessageDefForm.IconOptions.Icon");
			base.Name = "ShowMessageDefForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.checkEditAvailableForAll.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxIconNo.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionIcons).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDisplayName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkIsFavorite.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.spinEditTime.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxShowMode.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.memoEditMessage.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlTime).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlShowMode).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMessage).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDisplayName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIconNo).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIsFavorite).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlAvailableForAll).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040003BE RID: 958
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040003BF RID: 959
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040003C0 RID: 960
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x040003C1 RID: 961
		private global::DevExpress.XtraEditors.SpinEdit spinEditTime;

		// Token: 0x040003C2 RID: 962
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxShowMode;

		// Token: 0x040003C3 RID: 963
		private global::DevExpress.XtraEditors.MemoEdit memoEditMessage;

		// Token: 0x040003C4 RID: 964
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlMessage;

		// Token: 0x040003C5 RID: 965
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlShowMode;

		// Token: 0x040003C6 RID: 966
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlTime;

		// Token: 0x040003C7 RID: 967
		private global::DevExpress.XtraEditors.CheckEdit checkIsFavorite;

		// Token: 0x040003C8 RID: 968
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlIsFavorite;

		// Token: 0x040003C9 RID: 969
		private global::DevExpress.XtraEditors.TextEdit textEditDisplayName;

		// Token: 0x040003CA RID: 970
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDisplayName;

		// Token: 0x040003CB RID: 971
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040003CC RID: 972
		private global::DevExpress.Utils.ImageCollection imageCollectionIcons;

		// Token: 0x040003CD RID: 973
		private global::DevExpress.XtraEditors.ImageComboBoxEdit imageComboBoxIconNo;

		// Token: 0x040003CE RID: 974
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlIconNo;

		// Token: 0x040003CF RID: 975
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040003D0 RID: 976
		private global::DevExpress.XtraEditors.CheckEdit checkEditAvailableForAll;

		// Token: 0x040003D1 RID: 977
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlAvailableForAll;
	}
}
