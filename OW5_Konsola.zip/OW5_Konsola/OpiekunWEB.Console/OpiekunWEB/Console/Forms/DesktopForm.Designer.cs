﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000061 RID: 97
	public partial class DesktopForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x06000527 RID: 1319 RVA: 0x0001C9A3 File Offset: 0x0001ABA3
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0001C9C4 File Offset: 0x0001ABC4
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DesktopForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.textEditDescription = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditName = new global::DevExpress.XtraEditors.TextEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlDescription = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.lookUpEditWhiteList = new global::DevExpress.XtraEditors.LookUpEdit();
			this.layoutControlWhiteList = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDescription.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDescription).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.lookUpEditWhiteList.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlWhiteList).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.layoutControlMain.Controls.Add(this.lookUpEditWhiteList);
			this.layoutControlMain.Controls.Add(this.textEditDescription);
			this.layoutControlMain.Controls.Add(this.textEditName);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.textEditDescription, "textEditDescription");
			this.textEditDescription.Name = "textEditDescription";
			this.textEditDescription.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditName, "textEditName");
			this.textEditName.Name = "textEditName";
			this.textEditName.Properties.Mask.EditMask = resources.GetString("textEditName.Properties.Mask.EditMask");
			this.textEditName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditName.Properties.Mask.IgnoreMaskBlank");
			this.textEditName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditName.Properties.Mask.MaskType");
			this.textEditName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditName.Properties.Mask.ShowPlaceHolders");
			this.textEditName.StyleController = this.layoutControlMain;
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlName,
				this.emptySpaceItem1,
				this.layoutControlDescription,
				this.layoutControlWhiteList
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(390, 225);
			this.Root.TextVisible = false;
			this.layoutControlName.Control = this.textEditName;
			this.layoutControlName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlName.Name = "layoutControlName";
			this.layoutControlName.Size = new global::System.Drawing.Size(370, 45);
			resources.ApplyResources(this.layoutControlName, "layoutControlName");
			this.layoutControlName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlName.TextSize = new global::System.Drawing.Size(161, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 135);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(370, 70);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlDescription.Control = this.textEditDescription;
			this.layoutControlDescription.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlDescription.Name = "layoutControlDescription";
			this.layoutControlDescription.Size = new global::System.Drawing.Size(370, 45);
			resources.ApplyResources(this.layoutControlDescription, "layoutControlDescription");
			this.layoutControlDescription.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDescription.TextSize = new global::System.Drawing.Size(161, 16);
			resources.ApplyResources(this.lookUpEditWhiteList, "lookUpEditWhiteList");
			this.lookUpEditWhiteList.Name = "lookUpEditWhiteList";
			this.lookUpEditWhiteList.Properties.ActionButtonIndex = 1;
			this.lookUpEditWhiteList.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("lookUpEdit1.Properties.Buttons")),
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("lookUpEdit1.Properties.Buttons1"))
			});
			this.lookUpEditWhiteList.Properties.Columns.AddRange(new global::DevExpress.XtraEditors.Controls.LookUpColumnInfo[]
			{
				new global::DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("lookUpEdit1.Properties.Columns"), resources.GetString("lookUpEdit1.Properties.Columns1"))
			});
			this.lookUpEditWhiteList.Properties.DisplayMember = "Name";
			this.lookUpEditWhiteList.Properties.NullText = resources.GetString("lookUpEdit1.Properties.NullText");
			this.lookUpEditWhiteList.StyleController = this.layoutControlMain;
			this.lookUpEditWhiteList.ButtonPressed += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.lookUpEditWhiteList_ButtonPressed);
			this.layoutControlWhiteList.Control = this.lookUpEditWhiteList;
			this.layoutControlWhiteList.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlWhiteList.Name = "layoutControlWhiteList";
			this.layoutControlWhiteList.Size = new global::System.Drawing.Size(370, 45);
			resources.ApplyResources(this.layoutControlWhiteList, "layoutControlWhiteList");
			this.layoutControlWhiteList.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlWhiteList.TextSize = new global::System.Drawing.Size(161, 16);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("DesktopForm.IconOptions.Icon");
			base.Name = "DesktopForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditDescription.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDescription).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.lookUpEditWhiteList.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlWhiteList).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400026A RID: 618
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400026B RID: 619
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x0400026C RID: 620
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x0400026D RID: 621
		private global::DevExpress.XtraEditors.TextEdit textEditName;

		// Token: 0x0400026E RID: 622
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlName;

		// Token: 0x0400026F RID: 623
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x04000270 RID: 624
		private global::DevExpress.XtraEditors.TextEdit textEditDescription;

		// Token: 0x04000271 RID: 625
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDescription;

		// Token: 0x04000272 RID: 626
		private global::DevExpress.XtraEditors.LookUpEdit lookUpEditWhiteList;

		// Token: 0x04000273 RID: 627
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlWhiteList;
	}
}
