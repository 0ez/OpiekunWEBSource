﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007C RID: 124
	public partial class TextValueEditForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000687 RID: 1671 RVA: 0x00034F7D File Offset: 0x0003317D
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x00034F9C File Offset: 0x0003319C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.TextValueEditForm));
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.labelDescription = new global::DevExpress.XtraEditors.LabelControl();
			this.textEditValue = new global::DevExpress.XtraEditors.TextEdit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditValue.Properties).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.buttonOk.ImageOptions.ImageIndex = (int)resources.GetObject("buttonOk.ImageOptions.ImageIndex");
			this.buttonOk.Name = "buttonOk";
			resources.ApplyResources(this.labelDescription, "labelDescription");
			this.labelDescription.Name = "labelDescription";
			resources.ApplyResources(this.textEditValue, "textEditValue");
			this.textEditValue.Name = "textEditValue";
			this.textEditValue.Properties.AccessibleDescription = resources.GetString("textEditValue.Properties.AccessibleDescription");
			this.textEditValue.Properties.AccessibleName = resources.GetString("textEditValue.Properties.AccessibleName");
			this.textEditValue.Properties.AutoHeight = (bool)resources.GetObject("textEditValue.Properties.AutoHeight");
			this.textEditValue.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("textEditValue.Properties.Mask.AutoComplete");
			this.textEditValue.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditValue.Properties.Mask.BeepOnError");
			this.textEditValue.Properties.Mask.EditMask = resources.GetString("textEditValue.Properties.Mask.EditMask");
			this.textEditValue.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditValue.Properties.Mask.IgnoreMaskBlank");
			this.textEditValue.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditValue.Properties.Mask.MaskType");
			this.textEditValue.Properties.Mask.PlaceHolder = (char)resources.GetObject("textEditValue.Properties.Mask.PlaceHolder");
			this.textEditValue.Properties.Mask.SaveLiteral = (bool)resources.GetObject("textEditValue.Properties.Mask.SaveLiteral");
			this.textEditValue.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditValue.Properties.Mask.ShowPlaceHolders");
			this.textEditValue.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("textEditValue.Properties.Mask.UseMaskAsDisplayFormat");
			this.textEditValue.Properties.NullValuePrompt = resources.GetString("textEditValue.Properties.NullValuePrompt");
			this.textEditValue.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("textEditValue.Properties.NullValuePromptShowForEmptyValue");
			base.AcceptButton = this.buttonOk;
			resources.ApplyResources(this, "$this");
			base.Controls.Add(this.buttonOk);
			base.Controls.Add(this.labelDescription);
			base.Controls.Add(this.textEditValue);
			base.Name = "TextValueEditForm";
			base.Load += new global::System.EventHandler(this.FormTextValueEdit_Load);
			((global::System.ComponentModel.ISupportInitialize)this.textEditValue.Properties).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400044F RID: 1103
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000450 RID: 1104
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x04000451 RID: 1105
		private global::DevExpress.XtraEditors.LabelControl labelDescription;

		// Token: 0x04000452 RID: 1106
		private global::DevExpress.XtraEditors.TextEdit textEditValue;
	}
}
