﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000060 RID: 96
	public partial class DesktopItemForm : CRUDBaseForm
	{
		// Token: 0x06000512 RID: 1298 RVA: 0x0001B748 File Offset: 0x00019948
		public DesktopItemForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x0001B758 File Offset: 0x00019958
		public DesktopItemForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, DesktopItem desktopItem) : base(formsSettings, formCreator, action, apiClient)
		{
			this.InitializeComponent();
			this._desktopItem = desktopItem;
			this._macroList = Macros.GetDirMacrosAsStringKeyValueList(true);
			this.comboBoxMacro.Properties.Items.AddRange(this._macroList);
			if (action != FormAction.Create)
			{
				this.textEditName.Text = desktopItem.Name;
				this.textEditParams.Text = desktopItem.Params;
				System.ValueTuple<StringKeyAndValue, string> valueTuple = Macros.SplitFileNameToMacroAndFileName(this._macroList, desktopItem.FileName);
				StringKeyAndValue macro = valueTuple.Item1;
				string fileName = valueTuple.Item2;
				this.comboBoxMacro.SelectedItem = macro;
				this.textEditFilePath.Text = fileName;
				if (!desktopItem.Icon.IsEmpty)
				{
					this.SetIcon(desktopItem.Icon.ToByteArray().ToBitmap());
					return;
				}
			}
			else
			{
				this.comboBoxMacro.SelectedItem = this._macroList.Find((StringKeyAndValue x) => x.Key == "{?}");
			}
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x0001B862 File Offset: 0x00019A62
		protected string GetFileName()
		{
			StringKeyAndValue selectedMacro = this.GetSelectedMacro();
			return Macros.MacroAndFileNameToString((selectedMacro != null) ? selectedMacro.Key : null, this.textEditFilePath.Text);
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x0001B888 File Offset: 0x00019A88
		protected override bool IsDataUpdated()
		{
			DesktopItem desktopItem = this._desktopItem;
			if (!(((desktopItem != null) ? desktopItem.Name : null) != this.textEditName.Text))
			{
				DesktopItem desktopItem2 = this._desktopItem;
				if (!(((desktopItem2 != null) ? desktopItem2.FileName : null) != this.GetFileName()))
				{
					DesktopItem desktopItem3 = this._desktopItem;
					if (!(((desktopItem3 != null) ? desktopItem3.Params : null) != this.textEditParams.Text))
					{
						return this._isIconChanged;
					}
				}
			}
			return true;
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x0001B904 File Offset: 0x00019B04
		protected override bool IsDataValid()
		{
			StringKeyAndValue selectedMacro = this.GetSelectedMacro();
			string modifiedPath;
			bool flag = Macros.ValidateMacroAndPath((selectedMacro != null) ? selectedMacro.Key : null, this.textEditFilePath.Text, out modifiedPath, FileOrFolder.File);
			this.textEditFilePath.Text = modifiedPath;
			if (!flag)
			{
				this.textEditFilePath.Focus();
				this.textEditFilePath.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
			}
			return flag && this.textEditName.Text.Length > 0;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0001B980 File Offset: 0x00019B80
		protected override Task<bool> OnActionCreate()
		{
			DesktopItemForm.<OnActionCreate>d__8 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<DesktopItemForm.<OnActionCreate>d__8>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x0001B9C4 File Offset: 0x00019BC4
		protected override Task<bool> OnActionUpdate()
		{
			DesktopItemForm.<OnActionUpdate>d__9 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<DesktopItemForm.<OnActionUpdate>d__9>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x0001BA07 File Offset: 0x00019C07
		private byte[] GetIconBytes()
		{
			if (this.imageComboBoxIcon.Properties.Items.Count > 0)
			{
				return this.imageCollectionIcon.Images[0].ToBytes(ImageFormat.Png);
			}
			return null;
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x0001BA3E File Offset: 0x00019C3E
		private StringKeyAndValue GetSelectedMacro()
		{
			return this.comboBoxMacro.SelectedItem as StringKeyAndValue;
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x0001BA50 File Offset: 0x00019C50
		private void imageComboBoxIconNo_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			if (e.Button.Kind == ButtonPredefines.Delete)
			{
				this._isIconChanged = true;
				this.imageCollectionIcon.Clear();
				this.imageComboBoxIcon.Properties.Items.Clear();
				return;
			}
			if (e.Button.Kind == ButtonPredefines.Ellipsis)
			{
				using (XtraOpenFileDialog dlg = new XtraOpenFileDialog())
				{
					dlg.Title = Resources.DesktopItemForm_OpenFileDialogTitle;
					dlg.Filter = Resources.DesktopItem_OpenFileDialogFilter;
					if (dlg.ShowDialog() == DialogResult.OK)
					{
						try
						{
							string ext = Path.GetExtension(dlg.FileName).ToLower();
							Bitmap bmp;
							if (ext == ".exe" || ext == ".com")
							{
								bmp = Icon.ExtractAssociatedIcon(dlg.FileName).ToBitmap();
							}
							else
							{
								bmp = new Bitmap(dlg.FileName);
							}
							if (bmp.Width > 128 || bmp.Height > 128)
							{
								this._formCreator.ShowError(Resources.DesktopItemForm_InvalidIconSizeError);
							}
							else
							{
								this.SetIcon(bmp);
								this._isIconChanged = true;
							}
						}
						catch (Exception)
						{
							this._formCreator.ShowError(Resources.DesktopItemForm_LoadIconError);
						}
					}
				}
			}
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x0001BB90 File Offset: 0x00019D90
		private void SetIcon(Bitmap bitmap)
		{
			this.imageCollectionIcon.Clear();
			this.imageComboBoxIcon.Properties.Items.Clear();
			this.imageCollectionIcon.AddImage(bitmap);
			this.imageComboBoxIcon.Properties.Items.Add(new ImageComboBoxItem("", null, 0));
			this.imageComboBoxIcon.SelectedIndex = 0;
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x0001BBF8 File Offset: 0x00019DF8
		private void textEditFilePath_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			using (XtraOpenFileDialog dlg = new XtraOpenFileDialog())
			{
				if (dlg.ShowDialog() == DialogResult.OK)
				{
					this.textEditFilePath.Text = dlg.FileName;
				}
			}
		}

		// Token: 0x04000257 RID: 599
		private readonly DesktopItem _desktopItem;

		// Token: 0x04000258 RID: 600
		private readonly List<StringKeyAndValue> _macroList;

		// Token: 0x04000259 RID: 601
		private bool _isIconChanged;
	}
}
