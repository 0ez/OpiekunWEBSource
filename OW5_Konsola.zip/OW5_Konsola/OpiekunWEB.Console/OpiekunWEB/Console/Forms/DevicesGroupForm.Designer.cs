﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000082 RID: 130
	public partial class DevicesGroupForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x060006F7 RID: 1783 RVA: 0x0003CAFB File Offset: 0x0003ACFB
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x0003CB1C File Offset: 0x0003AD1C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DevicesGroupForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.treeListLookUpEditParentGroupName = new global::DevExpress.XtraEditors.TreeListLookUpEdit();
			this.treeListLookUpGroupsTreeList = new global::DevExpress.XtraTreeList.TreeList();
			this.textEditGroupName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlItemGroupName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlItemParentGroupName = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpEditParentGroupName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditGroupName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemGroupName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemParentGroupName).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			this.buttonSave.ImageOptions.ImageIndex = (int)resources.GetObject("buttonSave.ImageOptions.ImageIndex");
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutItem.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.Image");
			this.layoutControlMain.Controls.Add(this.treeListLookUpEditParentGroupName);
			this.layoutControlMain.Controls.Add(this.textEditGroupName);
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2551, 194, 812, 500));
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.Image");
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.treeListLookUpEditParentGroupName, "treeListLookUpEditParentGroupName");
			this.treeListLookUpEditParentGroupName.Name = "treeListLookUpEditParentGroupName";
			this.treeListLookUpEditParentGroupName.Properties.AccessibleDescription = resources.GetString("treeListLookUpEditParentGroupName.Properties.AccessibleDescription");
			this.treeListLookUpEditParentGroupName.Properties.AccessibleName = resources.GetString("treeListLookUpEditParentGroupName.Properties.AccessibleName");
			this.treeListLookUpEditParentGroupName.Properties.AutoHeight = (bool)resources.GetObject("treeListLookUpEditParentGroupName.Properties.AutoHeight");
			this.treeListLookUpEditParentGroupName.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("treeListLookUpEditParentGroupName.Properties.Buttons"))
			});
			this.treeListLookUpEditParentGroupName.Properties.DisplayMember = "Name";
			this.treeListLookUpEditParentGroupName.Properties.NullText = resources.GetString("treeListLookUpEditParentGroupName.Properties.NullText");
			this.treeListLookUpEditParentGroupName.Properties.NullValuePrompt = resources.GetString("treeListLookUpEditParentGroupName.Properties.NullValuePrompt");
			this.treeListLookUpEditParentGroupName.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("treeListLookUpEditParentGroupName.Properties.NullValuePromptShowForEmptyValue");
			this.treeListLookUpEditParentGroupName.Properties.TreeList = this.treeListLookUpGroupsTreeList;
			this.treeListLookUpEditParentGroupName.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.treeListLookUpGroupsTreeList, "treeListLookUpGroupsTreeList");
			this.treeListLookUpGroupsTreeList.KeyFieldName = "Id";
			this.treeListLookUpGroupsTreeList.Name = "treeListLookUpGroupsTreeList";
			this.treeListLookUpGroupsTreeList.OptionsView.ShowColumns = false;
			this.treeListLookUpGroupsTreeList.OptionsView.ShowIndentAsRowStyle = true;
			this.treeListLookUpGroupsTreeList.ParentFieldName = "ParentId";
			resources.ApplyResources(this.textEditGroupName, "textEditGroupName");
			this.textEditGroupName.Name = "textEditGroupName";
			this.textEditGroupName.Properties.AccessibleDescription = resources.GetString("textEditGroupName.Properties.AccessibleDescription");
			this.textEditGroupName.Properties.AccessibleName = resources.GetString("textEditGroupName.Properties.AccessibleName");
			this.textEditGroupName.Properties.AutoHeight = (bool)resources.GetObject("textEditGroupName.Properties.AutoHeight");
			this.textEditGroupName.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("textEditGroupName.Properties.Mask.AutoComplete");
			this.textEditGroupName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditGroupName.Properties.Mask.BeepOnError");
			this.textEditGroupName.Properties.Mask.EditMask = resources.GetString("textEditGroupName.Properties.Mask.EditMask");
			this.textEditGroupName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditGroupName.Properties.Mask.IgnoreMaskBlank");
			this.textEditGroupName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditGroupName.Properties.Mask.MaskType");
			this.textEditGroupName.Properties.Mask.PlaceHolder = (char)resources.GetObject("textEditGroupName.Properties.Mask.PlaceHolder");
			this.textEditGroupName.Properties.Mask.SaveLiteral = (bool)resources.GetObject("textEditGroupName.Properties.Mask.SaveLiteral");
			this.textEditGroupName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditGroupName.Properties.Mask.ShowPlaceHolders");
			this.textEditGroupName.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("textEditGroupName.Properties.Mask.UseMaskAsDisplayFormat");
			this.textEditGroupName.Properties.NullValuePrompt = resources.GetString("textEditGroupName.Properties.NullValuePrompt");
			this.textEditGroupName.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("textEditGroupName.Properties.NullValuePromptShowForEmptyValue");
			this.textEditGroupName.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.BackgroundImageOptions.ImageIndex");
			this.layoutControlGroupMain.CaptionImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.CaptionImageOptions.ImageIndex");
			this.layoutControlGroupMain.ContentImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.ContentImageOptions.ImageIndex");
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlItemGroupName,
				this.emptySpaceItem1,
				this.layoutControlItemParentGroupName
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.OptionsItemText.TextToControlDistance = 4;
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(352, 162);
			this.layoutControlGroupMain.TextVisible = false;
			resources.ApplyResources(this.layoutControlItemGroupName, "layoutControlItemGroupName");
			this.layoutControlItemGroupName.Control = this.textEditGroupName;
			this.layoutControlItemGroupName.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlItemGroupName.ImageOptions.ImageIndex");
			this.layoutControlItemGroupName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlItemGroupName.Name = "layoutControlItemGroupName";
			this.layoutControlItemGroupName.Size = new global::System.Drawing.Size(332, 46);
			this.layoutControlItemGroupName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemGroupName.TextSize = new global::System.Drawing.Size(96, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 92);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(332, 50);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			resources.ApplyResources(this.layoutControlItemParentGroupName, "layoutControlItemParentGroupName");
			this.layoutControlItemParentGroupName.Control = this.treeListLookUpEditParentGroupName;
			this.layoutControlItemParentGroupName.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlItemParentGroupName.ImageOptions.ImageIndex");
			this.layoutControlItemParentGroupName.Location = new global::System.Drawing.Point(0, 46);
			this.layoutControlItemParentGroupName.Name = "layoutControlItemParentGroupName";
			this.layoutControlItemParentGroupName.Size = new global::System.Drawing.Size(332, 46);
			this.layoutControlItemParentGroupName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemParentGroupName.TextSize = new global::System.Drawing.Size(96, 16);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.Name = "DevicesGroupForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpEditParentGroupName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditGroupName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemGroupName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemParentGroupName).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040004E9 RID: 1257
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040004EA RID: 1258
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040004EB RID: 1259
		private global::DevExpress.XtraEditors.TreeListLookUpEdit treeListLookUpEditParentGroupName;

		// Token: 0x040004EC RID: 1260
		private global::DevExpress.XtraTreeList.TreeList treeListLookUpGroupsTreeList;

		// Token: 0x040004ED RID: 1261
		private global::DevExpress.XtraEditors.TextEdit textEditGroupName;

		// Token: 0x040004EE RID: 1262
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040004EF RID: 1263
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemGroupName;

		// Token: 0x040004F0 RID: 1264
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040004F1 RID: 1265
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemParentGroupName;
	}
}
