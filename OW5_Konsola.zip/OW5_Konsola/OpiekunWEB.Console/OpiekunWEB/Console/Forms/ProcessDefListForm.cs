﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000077 RID: 119
	public partial class ProcessDefListForm : ConsoleDefBaseForm
	{
		// Token: 0x06000642 RID: 1602 RVA: 0x00030FC1 File Offset: 0x0002F1C1
		public ProcessDefListForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient, ProcessDefListFormParams @params) : base(formsSettings, formCreator, apiClient)
		{
			this.InitializeComponent();
			this._params = @params;
			this.gridProcessDefs.DataSource = this._apiClient.ConsoleDefs;
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x00030FF0 File Offset: 0x0002F1F0
		private void barButtonAdd_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<ProcessDefForm>(FormAction.Create);
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x00031000 File Offset: 0x0002F200
		private void barButtonDelete_ItemClick(object sender, ItemClickEventArgs e)
		{
			ProcessDefListForm.<barButtonDelete_ItemClick>d__3 <barButtonDelete_ItemClick>d__;
			<barButtonDelete_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<barButtonDelete_ItemClick>d__.<>4__this = this;
			<barButtonDelete_ItemClick>d__.<>1__state = -1;
			<barButtonDelete_ItemClick>d__.<>t__builder.Start<ProcessDefListForm.<barButtonDelete_ItemClick>d__3>(ref <barButtonDelete_ItemClick>d__);
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x00031038 File Offset: 0x0002F238
		private void barButtonEdit_ItemClick(object sender, ItemClickEventArgs e)
		{
			ConsoleDef consoleDef = this.GetFocusedConsoleDef();
			if (consoleDef == null)
			{
				return;
			}
			ProcessDefFormParams @params = new ProcessDefFormParams
			{
				ProcessDef = consoleDef.AsProcessDef(),
				DefinitionId = consoleDef.Id
			};
			if (@params.ProcessDef.IsAvailableForAllUsers() && !this._apiClient.IsLoggedUserHasAdminPermission())
			{
				this._formCreator.ShowError(Resources.ElementCanBeEditedOrDeletedOnlyByAdmin);
				return;
			}
			this._formCreator.ShowAndKeepGridPosition<ProcessDefForm, ProcessDefFormParams>(this.gridViewProcessDefs, FormAction.Update, @params);
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x000310B0 File Offset: 0x0002F2B0
		private void barButtonLaunch_ItemClick(object sender, ItemClickEventArgs e)
		{
			ConsoleDef consoleDef = this.GetFocusedConsoleDef();
			if (consoleDef == null)
			{
				return;
			}
			this._params.ProcessDef = consoleDef.AsProcessDef();
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x000310E0 File Offset: 0x0002F2E0
		private ConsoleDef GetFocusedConsoleDef()
		{
			return this.gridViewProcessDefs.GetFocusedRow() as ConsoleDef;
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x000310F4 File Offset: 0x0002F2F4
		private void gridViewProcessDefs_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			ColumnView columnView = sender as ColumnView;
			e.Visible = false;
			string id = columnView.GetListSourceRowCellValue(e.ListSourceRow, "Id") as string;
			if (!string.IsNullOrEmpty(id))
			{
				ConsoleDef consoleDef = this._apiClient.ConsoleDefs.FindItemById(id);
				if (consoleDef != null && consoleDef.Type == ConsoleDefType.StartProcess)
				{
					StartProcessDef processDef = consoleDef.AsProcessDef();
					e.Visible = (processDef != null && processDef.IsAvailableForUser(this._apiClient.UserId));
				}
			}
			e.Handled = true;
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x00031178 File Offset: 0x0002F378
		private void gridViewProcessDefs_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			StartProcessDef startProcessDef = (e.Row as ConsoleDef).AsProcessDef();
			if (e.Column.FieldName == "DisplayName")
			{
				e.Value = ((startProcessDef != null) ? startProcessDef.DisplayName : null);
			}
			if (e.Column.FieldName == "IsFavorite")
			{
				e.Value = ((startProcessDef != null) ? new bool?(startProcessDef.IsFavorite) : null);
			}
			if (e.Column.FieldName == "AvailableForAll")
			{
				e.Value = ((startProcessDef != null) ? new bool?(startProcessDef.IsAvailableForAllUsers()) : null);
			}
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x00006DA5 File Offset: 0x00004FA5
		private void gridViewProcessDefs_DoubleClick(object sender, EventArgs e)
		{
			this.barButtonLaunch.PerformClick();
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x00031238 File Offset: 0x0002F438
		private void gridViewProcessDefs_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this.barButtonDelete.Enabled = this.gridViewProcessDefs.IsDataRow(e.FocusedRowHandle);
			this.barButtonEdit.Enabled = this.gridViewProcessDefs.IsDataRow(e.FocusedRowHandle);
			this.barButtonLaunch.Enabled = this.gridViewProcessDefs.IsDataRow(e.FocusedRowHandle);
		}

		// Token: 0x040003F3 RID: 1011
		private readonly ProcessDefListFormParams _params;
	}
}
