﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTab;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200004D RID: 77
	public partial class AppCategoriesForm : RibbonBaseForm
	{
		// Token: 0x0600044F RID: 1103 RVA: 0x00010478 File Offset: 0x0000E678
		public AppCategoriesForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x00010488 File Offset: 0x0000E688
		public AppCategoriesForm(FormsSettings formsSettings, IFormCreator formCreator, IIconsProvider iconsProvider, ApiClient apiClient) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this.gridUserCategories.DataSource = apiClient.AppCategories;
			this.gridAppFilters.DataSource = this._apiClient.AppFilters;
			this.tabControlCategories.ShowTabHeader = DefaultBoolean.False;
			this._macroList = Macros.GetDirMacrosAsStringKeyValueList(true);
			this.imageComboBoxUserCategoryType.SmallImages = iconsProvider.AppCategoryTypeImages16x16;
			this.imageComboBoxUserCategoryType.Items.AddEnum<AppCategoryType>((AppCategoryType cat) => cat.GetDescription());
			base.SetGridColumnForEditDeleteCommands(this.columnUserCategoryCommand);
			base.SetGridColumnForEditDeleteCommands(this.columnAppFilterCommand);
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00010544 File Offset: 0x0000E744
		protected override void OnGridCommandDeleteClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			AppCategoriesForm.<OnGridCommandDeleteClick>d__5 <OnGridCommandDeleteClick>d__;
			<OnGridCommandDeleteClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnGridCommandDeleteClick>d__.<>4__this = this;
			<OnGridCommandDeleteClick>d__.parent = parent;
			<OnGridCommandDeleteClick>d__.<>1__state = -1;
			<OnGridCommandDeleteClick>d__.<>t__builder.Start<AppCategoriesForm.<OnGridCommandDeleteClick>d__5>(ref <OnGridCommandDeleteClick>d__);
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x00010584 File Offset: 0x0000E784
		protected override void OnGridCommandEditClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			if (parent == this.gridUserCategories)
			{
				AppCategory category = this.GetSelectedAppCategory();
				if (this._formCreator.Show<AppCategoryForm, AppCategory>(FormAction.Update, category))
				{
					this.gridViewUserCategories.RefreshRow(this.gridViewUserCategories.FocusedRowHandle);
					return;
				}
			}
			else
			{
				AppFilter appFilter = this.GetSelectedAppFilter();
				if (this._formCreator.Show<AppFilterForm, AppFilter>(FormAction.Update, appFilter))
				{
					this.gridViewAppFilters.RefreshRow(this.gridViewAppFilters.FocusedRowHandle);
				}
			}
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x000105F4 File Offset: 0x0000E7F4
		private void barButtonAddAppPath_ItemClick(object sender, ItemClickEventArgs e)
		{
			AppCategory category = this.GetSelectedAppCategory();
			if (category != null)
			{
				AppFilter filter = new AppFilter
				{
					FilterType = AppFilterType.PathFilter
				};
				filter.CategoriesId.Add(category.Id);
				this._formCreator.Show<AppFilterForm, AppFilter>(FormAction.Create, filter);
			}
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00010638 File Offset: 0x0000E838
		private void barButtonAddCategory_ItemClick(object sender, ItemClickEventArgs e)
		{
			AppCategory category = new AppCategory();
			this._formCreator.Show<AppCategoryForm, AppCategory>(FormAction.Create, category);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0000228D File Offset: 0x0000048D
		private void barButtonExit_ItemClick(object sender, ItemClickEventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0001065C File Offset: 0x0000E85C
		private Task DeleteAppCategory()
		{
			AppCategoriesForm.<DeleteAppCategory>d__10 <DeleteAppCategory>d__;
			<DeleteAppCategory>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<DeleteAppCategory>d__.<>4__this = this;
			<DeleteAppCategory>d__.<>1__state = -1;
			<DeleteAppCategory>d__.<>t__builder.Start<AppCategoriesForm.<DeleteAppCategory>d__10>(ref <DeleteAppCategory>d__);
			return <DeleteAppCategory>d__.<>t__builder.Task;
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x000106A0 File Offset: 0x0000E8A0
		private Task DeleteAppFilter()
		{
			AppCategoriesForm.<DeleteAppFilter>d__11 <DeleteAppFilter>d__;
			<DeleteAppFilter>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<DeleteAppFilter>d__.<>4__this = this;
			<DeleteAppFilter>d__.<>1__state = -1;
			<DeleteAppFilter>d__.<>t__builder.Start<AppCategoriesForm.<DeleteAppFilter>d__11>(ref <DeleteAppFilter>d__);
			return <DeleteAppFilter>d__.<>t__builder.Task;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x000106E4 File Offset: 0x0000E8E4
		private string GetPathDisplayText(string path)
		{
			if (path != null && path.StartsWith("{"))
			{
				System.ValueTuple<StringKeyAndValue, string> valueTuple = Macros.SplitFileNameToMacroAndFileName(this._macroList, path);
				StringKeyAndValue macro = valueTuple.Item1;
				string fileName = valueTuple.Item2;
				return macro.Value + fileName;
			}
			return path;
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00010728 File Offset: 0x0000E928
		private AppCategory GetSelectedAppCategory()
		{
			return this.gridViewUserCategories.GetFocusedRow() as AppCategory;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0001073A File Offset: 0x0000E93A
		private AppFilter GetSelectedAppFilter()
		{
			return this.gridViewAppFilters.GetFocusedRow() as AppFilter;
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x0001074C File Offset: 0x0000E94C
		private void gridViewAppFilters_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			if (e.Column == this.columnAppFilterPath)
			{
				e.DisplayText = this.GetPathDisplayText(e.DisplayText);
			}
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x00010770 File Offset: 0x0000E970
		private void gridViewAppFilters_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			e.Visible = false;
			if (this._selectedUserAppCategory != null)
			{
				string id = (sender as ColumnView).GetListSourceRowCellValue(e.ListSourceRow, "Id") as string;
				AppFilter item = this._apiClient.AppFilters.FindItemById(id);
				if (item != null)
				{
					e.Visible = item.CategoriesId.Contains(this._selectedUserAppCategory.Id);
				}
			}
			e.Handled = true;
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x000107E0 File Offset: 0x0000E9E0
		private void gridViewAppFilters_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			if (e.Column.FieldName == "Path" && e.IsGetData && e.IsGetData)
			{
				AppFilter filter = e.Row as AppFilter;
				if (filter != null)
				{
					AppFilterType filterType = filter.FilterType;
					if (filterType != AppFilterType.PathFilter)
					{
						return;
					}
					AppPathFilter pathFilter = filter.GetAppPathFilter();
					if (pathFilter != null)
					{
						e.Value = pathFilter.Path;
					}
				}
			}
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00010848 File Offset: 0x0000EA48
		private void gridViewUserCategories_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this._selectedUserAppCategory = this.GetSelectedAppCategory();
			this.gridViewAppFilters.RefreshData();
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x00010861 File Offset: 0x0000EA61
		private void gridViewUserCategories_RowCountChanged(object sender, EventArgs e)
		{
			this.barButtonAddAppPathFilter.Enabled = (this.gridViewUserCategories.RowCount > 0);
		}

		// Token: 0x04000165 RID: 357
		private readonly List<StringKeyAndValue> _macroList;

		// Token: 0x04000166 RID: 358
		private ApiClient _apiClient;

		// Token: 0x04000167 RID: 359
		private AppCategory _selectedUserAppCategory;
	}
}
