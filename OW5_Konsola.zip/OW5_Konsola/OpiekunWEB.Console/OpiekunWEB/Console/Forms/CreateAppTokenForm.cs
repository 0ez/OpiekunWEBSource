﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005E RID: 94
	public partial class CreateAppTokenForm : BaseForm
	{
		// Token: 0x06000508 RID: 1288 RVA: 0x00019DF8 File Offset: 0x00017FF8
		public CreateAppTokenForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x00019E10 File Offset: 0x00018010
		private void buttonCreateToken_Click(object sender, EventArgs e)
		{
			CreateAppTokenForm.<buttonCreateToken_Click>d__2 <buttonCreateToken_Click>d__;
			<buttonCreateToken_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonCreateToken_Click>d__.<>4__this = this;
			<buttonCreateToken_Click>d__.<>1__state = -1;
			<buttonCreateToken_Click>d__.<>t__builder.Start<CreateAppTokenForm.<buttonCreateToken_Click>d__2>(ref <buttonCreateToken_Click>d__);
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x00019E48 File Offset: 0x00018048
		private Task CreateToken()
		{
			CreateAppTokenForm.<CreateToken>d__3 <CreateToken>d__;
			<CreateToken>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CreateToken>d__.<>4__this = this;
			<CreateToken>d__.<>1__state = -1;
			<CreateToken>d__.<>t__builder.Start<CreateAppTokenForm.<CreateToken>d__3>(ref <CreateToken>d__);
			return <CreateToken>d__.<>t__builder.Task;
		}

		// Token: 0x04000238 RID: 568
		private readonly ApiClient _apiClient;
	}
}
