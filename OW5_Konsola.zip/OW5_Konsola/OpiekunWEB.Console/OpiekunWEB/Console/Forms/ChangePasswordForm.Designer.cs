﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005D RID: 93
	public partial class ChangePasswordForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000506 RID: 1286 RVA: 0x00019647 File Offset: 0x00017847
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00019668 File Offset: 0x00017868
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ChangePasswordForm));
			this.layoutControlPasswords = new global::DevExpress.XtraLayout.LayoutControl();
			this.textEditPassword2 = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditPassword1 = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditOldPassword = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroup1 = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlItemOldPassword = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemPassword1 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemPassword2 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.pictureBoxLogo = new global::System.Windows.Forms.PictureBox();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPasswords).BeginInit();
			this.layoutControlPasswords.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword2.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword1.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditOldPassword.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroup1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemOldPassword).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemPassword1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemPassword2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).BeginInit();
			base.SuspendLayout();
			this.layoutControlPasswords.AllowCustomization = false;
			this.layoutControlPasswords.Controls.Add(this.textEditPassword2);
			this.layoutControlPasswords.Controls.Add(this.textEditPassword1);
			this.layoutControlPasswords.Controls.Add(this.textEditOldPassword);
			resources.ApplyResources(this.layoutControlPasswords, "layoutControlPasswords");
			this.layoutControlPasswords.Name = "layoutControlPasswords";
			this.layoutControlPasswords.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2145, 256, 609, 465));
			this.layoutControlPasswords.Root = this.layoutControlGroup1;
			resources.ApplyResources(this.textEditPassword2, "textEditPassword2");
			this.textEditPassword2.Name = "textEditPassword2";
			this.textEditPassword2.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditPassword2.Properties.Mask.BeepOnError");
			this.textEditPassword2.Properties.Mask.EditMask = resources.GetString("textEditPassword2.Properties.Mask.EditMask");
			this.textEditPassword2.Properties.NullValuePrompt = resources.GetString("textEditPassword2.Properties.NullValuePrompt");
			this.textEditPassword2.Properties.PasswordChar = '*';
			this.textEditPassword2.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditPassword2.Properties.UseSystemPasswordChar = true;
			this.textEditPassword2.StyleController = this.layoutControlPasswords;
			resources.ApplyResources(this.textEditPassword1, "textEditPassword1");
			this.textEditPassword1.Name = "textEditPassword1";
			this.textEditPassword1.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditPassword1.Properties.Mask.BeepOnError");
			this.textEditPassword1.Properties.Mask.EditMask = resources.GetString("textEditPassword1.Properties.Mask.EditMask");
			this.textEditPassword1.Properties.NullValuePrompt = resources.GetString("textEditPassword1.Properties.NullValuePrompt");
			this.textEditPassword1.Properties.PasswordChar = '*';
			this.textEditPassword1.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditPassword1.Properties.UseSystemPasswordChar = true;
			this.textEditPassword1.StyleController = this.layoutControlPasswords;
			resources.ApplyResources(this.textEditOldPassword, "textEditOldPassword");
			this.textEditOldPassword.Name = "textEditOldPassword";
			this.textEditOldPassword.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditOldPassword.Properties.Mask.BeepOnError");
			this.textEditOldPassword.Properties.Mask.EditMask = resources.GetString("textEditOldPassword.Properties.Mask.EditMask");
			this.textEditOldPassword.Properties.NullValuePrompt = resources.GetString("textEditOldPassword.Properties.NullValuePrompt");
			this.textEditOldPassword.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditOldPassword.Properties.UseSystemPasswordChar = true;
			this.textEditOldPassword.StyleController = this.layoutControlPasswords;
			this.layoutControlGroup1.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroup1.GroupBordersVisible = false;
			this.layoutControlGroup1.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlItemOldPassword,
				this.layoutControlItemPassword1,
				this.layoutControlItemPassword2
			});
			this.layoutControlGroup1.Name = "Root";
			this.layoutControlGroup1.Padding = new global::DevExpress.XtraLayout.Utils.Padding(12, 12, 12, 12);
			this.layoutControlGroup1.Size = new global::System.Drawing.Size(252, 188);
			this.layoutControlGroup1.TextVisible = false;
			this.layoutControlItemOldPassword.Control = this.textEditOldPassword;
			this.layoutControlItemOldPassword.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlItemOldPassword.Name = "layoutControlItemOldPassword";
			this.layoutControlItemOldPassword.Size = new global::System.Drawing.Size(228, 45);
			resources.ApplyResources(this.layoutControlItemOldPassword, "layoutControlItemOldPassword");
			this.layoutControlItemOldPassword.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemOldPassword.TextSize = new global::System.Drawing.Size(132, 16);
			this.layoutControlItemPassword1.Control = this.textEditPassword1;
			resources.ApplyResources(this.layoutControlItemPassword1, "layoutControlItemPassword1");
			this.layoutControlItemPassword1.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlItemPassword1.Name = "layoutControlItemPassword1";
			this.layoutControlItemPassword1.Size = new global::System.Drawing.Size(228, 45);
			this.layoutControlItemPassword1.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemPassword1.TextSize = new global::System.Drawing.Size(132, 16);
			this.layoutControlItemPassword2.Control = this.textEditPassword2;
			this.layoutControlItemPassword2.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlItemPassword2.Name = "layoutControlItemPassword2";
			this.layoutControlItemPassword2.Size = new global::System.Drawing.Size(228, 74);
			resources.ApplyResources(this.layoutControlItemPassword2, "layoutControlItemPassword2");
			this.layoutControlItemPassword2.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemPassword2.TextSize = new global::System.Drawing.Size(132, 16);
			this.pictureBoxLogo.Image = global::OpiekunWEB.Console.Properties.Resources.opiekun_logo_120x125;
			resources.ApplyResources(this.pictureBoxLogo, "pictureBoxLogo");
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.TabStop = false;
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.pictureBoxLogo);
			base.Controls.Add(this.layoutControlPasswords);
			base.Controls.Add(this.buttonOk);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("ChangePasswordForm.IconOptions.Icon");
			base.Name = "ChangePasswordForm";
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPasswords).EndInit();
			this.layoutControlPasswords.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword2.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword1.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditOldPassword.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroup1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemOldPassword).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemPassword1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemPassword2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400022D RID: 557
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400022E RID: 558
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x0400022F RID: 559
		private global::DevExpress.XtraLayout.LayoutControl layoutControlPasswords;

		// Token: 0x04000230 RID: 560
		private global::DevExpress.XtraEditors.TextEdit textEditPassword2;

		// Token: 0x04000231 RID: 561
		private global::DevExpress.XtraEditors.TextEdit textEditPassword1;

		// Token: 0x04000232 RID: 562
		private global::DevExpress.XtraEditors.TextEdit textEditOldPassword;

		// Token: 0x04000233 RID: 563
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;

		// Token: 0x04000234 RID: 564
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemOldPassword;

		// Token: 0x04000235 RID: 565
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemPassword1;

		// Token: 0x04000236 RID: 566
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemPassword2;

		// Token: 0x04000237 RID: 567
		private global::System.Windows.Forms.PictureBox pictureBoxLogo;
	}
}
