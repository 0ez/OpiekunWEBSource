﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000077 RID: 119
	public partial class ProcessDefListForm : global::OpiekunWEB.ConsoleDefBaseForm
	{
		// Token: 0x0600064C RID: 1612 RVA: 0x00031299 File Offset: 0x0002F499
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600064D RID: 1613 RVA: 0x000312B8 File Offset: 0x0002F4B8
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ProcessDefListForm));
			this.gridProcessDefs = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewProcessDefs = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnIsFavorite = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryItemImageComboBoxIsFavorite = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imageCollection = new global::DevExpress.Utils.ImageCollection(this.components);
			this.gridColumnDisplayName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnDefinition = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnId = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnAvailableForAll = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryItemImageComboBoxAvailableForAll = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonCommands).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridProcessDefs).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewProcessDefs).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxIsFavorite).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollection).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxAvailableForAll).BeginInit();
			base.SuspendLayout();
			this.ribbonCommands.ExpandCollapseItem.Id = 0;
			this.ribbonCommands.SearchEditItem.Alignment = global::DevExpress.XtraBars.BarItemLinkAlignment.Left;
			this.ribbonCommands.SearchEditItem.EditWidth = (int)resources.GetObject("ribbonCommands.SearchEditItem.EditWidth");
			this.ribbonCommands.SearchEditItem.Id = -5000;
			this.ribbonCommands.SearchEditItem.ImageOptions.AllowGlyphSkinning = global::DevExpress.Utils.DefaultBoolean.True;
			this.ribbonCommands.ShowDisplayOptionsMenuButton = global::DevExpress.Utils.DefaultBoolean.False;
			resources.ApplyResources(this.ribbonCommands, "ribbonCommands");
			this.ribbonCommands.Toolbar.ShowCustomizeItem = false;
			this.barButtonClose.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonClose.ImageOptions.Image");
			this.barButtonClose.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonClose.ImageOptions.LargeImage");
			this.barButtonAdd.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonAdd.ImageOptions.Image");
			this.barButtonAdd.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonAdd.ImageOptions.LargeImage");
			this.barButtonAdd.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAdd_ItemClick);
			this.barButtonEdit.Enabled = false;
			this.barButtonEdit.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonEdit.ImageOptions.Image");
			this.barButtonEdit.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonEdit.ImageOptions.LargeImage");
			this.barButtonEdit.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonEdit_ItemClick);
			this.barButtonDelete.Enabled = false;
			this.barButtonDelete.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonDelete.ImageOptions.Image");
			this.barButtonDelete.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonDelete.ImageOptions.LargeImage");
			this.barButtonDelete.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonDelete_ItemClick);
			this.barButtonLaunch.Enabled = false;
			this.barButtonLaunch.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonLaunch.ImageOptions.Image");
			this.barButtonLaunch.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonLaunch.ImageOptions.LargeImage");
			this.barButtonLaunch.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonLaunch_ItemClick);
			resources.ApplyResources(this.gridProcessDefs, "gridProcessDefs");
			this.gridProcessDefs.EmbeddedNavigator.Margin = (global::System.Windows.Forms.Padding)resources.GetObject("gridProcessDefs.EmbeddedNavigator.Margin");
			this.gridProcessDefs.MainView = this.gridViewProcessDefs;
			this.gridProcessDefs.Name = "gridProcessDefs";
			this.gridProcessDefs.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryItemImageComboBoxIsFavorite,
				this.repositoryItemImageComboBoxAvailableForAll
			});
			this.gridProcessDefs.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewProcessDefs
			});
			this.gridViewProcessDefs.Appearance.FocusedRow.BackColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			this.gridViewProcessDefs.Appearance.FocusedRow.Options.UseBackColor = true;
			this.gridViewProcessDefs.Appearance.SelectedRow.BackColor = global::System.Drawing.SystemColors.ScrollBar;
			this.gridViewProcessDefs.Appearance.SelectedRow.Options.UseBackColor = true;
			this.gridViewProcessDefs.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnIsFavorite,
				this.gridColumnDisplayName,
				this.gridColumnDefinition,
				this.gridColumnType,
				this.gridColumnId,
				this.gridColumnAvailableForAll
			});
			this.gridViewProcessDefs.DetailHeight = 431;
			this.gridViewProcessDefs.GridControl = this.gridProcessDefs;
			this.gridViewProcessDefs.Name = "gridViewProcessDefs";
			this.gridViewProcessDefs.OptionsMenu.EnableColumnMenu = false;
			this.gridViewProcessDefs.OptionsNavigation.AutoFocusNewRow = true;
			this.gridViewProcessDefs.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewProcessDefs.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewProcessDefs.OptionsView.ShowGroupPanel = false;
			this.gridViewProcessDefs.OptionsView.ShowHorizontalLines = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridViewProcessDefs.OptionsView.ShowIndicator = false;
			this.gridViewProcessDefs.OptionsView.ShowVerticalLines = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridViewProcessDefs.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnDisplayName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewProcessDefs.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewProcessDefs_FocusedRowChanged);
			this.gridViewProcessDefs.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewProcessDefs_CustomUnboundColumnData);
			this.gridViewProcessDefs.CustomRowFilter += new global::DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridViewProcessDefs_CustomRowFilter);
			this.gridViewProcessDefs.DoubleClick += new global::System.EventHandler(this.gridViewProcessDefs_DoubleClick);
			this.gridColumnIsFavorite.ColumnEdit = this.repositoryItemImageComboBoxIsFavorite;
			this.gridColumnIsFavorite.FieldName = "IsFavorite";
			this.gridColumnIsFavorite.MaxWidth = 30;
			this.gridColumnIsFavorite.MinWidth = 30;
			this.gridColumnIsFavorite.Name = "gridColumnIsFavorite";
			this.gridColumnIsFavorite.OptionsColumn.AllowEdit = false;
			this.gridColumnIsFavorite.OptionsColumn.AllowFocus = false;
			this.gridColumnIsFavorite.OptionsColumn.AllowGroup = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridColumnIsFavorite.OptionsColumn.AllowMove = false;
			this.gridColumnIsFavorite.OptionsColumn.AllowShowHide = false;
			this.gridColumnIsFavorite.OptionsColumn.AllowSize = false;
			this.gridColumnIsFavorite.OptionsColumn.AllowSort = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridColumnIsFavorite.OptionsColumn.FixedWidth = true;
			this.gridColumnIsFavorite.OptionsColumn.ReadOnly = true;
			this.gridColumnIsFavorite.OptionsColumn.ShowCaption = false;
			this.gridColumnIsFavorite.OptionsColumn.TabStop = false;
			this.gridColumnIsFavorite.OptionsFilter.AllowAutoFilter = false;
			this.gridColumnIsFavorite.OptionsFilter.AllowFilter = false;
			this.gridColumnIsFavorite.UnboundType = global::DevExpress.Data.UnboundColumnType.Boolean;
			resources.ApplyResources(this.gridColumnIsFavorite, "gridColumnIsFavorite");
			resources.ApplyResources(this.repositoryItemImageComboBoxIsFavorite, "repositoryItemImageComboBoxIsFavorite");
			this.repositoryItemImageComboBoxIsFavorite.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxIsFavorite.Items"), resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items1"), (int)resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxIsFavorite.Items3"), resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items4"), (int)resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items5"))
			});
			this.repositoryItemImageComboBoxIsFavorite.Name = "repositoryItemImageComboBoxIsFavorite";
			this.repositoryItemImageComboBoxIsFavorite.SmallImages = this.imageCollection;
			this.imageCollection.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imageCollection.ImageStream");
			this.imageCollection.InsertImage(global::OpiekunWEB.Console.Properties.Resources.feature_16x16, "feature_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imageCollection.Images.SetKeyName(0, "feature_16x16");
			this.imageCollection.InsertImage(global::OpiekunWEB.Console.Properties.Resources.usergroup_16x16, "usergroup_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imageCollection.Images.SetKeyName(1, "usergroup_16x16");
			this.gridColumnDisplayName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDisplayName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnDisplayName, "gridColumnDisplayName");
			this.gridColumnDisplayName.FieldName = "DisplayName";
			this.gridColumnDisplayName.MinWidth = 27;
			this.gridColumnDisplayName.Name = "gridColumnDisplayName";
			this.gridColumnDisplayName.OptionsColumn.AllowEdit = false;
			this.gridColumnDisplayName.OptionsColumn.AllowMove = false;
			this.gridColumnDisplayName.OptionsColumn.AllowShowHide = false;
			this.gridColumnDisplayName.OptionsColumn.AllowSize = false;
			this.gridColumnDisplayName.OptionsColumn.ReadOnly = true;
			this.gridColumnDisplayName.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			resources.ApplyResources(this.gridColumnDefinition, "gridColumnDefinition");
			this.gridColumnDefinition.FieldName = "Definition";
			this.gridColumnDefinition.MinWidth = 27;
			this.gridColumnDefinition.Name = "gridColumnDefinition";
			this.gridColumnDefinition.OptionsColumn.ShowInCustomizationForm = false;
			this.gridColumnDefinition.OptionsColumn.ShowInExpressionEditor = false;
			resources.ApplyResources(this.gridColumnType, "gridColumnType");
			this.gridColumnType.FieldName = "Type";
			this.gridColumnType.MinWidth = 27;
			this.gridColumnType.Name = "gridColumnType";
			this.gridColumnType.OptionsColumn.ShowInCustomizationForm = false;
			this.gridColumnType.OptionsColumn.ShowInExpressionEditor = false;
			resources.ApplyResources(this.gridColumnId, "gridColumnId");
			this.gridColumnId.FieldName = "id";
			this.gridColumnId.MinWidth = 27;
			this.gridColumnId.Name = "gridColumnId";
			this.gridColumnId.OptionsColumn.ShowInCustomizationForm = false;
			this.gridColumnId.OptionsColumn.ShowInExpressionEditor = false;
			this.gridColumnAvailableForAll.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnAvailableForAll.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridColumnAvailableForAll.ColumnEdit = this.repositoryItemImageComboBoxAvailableForAll;
			this.gridColumnAvailableForAll.FieldName = "AvailableForAll";
			this.gridColumnAvailableForAll.MaxWidth = 30;
			this.gridColumnAvailableForAll.MinWidth = 30;
			this.gridColumnAvailableForAll.Name = "gridColumnAvailableForAll";
			this.gridColumnAvailableForAll.OptionsColumn.AllowEdit = false;
			this.gridColumnAvailableForAll.OptionsColumn.AllowFocus = false;
			this.gridColumnAvailableForAll.OptionsColumn.AllowGroup = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridColumnAvailableForAll.OptionsColumn.AllowMove = false;
			this.gridColumnAvailableForAll.OptionsColumn.AllowShowHide = false;
			this.gridColumnAvailableForAll.OptionsColumn.AllowSize = false;
			this.gridColumnAvailableForAll.OptionsColumn.AllowSort = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridColumnAvailableForAll.OptionsColumn.FixedWidth = true;
			this.gridColumnAvailableForAll.OptionsColumn.ReadOnly = true;
			this.gridColumnAvailableForAll.OptionsColumn.ShowCaption = false;
			this.gridColumnAvailableForAll.OptionsColumn.TabStop = false;
			this.gridColumnAvailableForAll.OptionsFilter.AllowAutoFilter = false;
			this.gridColumnAvailableForAll.OptionsFilter.AllowFilter = false;
			this.gridColumnAvailableForAll.UnboundType = global::DevExpress.Data.UnboundColumnType.Boolean;
			resources.ApplyResources(this.gridColumnAvailableForAll, "gridColumnAvailableForAll");
			resources.ApplyResources(this.repositoryItemImageComboBoxAvailableForAll, "repositoryItemImageComboBoxAvailableForAll");
			this.repositoryItemImageComboBoxAvailableForAll.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxAvailableForAll.Items"), resources.GetObject("repositoryItemImageComboBoxAvailableForAll.Items1"), (int)resources.GetObject("repositoryItemImageComboBoxAvailableForAll.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxAvailableForAll.Items3"), resources.GetObject("repositoryItemImageComboBoxAvailableForAll.Items4"), (int)resources.GetObject("repositoryItemImageComboBoxAvailableForAll.Items5"))
			});
			this.repositoryItemImageComboBoxAvailableForAll.Name = "repositoryItemImageComboBoxAvailableForAll";
			this.repositoryItemImageComboBoxAvailableForAll.SmallImages = this.imageCollection;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.gridProcessDefs);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.Name = "ProcessDefListForm";
			base.Controls.SetChildIndex(this.ribbonCommands, 0);
			base.Controls.SetChildIndex(this.gridProcessDefs, 0);
			((global::System.ComponentModel.ISupportInitialize)this.ribbonCommands).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridProcessDefs).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewProcessDefs).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxIsFavorite).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollection).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxAvailableForAll).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040003F4 RID: 1012
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040003F5 RID: 1013
		private global::DevExpress.XtraGrid.GridControl gridProcessDefs;

		// Token: 0x040003F6 RID: 1014
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewProcessDefs;

		// Token: 0x040003F7 RID: 1015
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnIsFavorite;

		// Token: 0x040003F8 RID: 1016
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemImageComboBoxIsFavorite;

		// Token: 0x040003F9 RID: 1017
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDisplayName;

		// Token: 0x040003FA RID: 1018
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDefinition;

		// Token: 0x040003FB RID: 1019
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnType;

		// Token: 0x040003FC RID: 1020
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnId;

		// Token: 0x040003FD RID: 1021
		private global::DevExpress.Utils.ImageCollection imageCollection;

		// Token: 0x040003FE RID: 1022
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnAvailableForAll;

		// Token: 0x040003FF RID: 1023
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemImageComboBoxAvailableForAll;
	}
}
