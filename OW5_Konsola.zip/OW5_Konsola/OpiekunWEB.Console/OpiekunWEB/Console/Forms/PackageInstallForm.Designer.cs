﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007A RID: 122
	public partial class PackageInstallForm : global::OpiekunWEB.Console.Forms.NonModalBaseForm
	{
		// Token: 0x0600067B RID: 1659 RVA: 0x00033AF2 File Offset: 0x00031CF2
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x00033B14 File Offset: 0x00031D14
		private void InitializeComponent()
		{
			this.wizardControl1 = new global::DevExpress.XtraWizard.WizardControl();
			this.wizardPage1 = new global::DevExpress.XtraWizard.WizardPage();
			this.gridControlPackages = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewPackages = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.colPackage = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colRegistrySnapshot = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colFilesSnapshot = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colArguments = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colVersionOverride = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colHasSilentUninstall = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colIsSideBySide = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colIsPinned = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.colExtraInformation = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.simpleButton1 = new global::DevExpress.XtraEditors.SimpleButton();
			this.textEdit1 = new global::DevExpress.XtraEditors.TextEdit();
			this.completionWizardPage1 = new global::DevExpress.XtraWizard.CompletionWizardPage();
			this.wizardPage2 = new global::DevExpress.XtraWizard.WizardPage();
			this.virtualServerModeSource = new global::DevExpress.Data.VirtualServerModeSource();
			((global::System.ComponentModel.ISupportInitialize)this.wizardControl1).BeginInit();
			this.wizardControl1.SuspendLayout();
			this.wizardPage1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridControlPackages).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewPackages).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEdit1.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.virtualServerModeSource).BeginInit();
			base.SuspendLayout();
			this.wizardControl1.Controls.Add(this.wizardPage1);
			this.wizardControl1.Controls.Add(this.completionWizardPage1);
			this.wizardControl1.Controls.Add(this.wizardPage2);
			this.wizardControl1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.wizardControl1.Location = new global::System.Drawing.Point(0, 0);
			this.wizardControl1.Name = "wizardControl1";
			this.wizardControl1.Pages.AddRange(new global::DevExpress.XtraWizard.BaseWizardPage[]
			{
				this.wizardPage1,
				this.wizardPage2,
				this.completionWizardPage1
			});
			this.wizardControl1.Size = new global::System.Drawing.Size(800, 450);
			this.wizardPage1.Controls.Add(this.gridControlPackages);
			this.wizardPage1.Controls.Add(this.simpleButton1);
			this.wizardPage1.Controls.Add(this.textEdit1);
			this.wizardPage1.DescriptionText = "Wpisz nazwę poszukiwanego pakietu a następnie zaznacz pakiet na liście dostępnych pakietów";
			this.wizardPage1.Name = "wizardPage1";
			this.wizardPage1.Size = new global::System.Drawing.Size(768, 278);
			this.wizardPage1.Text = "Wybór pakietu do instalacji";
			this.gridControlPackages.DataSource = this.virtualServerModeSource;
			this.gridControlPackages.Location = new global::System.Drawing.Point(28, 48);
			this.gridControlPackages.MainView = this.gridViewPackages;
			this.gridControlPackages.Name = "gridControlPackages";
			this.gridControlPackages.Size = new global::System.Drawing.Size(672, 230);
			this.gridControlPackages.TabIndex = 2;
			this.gridControlPackages.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewPackages
			});
			this.gridViewPackages.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.colPackage,
				this.colRegistrySnapshot,
				this.colFilesSnapshot,
				this.colArguments,
				this.colVersionOverride,
				this.colHasSilentUninstall,
				this.colIsSideBySide,
				this.colIsPinned,
				this.colExtraInformation
			});
			this.gridViewPackages.GridControl = this.gridControlPackages;
			this.gridViewPackages.Name = "gridViewPackages";
			this.colPackage.FieldName = "Package";
			this.colPackage.MinWidth = 25;
			this.colPackage.Name = "colPackage";
			this.colPackage.Visible = true;
			this.colPackage.VisibleIndex = 0;
			this.colPackage.Width = 94;
			this.colRegistrySnapshot.FieldName = "RegistrySnapshot";
			this.colRegistrySnapshot.MinWidth = 25;
			this.colRegistrySnapshot.Name = "colRegistrySnapshot";
			this.colRegistrySnapshot.Visible = true;
			this.colRegistrySnapshot.VisibleIndex = 1;
			this.colRegistrySnapshot.Width = 94;
			this.colFilesSnapshot.FieldName = "FilesSnapshot";
			this.colFilesSnapshot.MinWidth = 25;
			this.colFilesSnapshot.Name = "colFilesSnapshot";
			this.colFilesSnapshot.Visible = true;
			this.colFilesSnapshot.VisibleIndex = 2;
			this.colFilesSnapshot.Width = 94;
			this.colArguments.FieldName = "Arguments";
			this.colArguments.MinWidth = 25;
			this.colArguments.Name = "colArguments";
			this.colArguments.Visible = true;
			this.colArguments.VisibleIndex = 3;
			this.colArguments.Width = 94;
			this.colVersionOverride.FieldName = "VersionOverride";
			this.colVersionOverride.MinWidth = 25;
			this.colVersionOverride.Name = "colVersionOverride";
			this.colVersionOverride.Visible = true;
			this.colVersionOverride.VisibleIndex = 4;
			this.colVersionOverride.Width = 94;
			this.colHasSilentUninstall.FieldName = "HasSilentUninstall";
			this.colHasSilentUninstall.MinWidth = 25;
			this.colHasSilentUninstall.Name = "colHasSilentUninstall";
			this.colHasSilentUninstall.Visible = true;
			this.colHasSilentUninstall.VisibleIndex = 5;
			this.colHasSilentUninstall.Width = 94;
			this.colIsSideBySide.FieldName = "IsSideBySide";
			this.colIsSideBySide.MinWidth = 25;
			this.colIsSideBySide.Name = "colIsSideBySide";
			this.colIsSideBySide.Visible = true;
			this.colIsSideBySide.VisibleIndex = 6;
			this.colIsSideBySide.Width = 94;
			this.colIsPinned.FieldName = "IsPinned";
			this.colIsPinned.MinWidth = 25;
			this.colIsPinned.Name = "colIsPinned";
			this.colIsPinned.Visible = true;
			this.colIsPinned.VisibleIndex = 7;
			this.colIsPinned.Width = 94;
			this.colExtraInformation.FieldName = "ExtraInformation";
			this.colExtraInformation.MinWidth = 25;
			this.colExtraInformation.Name = "colExtraInformation";
			this.colExtraInformation.Visible = true;
			this.colExtraInformation.VisibleIndex = 8;
			this.colExtraInformation.Width = 94;
			this.simpleButton1.Location = new global::System.Drawing.Point(297, 16);
			this.simpleButton1.Name = "simpleButton1";
			this.simpleButton1.Size = new global::System.Drawing.Size(94, 29);
			this.simpleButton1.TabIndex = 1;
			this.simpleButton1.Text = "simpleButton1";
			this.simpleButton1.Click += new global::System.EventHandler(this.simpleButton1_Click);
			this.textEdit1.Location = new global::System.Drawing.Point(3, 20);
			this.textEdit1.Name = "textEdit1";
			this.textEdit1.Size = new global::System.Drawing.Size(233, 22);
			this.textEdit1.TabIndex = 0;
			this.completionWizardPage1.Name = "completionWizardPage1";
			this.completionWizardPage1.Size = new global::System.Drawing.Size(583, 301);
			this.wizardPage2.Name = "wizardPage2";
			this.wizardPage2.Size = new global::System.Drawing.Size(768, 278);
			this.virtualServerModeSource.RowType = typeof(global::chocolatey.infrastructure.app.domain.ChocolateyPackageInformation);
			this.virtualServerModeSource.ConfigurationChanged += new global::System.EventHandler<global::DevExpress.Data.VirtualServerModeRowsEventArgs>(this.virtualServerModeSource_ConfigurationChanged);
			this.virtualServerModeSource.MoreRows += new global::System.EventHandler<global::DevExpress.Data.VirtualServerModeRowsEventArgs>(this.virtualServerModeSource_MoreRows);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(800, 450);
			base.Controls.Add(this.wizardControl1);
			base.Name = "PackageInstallForm";
			this.Text = "PackageInstallForm";
			((global::System.ComponentModel.ISupportInitialize)this.wizardControl1).EndInit();
			this.wizardControl1.ResumeLayout(false);
			this.wizardPage1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridControlPackages).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewPackages).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEdit1.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.virtualServerModeSource).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400042C RID: 1068
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400042D RID: 1069
		private global::DevExpress.XtraWizard.WizardControl wizardControl1;

		// Token: 0x0400042E RID: 1070
		private global::DevExpress.XtraWizard.WizardPage wizardPage1;

		// Token: 0x0400042F RID: 1071
		private global::DevExpress.XtraWizard.CompletionWizardPage completionWizardPage1;

		// Token: 0x04000430 RID: 1072
		private global::DevExpress.XtraWizard.WizardPage wizardPage2;

		// Token: 0x04000431 RID: 1073
		private global::DevExpress.XtraEditors.TextEdit textEdit1;

		// Token: 0x04000432 RID: 1074
		private global::DevExpress.XtraEditors.SimpleButton simpleButton1;

		// Token: 0x04000433 RID: 1075
		private global::DevExpress.XtraGrid.GridControl gridControlPackages;

		// Token: 0x04000434 RID: 1076
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewPackages;

		// Token: 0x04000435 RID: 1077
		private global::DevExpress.XtraGrid.Columns.GridColumn colPackage;

		// Token: 0x04000436 RID: 1078
		private global::DevExpress.XtraGrid.Columns.GridColumn colRegistrySnapshot;

		// Token: 0x04000437 RID: 1079
		private global::DevExpress.XtraGrid.Columns.GridColumn colFilesSnapshot;

		// Token: 0x04000438 RID: 1080
		private global::DevExpress.XtraGrid.Columns.GridColumn colArguments;

		// Token: 0x04000439 RID: 1081
		private global::DevExpress.XtraGrid.Columns.GridColumn colVersionOverride;

		// Token: 0x0400043A RID: 1082
		private global::DevExpress.XtraGrid.Columns.GridColumn colHasSilentUninstall;

		// Token: 0x0400043B RID: 1083
		private global::DevExpress.XtraGrid.Columns.GridColumn colIsSideBySide;

		// Token: 0x0400043C RID: 1084
		private global::DevExpress.XtraGrid.Columns.GridColumn colIsPinned;

		// Token: 0x0400043D RID: 1085
		private global::DevExpress.XtraGrid.Columns.GridColumn colExtraInformation;

		// Token: 0x0400043E RID: 1086
		private global::DevExpress.Data.VirtualServerModeSource virtualServerModeSource;
	}
}
