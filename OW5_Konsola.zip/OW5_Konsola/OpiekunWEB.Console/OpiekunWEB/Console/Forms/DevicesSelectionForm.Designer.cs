﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006C RID: 108
	public partial class DevicesSelectionForm : global::OpiekunWEB.Console.Forms.BaseForm, global::System.IDisposable
	{
		// Token: 0x060005D4 RID: 1492 RVA: 0x00027462 File Offset: 0x00025662
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				global::DevExpress.XtraEditors.Repository.RepositoryItemTextEdit emptyItemTextEdit = this._emptyItemTextEdit;
				if (emptyItemTextEdit != null)
				{
					emptyItemTextEdit.Dispose();
				}
			}
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00027498 File Offset: 0x00025698
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DevicesSelectionForm));
			this.treeDevices = new global::DevExpress.XtraTreeList.TreeList();
			this.columnDeviceName = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.columnWindowsUser = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.columnDescription = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.columnIsSelected = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.repositoryItemCheckBoxIsSelected = new global::DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
			this.columnIsConnected = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.panelBottom = new global::System.Windows.Forms.Panel();
			this.checkEditShowOnlyConnected = new global::DevExpress.XtraEditors.CheckEdit();
			this.buttonCancel = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.treeDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemCheckBoxIsSelected).BeginInit();
			this.panelBottom.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditShowOnlyConnected.Properties).BeginInit();
			base.SuspendLayout();
			this.treeDevices.Appearance.FocusedRow.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("treeDevices.Appearance.FocusedRow.FontStyleDelta");
			this.treeDevices.Appearance.FocusedRow.Options.UseFont = true;
			this.treeDevices.Appearance.SelectedRow.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("treeDevices.Appearance.SelectedRow.FontStyleDelta");
			this.treeDevices.Appearance.SelectedRow.Options.UseFont = true;
			this.treeDevices.Columns.AddRange(new global::DevExpress.XtraTreeList.Columns.TreeListColumn[]
			{
				this.columnDeviceName,
				this.columnWindowsUser,
				this.columnDescription,
				this.columnIsSelected,
				this.columnIsConnected
			});
			this.treeDevices.Cursor = global::System.Windows.Forms.Cursors.Default;
			resources.ApplyResources(this.treeDevices, "treeDevices");
			this.treeDevices.ImageIndexFieldName = "IconIndex";
			this.treeDevices.KeyFieldName = "Id";
			this.treeDevices.Name = "treeDevices";
			this.treeDevices.OptionsBehavior.AllowExpandOnDblClick = false;
			this.treeDevices.OptionsNavigation.AutoFocusNewNode = true;
			this.treeDevices.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.treeDevices.OptionsSelection.MultiSelect = true;
			this.treeDevices.OptionsView.ShowHorzLines = false;
			this.treeDevices.OptionsView.ShowVertLines = false;
			this.treeDevices.ParentFieldName = "ParentId";
			this.treeDevices.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryItemCheckBoxIsSelected
			});
			this.treeDevices.CustomNodeCellEdit += new global::DevExpress.XtraTreeList.GetCustomNodeCellEditEventHandler(this.treeDevices_CustomNodeCellEdit);
			this.treeDevices.CustomUnboundColumnData += new global::DevExpress.XtraTreeList.CustomColumnDataEventHandler(this.treeStations_CustomUnboundColumnData);
			this.treeDevices.CellValueChanging += new global::DevExpress.XtraTreeList.CellValueChangedEventHandler(this.treeStations_CellValueChanging);
			this.treeDevices.CustomRowFilter += new global::DevExpress.XtraTreeList.CustomRowFilterEventHandler(this.treeStations_CustomRowFilter);
			this.columnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDeviceName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnDeviceName, "columnDeviceName");
			this.columnDeviceName.FieldName = "Name";
			this.columnDeviceName.Name = "columnDeviceName";
			this.columnDeviceName.OptionsColumn.AllowEdit = false;
			this.columnDeviceName.OptionsColumn.ReadOnly = true;
			this.columnWindowsUser.AppearanceHeader.Options.UseTextOptions = true;
			this.columnWindowsUser.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnWindowsUser, "columnWindowsUser");
			this.columnWindowsUser.FieldName = "DomainAndUserName";
			this.columnWindowsUser.Name = "columnWindowsUser";
			this.columnDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnDescription, "columnDescription");
			this.columnDescription.FieldName = "Description";
			this.columnDescription.Name = "columnDescription";
			this.columnIsSelected.AppearanceHeader.Options.UseTextOptions = true;
			this.columnIsSelected.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnIsSelected, "columnIsSelected");
			this.columnIsSelected.ColumnEdit = this.repositoryItemCheckBoxIsSelected;
			this.columnIsSelected.FieldName = "IsSelectedByUser";
			this.columnIsSelected.Name = "columnIsSelected";
			this.columnIsSelected.UnboundType = global::DevExpress.XtraTreeList.Data.UnboundColumnType.Boolean;
			resources.ApplyResources(this.repositoryItemCheckBoxIsSelected, "repositoryItemCheckBoxIsSelected");
			this.repositoryItemCheckBoxIsSelected.Name = "repositoryItemCheckBoxIsSelected";
			resources.ApplyResources(this.columnIsConnected, "columnIsConnected");
			this.columnIsConnected.FieldName = "IsConnected";
			this.columnIsConnected.Name = "columnIsConnected";
			this.panelBottom.Controls.Add(this.checkEditShowOnlyConnected);
			this.panelBottom.Controls.Add(this.buttonCancel);
			this.panelBottom.Controls.Add(this.buttonOk);
			resources.ApplyResources(this.panelBottom, "panelBottom");
			this.panelBottom.Name = "panelBottom";
			resources.ApplyResources(this.checkEditShowOnlyConnected, "checkEditShowOnlyConnected");
			this.checkEditShowOnlyConnected.Name = "checkEditShowOnlyConnected";
			this.checkEditShowOnlyConnected.Properties.Caption = resources.GetString("checkEditShowOnlyConnected.Properties.Caption");
			this.checkEditShowOnlyConnected.CheckStateChanged += new global::System.EventHandler(this.checkEditShowOnlyConnected_CheckStateChanged);
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonCancel.ImageOptions.Image");
			this.buttonCancel.Name = "buttonCancel";
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonOk.ImageOptions.Image");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.treeDevices);
			base.Controls.Add(this.panelBottom);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("DevicesSelectionForm.IconOptions.Icon");
			base.Name = "DevicesSelectionForm";
			((global::System.ComponentModel.ISupportInitialize)this.treeDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemCheckBoxIsSelected).EndInit();
			this.panelBottom.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.checkEditShowOnlyConnected.Properties).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000346 RID: 838
		private readonly global::DevExpress.XtraEditors.Repository.RepositoryItemTextEdit _emptyItemTextEdit;

		// Token: 0x04000349 RID: 841
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400034A RID: 842
		private global::DevExpress.XtraTreeList.TreeList treeDevices;

		// Token: 0x0400034B RID: 843
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn columnDeviceName;

		// Token: 0x0400034C RID: 844
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn columnIsSelected;

		// Token: 0x0400034D RID: 845
		private global::DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckBoxIsSelected;

		// Token: 0x0400034E RID: 846
		private global::System.Windows.Forms.Panel panelBottom;

		// Token: 0x0400034F RID: 847
		private global::DevExpress.XtraEditors.SimpleButton buttonCancel;

		// Token: 0x04000350 RID: 848
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x04000351 RID: 849
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn columnWindowsUser;

		// Token: 0x04000352 RID: 850
		private global::DevExpress.XtraEditors.CheckEdit checkEditShowOnlyConnected;

		// Token: 0x04000353 RID: 851
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn columnIsConnected;

		// Token: 0x04000354 RID: 852
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn columnDescription;
	}
}
