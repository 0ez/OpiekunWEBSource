﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000071 RID: 113
	public partial class RulesDefListForm : global::OpiekunWEB.ConsoleDefBaseForm
	{
		// Token: 0x060005FC RID: 1532 RVA: 0x00029EFD File Offset: 0x000280FD
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00029F1C File Offset: 0x0002811C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.RulesDefListForm));
			this.gridRules = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewRules = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnId = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryItemImageComboBoxIsFavorite = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonCommands).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridRules).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewRules).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxIsFavorite).BeginInit();
			base.SuspendLayout();
			this.ribbonCommands.ExpandCollapseItem.Id = 0;
			resources.ApplyResources(this.ribbonCommands, "ribbonCommands");
			this.ribbonCommands.Toolbar.ShowCustomizeItem = false;
			this.barButtonClose.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonClose.ImageOptions.Image");
			this.barButtonClose.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonClose.ImageOptions.LargeImage");
			this.barButtonAdd.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonAdd.ImageOptions.Image");
			this.barButtonAdd.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonAdd.ImageOptions.LargeImage");
			this.barButtonAdd.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAdd_ItemClick);
			this.barButtonEdit.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonEdit.ImageOptions.Image");
			this.barButtonEdit.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonEdit.ImageOptions.LargeImage");
			this.barButtonEdit.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonEdit_ItemClick);
			this.barButtonDelete.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonDelete.ImageOptions.Image");
			this.barButtonDelete.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonDelete.ImageOptions.LargeImage");
			this.barButtonDelete.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonDelete_ItemClick);
			this.barButtonLaunch.Enabled = false;
			this.barButtonLaunch.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonLaunch.ImageOptions.Image");
			this.barButtonLaunch.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("barButtonLaunch.ImageOptions.LargeImage");
			this.barButtonLaunch.Visibility = global::DevExpress.XtraBars.BarItemVisibility.Never;
			resources.ApplyResources(this.gridRules, "gridRules");
			this.gridRules.EmbeddedNavigator.Margin = (global::System.Windows.Forms.Padding)resources.GetObject("gridRules.EmbeddedNavigator.Margin");
			this.gridRules.MainView = this.gridViewRules;
			this.gridRules.Name = "gridRules";
			this.gridRules.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryItemImageComboBoxIsFavorite
			});
			this.gridRules.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewRules
			});
			this.gridViewRules.Appearance.FocusedRow.BackColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			this.gridViewRules.Appearance.FocusedRow.Options.UseBackColor = true;
			this.gridViewRules.Appearance.SelectedRow.BackColor = global::System.Drawing.SystemColors.ScrollBar;
			this.gridViewRules.Appearance.SelectedRow.Options.UseBackColor = true;
			this.gridViewRules.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnName,
				this.gridColumnId
			});
			this.gridViewRules.DetailHeight = 431;
			this.gridViewRules.GridControl = this.gridRules;
			this.gridViewRules.Name = "gridViewRules";
			this.gridViewRules.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewRules.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewRules.OptionsView.ShowGroupPanel = false;
			this.gridViewRules.OptionsView.ShowHorizontalLines = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridViewRules.OptionsView.ShowIndicator = false;
			this.gridViewRules.OptionsView.ShowVerticalLines = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridViewRules.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewRules.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewRules_FocusedRowChanged);
			this.gridColumnName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnName, "gridColumnName");
			this.gridColumnName.FieldName = "Name";
			this.gridColumnName.MinWidth = 27;
			this.gridColumnName.Name = "gridColumnName";
			this.gridColumnName.OptionsColumn.AllowEdit = false;
			this.gridColumnName.OptionsColumn.AllowMove = false;
			this.gridColumnName.OptionsColumn.AllowShowHide = false;
			this.gridColumnName.OptionsColumn.AllowSize = false;
			this.gridColumnName.OptionsColumn.ReadOnly = true;
			this.gridColumnName.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			resources.ApplyResources(this.gridColumnId, "gridColumnId");
			this.gridColumnId.FieldName = "Id";
			this.gridColumnId.MinWidth = 27;
			this.gridColumnId.Name = "gridColumnId";
			resources.ApplyResources(this.repositoryItemImageComboBoxIsFavorite, "repositoryItemImageComboBoxIsFavorite");
			this.repositoryItemImageComboBoxIsFavorite.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxIsFavorite.Items"), resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items1"), (int)resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxIsFavorite.Items3"), resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items4"), (int)resources.GetObject("repositoryItemImageComboBoxIsFavorite.Items5"))
			});
			this.repositoryItemImageComboBoxIsFavorite.Name = "repositoryItemImageComboBoxIsFavorite";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.gridRules);
			base.Name = "RulesDefListForm";
			base.Controls.SetChildIndex(this.ribbonCommands, 0);
			base.Controls.SetChildIndex(this.gridRules, 0);
			((global::System.ComponentModel.ISupportInitialize)this.ribbonCommands).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridRules).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewRules).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxIsFavorite).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400037F RID: 895
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000380 RID: 896
		private global::DevExpress.XtraGrid.GridControl gridRules;

		// Token: 0x04000381 RID: 897
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewRules;

		// Token: 0x04000382 RID: 898
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemImageComboBoxIsFavorite;

		// Token: 0x04000383 RID: 899
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnName;

		// Token: 0x04000384 RID: 900
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnId;
	}
}
