﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005C RID: 92
	public partial class RibbonBaseForm : RibbonForm
	{
		// Token: 0x060004F1 RID: 1265 RVA: 0x00018E48 File Offset: 0x00017048
		public RibbonBaseForm()
		{
			this.InitializeComponent();
			this._objectsToSaveState = new List<object>();
			this.CanCloseByEsc = true;
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x00018E68 File Offset: 0x00017068
		public RibbonBaseForm(FormsSettings formsSettings, IFormCreator formCreator) : this()
		{
			this._formsSettings = formsSettings;
			this._formCreator = formCreator;
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x060004F3 RID: 1267 RVA: 0x00018E7E File Offset: 0x0001707E
		// (set) Token: 0x060004F4 RID: 1268 RVA: 0x00018E86 File Offset: 0x00017086
		public bool CanCloseByEsc { get; set; }

		// Token: 0x060004F5 RID: 1269 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void OnGridCommandDeleteClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void OnGridCommandEditClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void OnTreeListCommandDeleteClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void OnTreeListCommandEditClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x00018E8F File Offset: 0x0001708F
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (this.CanCloseByEsc && keyData == Keys.Escape)
			{
				base.Close();
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x00018EAC File Offset: 0x000170AC
		protected void SetGridColumnForEditCommand(GridColumn column)
		{
			column.ColumnEdit = this.repositoryItemEdit;
			column.OptionsColumn.AllowSort = DefaultBoolean.False;
			column.OptionsColumn.AllowMove = false;
			column.OptionsColumn.AllowShowHide = false;
			column.OptionsColumn.ShowInCustomizationForm = false;
			column.OptionsColumn.ShowInExpressionEditor = false;
			column.OptionsFilter.AllowFilter = false;
			column.MinWidth = 80;
			column.Width = 80;
			column.OptionsColumn.FixedWidth = true;
			column.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowForFocusedRow;
			column.View.GridControl.ExternalRepository = this.editorsPersistentRepository;
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x00018F48 File Offset: 0x00017148
		protected void SetGridColumnForEditDeleteCommands(GridColumn column)
		{
			column.ColumnEdit = this.repositoryItemEditAndDelete;
			column.OptionsColumn.AllowSort = DefaultBoolean.False;
			column.OptionsColumn.AllowMove = false;
			column.OptionsColumn.AllowShowHide = false;
			column.OptionsColumn.ShowInCustomizationForm = false;
			column.OptionsColumn.ShowInExpressionEditor = false;
			column.OptionsFilter.AllowFilter = false;
			column.MinWidth = 120;
			column.Width = 120;
			column.OptionsColumn.FixedWidth = true;
			column.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowForFocusedRow;
			column.View.GridControl.ExternalRepository = this.editorsPersistentRepository;
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x00018FE4 File Offset: 0x000171E4
		protected void SetTreeColumnForEditDeleteCommands(TreeListColumn column)
		{
			column.ColumnEdit = this.repositoryItemEditAndDelete;
			column.OptionsColumn.AllowSort = false;
			column.OptionsColumn.AllowMove = false;
			column.OptionsColumn.ShowInCustomizationForm = false;
			column.OptionsColumn.ShowInExpressionEditor = false;
			column.OptionsFilter.AllowFilter = false;
			column.MinWidth = 120;
			column.Width = 120;
			column.OptionsColumn.FixedWidth = true;
			column.ShowButtonMode = DevExpress.XtraTreeList.ShowButtonModeEnum.ShowForFocusedRow;
			column.TreeList.ExternalRepository = this.editorsPersistentRepository;
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x0001906D File Offset: 0x0001726D
		private void repositoryItemEdit_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			this.OnGridCommandEditClick(sender, (sender as ButtonEdit).Parent, e);
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x00019084 File Offset: 0x00017284
		private void repositoryItemEditAndDelete_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			Control parent = (sender as ButtonEdit).Parent;
			if (parent is TreeList)
			{
				if (e.Button.Index == 0)
				{
					this.OnTreeListCommandEditClick(sender, parent, e);
					return;
				}
				if (e.Button.Index == 1)
				{
					this.OnTreeListCommandDeleteClick(sender, parent, e);
					return;
				}
			}
			else
			{
				if (e.Button.Index == 0)
				{
					this.OnGridCommandEditClick(sender, parent, e);
					return;
				}
				if (e.Button.Index == 1)
				{
					this.OnGridCommandDeleteClick(sender, parent, e);
				}
			}
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x00019102 File Offset: 0x00017302
		private void RibbonFormBase_FormClosing(object sender, FormClosingEventArgs e)
		{
			FormsSettings formsSettings = this._formsSettings;
			if (formsSettings == null)
			{
				return;
			}
			formsSettings.SaveObjectsState(base.Name, this._objectsToSaveState);
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x00019120 File Offset: 0x00017320
		private void RibbonFormBase_Load(object sender, EventArgs e)
		{
			FormsSettings formsSettings = this._formsSettings;
			if (formsSettings != null)
			{
				formsSettings.RestoreObjectsState(base.Name, this._objectsToSaveState);
			}
			this.SetDefaultComponentOptions();
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x00019148 File Offset: 0x00017348
		private void SetDefaultComponentOptions()
		{
			List<Control> controls = new List<Control>();
			ControlsExtensions.GetControls(base.Controls, controls);
			foreach (Control control in controls)
			{
				RibbonControl ribbon = control as RibbonControl;
				if (ribbon != null && ribbon.ShowDisplayOptionsMenuButton == DefaultBoolean.Default)
				{
					ribbon.ShowDisplayOptionsMenuButton = DefaultBoolean.False;
				}
			}
		}

		// Token: 0x04000224 RID: 548
		protected readonly IFormCreator _formCreator;

		// Token: 0x04000225 RID: 549
		protected readonly FormsSettings _formsSettings;

		// Token: 0x04000226 RID: 550
		protected List<object> _objectsToSaveState;
	}
}
