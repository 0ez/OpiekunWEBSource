﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006D RID: 109
	public partial class DeviceGroupSelectionForm : BaseForm
	{
		// Token: 0x060005D8 RID: 1496 RVA: 0x00027B70 File Offset: 0x00025D70
		public DeviceGroupSelectionForm(FormsSettings formsSettings, IFormCreator formCreator, DevicesTree devicesTree, DeviceGroupSelectionFormParams @params) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this._params = @params;
			this.InitializeComponent();
			this._groups = devicesTree.GetGroups();
			this.treeListLookUpGroups.Properties.DataSource = this._groups;
			this.treeListLookUpGroupsTreeList.ExpandAll();
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x00027BC4 File Offset: 0x00025DC4
		private void buttonOk_Click(object sender, EventArgs e)
		{
			DevicesGroupItem group = this.treeListLookUpGroups.GetSelectedDataRow() as DevicesGroupItem;
			if (group == null)
			{
				this._formCreator.ShowError(Resources.DeviceGroupSelectionForm_SelectGroup);
				return;
			}
			this._params.SelectedGroup = group;
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x04000355 RID: 853
		private readonly List<DevicesGroupItem> _groups;

		// Token: 0x04000356 RID: 854
		private readonly DeviceGroupSelectionFormParams _params;
	}
}
