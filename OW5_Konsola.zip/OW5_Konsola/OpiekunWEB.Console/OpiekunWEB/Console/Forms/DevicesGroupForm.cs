﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraLayout;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Nodes;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000082 RID: 130
	public partial class DevicesGroupForm : CRUDBaseForm
	{
		// Token: 0x060006F2 RID: 1778 RVA: 0x0003C928 File Offset: 0x0003AB28
		public DevicesGroupForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, DeviceTreeItemBase deviceTreeItem, DevicesTree devicesTree) : base(formsSettings, formCreator, action, apiClient)
		{
			this._deviceTreeItem = deviceTreeItem;
			this.InitializeComponent();
			if (action == FormAction.Update)
			{
				this.textEditGroupName.Text = deviceTreeItem.Name;
			}
			string groupIdToSelect = this._deviceTreeItem.ParentId;
			if (action == FormAction.Create)
			{
				DeviceTreeItemBase item = devicesTree.FocusedItem;
				if (item != null && !item.IsGroup)
				{
					item = devicesTree.FindItemParentGroup(devicesTree.FocusedItem);
				}
				groupIdToSelect = ((item == null) ? devicesTree.RootGroupId : ((item != null) ? item.Id : null));
			}
			this.treeListLookUpEditParentGroupName.Properties.DataSource = this._apiClient.DevicesGroups;
			TreeListNode treeItem = this.treeListLookUpGroupsTreeList.FindNodeByKeyID(groupIdToSelect);
			this.treeListLookUpEditParentGroupName.EditValue = this.treeListLookUpGroupsTreeList.GetDataRecordByNode(treeItem);
			this.treeListLookUpEditParentGroupName.Enabled = (this._deviceTreeItem.Id != devicesTree.RootGroupId);
		}

		// Token: 0x060006F3 RID: 1779 RVA: 0x0003CA10 File Offset: 0x0003AC10
		protected string GetSelectedGroupId()
		{
			DevicesGroup group = this.treeListLookUpEditParentGroupName.GetSelectedDataRow() as DevicesGroup;
			if (group == null)
			{
				return "";
			}
			return group.Id;
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x0003CA3D File Offset: 0x0003AC3D
		protected override bool IsDataUpdated()
		{
			return this._deviceTreeItem.Name != this.textEditGroupName.Text || this._deviceTreeItem.ParentId != this.GetSelectedGroupId();
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x0003CA74 File Offset: 0x0003AC74
		protected override Task<bool> OnActionCreate()
		{
			DevicesGroupForm.<OnActionCreate>d__4 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<DevicesGroupForm.<OnActionCreate>d__4>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x0003CAB8 File Offset: 0x0003ACB8
		protected override Task<bool> OnActionUpdate()
		{
			DevicesGroupForm.<OnActionUpdate>d__5 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<DevicesGroupForm.<OnActionUpdate>d__5>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x040004E8 RID: 1256
		private readonly DeviceTreeItemBase _deviceTreeItem;
	}
}
