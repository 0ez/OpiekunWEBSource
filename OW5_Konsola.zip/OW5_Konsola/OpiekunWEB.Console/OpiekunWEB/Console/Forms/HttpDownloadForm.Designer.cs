﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000066 RID: 102
	public partial class HttpDownloadForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600055C RID: 1372 RVA: 0x0002120B File Offset: 0x0001F40B
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600055D RID: 1373 RVA: 0x0002122C File Offset: 0x0001F42C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.HttpDownloadForm));
			this.progresBarDownload = new global::DevExpress.XtraEditors.ProgressBarControl();
			this.buttonCancel = new global::DevExpress.XtraEditors.SimpleButton();
			this.labelInfo = new global::DevExpress.XtraEditors.LabelControl();
			this.labelProgress = new global::DevExpress.XtraEditors.LabelControl();
			((global::System.ComponentModel.ISupportInitialize)this.progresBarDownload.Properties).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.progresBarDownload, "progresBarDownload");
			this.progresBarDownload.Name = "progresBarDownload";
			this.progresBarDownload.Properties.ShowTitle = true;
			this.progresBarDownload.Properties.Step = 1;
			this.buttonCancel.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Click += new global::System.EventHandler(this.buttonCancel_Click);
			this.labelInfo.Appearance.Font = (global::System.Drawing.Font)resources.GetObject("labelInfo.Appearance.Font");
			this.labelInfo.Appearance.Options.UseFont = true;
			resources.ApplyResources(this.labelInfo, "labelInfo");
			this.labelInfo.Name = "labelInfo";
			resources.ApplyResources(this.labelProgress, "labelProgress");
			this.labelProgress.Name = "labelProgress";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.buttonCancel;
			base.Controls.Add(this.labelProgress);
			base.Controls.Add(this.labelInfo);
			base.Controls.Add(this.buttonCancel);
			base.Controls.Add(this.progresBarDownload);
			base.Name = "HttpDownloadForm";
			base.Load += new global::System.EventHandler(this.HttpDownloadForm_Load);
			((global::System.ComponentModel.ISupportInitialize)this.progresBarDownload.Properties).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040002BE RID: 702
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002BF RID: 703
		private global::DevExpress.XtraEditors.ProgressBarControl progresBarDownload;

		// Token: 0x040002C0 RID: 704
		private global::DevExpress.XtraEditors.SimpleButton buttonCancel;

		// Token: 0x040002C1 RID: 705
		private global::DevExpress.XtraEditors.LabelControl labelInfo;

		// Token: 0x040002C2 RID: 706
		private global::DevExpress.XtraEditors.LabelControl labelProgress;
	}
}
