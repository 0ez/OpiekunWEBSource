﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000078 RID: 120
	public partial class SelectCustomerForm : BaseForm
	{
		// Token: 0x0600064E RID: 1614 RVA: 0x00031FA4 File Offset: 0x000301A4
		public SelectCustomerForm(SelectCustomerFormParams @params)
		{
			this.InitializeComponent();
			this._params = @params;
			this.gridCustomers.DataSource = @params.CustomerNameAndIds;
		}

		// Token: 0x0600064F RID: 1615 RVA: 0x00031FCC File Offset: 0x000301CC
		private void buttonOk_Click(object sender, EventArgs e)
		{
			CustomerNameAndId focusedRow = this.gridViewCustomers.GetFocusedRow() as CustomerNameAndId;
			if (focusedRow != null)
			{
				this._params.CustomerId = focusedRow.CustomerId;
				base.DialogResult = DialogResult.OK;
			}
		}

		// Token: 0x06000650 RID: 1616 RVA: 0x00032005 File Offset: 0x00030205
		private void gridViewCustomers_DoubleClick(object sender, EventArgs e)
		{
			this.buttonOk.PerformClick();
		}

		// Token: 0x04000400 RID: 1024
		public SelectCustomerFormParams _params;
	}
}
