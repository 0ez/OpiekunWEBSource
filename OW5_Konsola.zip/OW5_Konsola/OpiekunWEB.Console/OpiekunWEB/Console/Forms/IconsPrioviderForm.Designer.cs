﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006E RID: 110
	public partial class IconsPrioviderForm : global::System.Windows.Forms.Form, global::OpiekunWEB.Console.Interfaces.IIconsProvider
	{
		// Token: 0x060005E3 RID: 1507 RVA: 0x00027FEB File Offset: 0x000261EB
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0002800C File Offset: 0x0002620C
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.IconsPrioviderForm));
			this.imagesDevicesTree24x24 = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imagesInetControlState16x16 = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imagesAppCategoryType16x16 = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imagesConnectionType16x16 = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imagesConnectionType24x24 = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imagesAppControlState16x16 = new global::DevExpress.Utils.ImageCollection(this.components);
			((global::System.ComponentModel.ISupportInitialize)this.imagesDevicesTree24x24).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesInetControlState16x16).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesAppCategoryType16x16).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesConnectionType16x16).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesConnectionType24x24).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesAppControlState16x16).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.imagesDevicesTree24x24, "imagesDevicesTree24x24");
			this.imagesDevicesTree24x24.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesDevicesTree24x24.ImageStream");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_desktop_off_24x24, "device_desktop_off_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesDevicesTree24x24.Images.SetKeyName(0, "device_desktop_off_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_desktop_on_24x24, "device_desktop_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesDevicesTree24x24.Images.SetKeyName(1, "device_desktop_on_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_server_off_24x24, "device_server_off_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 2);
			this.imagesDevicesTree24x24.Images.SetKeyName(2, "device_server_off_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_server_on_24x24, "device_server_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 3);
			this.imagesDevicesTree24x24.Images.SetKeyName(3, "device_server_on_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_terminal_off_24x24, "device_terminal_off_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 4);
			this.imagesDevicesTree24x24.Images.SetKeyName(4, "device_terminal_off_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_terminal_on_24x24, "device_terminal_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 5);
			this.imagesDevicesTree24x24.Images.SetKeyName(5, "device_terminal_on_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.user_off_24x24, "user_off_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 6);
			this.imagesDevicesTree24x24.Images.SetKeyName(6, "user_off_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.user_on_24x24, "user_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 7);
			this.imagesDevicesTree24x24.Images.SetKeyName(7, "user_on_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.devices_group_off_24x24, "devices_group_off_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 8);
			this.imagesDevicesTree24x24.Images.SetKeyName(8, "devices_group_off_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.devices_group_on_24x24, "devices_group_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 9);
			this.imagesDevicesTree24x24.Images.SetKeyName(9, "devices_group_on_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_none_24x24, "access_none_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 10);
			this.imagesDevicesTree24x24.Images.SetKeyName(10, "access_none_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_multi_24x24, "access_multi_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 11);
			this.imagesDevicesTree24x24.Images.SetKeyName(11, "access_multi_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_check_24x24, "access_check_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 12);
			this.imagesDevicesTree24x24.Images.SetKeyName(12, "access_check_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_block_24x24, "access_block_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 13);
			this.imagesDevicesTree24x24.Images.SetKeyName(13, "access_block_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_allow_24x24, "access_allow_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 14);
			this.imagesDevicesTree24x24.Images.SetKeyName(14, "access_allow_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_strict_24x24, "access_strict_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 15);
			this.imagesDevicesTree24x24.Images.SetKeyName(15, "access_strict_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_display_on_24x24, "device_display_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 16);
			this.imagesDevicesTree24x24.Images.SetKeyName(16, "device_display_on_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.computer_access_all_24x24, "computer_access_all_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 17);
			this.imagesDevicesTree24x24.Images.SetKeyName(17, "computer_access_all_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.computer_access_deny_key_24x24, "computer_access_deny_key_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 18);
			this.imagesDevicesTree24x24.Images.SetKeyName(18, "computer_access_deny_key_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.computer_access_deny_all_24x24, "computer_access_deny_all_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 19);
			this.imagesDevicesTree24x24.Images.SetKeyName(19, "computer_access_deny_all_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_check_24x24, "app_access_check_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 20);
			this.imagesDevicesTree24x24.Images.SetKeyName(20, "app_access_check_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_allow_24x24, "app_access_allow_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 21);
			this.imagesDevicesTree24x24.Images.SetKeyName(21, "app_access_allow_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_blocked_24x24, "app_access_blocked_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 22);
			this.imagesDevicesTree24x24.Images.SetKeyName(22, "app_access_blocked_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_strict_24x24, "app_access_strict_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 23);
			this.imagesDevicesTree24x24.Images.SetKeyName(23, "app_access_strict_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_check_whitelist_24x24, "app_access_check_whitelist_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 24);
			this.imagesDevicesTree24x24.Images.SetKeyName(24, "app_access_check_whitelist_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_check_blacklist_24x24, "app_access_check_blacklist_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 25);
			this.imagesDevicesTree24x24.Images.SetKeyName(25, "app_access_check_blacklist_24x24");
			this.imagesDevicesTree24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.connection_proxy_24x24, "connection_proxy_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 26);
			this.imagesDevicesTree24x24.Images.SetKeyName(26, "connection_proxy_24x24");
			this.imagesInetControlState16x16.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesInetControlState16x16.ImageStream");
			this.imagesInetControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_check_16x16, "access_check_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesInetControlState16x16.Images.SetKeyName(0, "access_check_16x16");
			this.imagesInetControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_block_16x16, "access_block_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesInetControlState16x16.Images.SetKeyName(1, "access_block_16x16");
			this.imagesInetControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_allow_16x16, "access_allow_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 2);
			this.imagesInetControlState16x16.Images.SetKeyName(2, "access_allow_16x16");
			this.imagesInetControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.depend_on_user_16x16, "depend_on_user_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 3);
			this.imagesInetControlState16x16.Images.SetKeyName(3, "depend_on_user_16x16");
			this.imagesInetControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_strict_16x16, "access_strict_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 4);
			this.imagesInetControlState16x16.Images.SetKeyName(4, "access_strict_16x16");
			this.imagesAppCategoryType16x16.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesAppCategoryType16x16.ImageStream");
			this.imagesAppCategoryType16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_check_blacklist_24x24, "app_access_check_blacklist_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesAppCategoryType16x16.Images.SetKeyName(0, "app_access_check_blacklist_24x24");
			this.imagesAppCategoryType16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_check_whitelist_24x24, "app_access_check_whitelist_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesAppCategoryType16x16.Images.SetKeyName(1, "app_access_check_whitelist_24x24");
			this.imagesConnectionType16x16.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesConnectionType16x16.ImageStream");
			this.imagesConnectionType16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.connection_proxy_16x16, "connection_proxy_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesConnectionType16x16.Images.SetKeyName(0, "connection_proxy_16x16");
			this.imagesConnectionType16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.connection_rdp_16x16, "connection_rdp_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesConnectionType16x16.Images.SetKeyName(1, "connection_rdp_16x16");
			resources.ApplyResources(this.imagesConnectionType24x24, "imagesConnectionType24x24");
			this.imagesConnectionType24x24.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesConnectionType24x24.ImageStream");
			this.imagesConnectionType24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.connection_proxy_24x24, "connection_proxy_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesConnectionType24x24.Images.SetKeyName(0, "connection_proxy_24x24");
			this.imagesConnectionType24x24.InsertImage(global::OpiekunWEB.Console.Properties.Resources.connection_rdp_24x24, "connection_rdp_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesConnectionType24x24.Images.SetKeyName(1, "connection_rdp_24x24");
			this.imagesAppControlState16x16.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesAppControlState16x16.ImageStream");
			this.imagesAppControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.depend_on_user_16x16, "depend_on_user_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesAppControlState16x16.Images.SetKeyName(0, "depend_on_user_16x16");
			this.imagesAppControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_blocked_16x16, "app_access_blocked_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesAppControlState16x16.Images.SetKeyName(1, "app_access_blocked_16x16");
			this.imagesAppControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_allow_16x16, "app_access_allow_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 2);
			this.imagesAppControlState16x16.Images.SetKeyName(2, "app_access_allow_16x16");
			this.imagesAppControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.spacer_16x16, "spacer_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 3);
			this.imagesAppControlState16x16.Images.SetKeyName(3, "spacer_16x16");
			this.imagesAppControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_strict_16x16, "app_access_strict_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 4);
			this.imagesAppControlState16x16.Images.SetKeyName(4, "app_access_strict_16x16");
			this.imagesAppControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_check_blacklist_24x24, "app_access_check_blacklist_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 5);
			this.imagesAppControlState16x16.Images.SetKeyName(5, "app_access_check_blacklist_24x24");
			this.imagesAppControlState16x16.InsertImage(global::OpiekunWEB.Console.Properties.Resources.app_access_check_whitelist_24x24, "app_access_check_whitelist_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 6);
			this.imagesAppControlState16x16.Images.SetKeyName(6, "app_access_check_whitelist_24x24");
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Name = "IconsPrioviderForm";
			((global::System.ComponentModel.ISupportInitialize)this.imagesDevicesTree24x24).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesInetControlState16x16).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesAppCategoryType16x16).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesConnectionType16x16).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesConnectionType24x24).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesAppControlState16x16).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400035D RID: 861
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400035E RID: 862
		private global::DevExpress.Utils.ImageCollection imagesDevicesTree24x24;

		// Token: 0x0400035F RID: 863
		private global::DevExpress.Utils.ImageCollection imagesInetControlState16x16;

		// Token: 0x04000360 RID: 864
		private global::DevExpress.Utils.ImageCollection imagesAppCategoryType16x16;

		// Token: 0x04000361 RID: 865
		private global::DevExpress.Utils.ImageCollection imagesConnectionType16x16;

		// Token: 0x04000362 RID: 866
		private global::DevExpress.Utils.ImageCollection imagesConnectionType24x24;

		// Token: 0x04000363 RID: 867
		protected global::DevExpress.Utils.ImageCollection imagesAppControlState16x16;
	}
}
