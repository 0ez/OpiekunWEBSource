﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000063 RID: 99
	public partial class DeviceForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x0600053B RID: 1339 RVA: 0x0001DE9F File Offset: 0x0001C09F
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x0001DEC0 File Offset: 0x0001C0C0
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DeviceForm));
			global::DevExpress.XtraGrid.GridLevelNode gridLevelNode = new global::DevExpress.XtraGrid.GridLevelNode();
			this.imageCollectionDeviceTypes = new global::DevExpress.Utils.ImageCollection(this.components);
			this.xtraTabControlMain = new global::DevExpress.XtraTab.XtraTabControl();
			this.xtraTabPageDeviceInfo = new global::DevExpress.XtraTab.XtraTabPage();
			this.layoutControlDeviceInfo = new global::DevExpress.XtraLayout.LayoutControl();
			this.textEditDeviceDescription = new global::DevExpress.XtraEditors.TextEdit();
			this.imageComboBoxDeviceType = new global::DevExpress.XtraEditors.ImageComboBoxEdit();
			this.treeListLookUpDeviceGroup = new global::DevExpress.XtraEditors.TreeListLookUpEdit();
			this.treeListLookUpGroupsTreeList = new global::DevExpress.XtraTreeList.TreeList();
			this.textEditDeviceName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupDeviceInfo = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlItemDeviceName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlItemDeviceGroup = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemDeviceType = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemDeviceDescription = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.xtraTabPageMacList = new global::DevExpress.XtraTab.XtraTabPage();
			this.gridMacs = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewMacs = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnMacAddres = new global::DevExpress.XtraGrid.Columns.GridColumn();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionDeviceTypes).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControlMain).BeginInit();
			this.xtraTabControlMain.SuspendLayout();
			this.xtraTabPageDeviceInfo.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDeviceInfo).BeginInit();
			this.layoutControlDeviceInfo.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDeviceDescription.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxDeviceType.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpDeviceGroup.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDeviceName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupDeviceInfo).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceGroup).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceType).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceDescription).BeginInit();
			this.xtraTabPageMacList.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridMacs).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewMacs).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			resources.ApplyResources(this.imageCollectionDeviceTypes, "imageCollectionDeviceTypes");
			this.imageCollectionDeviceTypes.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imageCollectionDeviceTypes.ImageStream");
			this.imageCollectionDeviceTypes.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_unknown_on_24x24, "device_unknown_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imageCollectionDeviceTypes.Images.SetKeyName(0, "device_unknown_on_24x24");
			this.imageCollectionDeviceTypes.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_desktop_on_24x24, "device_desktop_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imageCollectionDeviceTypes.Images.SetKeyName(1, "device_desktop_on_24x24");
			this.imageCollectionDeviceTypes.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_server_on_24x24, "device_server_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 2);
			this.imageCollectionDeviceTypes.Images.SetKeyName(2, "device_server_on_24x24");
			this.imageCollectionDeviceTypes.InsertImage(global::OpiekunWEB.Console.Properties.Resources.device_terminal_on_24x24, "device_terminal_on_24x24", typeof(global::OpiekunWEB.Console.Properties.Resources), 3);
			this.imageCollectionDeviceTypes.Images.SetKeyName(3, "device_terminal_on_24x24");
			resources.ApplyResources(this.xtraTabControlMain, "xtraTabControlMain");
			this.xtraTabControlMain.Name = "xtraTabControlMain";
			this.xtraTabControlMain.SelectedTabPage = this.xtraTabPageDeviceInfo;
			this.xtraTabControlMain.TabPages.AddRange(new global::DevExpress.XtraTab.XtraTabPage[]
			{
				this.xtraTabPageDeviceInfo,
				this.xtraTabPageMacList
			});
			this.xtraTabPageDeviceInfo.Controls.Add(this.layoutControlDeviceInfo);
			resources.ApplyResources(this.xtraTabPageDeviceInfo, "xtraTabPageDeviceInfo");
			this.xtraTabPageDeviceInfo.Name = "xtraTabPageDeviceInfo";
			this.layoutControlDeviceInfo.Controls.Add(this.textEditDeviceDescription);
			this.layoutControlDeviceInfo.Controls.Add(this.imageComboBoxDeviceType);
			this.layoutControlDeviceInfo.Controls.Add(this.treeListLookUpDeviceGroup);
			this.layoutControlDeviceInfo.Controls.Add(this.textEditDeviceName);
			resources.ApplyResources(this.layoutControlDeviceInfo, "layoutControlDeviceInfo");
			this.layoutControlDeviceInfo.Name = "layoutControlDeviceInfo";
			this.layoutControlDeviceInfo.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2551, 194, 812, 500));
			this.layoutControlDeviceInfo.Root = this.layoutControlGroupDeviceInfo;
			resources.ApplyResources(this.textEditDeviceDescription, "textEditDeviceDescription");
			this.textEditDeviceDescription.Name = "textEditDeviceDescription";
			this.textEditDeviceDescription.StyleController = this.layoutControlDeviceInfo;
			resources.ApplyResources(this.imageComboBoxDeviceType, "imageComboBoxDeviceType");
			this.imageComboBoxDeviceType.Name = "imageComboBoxDeviceType";
			this.imageComboBoxDeviceType.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxDeviceType.Properties.Buttons"))
			});
			this.imageComboBoxDeviceType.Properties.ReadOnly = true;
			this.imageComboBoxDeviceType.Properties.SmallImages = this.imageCollectionDeviceTypes;
			this.imageComboBoxDeviceType.Properties.UseReadOnlyAppearance = false;
			this.imageComboBoxDeviceType.StyleController = this.layoutControlDeviceInfo;
			resources.ApplyResources(this.treeListLookUpDeviceGroup, "treeListLookUpDeviceGroup");
			this.treeListLookUpDeviceGroup.Name = "treeListLookUpDeviceGroup";
			this.treeListLookUpDeviceGroup.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("treeListLookUpDeviceGroup.Properties.Buttons"))
			});
			this.treeListLookUpDeviceGroup.Properties.DisplayMember = "Name";
			this.treeListLookUpDeviceGroup.Properties.NullText = resources.GetString("treeListLookUpDeviceGroup.Properties.NullText");
			this.treeListLookUpDeviceGroup.Properties.TreeList = this.treeListLookUpGroupsTreeList;
			this.treeListLookUpDeviceGroup.StyleController = this.layoutControlDeviceInfo;
			this.treeListLookUpGroupsTreeList.HorzScrollStep = 5;
			this.treeListLookUpGroupsTreeList.KeyFieldName = "Id";
			resources.ApplyResources(this.treeListLookUpGroupsTreeList, "treeListLookUpGroupsTreeList");
			this.treeListLookUpGroupsTreeList.MinWidth = 31;
			this.treeListLookUpGroupsTreeList.Name = "treeListLookUpGroupsTreeList";
			this.treeListLookUpGroupsTreeList.OptionsView.ShowColumns = false;
			this.treeListLookUpGroupsTreeList.OptionsView.ShowIndentAsRowStyle = true;
			this.treeListLookUpGroupsTreeList.ParentFieldName = "ParentId";
			this.treeListLookUpGroupsTreeList.TreeLevelWidth = 27;
			resources.ApplyResources(this.textEditDeviceName, "textEditDeviceName");
			this.textEditDeviceName.Name = "textEditDeviceName";
			this.textEditDeviceName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditDeviceName.Properties.Mask.BeepOnError");
			this.textEditDeviceName.Properties.Mask.EditMask = resources.GetString("textEditDeviceName.Properties.Mask.EditMask");
			this.textEditDeviceName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditDeviceName.Properties.Mask.IgnoreMaskBlank");
			this.textEditDeviceName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditDeviceName.Properties.Mask.MaskType");
			this.textEditDeviceName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditDeviceName.Properties.Mask.ShowPlaceHolders");
			this.textEditDeviceName.StyleController = this.layoutControlDeviceInfo;
			this.layoutControlGroupDeviceInfo.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupDeviceInfo.GroupBordersVisible = false;
			this.layoutControlGroupDeviceInfo.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlItemDeviceName,
				this.emptySpaceItem1,
				this.layoutControlItemDeviceGroup,
				this.layoutControlItemDeviceType,
				this.layoutControlItemDeviceDescription
			});
			this.layoutControlGroupDeviceInfo.Name = "layoutControlGroupDeviceInfo";
			this.layoutControlGroupDeviceInfo.OptionsItemText.TextToControlDistance = 4;
			this.layoutControlGroupDeviceInfo.Size = new global::System.Drawing.Size(324, 333);
			this.layoutControlGroupDeviceInfo.TextVisible = false;
			this.layoutControlItemDeviceName.Control = this.textEditDeviceName;
			this.layoutControlItemDeviceName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlItemDeviceName.Name = "layoutControlItemDeviceName";
			this.layoutControlItemDeviceName.Size = new global::System.Drawing.Size(304, 46);
			resources.ApplyResources(this.layoutControlItemDeviceName, "layoutControlItemDeviceName");
			this.layoutControlItemDeviceName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemDeviceName.TextSize = new global::System.Drawing.Size(79, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 188);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(304, 125);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemDeviceGroup.Control = this.treeListLookUpDeviceGroup;
			this.layoutControlItemDeviceGroup.Location = new global::System.Drawing.Point(0, 46);
			this.layoutControlItemDeviceGroup.Name = "layoutControlItemDeviceGroup";
			this.layoutControlItemDeviceGroup.Size = new global::System.Drawing.Size(304, 46);
			resources.ApplyResources(this.layoutControlItemDeviceGroup, "layoutControlItemDeviceGroup");
			this.layoutControlItemDeviceGroup.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemDeviceGroup.TextSize = new global::System.Drawing.Size(79, 16);
			this.layoutControlItemDeviceType.Control = this.imageComboBoxDeviceType;
			this.layoutControlItemDeviceType.Location = new global::System.Drawing.Point(0, 92);
			this.layoutControlItemDeviceType.Name = "layoutControlItemDeviceType";
			this.layoutControlItemDeviceType.Size = new global::System.Drawing.Size(304, 50);
			resources.ApplyResources(this.layoutControlItemDeviceType, "layoutControlItemDeviceType");
			this.layoutControlItemDeviceType.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemDeviceType.TextSize = new global::System.Drawing.Size(79, 16);
			this.layoutControlItemDeviceDescription.Control = this.textEditDeviceDescription;
			this.layoutControlItemDeviceDescription.Location = new global::System.Drawing.Point(0, 142);
			this.layoutControlItemDeviceDescription.Name = "layoutControlItemDeviceDescription";
			this.layoutControlItemDeviceDescription.Size = new global::System.Drawing.Size(304, 46);
			resources.ApplyResources(this.layoutControlItemDeviceDescription, "layoutControlItemDeviceDescription");
			this.layoutControlItemDeviceDescription.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemDeviceDescription.TextSize = new global::System.Drawing.Size(79, 16);
			this.xtraTabPageMacList.Controls.Add(this.gridMacs);
			resources.ApplyResources(this.xtraTabPageMacList, "xtraTabPageMacList");
			this.xtraTabPageMacList.Name = "xtraTabPageMacList";
			resources.ApplyResources(this.gridMacs, "gridMacs");
			this.gridMacs.EmbeddedNavigator.Margin = (global::System.Windows.Forms.Padding)resources.GetObject("gridMacs.EmbeddedNavigator.Margin");
			gridLevelNode.RelationName = "Level1";
			this.gridMacs.LevelTree.Nodes.AddRange(new global::DevExpress.XtraGrid.GridLevelNode[]
			{
				gridLevelNode
			});
			this.gridMacs.MainView = this.gridViewMacs;
			this.gridMacs.Name = "gridMacs";
			this.gridMacs.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewMacs
			});
			this.gridViewMacs.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnMacAddres
			});
			this.gridViewMacs.DetailHeight = 546;
			this.gridViewMacs.GridControl = this.gridMacs;
			this.gridViewMacs.Name = "gridViewMacs";
			this.gridViewMacs.OptionsSelection.InvertSelection = true;
			this.gridViewMacs.OptionsView.ShowGroupPanel = false;
			resources.ApplyResources(this.gridColumnMacAddres, "gridColumnMacAddres");
			this.gridColumnMacAddres.FieldName = "Column";
			this.gridColumnMacAddres.MinWidth = 31;
			this.gridColumnMacAddres.Name = "gridColumnMacAddres";
			this.gridColumnMacAddres.OptionsColumn.ReadOnly = true;
			this.gridColumnMacAddres.OptionsColumn.ShowCaption = false;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.xtraTabControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("DeviceForm.IconOptions.Icon");
			base.Name = "DeviceForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.xtraTabControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionDeviceTypes).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControlMain).EndInit();
			this.xtraTabControlMain.ResumeLayout(false);
			this.xtraTabPageDeviceInfo.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDeviceInfo).EndInit();
			this.layoutControlDeviceInfo.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditDeviceDescription.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxDeviceType.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpDeviceGroup.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDeviceName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupDeviceInfo).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceGroup).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceType).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDeviceDescription).EndInit();
			this.xtraTabPageMacList.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridMacs).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewMacs).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000288 RID: 648
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000289 RID: 649
		protected global::DevExpress.Utils.ImageCollection imageCollectionDeviceTypes;

		// Token: 0x0400028A RID: 650
		private global::DevExpress.XtraTab.XtraTabControl xtraTabControlMain;

		// Token: 0x0400028B RID: 651
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPageDeviceInfo;

		// Token: 0x0400028C RID: 652
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPageMacList;

		// Token: 0x0400028D RID: 653
		private global::DevExpress.XtraLayout.LayoutControl layoutControlDeviceInfo;

		// Token: 0x0400028E RID: 654
		private global::DevExpress.XtraEditors.TextEdit textEditDeviceDescription;

		// Token: 0x0400028F RID: 655
		private global::DevExpress.XtraEditors.ImageComboBoxEdit imageComboBoxDeviceType;

		// Token: 0x04000290 RID: 656
		private global::DevExpress.XtraEditors.TreeListLookUpEdit treeListLookUpDeviceGroup;

		// Token: 0x04000291 RID: 657
		private global::DevExpress.XtraTreeList.TreeList treeListLookUpGroupsTreeList;

		// Token: 0x04000292 RID: 658
		private global::DevExpress.XtraEditors.TextEdit textEditDeviceName;

		// Token: 0x04000293 RID: 659
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupDeviceInfo;

		// Token: 0x04000294 RID: 660
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemDeviceName;

		// Token: 0x04000295 RID: 661
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x04000296 RID: 662
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemDeviceGroup;

		// Token: 0x04000297 RID: 663
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemDeviceType;

		// Token: 0x04000298 RID: 664
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemDeviceDescription;

		// Token: 0x04000299 RID: 665
		private global::DevExpress.XtraGrid.GridControl gridMacs;

		// Token: 0x0400029A RID: 666
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewMacs;

		// Token: 0x0400029B RID: 667
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnMacAddres;
	}
}
