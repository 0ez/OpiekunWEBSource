﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000075 RID: 117
	public partial class ShowMessageDefForm : CRUDBaseForm
	{
		// Token: 0x0600061F RID: 1567 RVA: 0x0002DE7F File Offset: 0x0002C07F
		public ShowMessageDefForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x0002DE90 File Offset: 0x0002C090
		public ShowMessageDefForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, ShowMessageDefFormParams @params) : base(formsSettings, formCreator, action, apiClient)
		{
			this.InitializeComponent();
			this._params = @params;
			if (action == FormAction.Unknown)
			{
				this.Text = Resources.ShowMessageDefForm_SendMssageTitle;
				this.textEditDisplayName.Enabled = false;
				this.checkIsFavorite.Enabled = false;
				this.checkEditAvailableForAll.Enabled = false;
			}
			else
			{
				this.checkEditAvailableForAll.Enabled = this._apiClient.IsLoggedUserHasAdminPermission();
			}
			this._showMessageModesList = this.GetShowMessageModesList();
			this.comboBoxShowMode.Properties.Items.AddRange(this._showMessageModesList);
			this.InitData();
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x0002DF2D File Offset: 0x0002C12D
		protected override bool IsDataUpdated()
		{
			return this.GetShowMessageDef().ToString() != this._params.ShowMessageDef.ToString();
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x0002DF50 File Offset: 0x0002C150
		protected override bool IsDataValid()
		{
			if (!this.textEditDisplayName.DoValidate())
			{
				return false;
			}
			if (this.memoEditMessage.Text.Trim().Length == 0)
			{
				this.memoEditMessage.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
				return false;
			}
			return true;
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x0002DF9C File Offset: 0x0002C19C
		protected override Task<bool> OnActionCreate()
		{
			ShowMessageDefForm.<OnActionCreate>d__6 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<ShowMessageDefForm.<OnActionCreate>d__6>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x0002DFDF File Offset: 0x0002C1DF
		protected override Task<bool> OnActionUnknown()
		{
			if (!this.IsDataValid())
			{
				return Task.FromResult<bool>(false);
			}
			this._params.ShowMessageDef = this.GetShowMessageDef();
			return Task.FromResult<bool>(true);
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x0002E008 File Offset: 0x0002C208
		protected override Task<bool> OnActionUpdate()
		{
			ShowMessageDefForm.<OnActionUpdate>d__8 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<ShowMessageDefForm.<OnActionUpdate>d__8>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x0002E04C File Offset: 0x0002C24C
		private void comboBoxShowMode_SelectedIndexChanged(object sender, EventArgs e)
		{
			ShowMessageMode showMessageMode = this.GetSelectedShowMessageMode();
			this.spinEditTime.Enabled = (showMessageMode == ShowMessageMode.MessageAutoCloseAfterTime || showMessageMode == ShowMessageMode.MessageNeedConfirmationAfterTime);
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0002E076 File Offset: 0x0002C276
		private ShowMessageMode GetSelectedShowMessageMode()
		{
			return (ShowMessageMode)((KeyAndValue<int, string>)this.comboBoxShowMode.SelectedItem).Key;
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x0002E090 File Offset: 0x0002C290
		private ShowMessageDef GetShowMessageDef()
		{
			ShowMessageDef result = new ShowMessageDef
			{
				DisplayName = this.textEditDisplayName.Text,
				IsFavorite = this.checkIsFavorite.Checked,
				AgentRequest = new ShowMessageRequest
				{
					Message = this.memoEditMessage.Text,
					IconNo = (uint)this.imageComboBoxIconNo.SelectedIndex,
					Time = decimal.ToUInt32((decimal)this.spinEditTime.EditValue) * 1000U,
					ShowMode = this.GetSelectedShowMessageMode()
				}
			};
			if (this.checkEditAvailableForAll.Checked)
			{
				result.AvailableForUsers.Add("*");
			}
			else
			{
				result.AvailableForUsers.Add(this._apiClient.UserId);
			}
			return result;
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x0002E158 File Offset: 0x0002C358
		private List<KeyAndValue<int, string>> GetShowMessageModesList()
		{
			return new List<KeyAndValue<int, string>>
			{
				new KeyAndValue<int, string>(0, SsStringUtils.GetEnumDescriptionFromResource<ShowMessageMode>(ShowMessageMode.MessageShowNormal, null, null)),
				new KeyAndValue<int, string>(1, SsStringUtils.GetEnumDescriptionFromResource<ShowMessageMode>(ShowMessageMode.MessageNeedConfirmation, null, null)),
				new KeyAndValue<int, string>(2, SsStringUtils.GetEnumDescriptionFromResource<ShowMessageMode>(ShowMessageMode.MessageAutoCloseAfterTime, null, null)),
				new KeyAndValue<int, string>(3, SsStringUtils.GetEnumDescriptionFromResource<ShowMessageMode>(ShowMessageMode.MessageNeedConfirmationAfterTime, null, null))
			};
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x0002E1BC File Offset: 0x0002C3BC
		private void InitData()
		{
			if (base.Action != FormAction.Create)
			{
				this.textEditDisplayName.Text = this._params.ShowMessageDef.DisplayName;
				this.checkIsFavorite.Checked = this._params.ShowMessageDef.IsFavorite;
				this.memoEditMessage.Text = this._params.ShowMessageDef.AgentRequest.Message;
				this.imageComboBoxIconNo.SelectedIndex = (int)this._params.ShowMessageDef.AgentRequest.IconNo;
				this.spinEditTime.EditValue = this._params.ShowMessageDef.AgentRequest.Time / 1000U;
				this.comboBoxShowMode.SelectedItem = this._showMessageModesList.FirstOrDefault((KeyAndValue<int, string> x) => x.Key == (int)this._params.ShowMessageDef.AgentRequest.ShowMode);
				this.checkEditAvailableForAll.Checked = this._params.ShowMessageDef.AvailableForUsers.Contains("*");
				return;
			}
			this.imageComboBoxIconNo.SelectedIndex = 0;
			this.comboBoxShowMode.SelectedIndex = 0;
		}

		// Token: 0x040003BC RID: 956
		private ShowMessageDefFormParams _params;

		// Token: 0x040003BD RID: 957
		private List<KeyAndValue<int, string>> _showMessageModesList;
	}
}
