﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.Utils.Serializing;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using Newtonsoft.Json;
using OpiekunWEB.Console.Helpers;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005B RID: 91
	public class FormsSettings
	{
		// Token: 0x060004D3 RID: 1235 RVA: 0x00018328 File Offset: 0x00016528
		public FormsSettings(string appDataDir, string usersDataDir)
		{
			this._appDataDir = appDataDir;
			this._usersDataDir = usersDataDir;
			this.AppIniFile = new IniFile(this._appDataDir + "settings.ini", "app");
			this.SetUserLogin("nouser", "0");
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x00018379 File Offset: 0x00016579
		public IniFile AppIniFile { get; }

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x060004D5 RID: 1237 RVA: 0x00018381 File Offset: 0x00016581
		public string UserCustomerDataDir
		{
			get
			{
				return this._currentUserAndCustomerDir;
			}
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x060004D6 RID: 1238 RVA: 0x00018389 File Offset: 0x00016589
		public string UserDataDir
		{
			get
			{
				return this._currentUserDataDir;
			}
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x060004D7 RID: 1239 RVA: 0x00018391 File Offset: 0x00016591
		// (set) Token: 0x060004D8 RID: 1240 RVA: 0x00018399 File Offset: 0x00016599
		public IniFile UserIniFile { get; private set; }

		// Token: 0x060004D9 RID: 1241 RVA: 0x000183A4 File Offset: 0x000165A4
		public void RestoreFormState(XtraForm form)
		{
			if (this.UserIniFile.ReadBool(form.Name, "IsMaximized", false))
			{
				form.WindowState = FormWindowState.Maximized;
				return;
			}
			form.Location = new Point(this.UserIniFile.ReadInt(form.Name, "X", form.Location.X), this.UserIniFile.ReadInt(form.Name, "Y", form.Location.Y));
			form.Size = new Size(this.UserIniFile.ReadInt(form.Name, "Width", form.Size.Width), this.UserIniFile.ReadInt(form.Name, "Height", form.Size.Height));
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x00018478 File Offset: 0x00016678
		public void RestoreObjectsState(string formName, List<object> objects)
		{
			if (objects != null)
			{
				foreach (object obj in objects)
				{
					this.RestoreObjectState(formName, obj, null);
				}
			}
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x000184CC File Offset: 0x000166CC
		public void RestoreObjectState(string formName, object control, object defaultValue = null)
		{
			GridView gridView = control as GridView;
			if (gridView != null)
			{
				this.RestoreGridViewState(gridView);
				return;
			}
			TreeList treeList = control as TreeList;
			if (treeList != null)
			{
				this.RestoreTreeListState(treeList);
				return;
			}
			ISupportXtraSerializer serializer = control as ISupportXtraSerializer;
			if (serializer != null)
			{
				this.RestoreXtraControlLayout(serializer);
				return;
			}
			BarEditItem barEditItem = control as BarEditItem;
			if (barEditItem != null)
			{
				this.RestoreBarEditItemState(formName, barEditItem);
				return;
			}
			BarCheckItem barCheckItem = control as BarCheckItem;
			if (barCheckItem != null)
			{
				this.RestoreBarCheckItemState(formName, barCheckItem);
				return;
			}
			ComboBoxEdit comboBoxEdit = control as ComboBoxEdit;
			if (comboBoxEdit != null)
			{
				this.RestoreComboBoxEditState(formName, comboBoxEdit);
				return;
			}
			TextEdit editItem = control as TextEdit;
			if (editItem != null)
			{
				editItem.Text = this.UserIniFile.ReadString(formName, editItem.Name, editItem.Text);
				return;
			}
			CheckEdit checkItem = control as CheckEdit;
			if (checkItem != null)
			{
				checkItem.Checked = this.UserIniFile.ReadBool(formName, checkItem.Name, false);
				return;
			}
			XtraForm xtraForm = control as XtraForm;
			if (xtraForm != null)
			{
				this.RestoreFormState(xtraForm);
			}
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x000185B8 File Offset: 0x000167B8
		public T RestoreObjectStateFromJson<T>(string formName, string itemName, T defaultValue)
		{
			try
			{
				string json = this.UserIniFile.ReadString(formName, itemName, string.Empty);
				if (!string.IsNullOrEmpty(json))
				{
					return JsonConvert.DeserializeObject<T>(json);
				}
			}
			catch (Exception)
			{
			}
			return defaultValue;
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x00018604 File Offset: 0x00016804
		public void RestoreTreeListState(TreeList treeList)
		{
			TreeListViewState treeListViewState = new TreeListViewState(treeList);
			string imageFieldName = treeList.ImageIndexFieldName;
			treeListViewState.LoadState(this._currentUserAndCustomerDir + this.GetXtraControlName(treeList) + ".state");
			List<FormsSettings.TreeListColumnInfo> columnsInfo = new List<FormsSettings.TreeListColumnInfo>();
			foreach (TreeListColumn column2 in treeList.Columns)
			{
				columnsInfo.Add(new FormsSettings.TreeListColumnInfo(column2));
			}
			try
			{
				treeList.RestoreLayoutFromXml(this._currentUserAndCustomerDir + this.GetXtraControlName(treeList), new OptionsLayoutTreeList
				{
					RemoveOldColumns = true
				});
			}
			catch (Exception)
			{
			}
			using (IEnumerator<TreeListColumn> enumerator = treeList.Columns.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					TreeListColumn column = enumerator.Current;
					FormsSettings.TreeListColumnInfo treeListColumnInfo = columnsInfo.Find((FormsSettings.TreeListColumnInfo x) => x.Name == column.Name);
					if (treeListColumnInfo != null)
					{
						treeListColumnInfo.RestroreColumn(column);
					}
				}
			}
			treeList.ImageIndexFieldName = imageFieldName;
		}

		// Token: 0x060004DE RID: 1246 RVA: 0x0001872C File Offset: 0x0001692C
		public void RestoreXtraControlLayout(ISupportXtraSerializer control)
		{
			try
			{
				string fileName = this._currentUserDataDir + this.GetXtraControlName(control);
				if (File.Exists(fileName))
				{
					control.RestoreLayoutFromXml(fileName);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x00018770 File Offset: 0x00016970
		public void SaveFormState(XtraForm form)
		{
			this.UserIniFile.WriteBool(form.Name, "IsMaximized", form.WindowState == FormWindowState.Maximized);
			if (form.WindowState != FormWindowState.Minimized)
			{
				this.UserIniFile.WriteInt(form.Name, "X", form.Location.X);
				this.UserIniFile.WriteInt(form.Name, "Y", form.Location.Y);
				this.UserIniFile.WriteInt(form.Name, "Width", form.Size.Width);
				this.UserIniFile.WriteInt(form.Name, "Height", form.Size.Height);
			}
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x00018838 File Offset: 0x00016A38
		public void SaveObjectsState(string formName, List<object> objects)
		{
			if (objects != null)
			{
				foreach (object obj in objects)
				{
					this.SaveObjectState(formName, obj);
				}
			}
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x0001888C File Offset: 0x00016A8C
		public void SaveObjectState(string formName, object control)
		{
			GridView gridView = control as GridView;
			if (gridView != null)
			{
				this.SaveGridViewState(gridView);
				return;
			}
			TreeList treeList = control as TreeList;
			if (treeList != null)
			{
				this.SaveTreeListState(treeList);
				return;
			}
			ISupportXtraSerializer serializer = control as ISupportXtraSerializer;
			if (serializer != null)
			{
				this.SaveXtraControlLayout(serializer);
				return;
			}
			BarEditItem barEditItem = control as BarEditItem;
			if (barEditItem != null)
			{
				this.SaveBarEditItemState(formName, barEditItem);
				return;
			}
			BarCheckItem barCheckItem = control as BarCheckItem;
			if (barCheckItem != null)
			{
				this.UserIniFile.WriteBool(formName, barCheckItem.Name, barCheckItem.Checked);
				return;
			}
			ComboBoxEdit comboBoxEdit = control as ComboBoxEdit;
			if (comboBoxEdit != null)
			{
				this.SaveComboBoxEditState(formName, comboBoxEdit);
				return;
			}
			TextEdit editItem = control as TextEdit;
			if (editItem != null)
			{
				this.UserIniFile.WriteString(formName, editItem.Name, editItem.Text);
				return;
			}
			CheckEdit checkItem = control as CheckEdit;
			if (checkItem != null)
			{
				this.UserIniFile.WriteBool(formName, checkItem.Name, checkItem.Checked);
				return;
			}
			XtraForm xtraForm = control as XtraForm;
			if (xtraForm != null)
			{
				this.SaveFormState(xtraForm);
			}
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x00018984 File Offset: 0x00016B84
		public void SaveObjectStateAsJson(string formName, string itemName, object obj)
		{
			string json = JsonConvert.SerializeObject(obj);
			this.UserIniFile.WriteString(formName, itemName, json);
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x000189A8 File Offset: 0x00016BA8
		public void SaveTreeListState(TreeList treeList)
		{
			TreeListViewState treeListViewState = new TreeListViewState(treeList);
			string controlName = this.GetXtraControlName(treeList);
			treeListViewState.SaveState(this._currentUserAndCustomerDir + controlName + ".state");
			treeList.SaveLayoutToXml(this._currentUserAndCustomerDir + controlName);
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x000189EB File Offset: 0x00016BEB
		public void SaveXtraControlLayout(ISupportXtraSerializer control)
		{
			control.SaveLayoutToXml(this._currentUserDataDir + this.GetXtraControlName(control));
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x00018A08 File Offset: 0x00016C08
		public void SetUserLogin(string userLogin, string customerId)
		{
			this._currentUserDataDir = this._usersDataDir + userLogin + "\\";
			this.CreateDirIfNotExist(this._currentUserDataDir);
			this._currentUserAndCustomerDir = this._currentUserDataDir + customerId + "\\";
			this.CreateDirIfNotExist(this._currentUserAndCustomerDir);
			this.UserIniFile = new IniFile(this._currentUserDataDir + "user.ini", "app");
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x00018A7B File Offset: 0x00016C7B
		private void CreateDirIfNotExist(string dir)
		{
			if (!Directory.Exists(dir))
			{
				Directory.CreateDirectory(dir);
			}
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x00018A8C File Offset: 0x00016C8C
		private Control GetParentForm(Control control)
		{
			for (Control c = (control != null) ? control.Parent : null; c != null; c = c.Parent)
			{
				if (c is BaseView || c is BaseForm || c is CRUDBaseForm || c is RibbonBaseForm || c is BaseUserControl)
				{
					return c;
				}
			}
			return null;
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x00018AE0 File Offset: 0x00016CE0
		private string GetParentFormName(Control control)
		{
			Control c = this.GetParentForm(control);
			if (c == null)
			{
				return string.Empty;
			}
			return c.Name;
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x00018B04 File Offset: 0x00016D04
		private string GetXtraControlName(ISupportXtraSerializer control)
		{
			Control ctrl = control as Control;
			if (ctrl != null)
			{
				return this.GetParentFormName(ctrl) + "_" + ctrl.Name;
			}
			GridView grid = control as GridView;
			if (grid != null)
			{
				return this.GetParentFormName(grid.GridControl) + "_" + grid.Name;
			}
			throw new Exception("Unknown control type");
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x00018B64 File Offset: 0x00016D64
		private void RestoreBarCheckItemState(string formName, BarCheckItem barItem)
		{
			barItem.Checked = this.UserIniFile.ReadBool(formName, barItem.Name, barItem.Checked);
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x00018B84 File Offset: 0x00016D84
		private void RestoreBarEditItemState(string formName, BarEditItem barItem)
		{
			RepositoryItemComboBox itemComboBox = barItem.Edit as RepositoryItemComboBox;
			if (itemComboBox != null)
			{
				int idx = this.UserIniFile.ReadInt(formName, barItem.Name + "_ItemIndex", -1);
				if (idx != -1 && idx < itemComboBox.Items.Count)
				{
					barItem.EditValue = itemComboBox.Items[idx];
					return;
				}
				IniFile userIniFile = this.UserIniFile;
				string name = barItem.Name;
				object editValue = barItem.EditValue;
				string v = userIniFile.ReadString(formName, name, (editValue != null) ? editValue.ToString() : null);
				idx = itemComboBox.Items.IndexOf(v);
				if (idx != -1)
				{
					barItem.EditValue = itemComboBox.Items[idx];
					return;
				}
			}
			IniFile userIniFile2 = this.UserIniFile;
			string name2 = barItem.Name;
			object editValue2 = barItem.EditValue;
			string value = userIniFile2.ReadString(formName, name2, (editValue2 != null) ? editValue2.ToString() : null);
			if (barItem.EditValue is int)
			{
				int intValue;
				if (int.TryParse(value, out intValue))
				{
					barItem.EditValue = intValue;
					return;
				}
			}
			else if (barItem.EditValue == null || (value != null && barItem.EditValue.GetType() == value.GetType()))
			{
				barItem.EditValue = value;
			}
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x00018CA4 File Offset: 0x00016EA4
		private void RestoreComboBoxEditState(string formName, ComboBoxEdit comboBoxEdit)
		{
			int idx = this.UserIniFile.ReadInt(formName, comboBoxEdit.Name + "_SelectedIndex", -1);
			if (idx > -1 && idx <= comboBoxEdit.Properties.Items.Count)
			{
				comboBoxEdit.SelectedIndex = idx;
				return;
			}
			if (comboBoxEdit.EditValue == null && comboBoxEdit.Properties.Items.Count > 0)
			{
				comboBoxEdit.SelectedIndex = 0;
			}
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x00018D10 File Offset: 0x00016F10
		private void RestoreGridViewState(GridView gridView)
		{
			try
			{
				string fileName = this._currentUserDataDir + this.GetXtraControlName(gridView);
				if (File.Exists(fileName))
				{
					gridView.RestoreLayoutFromXml(fileName);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x00018D54 File Offset: 0x00016F54
		private void SaveBarEditItemState(string formName, BarEditItem barEditItem)
		{
			int idx = -1;
			RepositoryItemComboBox itemComboBox = barEditItem.Edit as RepositoryItemComboBox;
			if (itemComboBox != null)
			{
				for (int i = 0; i < itemComboBox.Items.Count; i++)
				{
					if (itemComboBox.Items[i] == barEditItem.EditValue)
					{
						idx = i;
						break;
					}
				}
			}
			this.UserIniFile.WriteInt(formName, barEditItem.Name + "_ItemIndex", idx);
			this.UserIniFile.WriteString(formName, barEditItem.Name, barEditItem.EditValue.ToString());
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x00018DDA File Offset: 0x00016FDA
		private void SaveComboBoxEditState(string formName, ComboBoxEdit comboBoxEdit)
		{
			this.UserIniFile.WriteInt(formName, comboBoxEdit.Name + "_SelectedIndex", comboBoxEdit.SelectedIndex);
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x00018E00 File Offset: 0x00017000
		private void SaveGridViewState(GridView gridView)
		{
			OptionsLayoutGrid options = new OptionsLayoutGrid();
			options.StoreVisualOptions = false;
			options.StoreAppearance = false;
			options.StoreAppearance = false;
			options.StoreDataSettings = true;
			gridView.SaveLayoutToXml(this._currentUserDataDir + this.GetXtraControlName(gridView), options);
		}

		// Token: 0x0400021E RID: 542
		private readonly string _appDataDir;

		// Token: 0x0400021F RID: 543
		private readonly string _usersDataDir;

		// Token: 0x04000220 RID: 544
		private string _currentUserAndCustomerDir;

		// Token: 0x04000221 RID: 545
		private string _currentUserDataDir;

		// Token: 0x02000120 RID: 288
		private class TreeListColumnInfo
		{
			// Token: 0x06000A93 RID: 2707 RVA: 0x0005BA1A File Offset: 0x00059C1A
			public TreeListColumnInfo(TreeListColumn column)
			{
				this.Caption = column.Caption;
				this.CustomizationCaption = column.CustomizationCaption;
				this.FieldName = column.FieldName;
				this.Name = column.Name;
			}

			// Token: 0x170002E1 RID: 737
			// (get) Token: 0x06000A94 RID: 2708 RVA: 0x0005BA52 File Offset: 0x00059C52
			// (set) Token: 0x06000A95 RID: 2709 RVA: 0x0005BA5A File Offset: 0x00059C5A
			public string Caption { get; set; }

			// Token: 0x170002E2 RID: 738
			// (get) Token: 0x06000A96 RID: 2710 RVA: 0x0005BA63 File Offset: 0x00059C63
			// (set) Token: 0x06000A97 RID: 2711 RVA: 0x0005BA6B File Offset: 0x00059C6B
			public string CustomizationCaption { get; set; }

			// Token: 0x170002E3 RID: 739
			// (get) Token: 0x06000A98 RID: 2712 RVA: 0x0005BA74 File Offset: 0x00059C74
			// (set) Token: 0x06000A99 RID: 2713 RVA: 0x0005BA7C File Offset: 0x00059C7C
			public string FieldName { get; set; }

			// Token: 0x170002E4 RID: 740
			// (get) Token: 0x06000A9A RID: 2714 RVA: 0x0005BA85 File Offset: 0x00059C85
			// (set) Token: 0x06000A9B RID: 2715 RVA: 0x0005BA8D File Offset: 0x00059C8D
			public string Name { get; set; }

			// Token: 0x06000A9C RID: 2716 RVA: 0x0005BA96 File Offset: 0x00059C96
			public void RestroreColumn(TreeListColumn column)
			{
				column.Caption = this.Caption;
				column.CustomizationCaption = this.CustomizationCaption;
				column.FieldName = this.FieldName;
			}
		}
	}
}
