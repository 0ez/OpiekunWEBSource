﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005F RID: 95
	public partial class DeleteHistoryForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000510 RID: 1296 RVA: 0x0001AD73 File Offset: 0x00018F73
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000511 RID: 1297 RVA: 0x0001AD94 File Offset: 0x00018F94
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DeleteHistoryForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.checkBoxDeleteAppHistory = new global::System.Windows.Forms.CheckBox();
			this.checkBoxDeleteWebHistory = new global::System.Windows.Forms.CheckBox();
			this.textEditConfirmation = new global::DevExpress.XtraEditors.TextEdit();
			this.labelControlInfo = new global::DevExpress.XtraEditors.LabelControl();
			this.dateEditLtTimestamp = new global::DevExpress.XtraEditors.DateEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlLtTimestamp = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlLabelInfo = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem2 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlConfirmation = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem3 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlItem1 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItem2 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.buttonSave = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditConfirmation.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditLtTimestamp.Properties.CalendarTimeProperties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditLtTimestamp.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlLtTimestamp).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlLabelInfo).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlConfirmation).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem3).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem2).BeginInit();
			base.SuspendLayout();
			this.layoutControlMain.Controls.Add(this.checkBoxDeleteAppHistory);
			this.layoutControlMain.Controls.Add(this.checkBoxDeleteWebHistory);
			this.layoutControlMain.Controls.Add(this.textEditConfirmation);
			this.layoutControlMain.Controls.Add(this.labelControlInfo);
			this.layoutControlMain.Controls.Add(this.dateEditLtTimestamp);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.checkBoxDeleteAppHistory, "checkBoxDeleteAppHistory");
			this.checkBoxDeleteAppHistory.Name = "checkBoxDeleteAppHistory";
			this.checkBoxDeleteAppHistory.UseVisualStyleBackColor = true;
			resources.ApplyResources(this.checkBoxDeleteWebHistory, "checkBoxDeleteWebHistory");
			this.checkBoxDeleteWebHistory.Name = "checkBoxDeleteWebHistory";
			this.checkBoxDeleteWebHistory.UseVisualStyleBackColor = true;
			resources.ApplyResources(this.textEditConfirmation, "textEditConfirmation");
			this.textEditConfirmation.Name = "textEditConfirmation";
			this.textEditConfirmation.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditConfirmation.Properties.Mask.BeepOnError");
			this.textEditConfirmation.Properties.Mask.EditMask = resources.GetString("textEditConfirmation.Properties.Mask.EditMask");
			this.textEditConfirmation.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditConfirmation.Properties.Mask.IgnoreMaskBlank");
			this.textEditConfirmation.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditConfirmation.Properties.Mask.MaskType");
			this.textEditConfirmation.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditConfirmation.Properties.Mask.ShowPlaceHolders");
			this.textEditConfirmation.StyleController = this.layoutControlMain;
			this.labelControlInfo.AllowHtmlString = true;
			resources.ApplyResources(this.labelControlInfo, "labelControlInfo");
			this.labelControlInfo.Name = "labelControlInfo";
			this.labelControlInfo.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.dateEditLtTimestamp, "dateEditLtTimestamp");
			this.dateEditLtTimestamp.Name = "dateEditLtTimestamp";
			this.dateEditLtTimestamp.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("dateEditLtTimestamp.Properties.Buttons"))
			});
			this.dateEditLtTimestamp.Properties.CalendarTimeProperties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("dateEditLtTimestamp.Properties.CalendarTimeProperties.Buttons"))
			});
			this.dateEditLtTimestamp.Properties.Mask.BeepOnError = (bool)resources.GetObject("dateEditLtTimestamp.Properties.Mask.BeepOnError");
			this.dateEditLtTimestamp.StyleController = this.layoutControlMain;
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlLtTimestamp,
				this.layoutControlLabelInfo,
				this.emptySpaceItem2,
				this.layoutControlConfirmation,
				this.emptySpaceItem3,
				this.layoutControlItem1,
				this.layoutControlItem2,
				this.emptySpaceItem1
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(345, 279);
			this.Root.TextVisible = false;
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 103);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(325, 10);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlLtTimestamp.Control = this.dateEditLtTimestamp;
			this.layoutControlLtTimestamp.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlLtTimestamp.Name = "layoutControlLtTimestamp";
			this.layoutControlLtTimestamp.Size = new global::System.Drawing.Size(325, 45);
			resources.ApplyResources(this.layoutControlLtTimestamp, "layoutControlLtTimestamp");
			this.layoutControlLtTimestamp.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlLtTimestamp.TextSize = new global::System.Drawing.Size(145, 16);
			this.layoutControlLabelInfo.Control = this.labelControlInfo;
			this.layoutControlLabelInfo.Location = new global::System.Drawing.Point(0, 113);
			this.layoutControlLabelInfo.Name = "layoutControlLabelInfo";
			this.layoutControlLabelInfo.Size = new global::System.Drawing.Size(325, 36);
			this.layoutControlLabelInfo.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlLabelInfo.TextVisible = false;
			this.emptySpaceItem2.AllowHotTrack = false;
			this.emptySpaceItem2.Location = new global::System.Drawing.Point(0, 149);
			this.emptySpaceItem2.Name = "emptySpaceItem2";
			this.emptySpaceItem2.Size = new global::System.Drawing.Size(325, 11);
			this.emptySpaceItem2.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlConfirmation.Control = this.textEditConfirmation;
			this.layoutControlConfirmation.Location = new global::System.Drawing.Point(0, 160);
			this.layoutControlConfirmation.Name = "layoutControlConfirmation";
			this.layoutControlConfirmation.Size = new global::System.Drawing.Size(325, 45);
			resources.ApplyResources(this.layoutControlConfirmation, "layoutControlConfirmation");
			this.layoutControlConfirmation.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlConfirmation.TextSize = new global::System.Drawing.Size(145, 16);
			this.emptySpaceItem3.AllowHotTrack = false;
			this.emptySpaceItem3.Location = new global::System.Drawing.Point(0, 205);
			this.emptySpaceItem3.Name = "emptySpaceItem3";
			this.emptySpaceItem3.Size = new global::System.Drawing.Size(325, 54);
			this.emptySpaceItem3.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem1.Control = this.checkBoxDeleteWebHistory;
			this.layoutControlItem1.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlItem1.Name = "layoutControlItem1";
			this.layoutControlItem1.Size = new global::System.Drawing.Size(325, 29);
			this.layoutControlItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem1.TextVisible = false;
			this.layoutControlItem2.Control = this.checkBoxDeleteAppHistory;
			this.layoutControlItem2.Location = new global::System.Drawing.Point(0, 74);
			this.layoutControlItem2.Name = "layoutControlItem2";
			this.layoutControlItem2.Size = new global::System.Drawing.Size(325, 29);
			this.layoutControlItem2.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem2.TextVisible = false;
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.buttonSave.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Click += new global::System.EventHandler(this.buttonSave_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.buttonSave);
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("DeleteHistoryForm.IconOptions.Icon");
			base.Name = "DeleteHistoryForm";
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditConfirmation.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditLtTimestamp.Properties.CalendarTimeProperties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditLtTimestamp.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlLtTimestamp).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlLabelInfo).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlConfirmation).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem3).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem2).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000246 RID: 582
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000247 RID: 583
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x04000248 RID: 584
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x04000249 RID: 585
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x0400024A RID: 586
		protected global::DevExpress.XtraEditors.SimpleButton buttonSave;

		// Token: 0x0400024B RID: 587
		private global::DevExpress.XtraEditors.DateEdit dateEditLtTimestamp;

		// Token: 0x0400024C RID: 588
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlLtTimestamp;

		// Token: 0x0400024D RID: 589
		private global::DevExpress.XtraEditors.LabelControl labelControlInfo;

		// Token: 0x0400024E RID: 590
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlLabelInfo;

		// Token: 0x0400024F RID: 591
		private global::DevExpress.XtraEditors.TextEdit textEditConfirmation;

		// Token: 0x04000250 RID: 592
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;

		// Token: 0x04000251 RID: 593
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlConfirmation;

		// Token: 0x04000252 RID: 594
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;

		// Token: 0x04000253 RID: 595
		private global::System.Windows.Forms.CheckBox checkBoxDeleteAppHistory;

		// Token: 0x04000254 RID: 596
		private global::System.Windows.Forms.CheckBox checkBoxDeleteWebHistory;

		// Token: 0x04000255 RID: 597
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;

		// Token: 0x04000256 RID: 598
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
	}
}
