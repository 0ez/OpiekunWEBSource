﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000A6 RID: 166
	public class ConfigLogView : BaseView
	{
		// Token: 0x0600088C RID: 2188 RVA: 0x0004B6C4 File Offset: 0x000498C4
		public ConfigLogView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
			this._objectsToSaveState.Add(this.gridViewDiagnostic);
			this.gridDiagnostic.DataSource = observableAgregator.DeviceEventsLog;
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x0004B6F9 File Offset: 0x000498F9
		protected override void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			base.OnSelectedDeviceChanged(selection);
			if (base.IsCurrentView)
			{
				this.gridViewDiagnostic.RefreshData();
			}
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x0004B715 File Offset: 0x00049915
		protected override void ViewActivate()
		{
			this.gridViewDiagnostic.RefreshData();
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x0004B724 File Offset: 0x00049924
		private void gridViewDiagnostic_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			if (this._devicesTree.Selection.IsAllDevicesGroupSelected)
			{
				return;
			}
			DeviceEvent operation = this._observableAgregator.DeviceEventsLog[e.ListSourceRow];
			e.Visible = this._devicesTree.Selection.ShouldShowSelectedDeviceLog(operation.DeviceId, operation.SessionNo);
			e.Handled = true;
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x0004B784 File Offset: 0x00049984
		private void gridViewDiagnostic_RowCountChanged(object sender, EventArgs e)
		{
			if (this.gridColumnDate.SortOrder == ColumnSortOrder.Ascending)
			{
				this.gridViewDiagnostic.FocusedRowHandle = this.gridViewDiagnostic.RowCount - 1;
			}
			if (this.gridColumnDate.SortOrder == ColumnSortOrder.Descending)
			{
				this.gridViewDiagnostic.FocusedRowHandle = 0;
			}
			this.gridViewDiagnostic.OptionsView.RowAutoHeight = true;
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x0004B7E2 File Offset: 0x000499E2
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x0004B804 File Offset: 0x00049A04
		private void InitializeComponent()
		{
			ComponentResourceManager resources = new ComponentResourceManager(typeof(ConfigLogView));
			this.gridDiagnostic = new GridControl();
			this.gridViewDiagnostic = new GridView();
			this.gridColumnDate = new GridColumn();
			this.gridColumnSuccess = new GridColumn();
			this.repositoryImageComboBoxResult = new RepositoryItemImageComboBox();
			this.gridColumnOperation = new GridColumn();
			this.gridColumnDeviceName = new GridColumn();
			this.gridColumnMessage = new GridColumn();
			this.repositoryMemoMessage = new RepositoryItemMemoEdit();
			this.gridColumnSessionNo = new GridColumn();
			this.labelInfo = new Label();
			((ISupportInitialize)this.gridDiagnostic).BeginInit();
			((ISupportInitialize)this.gridViewDiagnostic).BeginInit();
			((ISupportInitialize)this.repositoryImageComboBoxResult).BeginInit();
			((ISupportInitialize)this.repositoryMemoMessage).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.gridDiagnostic, "gridDiagnostic");
			this.gridDiagnostic.MainView = this.gridViewDiagnostic;
			this.gridDiagnostic.Name = "gridDiagnostic";
			this.gridDiagnostic.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryImageComboBoxResult,
				this.repositoryMemoMessage
			});
			this.gridDiagnostic.ViewCollection.AddRange(new BaseView[]
			{
				this.gridViewDiagnostic
			});
			this.gridViewDiagnostic.Columns.AddRange(new GridColumn[]
			{
				this.gridColumnDate,
				this.gridColumnSuccess,
				this.gridColumnOperation,
				this.gridColumnDeviceName,
				this.gridColumnMessage,
				this.gridColumnSessionNo
			});
			this.gridViewDiagnostic.GridControl = this.gridDiagnostic;
			this.gridViewDiagnostic.Name = "gridViewDiagnostic";
			this.gridViewDiagnostic.OptionsBehavior.AllowAddRows = DefaultBoolean.False;
			this.gridViewDiagnostic.OptionsBehavior.AllowDeleteRows = DefaultBoolean.False;
			this.gridViewDiagnostic.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewDiagnostic.OptionsSelection.MultiSelect = true;
			this.gridViewDiagnostic.OptionsView.EnableAppearanceEvenRow = true;
			this.gridViewDiagnostic.OptionsView.RowAutoHeight = true;
			this.gridViewDiagnostic.OptionsView.ShowGroupPanel = false;
			this.gridViewDiagnostic.SortInfo.AddRange(new GridColumnSortInfo[]
			{
				new GridColumnSortInfo(this.gridColumnDate, ColumnSortOrder.Descending)
			});
			this.gridViewDiagnostic.CustomRowFilter += this.gridViewDiagnostic_CustomRowFilter;
			this.gridViewDiagnostic.RowCountChanged += this.gridViewDiagnostic_RowCountChanged;
			this.gridColumnDate.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDate.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			this.gridColumnDate.AppearanceHeader.TextOptions.VAlignment = VertAlignment.Center;
			resources.ApplyResources(this.gridColumnDate, "gridColumnDate");
			this.gridColumnDate.DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";
			this.gridColumnDate.DisplayFormat.FormatType = FormatType.DateTime;
			this.gridColumnDate.FieldName = "DateTime";
			this.gridColumnDate.Name = "gridColumnDate";
			this.gridColumnDate.OptionsColumn.AllowEdit = false;
			this.gridColumnDate.OptionsColumn.FixedWidth = true;
			this.gridColumnDate.OptionsColumn.ReadOnly = true;
			this.gridColumnDate.UnboundType = UnboundColumnType.DateTime;
			this.gridColumnSuccess.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnSuccess.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			this.gridColumnSuccess.AppearanceHeader.TextOptions.VAlignment = VertAlignment.Center;
			resources.ApplyResources(this.gridColumnSuccess, "gridColumnSuccess");
			this.gridColumnSuccess.ColumnEdit = this.repositoryImageComboBoxResult;
			this.gridColumnSuccess.FieldName = "Success";
			this.gridColumnSuccess.Name = "gridColumnSuccess";
			this.gridColumnSuccess.OptionsColumn.AllowEdit = false;
			this.gridColumnSuccess.OptionsColumn.ReadOnly = true;
			this.gridColumnSuccess.UnboundType = UnboundColumnType.Boolean;
			resources.ApplyResources(this.repositoryImageComboBoxResult, "repositoryImageComboBoxResult");
			this.repositoryImageComboBoxResult.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryImageComboBoxResult.Buttons"))
			});
			this.repositoryImageComboBoxResult.Items.AddRange(new ImageComboBoxItem[]
			{
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxResult.Items"), resources.GetObject("repositoryImageComboBoxResult.Items1"), (int)resources.GetObject("repositoryImageComboBoxResult.Items2")),
				new ImageComboBoxItem(resources.GetString("repositoryImageComboBoxResult.Items3"), resources.GetObject("repositoryImageComboBoxResult.Items4"), (int)resources.GetObject("repositoryImageComboBoxResult.Items5"))
			});
			this.repositoryImageComboBoxResult.Name = "repositoryImageComboBoxResult";
			this.gridColumnOperation.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnOperation.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			this.gridColumnOperation.AppearanceHeader.TextOptions.VAlignment = VertAlignment.Center;
			resources.ApplyResources(this.gridColumnOperation, "gridColumnOperation");
			this.gridColumnOperation.FieldName = "Description";
			this.gridColumnOperation.Name = "gridColumnOperation";
			this.gridColumnOperation.OptionsColumn.AllowEdit = false;
			this.gridColumnOperation.OptionsColumn.ReadOnly = true;
			this.gridColumnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDeviceName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			this.gridColumnDeviceName.AppearanceHeader.TextOptions.VAlignment = VertAlignment.Center;
			resources.ApplyResources(this.gridColumnDeviceName, "gridColumnDeviceName");
			this.gridColumnDeviceName.FieldName = "DeviceName";
			this.gridColumnDeviceName.Name = "gridColumnDeviceName";
			this.gridColumnDeviceName.OptionsColumn.FixedWidth = true;
			this.gridColumnDeviceName.OptionsColumn.ReadOnly = true;
			this.gridColumnDeviceName.UnboundType = UnboundColumnType.String;
			this.gridColumnMessage.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnMessage.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			this.gridColumnMessage.AppearanceHeader.TextOptions.VAlignment = VertAlignment.Center;
			resources.ApplyResources(this.gridColumnMessage, "gridColumnMessage");
			this.gridColumnMessage.ColumnEdit = this.repositoryMemoMessage;
			this.gridColumnMessage.FieldName = "Message";
			this.gridColumnMessage.Name = "gridColumnMessage";
			this.gridColumnMessage.OptionsColumn.ReadOnly = true;
			this.gridColumnMessage.UnboundType = UnboundColumnType.String;
			this.repositoryMemoMessage.Name = "repositoryMemoMessage";
			this.gridColumnSessionNo.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnSessionNo.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnSessionNo, "gridColumnSessionNo");
			this.gridColumnSessionNo.FieldName = "SessionNo";
			this.gridColumnSessionNo.MinWidth = 25;
			this.gridColumnSessionNo.Name = "gridColumnSessionNo";
			this.gridColumnSessionNo.OptionsColumn.AllowEdit = false;
			this.gridColumnSessionNo.OptionsColumn.ReadOnly = true;
			resources.ApplyResources(this.labelInfo, "labelInfo");
			this.labelInfo.Name = "labelInfo";
			this.labelInfo.UseCompatibleTextRendering = true;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.gridDiagnostic);
			base.Controls.Add(this.labelInfo);
			base.Name = "ConfigLogView";
			((ISupportInitialize)this.gridDiagnostic).EndInit();
			((ISupportInitialize)this.gridViewDiagnostic).EndInit();
			((ISupportInitialize)this.repositoryImageComboBoxResult).EndInit();
			((ISupportInitialize)this.repositoryMemoMessage).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000673 RID: 1651
		private IContainer components;

		// Token: 0x04000674 RID: 1652
		private GridControl gridDiagnostic;

		// Token: 0x04000675 RID: 1653
		private GridView gridViewDiagnostic;

		// Token: 0x04000676 RID: 1654
		private GridColumn gridColumnDate;

		// Token: 0x04000677 RID: 1655
		private GridColumn gridColumnSuccess;

		// Token: 0x04000678 RID: 1656
		private RepositoryItemImageComboBox repositoryImageComboBoxResult;

		// Token: 0x04000679 RID: 1657
		private GridColumn gridColumnOperation;

		// Token: 0x0400067A RID: 1658
		private GridColumn gridColumnDeviceName;

		// Token: 0x0400067B RID: 1659
		private GridColumn gridColumnMessage;

		// Token: 0x0400067C RID: 1660
		private Label labelInfo;

		// Token: 0x0400067D RID: 1661
		private GridColumn gridColumnSessionNo;

		// Token: 0x0400067E RID: 1662
		private RepositoryItemMemoEdit repositoryMemoMessage;
	}
}
