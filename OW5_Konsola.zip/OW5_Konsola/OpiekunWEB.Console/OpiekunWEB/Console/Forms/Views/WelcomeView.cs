﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000AC RID: 172
	public class WelcomeView : BaseView
	{
		// Token: 0x060008F2 RID: 2290 RVA: 0x00051C65 File Offset: 0x0004FE65
		public WelcomeView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x00051C78 File Offset: 0x0004FE78
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x00051C97 File Offset: 0x0004FE97
		private void InitializeComponent()
		{
			base.SuspendLayout();
			base.AutoScaleDimensions = new SizeF(7f, 16f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Name = "WelcomeView";
			base.ResumeLayout(false);
		}

		// Token: 0x040006FB RID: 1787
		private IContainer components;
	}
}
