﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000AB RID: 171
	public class HelpView : BaseView
	{
		// Token: 0x060008EF RID: 2287 RVA: 0x00051BFD File Offset: 0x0004FDFD
		public HelpView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x00051C10 File Offset: 0x0004FE10
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060008F1 RID: 2289 RVA: 0x00051C2F File Offset: 0x0004FE2F
		private void InitializeComponent()
		{
			base.SuspendLayout();
			base.AutoScaleDimensions = new SizeF(7f, 16f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Name = "HelpView";
			base.ResumeLayout(false);
		}

		// Token: 0x040006FA RID: 1786
		private IContainer components;
	}
}
