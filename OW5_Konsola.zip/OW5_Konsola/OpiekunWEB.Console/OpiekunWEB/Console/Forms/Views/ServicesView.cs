﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000A4 RID: 164
	public class ServicesView : BaseView
	{
		// Token: 0x06000867 RID: 2151 RVA: 0x00049111 File Offset: 0x00047311
		public ServicesView()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x00049120 File Offset: 0x00047320
		public ServicesView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
			this._servicesList = new BindingList<ServicesView.AgentItemAndServiceInfo>();
			this._agentTaskThrottler = new AgentTaskThrottler(10);
			RealTimeSource rts = new RealTimeSource
			{
				DataSource = this._servicesList
			};
			this.gridServicesList.DataSource = rts;
			this.miServiceStartTypeAutoStart.Caption = SsStringUtils.GetEnumDescriptionFromResource<ServiceStartType>(ServiceStartType.AutoStart, null, null);
			this.miServiceStartTypeAutostartDelayed.Caption = SsStringUtils.GetEnumDescriptionFromResource<ServiceStartType>(ServiceStartType.AutoStart, null, null) + " " + OwpbExtensions.GetServiceDelayedString();
			this.miServiceStartTypeOnDemand.Caption = SsStringUtils.GetEnumDescriptionFromResource<ServiceStartType>(ServiceStartType.DemandStart, null, null);
			this.miServiceStartTypeDisabled.Caption = SsStringUtils.GetEnumDescriptionFromResource<ServiceStartType>(ServiceStartType.Disabled, null, null);
			EnumHelpers.InitializeComboBoxAsStringKeyAndValue<ServicesView.ServicesToShow>(this.barEditServicesToShow, ServicesView.ServicesToShow.Services, Resources.ResourceManager);
			this._formsSettings.RestoreObjectState(base.Name, this.barEditServicesToShow, null);
		}

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x06000869 RID: 2153 RVA: 0x000491F8 File Offset: 0x000473F8
		// (set) Token: 0x0600086A RID: 2154 RVA: 0x00049200 File Offset: 0x00047400
		public string StartTypeAsString { get; private set; }

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x0600086B RID: 2155 RVA: 0x00049209 File Offset: 0x00047409
		// (set) Token: 0x0600086C RID: 2156 RVA: 0x00049211 File Offset: 0x00047411
		public string StateAsString { get; private set; }

		// Token: 0x0600086D RID: 2157 RVA: 0x0004921C File Offset: 0x0004741C
		protected override void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			if (!base.IsCurrentView)
			{
				return;
			}
			base.OnSelectedDeviceChanged(selection);
			this._agentTaskThrottler.CancelAgentTask(selection.SelectionChanges.AgentItemsRemoved);
			this.gridServicesList.BeginUpdate();
			BindingList<ServicesView.AgentItemAndServiceInfo> servicesList = this._servicesList;
			lock (servicesList)
			{
				foreach (ServicesView.AgentItemAndServiceInfo item in this._servicesList)
				{
					if (selection.SelectionChanges.AgentItemsRemoved.IndexOf(item.AgentItem) > -1)
					{
						item.Hidden = true;
					}
					if (selection.SelectionChanges.AgentItemsAdded.IndexOf(item.AgentItem) > -1)
					{
						item.Hidden = false;
					}
				}
			}
			this.gridServicesList.EndUpdate();
			this.GetServicesList(selection.SelectionChanges.AgentItemsAdded);
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x00049318 File Offset: 0x00047518
		protected override void ViewActivate()
		{
			base.ViewActivate();
			this.btnRefresh_ItemClick(this, null);
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x00049328 File Offset: 0x00047528
		protected override void ViewDeactivate()
		{
			this._agentTaskThrottler.CancelAllTask();
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x00049338 File Offset: 0x00047538
		private void AgentServicesListReceived(AgentItem agentItem, ServicesListResponse response)
		{
			BindingList<ServicesView.AgentItemAndServiceInfo> servicesList = this._servicesList;
			lock (servicesList)
			{
				if (!this.SholudGetServicesFromAgent(agentItem) || response == null)
				{
					this.RemoveItemsForAgentItem(agentItem);
				}
				else
				{
					IEnumerable<ServicesView.AgentItemAndServiceInfo> oldAgentServicesList = from x in this._servicesList
					where x.AgentItem == agentItem
					select x;
					foreach (ServicesView.AgentItemAndServiceInfo serviceInfo2 in (from x in oldAgentServicesList
					where !response.Items.Any((ServiceInfo y) => y.ServiceName == x.ServiceInfo.ServiceName)
					select x).ToList<ServicesView.AgentItemAndServiceInfo>())
					{
						this._servicesList.Remove(serviceInfo2);
					}
					using (IEnumerator<ServiceInfo> enumerator2 = response.Items.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							ServiceInfo serviceInfo = enumerator2.Current;
							ServicesView.AgentItemAndServiceInfo oldItem = oldAgentServicesList.FirstOrDefault((ServicesView.AgentItemAndServiceInfo x) => x.ServiceInfo.ServiceName == serviceInfo.ServiceName);
							if (oldItem != null)
							{
								oldItem.ServiceInfo = serviceInfo;
							}
							else
							{
								this._servicesList.Add(new ServicesView.AgentItemAndServiceInfo(agentItem, serviceInfo));
							}
						}
					}
				}
			}
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x000494D8 File Offset: 0x000476D8
		private void barEditServicesToShow_EditValueChanged(object sender, EventArgs e)
		{
			KeyAndValue<ServicesView.ServicesToShow, string> kv = (KeyAndValue<ServicesView.ServicesToShow, string>)this.barEditServicesToShow.EditValue;
			if (kv == null)
			{
				return;
			}
			this._servicesToShow = kv.Key;
			if (base.IsCurrentView)
			{
				this.gridViewServicesList.RefreshData();
				this._formsSettings.SaveObjectState(base.Name, this.barEditServicesToShow);
			}
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00049530 File Offset: 0x00047730
		private void btnPauseService_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceControl(ServiceControlOperation.PauseService);
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x00049539 File Offset: 0x00047739
		private void btnRefresh_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._agentTaskThrottler.CancelAllTask();
			this._servicesList.Clear();
			this.GetServicesList();
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x00049557 File Offset: 0x00047757
		private void btnRestartService_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceControl(ServiceControlOperation.RestartService);
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x00049560 File Offset: 0x00047760
		private void btnResumeService_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceControl(ServiceControlOperation.ResumeService);
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x00049569 File Offset: 0x00047769
		private void btnStartService_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceControl(ServiceControlOperation.StartService);
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x00049572 File Offset: 0x00047772
		private void btnStopService_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceControl(ServiceControlOperation.StopService);
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x0004957C File Offset: 0x0004777C
		private List<ServicesView.AgentItemAndServiceInfo> GetSelectedItems()
		{
			List<ServicesView.AgentItemAndServiceInfo> selectedItems = new List<ServicesView.AgentItemAndServiceInfo>();
			for (int i = 0; i < this.gridViewServicesList.SelectedRowsCount; i++)
			{
				int rowHandle = this.gridViewServicesList.GetSelectedRows()[i];
				int index = this.gridViewServicesList.GetDataSourceRowIndex(rowHandle);
				ServicesView.AgentItemAndServiceInfo pi = this._servicesList[index];
				if (pi != null)
				{
					selectedItems.Add(pi);
				}
			}
			return selectedItems;
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x000495DC File Offset: 0x000477DC
		private void GetServiceListFromAgent(AgentItem agentItem)
		{
			ServicesView.<>c__DisplayClass26_0 CS$<>8__locals1 = new ServicesView.<>c__DisplayClass26_0();
			CS$<>8__locals1.agentItem = agentItem;
			CS$<>8__locals1.<>4__this = this;
			this._agentTaskThrottler.StartNewTask<Task>(delegate
			{
				ServicesView.<>c__DisplayClass26_0.<<GetServiceListFromAgent>b__0>d <<GetServiceListFromAgent>b__0>d;
				<<GetServiceListFromAgent>b__0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<GetServiceListFromAgent>b__0>d.<>4__this = CS$<>8__locals1;
				<<GetServiceListFromAgent>b__0>d.<>1__state = -1;
				<<GetServiceListFromAgent>b__0>d.<>t__builder.Start<ServicesView.<>c__DisplayClass26_0.<<GetServiceListFromAgent>b__0>d>(ref <<GetServiceListFromAgent>b__0>d);
				return <<GetServiceListFromAgent>b__0>d.<>t__builder.Task;
			});
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x00049618 File Offset: 0x00047818
		private void GetServicesList(List<AgentItem> agentList)
		{
			foreach (AgentItem agentItem in this._devicesTree.Selection.AgentsList)
			{
				this.GetServiceListFromAgent(agentItem);
			}
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x00049678 File Offset: 0x00047878
		private void GetServicesList()
		{
			this.GetServicesList(this._devicesTree.Selection.AgentsList);
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x00049690 File Offset: 0x00047890
		private void gridViewServicesList_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			GridView view = sender as GridView;
			object listSourceRowCellValue = view.GetListSourceRowCellValue(e.ListSourceRow, this.columnHidden.FieldName);
			if (listSourceRowCellValue is bool)
			{
				bool hidden = (bool)listSourceRowCellValue;
				if (hidden)
				{
					e.Visible = false;
					e.Handled = true;
					return;
				}
			}
			listSourceRowCellValue = view.GetListSourceRowCellValue(e.ListSourceRow, this.columnServiceType.FieldName);
			if (listSourceRowCellValue is uint)
			{
				uint serviceType = (uint)listSourceRowCellValue;
				listSourceRowCellValue = view.GetListSourceRowCellValue(e.ListSourceRow, this.columnState.FieldName);
				if (listSourceRowCellValue is uint)
				{
					uint state = (uint)listSourceRowCellValue;
					ServicesView.ServicesToShow servicesToShow = this._servicesToShow;
					if (servicesToShow == ServicesView.ServicesToShow.Services)
					{
						e.Visible = (serviceType > 2U);
						e.Handled = !e.Visible;
						return;
					}
					if (servicesToShow != ServicesView.ServicesToShow.OnlyStartedServices)
					{
						return;
					}
					e.Visible = (serviceType > 2U && state == 4U);
					e.Handled = !e.Visible;
				}
			}
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00049779 File Offset: 0x00047979
		private void miServiceStartTypeAutoStart_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceSetStartType(ServiceStartType.AutoStart, false);
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x00049783 File Offset: 0x00047983
		private void miServiceStartTypeAutostartDelayed_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceSetStartType(ServiceStartType.AutoStart, true);
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x0004978D File Offset: 0x0004798D
		private void miServiceStartTypeDisabled_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceSetStartType(ServiceStartType.Disabled, false);
		}

		// Token: 0x06000880 RID: 2176 RVA: 0x00049797 File Offset: 0x00047997
		private void miServiceStartTypeOnDemand_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ServiceSetStartType(ServiceStartType.DemandStart, false);
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x000497A4 File Offset: 0x000479A4
		private void RemoveItemsForAgentItem(AgentItem agentItem)
		{
			foreach (ServicesView.AgentItemAndServiceInfo serviceInfo in (from x in this._servicesList
			where x.AgentItem == agentItem
			select x).ToList<ServicesView.AgentItemAndServiceInfo>())
			{
				this._servicesList.Remove(serviceInfo);
			}
		}

		// Token: 0x06000882 RID: 2178 RVA: 0x00049820 File Offset: 0x00047A20
		private void ServiceControl(ServiceControlOperation operation)
		{
			ServicesView.<ServiceControl>d__35 <ServiceControl>d__;
			<ServiceControl>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ServiceControl>d__.<>4__this = this;
			<ServiceControl>d__.operation = operation;
			<ServiceControl>d__.<>1__state = -1;
			<ServiceControl>d__.<>t__builder.Start<ServicesView.<ServiceControl>d__35>(ref <ServiceControl>d__);
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x00049860 File Offset: 0x00047A60
		private void ServiceSetStartType(ServiceStartType serviceStartType, bool delayedAutoStart)
		{
			ServicesView.<ServiceSetStartType>d__36 <ServiceSetStartType>d__;
			<ServiceSetStartType>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ServiceSetStartType>d__.<>4__this = this;
			<ServiceSetStartType>d__.serviceStartType = serviceStartType;
			<ServiceSetStartType>d__.delayedAutoStart = delayedAutoStart;
			<ServiceSetStartType>d__.<>1__state = -1;
			<ServiceSetStartType>d__.<>t__builder.Start<ServicesView.<ServiceSetStartType>d__36>(ref <ServiceSetStartType>d__);
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x000498A8 File Offset: 0x00047AA8
		private bool SholudGetServicesFromAgent(AgentItem agentItem)
		{
			return this._devicesTree.Selection.DevicesList.Contains(agentItem.DeviceItem) && agentItem.AgentClient != null && agentItem.AgentClient.IsConnected && agentItem.DeviceType != DeviceType.TerminalClient && (agentItem.AgentClient.IsMasterAgent || agentItem.DeviceItem.GetConnectedAgentItemsList().Count == 1);
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x00049918 File Offset: 0x00047B18
		private Task UpdateServiceInfo(ServicesView.AgentItemAndServiceInfo agentAndServiceInfo)
		{
			ServicesView.<UpdateServiceInfo>d__38 <UpdateServiceInfo>d__;
			<UpdateServiceInfo>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UpdateServiceInfo>d__.<>4__this = this;
			<UpdateServiceInfo>d__.agentAndServiceInfo = agentAndServiceInfo;
			<UpdateServiceInfo>d__.<>1__state = -1;
			<UpdateServiceInfo>d__.<>t__builder.Start<ServicesView.<UpdateServiceInfo>d__38>(ref <UpdateServiceInfo>d__);
			return <UpdateServiceInfo>d__.<>t__builder.Task;
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x00049963 File Offset: 0x00047B63
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x00049984 File Offset: 0x00047B84
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager resources = new ComponentResourceManager(typeof(ServicesView));
			this.barManager = new BarManager(this.components);
			this.barMenu = new Bar();
			this.barEditServicesToShow = new BarEditItem();
			this.repositoryComboBoxServicesToShow = new RepositoryItemComboBox();
			this.btnRefresh = new BarButtonItem();
			this.btnStartService = new BarButtonItem();
			this.btnStopService = new BarButtonItem();
			this.btnRestartService = new BarButtonItem();
			this.btnServiceMoreCommands = new BarButtonItem();
			this.btnPauseService = new BarButtonItem();
			this.btnResumeService = new BarButtonItem();
			this.btnChangeServiceStartType = new BarButtonItem();
			this.menuChangeServiceStartType = new PopupMenu(this.components);
			this.miServiceStartTypeAutoStart = new BarButtonItem();
			this.miServiceStartTypeAutostartDelayed = new BarButtonItem();
			this.miServiceStartTypeOnDemand = new BarButtonItem();
			this.miServiceStartTypeDisabled = new BarButtonItem();
			this.barButtonExport = new BarButtonItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControl1 = new BarDockControl();
			this.gridServicesList = new GridControl();
			this.gridViewServicesList = new GridView();
			this.columnDeviceName = new GridColumn();
			this.columnServiceName = new GridColumn();
			this.columnDisplayName = new GridColumn();
			this.columnDescription = new GridColumn();
			this.columnStateAsString = new GridColumn();
			this.columnStartType = new GridColumn();
			this.columnServiceType = new GridColumn();
			this.columnDelayedAutoStart = new GridColumn();
			this.columnHidden = new GridColumn();
			this.columnState = new GridColumn();
			this.menuServiceMoreCommands = new PopupMenu(this.components);
			((ISupportInitialize)this.barManager).BeginInit();
			((ISupportInitialize)this.repositoryComboBoxServicesToShow).BeginInit();
			((ISupportInitialize)this.menuChangeServiceStartType).BeginInit();
			((ISupportInitialize)this.gridServicesList).BeginInit();
			((ISupportInitialize)this.gridViewServicesList).BeginInit();
			((ISupportInitialize)this.menuServiceMoreCommands).BeginInit();
			base.SuspendLayout();
			this.barManager.AllowCustomization = false;
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.barMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControl1);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.btnRefresh,
				this.barEditServicesToShow,
				this.barButtonExport,
				this.btnStartService,
				this.btnStopService,
				this.btnPauseService,
				this.btnResumeService,
				this.btnRestartService,
				this.btnChangeServiceStartType,
				this.miServiceStartTypeAutoStart,
				this.miServiceStartTypeOnDemand,
				this.miServiceStartTypeDisabled,
				this.miServiceStartTypeAutostartDelayed,
				this.btnServiceMoreCommands
			});
			this.barManager.MainMenu = this.barMenu;
			this.barManager.MaxItemId = 21;
			this.barManager.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryComboBoxServicesToShow
			});
			this.barMenu.BarName = "Main menu";
			this.barMenu.CanDockStyle = BarCanDockStyle.Top;
			this.barMenu.DockCol = 0;
			this.barMenu.DockRow = 0;
			this.barMenu.DockStyle = BarDockStyle.Top;
			this.barMenu.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barEditServicesToShow),
				new LinkPersistInfo(this.btnRefresh),
				new LinkPersistInfo(this.btnStartService, true),
				new LinkPersistInfo(this.btnStopService),
				new LinkPersistInfo(this.btnRestartService),
				new LinkPersistInfo(this.btnServiceMoreCommands, true),
				new LinkPersistInfo(this.btnChangeServiceStartType, true),
				new LinkPersistInfo(this.barButtonExport, true)
			});
			this.barMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMenu.OptionsBar.MultiLine = true;
			this.barMenu.OptionsBar.UseWholeRow = true;
			resources.ApplyResources(this.barMenu, "barMenu");
			resources.ApplyResources(this.barEditServicesToShow, "barEditServicesToShow");
			this.barEditServicesToShow.Edit = this.repositoryComboBoxServicesToShow;
			this.barEditServicesToShow.Id = 6;
			this.barEditServicesToShow.Name = "barEditServicesToShow";
			this.barEditServicesToShow.PaintStyle = BarItemPaintStyle.Caption;
			this.barEditServicesToShow.EditValueChanged += this.barEditServicesToShow_EditValueChanged;
			resources.ApplyResources(this.repositoryComboBoxServicesToShow, "repositoryComboBoxServicesToShow");
			this.repositoryComboBoxServicesToShow.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryComboBoxServicesToShow.Buttons"))
			});
			this.repositoryComboBoxServicesToShow.Name = "repositoryComboBoxServicesToShow";
			this.repositoryComboBoxServicesToShow.TextEditStyle = TextEditStyles.DisableTextEditor;
			this.btnRefresh.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnRefresh, "btnRefresh");
			this.btnRefresh.Id = 1;
			this.btnRefresh.ImageOptions.Image = Resources.refresh2_16x16;
			this.btnRefresh.ImageOptions.LargeImage = Resources.refresh2_32x32;
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnRefresh.ItemClick += this.btnRefresh_ItemClick;
			this.btnStartService.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnStartService, "btnStartService");
			this.btnStartService.Id = 9;
			this.btnStartService.ImageOptions.Image = Resources.play_16x16;
			this.btnStartService.ImageOptions.LargeImage = Resources.play_32x32;
			this.btnStartService.Name = "btnStartService";
			this.btnStartService.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnStartService.ItemClick += this.btnStartService_ItemClick;
			this.btnStopService.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnStopService, "btnStopService");
			this.btnStopService.Id = 10;
			this.btnStopService.ImageOptions.Image = Resources.stop_16x16;
			this.btnStopService.ImageOptions.LargeImage = Resources.stop_32x32;
			this.btnStopService.Name = "btnStopService";
			this.btnStopService.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnStopService.ItemClick += this.btnStopService_ItemClick;
			this.btnRestartService.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnRestartService, "btnRestartService");
			this.btnRestartService.Id = 13;
			this.btnRestartService.ImageOptions.Image = Resources.refreshallpivottable_16x16;
			this.btnRestartService.ImageOptions.LargeImage = Resources.refreshallpivottable_32x32;
			this.btnRestartService.Name = "btnRestartService";
			this.btnRestartService.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnRestartService.ItemClick += this.btnRestartService_ItemClick;
			this.btnServiceMoreCommands.ButtonStyle = BarButtonStyle.DropDown;
			resources.ApplyResources(this.btnServiceMoreCommands, "btnServiceMoreCommands");
			this.btnServiceMoreCommands.DropDownControl = this.menuServiceMoreCommands;
			this.btnServiceMoreCommands.Id = 20;
			this.btnServiceMoreCommands.Name = "btnServiceMoreCommands";
			this.btnPauseService.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnPauseService, "btnPauseService");
			this.btnPauseService.Id = 11;
			this.btnPauseService.ImageOptions.Image = Resources.pause_16x16;
			this.btnPauseService.ImageOptions.LargeImage = Resources.pause_32x32;
			this.btnPauseService.Name = "btnPauseService";
			this.btnPauseService.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnPauseService.ItemClick += this.btnPauseService_ItemClick;
			this.btnResumeService.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnResumeService, "btnResumeService");
			this.btnResumeService.Id = 12;
			this.btnResumeService.ImageOptions.Image = Resources.play_16x16;
			this.btnResumeService.ImageOptions.LargeImage = Resources.play_32x32;
			this.btnResumeService.Name = "btnResumeService";
			this.btnResumeService.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnResumeService.ItemClick += this.btnResumeService_ItemClick;
			this.btnChangeServiceStartType.Border = BorderStyles.Simple;
			this.btnChangeServiceStartType.ButtonStyle = BarButtonStyle.DropDown;
			resources.ApplyResources(this.btnChangeServiceStartType, "btnChangeServiceStartType");
			this.btnChangeServiceStartType.DropDownControl = this.menuChangeServiceStartType;
			this.btnChangeServiceStartType.Id = 14;
			this.btnChangeServiceStartType.ImageOptions.Image = Resources.properties_16x16;
			this.btnChangeServiceStartType.ImageOptions.LargeImage = Resources.properties_32x32;
			this.btnChangeServiceStartType.Name = "btnChangeServiceStartType";
			this.btnChangeServiceStartType.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.menuChangeServiceStartType.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.miServiceStartTypeAutoStart),
				new LinkPersistInfo(this.miServiceStartTypeAutostartDelayed),
				new LinkPersistInfo(this.miServiceStartTypeOnDemand),
				new LinkPersistInfo(this.miServiceStartTypeDisabled)
			});
			this.menuChangeServiceStartType.Manager = this.barManager;
			this.menuChangeServiceStartType.Name = "menuChangeServiceStartType";
			resources.ApplyResources(this.miServiceStartTypeAutoStart, "miServiceStartTypeAutoStart");
			this.miServiceStartTypeAutoStart.Id = 15;
			this.miServiceStartTypeAutoStart.Name = "miServiceStartTypeAutoStart";
			this.miServiceStartTypeAutoStart.ItemClick += this.miServiceStartTypeAutoStart_ItemClick;
			resources.ApplyResources(this.miServiceStartTypeAutostartDelayed, "miServiceStartTypeAutostartDelayed");
			this.miServiceStartTypeAutostartDelayed.Id = 18;
			this.miServiceStartTypeAutostartDelayed.Name = "miServiceStartTypeAutostartDelayed";
			this.miServiceStartTypeAutostartDelayed.ItemClick += this.miServiceStartTypeAutostartDelayed_ItemClick;
			resources.ApplyResources(this.miServiceStartTypeOnDemand, "miServiceStartTypeOnDemand");
			this.miServiceStartTypeOnDemand.Id = 16;
			this.miServiceStartTypeOnDemand.Name = "miServiceStartTypeOnDemand";
			this.miServiceStartTypeOnDemand.ItemClick += this.miServiceStartTypeOnDemand_ItemClick;
			resources.ApplyResources(this.miServiceStartTypeDisabled, "miServiceStartTypeDisabled");
			this.miServiceStartTypeDisabled.Id = 17;
			this.miServiceStartTypeDisabled.Name = "miServiceStartTypeDisabled";
			this.miServiceStartTypeDisabled.ItemClick += this.miServiceStartTypeDisabled_ItemClick;
			this.barButtonExport.Border = BorderStyles.Simple;
			resources.ApplyResources(this.barButtonExport, "barButtonExport");
			this.barButtonExport.Id = 8;
			this.barButtonExport.Name = "barButtonExport";
			this.barButtonExport.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonExport.Visibility = BarItemVisibility.Never;
			this.barDockControlTop.CausesValidation = false;
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlBottom.CausesValidation = false;
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlLeft.CausesValidation = false;
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControl1.CausesValidation = false;
			resources.ApplyResources(this.barDockControl1, "barDockControl1");
			this.barDockControl1.Manager = this.barManager;
			resources.ApplyResources(this.gridServicesList, "gridServicesList");
			this.gridServicesList.MainView = this.gridViewServicesList;
			this.gridServicesList.MenuManager = this.barManager;
			this.gridServicesList.Name = "gridServicesList";
			this.gridServicesList.ViewCollection.AddRange(new BaseView[]
			{
				this.gridViewServicesList
			});
			this.gridViewServicesList.Columns.AddRange(new GridColumn[]
			{
				this.columnDeviceName,
				this.columnServiceName,
				this.columnDisplayName,
				this.columnDescription,
				this.columnStateAsString,
				this.columnStartType,
				this.columnServiceType,
				this.columnDelayedAutoStart,
				this.columnHidden,
				this.columnState
			});
			this.gridViewServicesList.GridControl = this.gridServicesList;
			this.gridViewServicesList.Name = "gridViewServicesList";
			this.gridViewServicesList.OptionsBehavior.Editable = false;
			this.gridViewServicesList.OptionsSelection.MultiSelect = true;
			this.gridViewServicesList.OptionsView.EnableAppearanceEvenRow = true;
			this.gridViewServicesList.SortInfo.AddRange(new GridColumnSortInfo[]
			{
				new GridColumnSortInfo(this.columnServiceName, ColumnSortOrder.Ascending),
				new GridColumnSortInfo(this.columnDisplayName, ColumnSortOrder.Ascending)
			});
			this.gridViewServicesList.CustomRowFilter += this.gridViewServicesList_CustomRowFilter;
			this.columnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDeviceName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDeviceName, "columnDeviceName");
			this.columnDeviceName.FieldName = "AgentItem.DeviceItem.Name";
			this.columnDeviceName.Name = "columnDeviceName";
			this.columnServiceName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnServiceName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnServiceName, "columnServiceName");
			this.columnServiceName.FieldName = "ServiceInfo.Name";
			this.columnServiceName.Name = "columnServiceName";
			this.columnDisplayName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDisplayName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDisplayName, "columnDisplayName");
			this.columnDisplayName.FieldName = "ServiceInfo.DisplayName";
			this.columnDisplayName.Name = "columnDisplayName";
			this.columnDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDescription.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDescription, "columnDescription");
			this.columnDescription.FieldName = "ServiceInfo.Description";
			this.columnDescription.MinWidth = 25;
			this.columnDescription.Name = "columnDescription";
			this.columnStateAsString.AppearanceHeader.Options.UseTextOptions = true;
			this.columnStateAsString.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnStateAsString, "columnStateAsString");
			this.columnStateAsString.FieldName = "StateAsString";
			this.columnStateAsString.MaxWidth = 120;
			this.columnStateAsString.Name = "columnStateAsString";
			this.columnStartType.AppearanceHeader.Options.UseTextOptions = true;
			this.columnStartType.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnStartType, "columnStartType");
			this.columnStartType.FieldName = "StartTypeAsString";
			this.columnStartType.MaxWidth = 170;
			this.columnStartType.Name = "columnStartType";
			this.columnServiceType.AppearanceCell.Options.UseTextOptions = true;
			this.columnServiceType.AppearanceCell.TextOptions.HAlignment = HorzAlignment.Far;
			this.columnServiceType.AppearanceHeader.Options.UseTextOptions = true;
			this.columnServiceType.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnServiceType, "columnServiceType");
			this.columnServiceType.FieldName = "ServiceInfo.ServiceType";
			this.columnServiceType.Name = "columnServiceType";
			resources.ApplyResources(this.columnDelayedAutoStart, "columnDelayedAutoStart");
			this.columnDelayedAutoStart.FieldName = "ServiceInfo.DelayedAutoStart";
			this.columnDelayedAutoStart.MinWidth = 25;
			this.columnDelayedAutoStart.Name = "columnDelayedAutoStart";
			this.columnHidden.FieldName = "Hidden";
			this.columnHidden.MinWidth = 25;
			this.columnHidden.Name = "columnHidden";
			this.columnHidden.OptionsColumn.ShowInCustomizationForm = false;
			this.columnHidden.OptionsColumn.ShowInExpressionEditor = false;
			resources.ApplyResources(this.columnHidden, "columnHidden");
			resources.ApplyResources(this.columnState, "columnState");
			this.columnState.FieldName = "ServiceInfo.State";
			this.columnState.MinWidth = 25;
			this.columnState.Name = "columnState";
			this.columnState.OptionsColumn.ShowInCustomizationForm = false;
			this.columnState.OptionsColumn.ShowInExpressionEditor = false;
			this.menuServiceMoreCommands.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.btnPauseService),
				new LinkPersistInfo(this.btnResumeService)
			});
			this.menuServiceMoreCommands.Manager = this.barManager;
			this.menuServiceMoreCommands.Name = "menuServiceMoreCommands";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.gridServicesList);
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControl1);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "ServicesView";
			((ISupportInitialize)this.barManager).EndInit();
			((ISupportInitialize)this.repositoryComboBoxServicesToShow).EndInit();
			((ISupportInitialize)this.menuChangeServiceStartType).EndInit();
			((ISupportInitialize)this.gridServicesList).EndInit();
			((ISupportInitialize)this.gridViewServicesList).EndInit();
			((ISupportInitialize)this.menuServiceMoreCommands).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400063B RID: 1595
		private AgentTaskThrottler _agentTaskThrottler;

		// Token: 0x0400063C RID: 1596
		private BindingList<ServicesView.AgentItemAndServiceInfo> _servicesList;

		// Token: 0x0400063D RID: 1597
		private ServicesView.ServicesToShow _servicesToShow;

		// Token: 0x04000640 RID: 1600
		private IContainer components;

		// Token: 0x04000641 RID: 1601
		private BarManager barManager;

		// Token: 0x04000642 RID: 1602
		private Bar barMenu;

		// Token: 0x04000643 RID: 1603
		private BarEditItem barEditServicesToShow;

		// Token: 0x04000644 RID: 1604
		private RepositoryItemComboBox repositoryComboBoxServicesToShow;

		// Token: 0x04000645 RID: 1605
		private BarButtonItem btnRefresh;

		// Token: 0x04000646 RID: 1606
		private BarButtonItem barButtonExport;

		// Token: 0x04000647 RID: 1607
		private BarDockControl barDockControlTop;

		// Token: 0x04000648 RID: 1608
		private BarDockControl barDockControlBottom;

		// Token: 0x04000649 RID: 1609
		private BarDockControl barDockControlLeft;

		// Token: 0x0400064A RID: 1610
		private BarDockControl barDockControl1;

		// Token: 0x0400064B RID: 1611
		private GridControl gridServicesList;

		// Token: 0x0400064C RID: 1612
		private GridView gridViewServicesList;

		// Token: 0x0400064D RID: 1613
		private GridColumn columnDeviceName;

		// Token: 0x0400064E RID: 1614
		private GridColumn columnServiceName;

		// Token: 0x0400064F RID: 1615
		private GridColumn columnDisplayName;

		// Token: 0x04000650 RID: 1616
		private GridColumn columnStateAsString;

		// Token: 0x04000651 RID: 1617
		private GridColumn columnStartType;

		// Token: 0x04000652 RID: 1618
		private GridColumn columnServiceType;

		// Token: 0x04000653 RID: 1619
		private GridColumn columnDescription;

		// Token: 0x04000654 RID: 1620
		private GridColumn columnDelayedAutoStart;

		// Token: 0x04000655 RID: 1621
		private BarButtonItem btnStartService;

		// Token: 0x04000656 RID: 1622
		private BarButtonItem btnStopService;

		// Token: 0x04000657 RID: 1623
		private BarButtonItem btnPauseService;

		// Token: 0x04000658 RID: 1624
		private BarButtonItem btnResumeService;

		// Token: 0x04000659 RID: 1625
		private BarButtonItem btnRestartService;

		// Token: 0x0400065A RID: 1626
		private BarButtonItem btnChangeServiceStartType;

		// Token: 0x0400065B RID: 1627
		private PopupMenu menuChangeServiceStartType;

		// Token: 0x0400065C RID: 1628
		private BarButtonItem miServiceStartTypeAutoStart;

		// Token: 0x0400065D RID: 1629
		private BarButtonItem miServiceStartTypeOnDemand;

		// Token: 0x0400065E RID: 1630
		private BarButtonItem miServiceStartTypeDisabled;

		// Token: 0x0400065F RID: 1631
		private BarButtonItem miServiceStartTypeAutostartDelayed;

		// Token: 0x04000660 RID: 1632
		private GridColumn columnHidden;

		// Token: 0x04000661 RID: 1633
		private GridColumn columnState;

		// Token: 0x04000662 RID: 1634
		private BarButtonItem btnServiceMoreCommands;

		// Token: 0x04000663 RID: 1635
		private PopupMenu menuServiceMoreCommands;

		// Token: 0x020001AC RID: 428
		private enum ServicesToShow
		{
			// Token: 0x04000B1C RID: 2844
			Services,
			// Token: 0x04000B1D RID: 2845
			OnlyStartedServices,
			// Token: 0x04000B1E RID: 2846
			All
		}

		// Token: 0x020001AD RID: 429
		private class AgentItemAndServiceInfo : INotifyPropertyChanged
		{
			// Token: 0x06000BFF RID: 3071 RVA: 0x00064E52 File Offset: 0x00063052
			public AgentItemAndServiceInfo(AgentItem agentItem, ServiceInfo serviceInfo)
			{
				this.AgentItem = agentItem;
				this.ServiceInfo = serviceInfo;
			}

			// Token: 0x1400000A RID: 10
			// (add) Token: 0x06000C00 RID: 3072 RVA: 0x00064E68 File Offset: 0x00063068
			// (remove) Token: 0x06000C01 RID: 3073 RVA: 0x00064EA0 File Offset: 0x000630A0
			public event PropertyChangedEventHandler PropertyChanged;

			// Token: 0x17000306 RID: 774
			// (get) Token: 0x06000C02 RID: 3074 RVA: 0x00064ED5 File Offset: 0x000630D5
			public AgentItem AgentItem { get; }

			// Token: 0x17000307 RID: 775
			// (get) Token: 0x06000C03 RID: 3075 RVA: 0x00064EDD File Offset: 0x000630DD
			// (set) Token: 0x06000C04 RID: 3076 RVA: 0x00064EE5 File Offset: 0x000630E5
			public bool Hidden
			{
				get
				{
					return this._hidden;
				}
				set
				{
					if (this._hidden != value)
					{
						this._hidden = value;
						this.NotifyPropertyChanged("Hidden");
					}
				}
			}

			// Token: 0x17000308 RID: 776
			// (get) Token: 0x06000C05 RID: 3077 RVA: 0x00064F02 File Offset: 0x00063102
			// (set) Token: 0x06000C06 RID: 3078 RVA: 0x00064F0A File Offset: 0x0006310A
			public ServiceInfo ServiceInfo
			{
				get
				{
					return this._serviceInfo;
				}
				set
				{
					this._serviceInfo = value;
					this.NotifyPropertyChanged("ServiceInfo");
					this.ChangeServiceState(this._serviceInfo.State);
					this.ChangeServiceStartType(this._serviceInfo.StartType);
				}
			}

			// Token: 0x17000309 RID: 777
			// (get) Token: 0x06000C07 RID: 3079 RVA: 0x00064F40 File Offset: 0x00063140
			// (set) Token: 0x06000C08 RID: 3080 RVA: 0x00064F48 File Offset: 0x00063148
			public string StartTypeAsString { get; private set; }

			// Token: 0x1700030A RID: 778
			// (get) Token: 0x06000C09 RID: 3081 RVA: 0x00064F51 File Offset: 0x00063151
			// (set) Token: 0x06000C0A RID: 3082 RVA: 0x00064F59 File Offset: 0x00063159
			public string StateAsString { get; private set; }

			// Token: 0x06000C0B RID: 3083 RVA: 0x00064F62 File Offset: 0x00063162
			public void ChangeServiceStartType(uint startType)
			{
				this._serviceInfo.StartType = startType;
				this.StartTypeAsString = this._serviceInfo.GetServiceStartTypeDescription();
				this.NotifyPropertyChanged("StartTypeAsString");
			}

			// Token: 0x06000C0C RID: 3084 RVA: 0x00064F8C File Offset: 0x0006318C
			public void ChangeServiceState(uint state)
			{
				this._serviceInfo.State = state;
				ServiceState newState = (ServiceState)this._serviceInfo.State;
				this.StateAsString = "";
				if (newState != ServiceState.Stopped)
				{
					this.StateAsString = SsStringUtils.GetEnumDescriptionFromResource<ServiceState>(newState, null, null);
				}
				this.NotifyPropertyChanged("StateAsString");
			}

			// Token: 0x06000C0D RID: 3085 RVA: 0x00064FD9 File Offset: 0x000631D9
			private void NotifyPropertyChanged(string name)
			{
				PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
				if (propertyChanged == null)
				{
					return;
				}
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}

			// Token: 0x04000B1F RID: 2847
			private bool _hidden;

			// Token: 0x04000B20 RID: 2848
			private ServiceInfo _serviceInfo;
		}
	}
}
