﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using OpiekunWEB.Console.Events;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000AD RID: 173
	public class ViewsManager
	{
		// Token: 0x060008F5 RID: 2293 RVA: 0x00051CCD File Offset: 0x0004FECD
		public ViewsManager(IFormCreator formCreator, ObservableAgregator observableAgregator, Control workspaceFullControl, Control workspaceDeviceTreeControl, Control workspaceDeviceTreePanel)
		{
			this._formCreator = formCreator;
			this._observableAgregator = observableAgregator;
			this._workspaceFullControl = workspaceFullControl;
			this._workspaceDeviceTreeControl = workspaceDeviceTreeControl;
			this._workspaceDeviceTreePanel = workspaceDeviceTreePanel;
			this.InitializeViews();
		}

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x060008F6 RID: 2294 RVA: 0x00051D00 File Offset: 0x0004FF00
		public ScreenshotsView ScreenshotsView
		{
			get
			{
				return this._screenShotViewInfo.Control as ScreenshotsView;
			}
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x00051D14 File Offset: 0x0004FF14
		public void ChangeViewForCurrentGroup(string viewName)
		{
			IViewInfo view = this._currentViewGroup.FindView(viewName);
			ViewGroup currentViewGroup = this._currentViewGroup;
			IViewInfo viewInfo = view;
			if (viewInfo == null)
			{
				throw new Exception("View does not exists:" + viewName);
			}
			currentViewGroup.CurrentView = viewInfo;
			this.ShowView(this._currentViewGroup.CurrentView);
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x00051D60 File Offset: 0x0004FF60
		public void DoneViews()
		{
			foreach (ViewGroup viewGroup in this._viewGroups)
			{
				foreach (IViewInfo view in viewGroup.Views)
				{
					if (view.ControlCreated && !view.ControlDisposed)
					{
						view.Control.Dispose();
						view.ControlDisposed = true;
					}
				}
			}
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x00051DE8 File Offset: 0x0004FFE8
		public void RefreshCurrentView()
		{
			if (this._currentView != null)
			{
				this._observableAgregator.SendViewChangedEvent(new ViewChangedEvent(this._currentView));
			}
		}

		// Token: 0x060008FA RID: 2298 RVA: 0x00051E08 File Offset: 0x00050008
		public void ShowViewGroup(string groupName)
		{
			ViewGroup group = this._viewGroups.Find((ViewGroup x) => x.Name == groupName);
			ViewGroup viewGroup = group;
			if (viewGroup == null)
			{
				throw new Exception("Group does not exists:" + groupName);
			}
			this._currentViewGroup = viewGroup;
			this.ShowView(this._currentViewGroup.CurrentView);
		}

		// Token: 0x060008FB RID: 2299 RVA: 0x00051E6C File Offset: 0x0005006C
		private void InitializeViews()
		{
			this._screenShotViewInfo = new ViewInfo<ScreenshotsView>(this._formCreator, ViewWorkspaceType.DeviceTree);
			ViewGroup groupWelcome = new ViewGroup(new ViewInfo<WelcomeView>(this._formCreator, ViewWorkspaceType.Full), "Welcome");
			ViewGroup groupTools = new ViewGroup(this._screenShotViewInfo, "Tools");
			ViewGroup groupConfig = new ViewGroup(new IViewInfo[]
			{
				new ViewInfo<ConfigLogView>(this._formCreator, ViewWorkspaceType.DeviceTree)
			}, "Config");
			ViewGroup groupControl = new ViewGroup(new IViewInfo[]
			{
				this._screenShotViewInfo,
				new ViewInfo<HistoryView>(this._formCreator, ViewWorkspaceType.DeviceTree),
				new ViewInfo<AppHistoryView>(this._formCreator, ViewWorkspaceType.DeviceTree)
			}, "Control");
			ViewGroup groupApplications = new ViewGroup(new IViewInfo[]
			{
				new ViewInfo<ProcessesView>(this._formCreator, ViewWorkspaceType.DeviceTree),
				new ViewInfo<ServicesView>(this._formCreator, ViewWorkspaceType.DeviceTree),
				new ViewInfo<PackagesView>(this._formCreator, ViewWorkspaceType.DeviceTree)
			}, "Applications");
			this._viewGroups = new List<ViewGroup>();
			this._viewGroups.AddRange(new ViewGroup[]
			{
				groupWelcome,
				groupTools,
				groupControl,
				groupApplications,
				groupConfig
			});
		}

		// Token: 0x060008FC RID: 2300 RVA: 0x00051F7C File Offset: 0x0005017C
		private void ShowView(IViewInfo viewInfo)
		{
			if (this._currentView == viewInfo)
			{
				return;
			}
			Cursor current = Cursor.Current;
			Cursor.Current = Cursors.WaitCursor;
			Control container;
			if (viewInfo.WorkspaceType == ViewWorkspaceType.DeviceTree)
			{
				container = this._workspaceDeviceTreePanel;
			}
			else
			{
				container = this._workspaceFullControl;
			}
			Control parent = container.Parent;
			if (parent != null)
			{
				parent.SuspendLayout();
			}
			container.SuspendLayout();
			try
			{
				Control controlToShow = viewInfo.Control;
				controlToShow.Bounds = container.DisplayRectangle;
				this._currentView = viewInfo;
				controlToShow.Visible = false;
				container.Controls.Clear();
				container.Controls.Add(controlToShow);
				controlToShow.Dock = DockStyle.Fill;
				controlToShow.Visible = true;
				if (viewInfo.WorkspaceType == ViewWorkspaceType.Full && !this._workspaceFullControl.Visible)
				{
					this._workspaceFullControl.Visible = true;
				}
				if (viewInfo.WorkspaceType == ViewWorkspaceType.DeviceTree && !this._workspaceDeviceTreeControl.Visible)
				{
					this._workspaceDeviceTreeControl.Visible = true;
				}
			}
			finally
			{
				this._currentView = viewInfo;
				this._observableAgregator.SendViewChangedEvent(new ViewChangedEvent(this._currentView));
				container.ResumeLayout(true);
				Control parent2 = container.Parent;
				if (parent2 != null)
				{
					parent2.ResumeLayout(true);
				}
				Cursor.Current = current;
			}
		}

		// Token: 0x040006FC RID: 1788
		private readonly IFormCreator _formCreator;

		// Token: 0x040006FD RID: 1789
		private readonly ObservableAgregator _observableAgregator;

		// Token: 0x040006FE RID: 1790
		private readonly Control _workspaceDeviceTreeControl;

		// Token: 0x040006FF RID: 1791
		private readonly Control _workspaceDeviceTreePanel;

		// Token: 0x04000700 RID: 1792
		private readonly Control _workspaceFullControl;

		// Token: 0x04000701 RID: 1793
		private IViewInfo _currentView;

		// Token: 0x04000702 RID: 1794
		private ViewGroup _currentViewGroup;

		// Token: 0x04000703 RID: 1795
		private ViewInfo<ScreenshotsView> _screenShotViewInfo;

		// Token: 0x04000704 RID: 1796
		private List<ViewGroup> _viewGroups;
	}
}
