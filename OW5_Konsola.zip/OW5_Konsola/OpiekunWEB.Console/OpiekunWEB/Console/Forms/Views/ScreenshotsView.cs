﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Reactive.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Windows.Threading;
using DevExpress.LookAndFeel;
using DevExpress.Skins;
using DevExpress.Utils;
using DevExpress.Utils.Drawing;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraBars.Ribbon.Gallery;
using DevExpress.XtraBars.Ribbon.ViewInfo;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000AA RID: 170
	public class ScreenshotsView : BaseView, ICommandTarget
	{
		// Token: 0x060008BE RID: 2238 RVA: 0x0004F6B0 File Offset: 0x0004D8B0
		public ScreenshotsView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, ApiClient apiClient, DevicesTree devicesTree, IPopupMenuCreator popupMenuCreator, IIconsProvider iconsProvider) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._iconsProvider = iconsProvider;
			this.galleryControl.Invalidated += this.GalleryControlOnInvalidated;
			this.galleryControl.Gallery.Groups.Add(new GalleryItemGroup
			{
				Caption = string.Empty
			});
			this._textOnScreenshotFont = new Font("Arial", 7f, FontStyle.Bold);
			this._textOnScreenshotBrush = new SolidBrush(Color.AntiqueWhite);
			this._errorTextOnScreenshotBrush = new SolidBrush(Color.OrangeRed);
			this._screenBackgroundBrush = new SolidBrush(Color.FromArgb(229, 229, 229));
			this._sfCenter = new StringFormat
			{
				Alignment = StringAlignment.Center,
				LineAlignment = StringAlignment.Center,
				Trimming = StringTrimming.EllipsisCharacter
			};
			this._refreshTimer = new Timer
			{
				Enabled = false
			};
			this._refreshTimer.Tick += this.RefreshTimerOnTick;
			this._gallleryGetItemInfoMethod = this.galleryControl.Gallery.GetType().GetMethod("GetItemInfo", BindingFlags.Instance | BindingFlags.NonPublic);
			this._thumbnailBackgroundTemplate = Resources.screenshot_background;
			this._thumbnailShadowTemplate = Resources.screenshot_shadow;
			this._settings = this._formsSettings.RestoreObjectStateFromJson<ScreenshotViewSettings>(base.Name, "ScreenshotViewOptions", new ScreenshotViewSettings
			{
				ScreenshotItemDescriptionsKind = new List<ScreenshotItemDescription>
				{
					ScreenshotItemDescription.DeviceName
				}
			});
			this._thumbnailInfo = this.GetThumbnailInforScreenshotSize(this._thumbnailScrenshotMinSize);
			this.barEditScreenshotZoom.EditValue = 12;
			this.barEditScreenshotQuality.EditValue = 90;
			this._apiClient.AgentWindowsSessionChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentWindowsSessionChanged));
			this._observableAgregator.AgentConnectionChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentConnectionChanged));
			RefreshTimes.InitializeComboBoxRefreshTimes(this.repositoryComboBoxRefreshTime);
			this.barEditRefreshTime.EditValue = RefreshTimes.GetDefaultText();
			popupMenuCreator.FillPopupMenu(this.popupMenu, PopupMenuKind.DeviceScreenshot, this);
			this._objectsToSaveState.Add(this.barEditScreenshotZoom);
			this._objectsToSaveState.Add(this.barEditScreenshotAutosize);
			this._objectsToSaveState.Add(this.barEditScreenshotQuality);
			this._objectsToSaveState.Add(this.barEditRefreshTime);
			LookAndFeelHelper.ForceDefaultLookAndFeelChanged();
		}

		// Token: 0x060008BF RID: 2239 RVA: 0x0004F939 File Offset: 0x0004DB39
		public List<AgentItem> GetCommandTargetAsAgentItems()
		{
			return new List<AgentItem>
			{
				this._itemSelectedByPopupMenu.DisplayItem.AgentItem
			};
		}

		// Token: 0x060008C0 RID: 2240 RVA: 0x0004F956 File Offset: 0x0004DB56
		public List<DeviceItem> GetCommandTargetAsDeviceItems()
		{
			return new List<DeviceItem>
			{
				this._itemSelectedByPopupMenu.DeviceItem
			};
		}

		// Token: 0x060008C1 RID: 2241 RVA: 0x0004F96E File Offset: 0x0004DB6E
		public DeviceAndDisplayList GetCommandTargetAsDevicesAndDisplays()
		{
			return new DeviceAndDisplayList
			{
				new DeviceAndDisplay(this._itemSelectedByPopupMenu.DeviceItem, this._itemSelectedByPopupMenu.DisplayItem)
			};
		}

		// Token: 0x060008C2 RID: 2242 RVA: 0x0004F996 File Offset: 0x0004DB96
		public bool IsCommandEnabled(ConsoleEventType systemEvent)
		{
			if (systemEvent == ConsoleEventType.RpcWakeOnLan)
			{
				return !this._itemSelectedByPopupMenu.DeviceItem.IsConnected;
			}
			return this._itemSelectedByPopupMenu.DeviceItem.IsConnected;
		}

		// Token: 0x060008C3 RID: 2243 RVA: 0x0004F9C4 File Offset: 0x0004DBC4
		protected override void AfterRestoreState()
		{
			this.SetRefreshTimer(RefreshTimes.GetRefreshTime(this.barEditRefreshTime.EditValue as string));
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x0004F9E4 File Offset: 0x0004DBE4
		protected Size GetAutoScaleSize(Size desktop, Size thumbnailMinSize, int thumbnailCount)
		{
			int size = desktop.Width / thumbnailCount;
			float aspectRatio = (float)thumbnailMinSize.Width / (float)thumbnailMinSize.Height;
			if (size >= thumbnailMinSize.Width)
			{
				return new Size(size, (int)((float)size / aspectRatio));
			}
			return this.GetAutoScaleSize(desktop, thumbnailMinSize, thumbnailCount - 1);
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x0004FA30 File Offset: 0x0004DC30
		protected override void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			List<ScreenshotsView.ScreenshotItem> newItems = new List<ScreenshotsView.ScreenshotItem>();
			this.galleryControl.Gallery.BeginUpdate();
			if (this.galleryControl.Gallery.Groups.Count > 0)
			{
				foreach (DeviceAndDisplay deviceAndDisplay in selection.SelectionChanges.DeviceAndDisplayRemoved)
				{
					ScreenshotsView.ScreenshotItem item = this.FindScreenshotItem(deviceAndDisplay);
					if (item != null)
					{
						this.galleryControl.Gallery.Groups[0].Items.Remove(item);
					}
				}
				foreach (DeviceAndDisplay deviceAndDisplay2 in selection.SelectionChanges.DeviceAndDisplayAdded)
				{
					ScreenshotsView.ScreenshotItem item2 = new ScreenshotsView.ScreenshotItem(deviceAndDisplay2);
					this.galleryControl.Gallery.Groups[0].Items.Insert(this.FindIndexToInsertNewScreenshotItem(deviceAndDisplay2), item2);
					newItems.Add(item2);
				}
			}
			this.galleryControl.Gallery.EndUpdate();
			Size oldItemSize = this.galleryControl.Gallery.ItemSize;
			this.SetScreenshotsSize();
			if (!base.IsCurrentView)
			{
				return;
			}
			if (oldItemSize != this.galleryControl.Gallery.ItemSize)
			{
				this.GetAllScreenshots();
				return;
			}
			foreach (ScreenshotsView.ScreenshotItem item3 in newItems)
			{
				this.GetScreenshot(item3);
			}
		}

		// Token: 0x060008C6 RID: 2246 RVA: 0x0004FBEC File Offset: 0x0004DDEC
		protected override void ViewActivate()
		{
			base.ViewActivate();
			this.SetScreenshotsSize();
			this.GetAllScreenshots();
			this._refreshTimer.Enabled = (this._refreshTimer.Interval > 1);
		}

		// Token: 0x060008C7 RID: 2247 RVA: 0x0004FC19 File Offset: 0x0004DE19
		protected override void ViewDeactivate()
		{
			base.ViewDeactivate();
			this._refreshTimer.Enabled = false;
		}

		// Token: 0x060008C8 RID: 2248 RVA: 0x0004FC30 File Offset: 0x0004DE30
		protected override void WndProc(ref Message m)
		{
			if (m.Msg == 1035)
			{
				if (this.galleryControl.Gallery.Groups.Count == 0)
				{
					return;
				}
				foreach (object obj in this.galleryControl.Gallery.Groups[0].Items)
				{
					ScreenshotsView.ScreenshotItem screenshotItem = obj as ScreenshotsView.ScreenshotItem;
					bool isVisibleNow = this.IsGaleryItemVisible(screenshotItem);
					if (!screenshotItem.IsVisible && isVisibleNow)
					{
						this.GetScreenshot(screenshotItem);
					}
					screenshotItem.IsVisible = isVisibleNow;
				}
			}
			base.WndProc(ref m);
		}

		// Token: 0x060008C9 RID: 2249 RVA: 0x0004FCEC File Offset: 0x0004DEEC
		private void barEditScreenshotAutosize_CheckedChanged(object sender, ItemClickEventArgs e)
		{
			this.SetScreenshotsSize();
			this.GetAllScreenshots();
		}

		// Token: 0x060008CA RID: 2250 RVA: 0x0004FCFA File Offset: 0x0004DEFA
		private void buttonRefresh_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.GetAllScreenshots();
		}

		// Token: 0x060008CB RID: 2251 RVA: 0x0004FD04 File Offset: 0x0004DF04
		private void buttonViewSettings_ItemClick(object sender, ItemClickEventArgs e)
		{
			ScreenshotViewSettings options = this._settings;
			ScreenshotItemSortMode oldSortMode = this._settings.ScreenshotSortMode;
			if (this._formCreator.Show<ScreenshotViewSettingsForm, ScreenshotViewSettings>(FormAction.Unknown, options, out options))
			{
				this._settings = options;
				this._formsSettings.SaveObjectStateAsJson(base.Name, "ScreenshotViewOptions", this._settings);
				if (oldSortMode != this._settings.ScreenshotSortMode)
				{
					List<GalleryItem> items = this.galleryControl.Gallery.GetAllItems();
					if (this.galleryControl.Gallery.Groups.Count > 0)
					{
						this.galleryControl.Gallery.BeginUpdate();
						this.galleryControl.Gallery.Groups[0].Items.Clear();
						foreach (GalleryItem item in items)
						{
							ScreenshotsView.ScreenshotItem screenshotItem = item as ScreenshotsView.ScreenshotItem;
							this.galleryControl.Gallery.Groups[0].Items.Insert(this.FindIndexToInsertNewScreenshotItem(screenshotItem.DeviceAndDisplay), item);
						}
						this.galleryControl.Gallery.EndUpdate();
					}
				}
				this.SetScreenshotsSize();
				this.GetAllScreenshots();
			}
		}

		// Token: 0x060008CC RID: 2252 RVA: 0x0004FE58 File Offset: 0x0004E058
		private int CompareDeviceGroupNames(DeviceItem deviceItem1, DeviceItem deviceItem2)
		{
			if (deviceItem1.ParentId == deviceItem2.ParentId)
			{
				return 0;
			}
			if (deviceItem1.ParentId == this._devicesTree.RootGroupId)
			{
				return -1;
			}
			if (deviceItem2.ParentId == this._devicesTree.RootGroupId)
			{
				return 1;
			}
			return string.Compare(this._devicesTree.GetItemGroupName(deviceItem1), this._devicesTree.GetItemGroupName(deviceItem2), StringComparison.InvariantCultureIgnoreCase);
		}

		// Token: 0x060008CD RID: 2253 RVA: 0x0004FECC File Offset: 0x0004E0CC
		private ScreenshotsView.ThumbnailInfo ComputeThumbnailAutoSize(Size deskSize, Size screnshotAreaMinSize, Size thumbnailMargins, int imgCount)
		{
			deskSize.Width -= thumbnailMargins.Width;
			deskSize.Height -= thumbnailMargins.Height;
			ScreenshotsView.ThumbnailInfo bestSizeInfo = this.GetThumbnailInforScreenshotSize(screnshotAreaMinSize);
			ScreenshotsView.ThumbnailInfo tmpSizeInfo = bestSizeInfo;
			Size tmpScreenshotSize = bestSizeInfo.ScreenshotSize;
			float aspectRatio = (float)this._thumbnailScrenshotMinSize.Width / (float)this._thumbnailScrenshotMinSize.Height;
			for (;;)
			{
				Size tmpSize = tmpSizeInfo.ThumbnailSize;
				int columns = deskSize.Width / (tmpSize.Width + thumbnailMargins.Width);
				if (columns == 0)
				{
					break;
				}
				int rows = imgCount / columns;
				if (rows * columns < imgCount)
				{
					rows++;
				}
				int height = tmpSize.Height + thumbnailMargins.Height;
				if (rows * height > deskSize.Height)
				{
					return bestSizeInfo;
				}
				bestSizeInfo = tmpSizeInfo;
				int width = tmpScreenshotSize.Width;
				tmpScreenshotSize.Width = width + 1;
				tmpScreenshotSize.Height = (int)((float)tmpScreenshotSize.Width / aspectRatio);
				tmpSizeInfo = this.GetThumbnailInforScreenshotSize(tmpScreenshotSize);
			}
			return bestSizeInfo;
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x0004FFC7 File Offset: 0x0004E1C7
		private void CopyRegionIntoImage(Image srcBitmap, Rectangle srcRect, Graphics dstBitmap, Rectangle destRect)
		{
			dstBitmap.DrawImage(srcBitmap, destRect, srcRect.X, srcRect.Y, srcRect.Width, srcRect.Height, GraphicsUnit.Pixel);
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x0004FFF0 File Offset: 0x0004E1F0
		private Bitmap CreateThumbnailBackgroundImage(Size thumbnailSize, Size shadowSize, int frameSize, int descriptionHeight)
		{
			Bitmap result = new Bitmap(thumbnailSize.Width, thumbnailSize.Height);
			Rectangle screenBounds = new Rectangle(0, 0, thumbnailSize.Width - shadowSize.Width, thumbnailSize.Height - shadowSize.Height);
			using (Graphics graphics = Graphics.FromImage(result))
			{
				Rectangle srcRect;
				Rectangle dstRect;
				if (shadowSize.Width != 0 || shadowSize.Height != 0)
				{
					srcRect = new Rectangle(0, 0, this._thumbnailShadowTemplate.Width, this._thumbnailShadowTemplate.Height);
					dstRect = new Rectangle(0, 0, thumbnailSize.Width, thumbnailSize.Height);
					this.CopyRegionIntoImage(this._thumbnailShadowTemplate, srcRect, graphics, dstRect);
				}
				graphics.FillRectangle(this._screenBackgroundBrush, screenBounds);
				srcRect = new Rectangle(0, 0, 5, 5);
				dstRect = new Rectangle(0, 0, 5, 5);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				srcRect = new Rectangle(this._thumbnailBackgroundTemplate.Width - 5, 0, 5, 5);
				dstRect = new Rectangle(screenBounds.Right - 5, screenBounds.Y, 5, 5);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				srcRect = new Rectangle(0, this._thumbnailBackgroundTemplate.Height - 5, 5, 5);
				dstRect = new Rectangle(screenBounds.X, screenBounds.Bottom - 5, 5, 5);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				srcRect = new Rectangle(this._thumbnailBackgroundTemplate.Width - 5, this._thumbnailBackgroundTemplate.Height - 5, 5, 5);
				dstRect = new Rectangle(screenBounds.Right - 5, screenBounds.Bottom - 5, 5, 5);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				srcRect = new Rectangle(0, 5, 5, this._thumbnailBackgroundTemplate.Height - 10);
				dstRect = new Rectangle(screenBounds.Left, screenBounds.Top + 5, 5, screenBounds.Height - 10);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				srcRect = new Rectangle(this._thumbnailBackgroundTemplate.Width - 5, 5, 5, this._thumbnailBackgroundTemplate.Height - 10);
				dstRect = new Rectangle(screenBounds.Right - 5, screenBounds.Top + 5, 5, screenBounds.Height - 10);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				srcRect = new Rectangle(5, 0, this._thumbnailBackgroundTemplate.Width - 10, 5);
				dstRect = new Rectangle(screenBounds.X + 5, screenBounds.Y, screenBounds.Width - 10, 5);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				srcRect = new Rectangle(5, this._thumbnailBackgroundTemplate.Height - 5, this._thumbnailBackgroundTemplate.Width - 10, 5);
				dstRect = new Rectangle(screenBounds.X + 5, screenBounds.Bottom - 5, screenBounds.Width - 10, 5);
				this.CopyRegionIntoImage(this._thumbnailBackgroundTemplate, srcRect, graphics, dstRect);
				dstRect = new Rectangle(frameSize, frameSize, screenBounds.Width - frameSize * 2, screenBounds.Height - frameSize * 2 - descriptionHeight);
				using (LinearGradientBrush brush = new LinearGradientBrush(dstRect, Color.FromArgb(127, 127, 127), Color.FromArgb(0, 0, 0), LinearGradientMode.ForwardDiagonal))
				{
					graphics.FillRectangle(brush, dstRect);
				}
			}
			return result;
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x00050374 File Offset: 0x0004E574
		private int FindIndexToInsertNewScreenshotItem(DeviceAndDisplay deviceAndDisplay)
		{
			int result = 0;
			if (this.galleryControl.Gallery.Groups.Count > 0)
			{
				ScreenshotItemSortMode screenshotSortMode = this._settings.ScreenshotSortMode;
				if (screenshotSortMode != ScreenshotItemSortMode.DeviceItemAscending)
				{
					if (screenshotSortMode == ScreenshotItemSortMode.DeviceItemInGroupAscending)
					{
						result = -1;
						for (int i = 0; i < this.galleryControl.Gallery.Groups[0].Items.Count; i++)
						{
							ScreenshotsView.ScreenshotItem screenshotItem = this.galleryControl.Gallery.Groups[0].Items[i] as ScreenshotsView.ScreenshotItem;
							if (deviceAndDisplay.DeviceItem.ParentId == screenshotItem.DeviceItem.ParentId)
							{
								if (string.Compare(deviceAndDisplay.DeviceItem.Name, screenshotItem.DeviceItem.Name, StringComparison.InvariantCultureIgnoreCase) < 0)
								{
									result = i;
									break;
								}
								result = i + 1;
							}
						}
						if (result == -1)
						{
							result = this.galleryControl.Gallery.Groups[0].Items.Count;
							for (int j = 0; j < this.galleryControl.Gallery.Groups[0].Items.Count; j++)
							{
								ScreenshotsView.ScreenshotItem screenshotItem2 = this.galleryControl.Gallery.Groups[0].Items[j] as ScreenshotsView.ScreenshotItem;
								if (this.CompareDeviceGroupNames(deviceAndDisplay.DeviceItem, screenshotItem2.DeviceItem) < 0)
								{
									result = j;
									break;
								}
							}
						}
					}
				}
				else
				{
					result = this.galleryControl.Gallery.Groups[0].Items.Count;
					for (int k = 0; k < this.galleryControl.Gallery.Groups[0].Items.Count; k++)
					{
						ScreenshotsView.ScreenshotItem screenshotItem3 = this.galleryControl.Gallery.Groups[0].Items[k] as ScreenshotsView.ScreenshotItem;
						if (string.Compare(deviceAndDisplay.DeviceItem.Name, screenshotItem3.DeviceItem.Name, StringComparison.InvariantCultureIgnoreCase) < 0)
						{
							result = k;
							break;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x00050594 File Offset: 0x0004E794
		private ScreenshotsView.ScreenshotItem FindScreenshotItem(DeviceItem deviceItem, DisplayItem displayItem)
		{
			if (this.galleryControl.Gallery.Groups.Count > 0)
			{
				foreach (ScreenshotsView.ScreenshotItem item in this.galleryControl.Gallery.Groups[0].Items.Cast<ScreenshotsView.ScreenshotItem>())
				{
					if (item.DeviceItem == deviceItem && item.DisplayItem == displayItem)
					{
						return item;
					}
				}
			}
			return null;
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x00050628 File Offset: 0x0004E828
		private ScreenshotsView.ScreenshotItem FindScreenshotItem(DeviceAndDisplay deviceAndDisplay)
		{
			return this.FindScreenshotItem(deviceAndDisplay.DeviceItem, deviceAndDisplay.DisplayItem);
		}

		// Token: 0x060008D3 RID: 2259 RVA: 0x0005063C File Offset: 0x0004E83C
		private void galleryControl_Gallery_ContextButtonClick(object sender, ContextItemClickEventArgs args)
		{
			this.ShowScrennshotZoom(args.DataItem as ScreenshotsView.ScreenshotItem);
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00050650 File Offset: 0x0004E850
		private void galleryControl_Gallery_CustomDrawItemImage(object sender, GalleryItemCustomDrawEventArgs e)
		{
			ScreenshotsView.ScreenshotItem item = e.Item as ScreenshotsView.ScreenshotItem;
			GalleryItemViewInfo itemViewInfo = (GalleryItemViewInfo)e.ItemInfo;
			Rectangle bounds = itemViewInfo.ContentBounds;
			if (this._thumbnailBackgroundImage == null)
			{
				this._thumbnailBackgroundImage = this.CreateThumbnailBackgroundImage(new Size(bounds.Width, bounds.Height), this._thumbnailInfo.ShadowSize, this._thumbnailInfo.FrameMargin, this._thumbnailInfo.DescriptionHeight);
			}
			e.Cache.Graphics.DrawImage(this._thumbnailBackgroundImage, bounds.X, bounds.Y);
			Rectangle screenshotRect = new Rectangle(bounds.X + this._thumbnailInfo.FrameMargin, bounds.Y + this._thumbnailInfo.FrameMargin, this._thumbnailInfo.ScreenshotSize.Width, this._thumbnailInfo.ScreenshotSize.Height);
			if (item.Image == null)
			{
				Brush brush = this._textOnScreenshotBrush;
				string textOnScreenshot = Resources.ScreenshotsView_DeviceNotConnected;
				if (item.DeviceItem.IsConnected)
				{
					if (item.ScreenshotInProgress && item.ErrorMessage == null)
					{
						textOnScreenshot = Resources.ScreenshotsView_TakingScreenshot;
					}
					else
					{
						textOnScreenshot = item.ErrorMessage;
						brush = this._errorTextOnScreenshotBrush;
					}
				}
				if (!string.IsNullOrEmpty(textOnScreenshot))
				{
					Rectangle textRect = screenshotRect;
					textRect.Inflate(-4, -4);
					e.Cache.DrawString(textOnScreenshot, this._textOnScreenshotFont, brush, textRect, this._sfCenter);
				}
			}
			else
			{
				e.Cache.ClipInfo.Graphics.DrawImage(item.Image, screenshotRect);
			}
			if (this._settings.ShowDeviceInetStateIcon)
			{
				Rectangle iconRect = new Rectangle(itemViewInfo.Bounds.X, itemViewInfo.Bounds.Y, 24, 24);
				for (int i = 0; i < item.DeviceItem.DeviceIconIndexes.Length; i++)
				{
					int iconIdx = item.DeviceItem.DeviceIconIndexes[i];
					if (iconIdx != -1)
					{
						e.Cache.DrawImage(this._iconsProvider.DevicesTreeImages24x24.Images[iconIdx], iconRect);
						iconRect.Offset(26, 0);
					}
				}
			}
			Rectangle descriptionRect = new Rectangle(screenshotRect.X, screenshotRect.Y + screenshotRect.Height + 2, screenshotRect.Width, 16);
			for (int j = 0; j < this._settings.ScreenshotItemDescriptionsKind.Count; j++)
			{
				e.Cache.DrawString(item.GetScreenshotDescription(this._settings.ScreenshotItemDescriptionsKind[j]), this.galleryControl.Gallery.Appearance.ItemCaptionAppearance.Normal.Font, Color.FromArgb(40, 40, 40), descriptionRect, this._sfCenter);
				descriptionRect.Y += 16;
			}
			e.Handled = true;
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x00050928 File Offset: 0x0004EB28
		private void galleryControl_Gallery_GalleryItemHover(object sender, GalleryItemEventArgs e)
		{
			ScreenshotsView.ScreenshotItem screenshotItem = e.Item as ScreenshotsView.ScreenshotItem;
			if (screenshotItem != null)
			{
				e.Item.Hint = string.Format(Resources.Resources_ScreenshotsView_ScreenshotHint, this._devicesTree.GetItemGroupName(screenshotItem.DeviceItem));
			}
		}

		// Token: 0x060008D6 RID: 2262 RVA: 0x0005096A File Offset: 0x0004EB6A
		private void galleryControlGallery_ItemClick(object sender, GalleryItemClickEventArgs e)
		{
			this.ShowScrennshotZoom(e.Item as ScreenshotsView.ScreenshotItem);
		}

		// Token: 0x060008D7 RID: 2263 RVA: 0x0005097D File Offset: 0x0004EB7D
		private void GalleryControlOnInvalidated(object sender, InvalidateEventArgs args)
		{
			if (this.galleryControl.Gallery.Groups.Count == 0 || !base.IsCurrentView)
			{
				return;
			}
			WindowsApi.PostMessage(base.Handle, 1035U, 0, 0);
		}

		// Token: 0x060008D8 RID: 2264 RVA: 0x000509B4 File Offset: 0x0004EBB4
		private void GetAllScreenshots()
		{
			if (this.galleryControl.Gallery.Groups.Count == 0)
			{
				return;
			}
			foreach (object item in this.galleryControl.Gallery.Groups[0].Items)
			{
				this.GetScreenshot(item as ScreenshotsView.ScreenshotItem);
			}
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x00050A3C File Offset: 0x0004EC3C
		private Size GetGalleryItemMargins()
		{
			SkinElement element = SkinManager.GetSkinElement(SkinProductId.Ribbon, UserLookAndFeel.Default, "GalleryButton");
			return new Size(element.ContentMargins.Width, element.ContentMargins.Height);
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x00050A78 File Offset: 0x0004EC78
		private void GetScreenshot(ScreenshotsView.ScreenshotItem screenshotItem)
		{
			ScreenshotsView.<GetScreenshot>d__49 <GetScreenshot>d__;
			<GetScreenshot>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<GetScreenshot>d__.<>4__this = this;
			<GetScreenshot>d__.screenshotItem = screenshotItem;
			<GetScreenshot>d__.<>1__state = -1;
			<GetScreenshot>d__.<>t__builder.Start<ScreenshotsView.<GetScreenshot>d__49>(ref <GetScreenshot>d__);
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x00050AB8 File Offset: 0x0004ECB8
		private List<ScreenshotsView.ScreenshotItem> GetScreenshotItemsForAgent(string agentId)
		{
			List<ScreenshotsView.ScreenshotItem> result = new List<ScreenshotsView.ScreenshotItem>();
			foreach (object obj in this.galleryControl.Gallery.Groups[0].Items)
			{
				ScreenshotsView.ScreenshotItem item = (ScreenshotsView.ScreenshotItem)obj;
				string a;
				if (item == null)
				{
					a = null;
				}
				else
				{
					DisplayItem displayItem = item.DisplayItem;
					if (displayItem == null)
					{
						a = null;
					}
					else
					{
						AgentItem agentItem = displayItem.AgentItem;
						if (agentItem == null)
						{
							a = null;
						}
						else
						{
							AgentClient agentClient = agentItem.AgentClient;
							a = ((agentClient != null) ? agentClient.AgentId : null);
						}
					}
				}
				if (a == agentId)
				{
					result.Add(item);
				}
			}
			return result;
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x00050B68 File Offset: 0x0004ED68
		private float GetScreenshotZoomValue()
		{
			float result = (float)((int)this.barEditScreenshotZoom.EditValue) * 0.25f;
			if (result >= 1f)
			{
				return result;
			}
			return 1f;
		}

		// Token: 0x060008DD RID: 2269 RVA: 0x00050B9C File Offset: 0x0004ED9C
		private int GetThumbnailDescriptionHeight()
		{
			int result = this._settings.ScreenshotItemDescriptionsKind.Count * 16;
			if (result > 0)
			{
				result += 4;
			}
			return result;
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x00050BC8 File Offset: 0x0004EDC8
		private ScreenshotsView.ThumbnailInfo GetThumbnailInforScreenshotSize(Size screenshotSize)
		{
			Size thumbnailContentSize = new Size(screenshotSize.Width + this._settings.FrameSize * 2, screenshotSize.Height + this._settings.FrameSize * 2);
			int descriptionHeight = this.GetThumbnailDescriptionHeight();
			Size shadowSize = new Size(0, 0);
			if (this._settings.DrawScreenshotItemShadow)
			{
				int shadowWidth = (int)((double)thumbnailContentSize.Width * 0.1);
				int shadowHeight = (int)((double)thumbnailContentSize.Height * 0.1);
				if (shadowWidth > this._thumbnailMaxShadowSize.Width)
				{
					shadowWidth = this._thumbnailMaxShadowSize.Width;
				}
				if (shadowHeight > this._thumbnailMaxShadowSize.Height)
				{
					shadowHeight = this._thumbnailMaxShadowSize.Height;
				}
				shadowSize = new Size(shadowWidth, shadowHeight);
			}
			thumbnailContentSize.Height += descriptionHeight;
			if (shadowSize.Width > 0)
			{
				thumbnailContentSize.Width += shadowSize.Width;
				thumbnailContentSize.Height += shadowSize.Height;
			}
			SkinElement element = SkinManager.GetSkinElement(SkinProductId.Ribbon, UserLookAndFeel.Default, "PopupGalleryButton");
			return new ScreenshotsView.ThumbnailInfo(new Size(thumbnailContentSize.Width + element.ContentMargins.Width, thumbnailContentSize.Height + element.ContentMargins.Height), thumbnailContentSize, screenshotSize, shadowSize, descriptionHeight, this._settings.FrameSize);
		}

		// Token: 0x060008DF RID: 2271 RVA: 0x00050D34 File Offset: 0x0004EF34
		private bool IsGaleryItemVisible(GalleryItem item)
		{
			GalleryItemViewInfo viewInfo = this._gallleryGetItemInfoMethod.Invoke(this.galleryControl.Gallery, new object[]
			{
				item
			}) as GalleryItemViewInfo;
			return viewInfo != null && !viewInfo.IsInvisible;
		}

		// Token: 0x060008E0 RID: 2272 RVA: 0x00050D78 File Offset: 0x0004EF78
		private void OnAgentConnectionChanged(AgentClient agentClient)
		{
			foreach (ScreenshotsView.ScreenshotItem item in this.GetScreenshotItemsForAgent(agentClient.AgentId))
			{
				if (agentClient.IsConnected)
				{
					this.GetScreenshot(item);
				}
				else
				{
					item.SetDisconnectedImage();
				}
			}
		}

		// Token: 0x060008E1 RID: 2273 RVA: 0x00050DE4 File Offset: 0x0004EFE4
		private void OnAgentWindowsSessionChanged(AgentClient agentClient)
		{
			foreach (ScreenshotsView.ScreenshotItem item in this.GetScreenshotItemsForAgent(agentClient.AgentId))
			{
				this.GetScreenshot(item);
			}
		}

		// Token: 0x060008E2 RID: 2274 RVA: 0x00050E40 File Offset: 0x0004F040
		private void popupMenuDeviceItem_BeforePopup(object sender, CancelEventArgs e)
		{
			Point point = this.galleryControl.PointToClient(Control.MousePosition);
			RibbonHitInfo hitInfo = this.galleryControl.CalcHitInfo(point);
			if (hitInfo.InGalleryItem || hitInfo.HitTest == RibbonHitTest.GalleryImage)
			{
				this._itemSelectedByPopupMenu = (hitInfo.GalleryItem as ScreenshotsView.ScreenshotItem);
				PopupMenu popupMenu = this.popupMenu;
				string devicesTree_SelectionDescriptionForOneDevice = Resources.DevicesTree_SelectionDescriptionForOneDevice;
				ScreenshotsView.ScreenshotItem itemSelectedByPopupMenu = this._itemSelectedByPopupMenu;
				object arg;
				if (itemSelectedByPopupMenu == null)
				{
					arg = null;
				}
				else
				{
					DeviceItem deviceItem = itemSelectedByPopupMenu.DeviceItem;
					arg = ((deviceItem != null) ? deviceItem.Name : null);
				}
				popupMenu.MenuCaption = string.Format(devicesTree_SelectionDescriptionForOneDevice, arg);
				return;
			}
			e.Cancel = true;
		}

		// Token: 0x060008E3 RID: 2275 RVA: 0x00050EC9 File Offset: 0x0004F0C9
		private void RefreshTimerOnTick(object sender, EventArgs eventArgs)
		{
			if (!IdleTime.IsIdleTime())
			{
				this.GetAllScreenshots();
			}
		}

		// Token: 0x060008E4 RID: 2276 RVA: 0x00050ED8 File Offset: 0x0004F0D8
		private void repositoryComboBoxRefreshTime_EditValueChanged(object sender, EventArgs e)
		{
			this.SetRefreshTimer(RefreshTimes.GetRefreshTime((ComboBoxEdit)sender));
		}

		// Token: 0x060008E5 RID: 2277 RVA: 0x00050EEB File Offset: 0x0004F0EB
		private void repositoryTrackBarScreenshotZoom_ValueChanged(object sender, EventArgs e)
		{
			this.SetScreenshotZoom(this.GetScreenshotZoomValue());
			this.GetAllScreenshots();
		}

		// Token: 0x060008E6 RID: 2278 RVA: 0x00050EFF File Offset: 0x0004F0FF
		private void ScreenshotModule_SizeChanged(object sender, EventArgs e)
		{
			if (base.IsCurrentView)
			{
				this.SetScreenshotsSize();
				this.GetAllScreenshots();
			}
		}

		// Token: 0x060008E7 RID: 2279 RVA: 0x00050F15 File Offset: 0x0004F115
		private int SelectedScreenshotItemsCount()
		{
			if (this.galleryControl.Gallery.Groups.Count == 0)
			{
				return 0;
			}
			return this.galleryControl.Gallery.Groups[0].Items.Count;
		}

		// Token: 0x060008E8 RID: 2280 RVA: 0x00050F50 File Offset: 0x0004F150
		private void SetRefreshTimer(int seconds)
		{
			this._refreshTimer.Enabled = (seconds > 0);
			this._refreshTimer.Interval = ((seconds == 0) ? 1 : (seconds * 1000));
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x00050F7C File Offset: 0x0004F17C
		private void SetScreenshotsSize()
		{
			if (this.barEditScreenshotAutosize.Checked || this.SelectedScreenshotItemsCount() <= 2)
			{
				this.SetThumbnailSize(this.ComputeThumbnailAutoSize(this.galleryControl.DisplayRectangle.Size, this._thumbnailScrenshotMinSize, this.GetGalleryItemMargins(), this.SelectedScreenshotItemsCount()));
				this.barEditScreenshotZoom.Enabled = false;
				return;
			}
			this.SetScreenshotZoom(this.GetScreenshotZoomValue());
			this.barEditScreenshotZoom.Enabled = true;
		}

		// Token: 0x060008EA RID: 2282 RVA: 0x00050FF8 File Offset: 0x0004F1F8
		private void SetScreenshotZoom(float zoom)
		{
			Size screenshotAreaSize = new Size((int)((float)this._thumbnailScrenshotMinSize.Width * zoom), (int)((float)this._thumbnailScrenshotMinSize.Height * zoom));
			this.SetThumbnailSize(this.GetThumbnailInforScreenshotSize(screenshotAreaSize));
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x0005103D File Offset: 0x0004F23D
		private void SetThumbnailSize(ScreenshotsView.ThumbnailInfo thumbnailInfo)
		{
			this.galleryControl.Gallery.ItemSize = thumbnailInfo.ThumbnailSize;
			this._thumbnailInfo = thumbnailInfo;
			this._thumbnailBackgroundImage = null;
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x00051064 File Offset: 0x0004F264
		private void ShowScrennshotZoom(ScreenshotsView.ScreenshotItem item)
		{
			if (item != null && item.DeviceItem.IsConnected)
			{
				this._formCreator.Show<ScreenshotZoomForm, ScreenshotZoomFormParams>(new ScreenshotZoomFormParams(item.DisplayItem, (int)this.barEditScreenshotQuality.EditValue, this._refreshTimer.Interval));
			}
		}

		// Token: 0x060008ED RID: 2285 RVA: 0x000510B3 File Offset: 0x0004F2B3
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x000510D4 File Offset: 0x0004F2D4
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager resources = new ComponentResourceManager(typeof(ScreenshotsView));
			ContextButton contextButton = new ContextButton();
			this.barManager = new BarManager(this.components);
			this.barMainMenu = new Bar();
			this.barEditScreenshotAutosize = new BarCheckItem();
			this.barEditScreenshotZoom = new BarEditItem();
			this.repositoryTrackBarScreenshotZoom = new RepositoryItemZoomTrackBar();
			this.buttonRefresh = new BarButtonItem();
			this.barEditRefreshTime = new BarEditItem();
			this.repositoryComboBoxRefreshTime = new RepositoryItemComboBox();
			this.barEditScreenshotQuality = new BarEditItem();
			this.repositoryTrackBarScreenshotQuality = new RepositoryItemZoomTrackBar();
			this.buttonViewSettings = new BarButtonItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControlRight = new BarDockControl();
			this.galleryControl = new GalleryControl();
			this.galleryControlClient1 = new GalleryControlClient();
			this.popupMenu = new PopupMenu(this.components);
			((ISupportInitialize)this.barManager).BeginInit();
			((ISupportInitialize)this.repositoryTrackBarScreenshotZoom).BeginInit();
			((ISupportInitialize)this.repositoryComboBoxRefreshTime).BeginInit();
			((ISupportInitialize)this.repositoryTrackBarScreenshotQuality).BeginInit();
			((ISupportInitialize)this.galleryControl).BeginInit();
			this.galleryControl.SuspendLayout();
			((ISupportInitialize)this.popupMenu).BeginInit();
			base.SuspendLayout();
			this.barManager.AllowCustomization = false;
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.barMainMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.barEditScreenshotZoom,
				this.buttonRefresh,
				this.barEditRefreshTime,
				this.barEditScreenshotQuality,
				this.barEditScreenshotAutosize,
				this.buttonViewSettings
			});
			this.barManager.MainMenu = this.barMainMenu;
			this.barManager.MaxItemId = 17;
			this.barManager.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryTrackBarScreenshotZoom,
				this.repositoryComboBoxRefreshTime,
				this.repositoryTrackBarScreenshotQuality
			});
			this.barMainMenu.BarName = "Main menu";
			this.barMainMenu.CanDockStyle = BarCanDockStyle.Top;
			this.barMainMenu.DockCol = 0;
			this.barMainMenu.DockRow = 0;
			this.barMainMenu.DockStyle = BarDockStyle.Top;
			this.barMainMenu.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barEditScreenshotAutosize),
				new LinkPersistInfo(this.barEditScreenshotZoom),
				new LinkPersistInfo(this.buttonRefresh),
				new LinkPersistInfo(this.barEditRefreshTime),
				new LinkPersistInfo(this.barEditScreenshotQuality),
				new LinkPersistInfo(this.buttonViewSettings)
			});
			this.barMainMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMainMenu.OptionsBar.MultiLine = true;
			this.barMainMenu.OptionsBar.UseWholeRow = true;
			resources.ApplyResources(this.barMainMenu, "barMainMenu");
			resources.ApplyResources(this.barEditScreenshotAutosize, "barEditScreenshotAutosize");
			this.barEditScreenshotAutosize.CheckBoxVisibility = CheckBoxVisibility.BeforeText;
			this.barEditScreenshotAutosize.Id = 15;
			this.barEditScreenshotAutosize.Name = "barEditScreenshotAutosize";
			this.barEditScreenshotAutosize.CheckedChanged += this.barEditScreenshotAutosize_CheckedChanged;
			resources.ApplyResources(this.barEditScreenshotZoom, "barEditScreenshotZoom");
			this.barEditScreenshotZoom.Edit = this.repositoryTrackBarScreenshotZoom;
			this.barEditScreenshotZoom.EditValue = 1;
			this.barEditScreenshotZoom.Id = 0;
			this.barEditScreenshotZoom.Name = "barEditScreenshotZoom";
			this.barEditScreenshotZoom.PaintStyle = BarItemPaintStyle.Caption;
			this.repositoryTrackBarScreenshotZoom.EditValueChangedDelay = 500;
			this.repositoryTrackBarScreenshotZoom.EditValueChangedFiringMode = EditValueChangedFiringMode.Buffered;
			this.repositoryTrackBarScreenshotZoom.Maximum = 60;
			this.repositoryTrackBarScreenshotZoom.Middle = 32;
			this.repositoryTrackBarScreenshotZoom.Minimum = 4;
			this.repositoryTrackBarScreenshotZoom.Name = "repositoryTrackBarScreenshotZoom";
			this.repositoryTrackBarScreenshotZoom.ValueChanged += this.repositoryTrackBarScreenshotZoom_ValueChanged;
			this.buttonRefresh.Border = BorderStyles.Simple;
			resources.ApplyResources(this.buttonRefresh, "buttonRefresh");
			this.buttonRefresh.Id = 1;
			this.buttonRefresh.ImageOptions.Image = (Image)resources.GetObject("buttonRefresh.ImageOptions.Image");
			this.buttonRefresh.ImageOptions.LargeImage = (Image)resources.GetObject("buttonRefresh.ImageOptions.LargeImage");
			this.buttonRefresh.Name = "buttonRefresh";
			this.buttonRefresh.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.buttonRefresh.ItemClick += this.buttonRefresh_ItemClick;
			resources.ApplyResources(this.barEditRefreshTime, "barEditRefreshTime");
			this.barEditRefreshTime.Edit = this.repositoryComboBoxRefreshTime;
			this.barEditRefreshTime.Id = 3;
			this.barEditRefreshTime.Name = "barEditRefreshTime";
			this.barEditRefreshTime.PaintStyle = BarItemPaintStyle.Caption;
			this.repositoryComboBoxRefreshTime.AutoComplete = false;
			resources.ApplyResources(this.repositoryComboBoxRefreshTime, "repositoryComboBoxRefreshTime");
			this.repositoryComboBoxRefreshTime.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryComboBoxRefreshTime.Buttons"))
			});
			this.repositoryComboBoxRefreshTime.HotTrackItems = false;
			this.repositoryComboBoxRefreshTime.Name = "repositoryComboBoxRefreshTime";
			this.repositoryComboBoxRefreshTime.EditValueChanged += this.repositoryComboBoxRefreshTime_EditValueChanged;
			resources.ApplyResources(this.barEditScreenshotQuality, "barEditScreenshotQuality");
			this.barEditScreenshotQuality.Edit = this.repositoryTrackBarScreenshotQuality;
			this.barEditScreenshotQuality.EditValue = "90";
			this.barEditScreenshotQuality.Id = 5;
			this.barEditScreenshotQuality.Name = "barEditScreenshotQuality";
			this.barEditScreenshotQuality.PaintStyle = BarItemPaintStyle.Caption;
			this.repositoryTrackBarScreenshotQuality.EditValueChangedFiringMode = EditValueChangedFiringMode.Buffered;
			this.repositoryTrackBarScreenshotQuality.LargeChange = 10;
			this.repositoryTrackBarScreenshotQuality.Maximum = 100;
			this.repositoryTrackBarScreenshotQuality.Middle = 60;
			this.repositoryTrackBarScreenshotQuality.Minimum = 20;
			this.repositoryTrackBarScreenshotQuality.Name = "repositoryTrackBarScreenshotQuality";
			this.repositoryTrackBarScreenshotQuality.ShowValueToolTip = true;
			resources.ApplyResources(this.buttonViewSettings, "buttonViewSettings");
			this.buttonViewSettings.Id = 16;
			this.buttonViewSettings.ImageOptions.Image = Resources.properties_16x16;
			this.buttonViewSettings.ImageOptions.LargeImage = Resources.properties_32x32;
			this.buttonViewSettings.Name = "buttonViewSettings";
			this.buttonViewSettings.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.buttonViewSettings.ItemClick += this.buttonViewSettings_ItemClick;
			this.barDockControlTop.CausesValidation = false;
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlBottom.CausesValidation = false;
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlLeft.CausesValidation = false;
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControlRight.CausesValidation = false;
			resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
			this.barDockControlRight.Manager = this.barManager;
			this.galleryControl.Controls.Add(this.galleryControlClient1);
			resources.ApplyResources(this.galleryControl, "galleryControl");
			this.galleryControl.Gallery.Appearance.ItemCaptionAppearance.Normal.FontStyleDelta = (FontStyle)resources.GetObject("galleryControl.Gallery.Appearance.ItemCaptionAppearance.Normal.FontStyleDelta");
			this.galleryControl.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseFont = true;
			this.galleryControl.Gallery.AutoSize = GallerySizeMode.None;
			this.galleryControl.Gallery.ContentHorzAlignment = HorzAlignment.Center;
			this.galleryControl.Gallery.ContextButtonOptions.DisplayArea = ContextItemDisplayArea.Item;
			this.galleryControl.Gallery.ContextButtonOptions.TopPanelPadding = new Padding(40, 20, 5, 5);
			contextButton.Id = new Guid("135f2fdf-58c0-4a31-a0d9-e6fb99bf9b99");
			contextButton.ImageOptionsCollection.ItemNormal.Image = (Image)resources.GetObject("resource.Image");
			contextButton.Name = "contextButtonZoom";
			this.galleryControl.Gallery.ContextButtons.Add(contextButton);
			this.galleryControl.Gallery.DrawImageBackground = false;
			this.galleryControl.Gallery.ItemAutoSizeMode = GalleryItemAutoSizeMode.None;
			this.galleryControl.Gallery.ItemImageLayout = ImageLayoutMode.ZoomInside;
			this.galleryControl.Gallery.ShowGroupCaption = false;
			this.galleryControl.Gallery.ShowScrollBar = ShowScrollBar.Auto;
			this.galleryControl.Gallery.ContextButtonClick += this.galleryControl_Gallery_ContextButtonClick;
			this.galleryControl.Gallery.ItemClick += this.galleryControlGallery_ItemClick;
			this.galleryControl.Gallery.CustomDrawItemImage += this.galleryControl_Gallery_CustomDrawItemImage;
			this.galleryControl.Gallery.GalleryItemHover += this.galleryControl_Gallery_GalleryItemHover;
			this.galleryControl.Name = "galleryControl";
			this.barManager.SetPopupContextMenu(this.galleryControl, this.popupMenu);
			this.galleryControlClient1.GalleryControl = this.galleryControl;
			resources.ApplyResources(this.galleryControlClient1, "galleryControlClient1");
			this.popupMenu.Manager = this.barManager;
			this.popupMenu.Name = "popupMenu";
			this.popupMenu.ShowCaption = true;
			this.popupMenu.BeforePopup += this.popupMenuDeviceItem_BeforePopup;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.galleryControl);
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "ScreenshotsView";
			base.SizeChanged += this.ScreenshotModule_SizeChanged;
			((ISupportInitialize)this.barManager).EndInit();
			((ISupportInitialize)this.repositoryTrackBarScreenshotZoom).EndInit();
			((ISupportInitialize)this.repositoryComboBoxRefreshTime).EndInit();
			((ISupportInitialize)this.repositoryTrackBarScreenshotQuality).EndInit();
			((ISupportInitialize)this.galleryControl).EndInit();
			this.galleryControl.ResumeLayout(false);
			((ISupportInitialize)this.popupMenu).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040006D2 RID: 1746
		private const int DescriptionLineHeight = 16;

		// Token: 0x040006D3 RID: 1747
		private const int ThumbnailBackgroundMargin = 5;

		// Token: 0x040006D4 RID: 1748
		private const int WM_USER_REFRESH_ITEM = 1035;

		// Token: 0x040006D5 RID: 1749
		private readonly ApiClient _apiClient;

		// Token: 0x040006D6 RID: 1750
		private readonly Brush _errorTextOnScreenshotBrush;

		// Token: 0x040006D7 RID: 1751
		private readonly MethodInfo _gallleryGetItemInfoMethod;

		// Token: 0x040006D8 RID: 1752
		private readonly IIconsProvider _iconsProvider;

		// Token: 0x040006D9 RID: 1753
		private readonly Timer _refreshTimer;

		// Token: 0x040006DA RID: 1754
		private readonly Brush _screenBackgroundBrush;

		// Token: 0x040006DB RID: 1755
		private readonly StringFormat _sfCenter;

		// Token: 0x040006DC RID: 1756
		private readonly Brush _textOnScreenshotBrush;

		// Token: 0x040006DD RID: 1757
		private readonly Font _textOnScreenshotFont;

		// Token: 0x040006DE RID: 1758
		private readonly Image _thumbnailBackgroundTemplate;

		// Token: 0x040006DF RID: 1759
		private readonly Size _thumbnailMaxShadowSize = new Size(40, 40);

		// Token: 0x040006E0 RID: 1760
		private readonly Size _thumbnailScrenshotMinSize = new Size(60, 45);

		// Token: 0x040006E1 RID: 1761
		private readonly Image _thumbnailShadowTemplate;

		// Token: 0x040006E2 RID: 1762
		private ScreenshotsView.ScreenshotItem _itemSelectedByPopupMenu;

		// Token: 0x040006E3 RID: 1763
		private Size _screenshotAreaSize;

		// Token: 0x040006E4 RID: 1764
		private ScreenshotViewSettings _settings;

		// Token: 0x040006E5 RID: 1765
		private Image _thumbnailBackgroundImage;

		// Token: 0x040006E6 RID: 1766
		private ScreenshotsView.ThumbnailInfo _thumbnailInfo;

		// Token: 0x040006E7 RID: 1767
		private IContainer components;

		// Token: 0x040006E8 RID: 1768
		private BarManager barManager;

		// Token: 0x040006E9 RID: 1769
		private Bar barMainMenu;

		// Token: 0x040006EA RID: 1770
		private BarEditItem barEditScreenshotZoom;

		// Token: 0x040006EB RID: 1771
		private RepositoryItemZoomTrackBar repositoryTrackBarScreenshotZoom;

		// Token: 0x040006EC RID: 1772
		private BarDockControl barDockControlTop;

		// Token: 0x040006ED RID: 1773
		private BarDockControl barDockControlBottom;

		// Token: 0x040006EE RID: 1774
		private BarDockControl barDockControlLeft;

		// Token: 0x040006EF RID: 1775
		private BarDockControl barDockControlRight;

		// Token: 0x040006F0 RID: 1776
		private GalleryControl galleryControl;

		// Token: 0x040006F1 RID: 1777
		private GalleryControlClient galleryControlClient1;

		// Token: 0x040006F2 RID: 1778
		private BarButtonItem buttonRefresh;

		// Token: 0x040006F3 RID: 1779
		private BarEditItem barEditRefreshTime;

		// Token: 0x040006F4 RID: 1780
		private RepositoryItemComboBox repositoryComboBoxRefreshTime;

		// Token: 0x040006F5 RID: 1781
		private BarEditItem barEditScreenshotQuality;

		// Token: 0x040006F6 RID: 1782
		private RepositoryItemZoomTrackBar repositoryTrackBarScreenshotQuality;

		// Token: 0x040006F7 RID: 1783
		private PopupMenu popupMenu;

		// Token: 0x040006F8 RID: 1784
		private BarCheckItem barEditScreenshotAutosize;

		// Token: 0x040006F9 RID: 1785
		private BarButtonItem buttonViewSettings;

		// Token: 0x020001C7 RID: 455
		private class ScreenshotItem : GalleryItem
		{
			// Token: 0x06000C4F RID: 3151 RVA: 0x00065F6B File Offset: 0x0006416B
			public ScreenshotItem(DeviceAndDisplay deviceAndDisplay) : base(null, null, null)
			{
				this.DeviceAndDisplay = deviceAndDisplay;
				this.ScreenshotInProgress = false;
				this.DeviceItem.PropertyChanged += this.DeviceItemOnPropertyChanged;
				base.Hint = " ";
			}

			// Token: 0x06000C50 RID: 3152 RVA: 0x00065FA8 File Offset: 0x000641A8
			~ScreenshotItem()
			{
				this.DeviceItem.PropertyChanged -= this.DeviceItemOnPropertyChanged;
			}

			// Token: 0x17000310 RID: 784
			// (get) Token: 0x06000C51 RID: 3153 RVA: 0x00065FE8 File Offset: 0x000641E8
			public DeviceAndDisplay DeviceAndDisplay { get; }

			// Token: 0x17000311 RID: 785
			// (get) Token: 0x06000C52 RID: 3154 RVA: 0x00065FF0 File Offset: 0x000641F0
			public DeviceItem DeviceItem
			{
				get
				{
					return this.DeviceAndDisplay.DeviceItem;
				}
			}

			// Token: 0x17000312 RID: 786
			// (get) Token: 0x06000C53 RID: 3155 RVA: 0x00065FFD File Offset: 0x000641FD
			public DisplayItem DisplayItem
			{
				get
				{
					return this.DeviceAndDisplay.DisplayItem;
				}
			}

			// Token: 0x17000313 RID: 787
			// (get) Token: 0x06000C54 RID: 3156 RVA: 0x0006600A File Offset: 0x0006420A
			// (set) Token: 0x06000C55 RID: 3157 RVA: 0x00066012 File Offset: 0x00064212
			public string ErrorMessage { get; private set; }

			// Token: 0x17000314 RID: 788
			// (get) Token: 0x06000C56 RID: 3158 RVA: 0x0006601B File Offset: 0x0006421B
			// (set) Token: 0x06000C57 RID: 3159 RVA: 0x00066023 File Offset: 0x00064223
			public bool IsVisible { get; set; }

			// Token: 0x17000315 RID: 789
			// (get) Token: 0x06000C58 RID: 3160 RVA: 0x0006602C File Offset: 0x0006422C
			// (set) Token: 0x06000C59 RID: 3161 RVA: 0x00066034 File Offset: 0x00064234
			public bool ScreenshotInProgress { get; set; }

			// Token: 0x06000C5A RID: 3162 RVA: 0x00066040 File Offset: 0x00064240
			public string GetScreenshotDescription(ScreenshotItemDescription itemDescriptionType)
			{
				switch (itemDescriptionType)
				{
				case ScreenshotItemDescription.None:
					return string.Empty;
				case ScreenshotItemDescription.DeviceName:
				{
					DeviceItem deviceItem = this.DeviceItem;
					if (deviceItem == null)
					{
						return null;
					}
					return deviceItem.Name;
				}
				case ScreenshotItemDescription.DeviceDescription:
				{
					DeviceItem deviceItem2 = this.DeviceItem;
					if (deviceItem2 == null)
					{
						return null;
					}
					return deviceItem2.Description;
				}
				case ScreenshotItemDescription.DomainAndUserName:
				{
					DisplayItem displayItem = this.DisplayItem;
					bool flag;
					if (displayItem == null)
					{
						flag = false;
					}
					else
					{
						AgentItem agentItem = displayItem.AgentItem;
						if (agentItem == null)
						{
							flag = false;
						}
						else
						{
							bool isConnected = agentItem.IsConnected;
							flag = true;
						}
					}
					if (flag)
					{
						DisplayItem displayItem2 = this.DisplayItem;
						if (displayItem2 == null)
						{
							return null;
						}
						return displayItem2.AgentItem.DomainAndUserName;
					}
					break;
				}
				case ScreenshotItemDescription.UserFullName:
				{
					DisplayItem displayItem3 = this.DisplayItem;
					bool flag2;
					if (displayItem3 == null)
					{
						flag2 = false;
					}
					else
					{
						AgentItem agentItem2 = displayItem3.AgentItem;
						if (agentItem2 == null)
						{
							flag2 = false;
						}
						else
						{
							bool isConnected2 = agentItem2.IsConnected;
							flag2 = true;
						}
					}
					if (flag2)
					{
						return this.DisplayItem.AgentItem.UserFullName;
					}
					break;
				}
				case ScreenshotItemDescription.UserName:
				{
					DisplayItem displayItem4 = this.DisplayItem;
					bool flag3;
					if (displayItem4 == null)
					{
						flag3 = false;
					}
					else
					{
						AgentItem agentItem3 = displayItem4.AgentItem;
						if (agentItem3 == null)
						{
							flag3 = false;
						}
						else
						{
							bool isConnected3 = agentItem3.IsConnected;
							flag3 = true;
						}
					}
					if (flag3)
					{
						return this.DisplayItem.AgentItem.UserName;
					}
					break;
				}
				}
				return string.Empty;
			}

			// Token: 0x06000C5B RID: 3163 RVA: 0x0006613E File Offset: 0x0006433E
			public void RefreshItem()
			{
				BaseGallery gallery = base.Gallery;
				if (gallery == null)
				{
					return;
				}
				gallery.Invalidate(this);
			}

			// Token: 0x06000C5C RID: 3164 RVA: 0x00066151 File Offset: 0x00064351
			public void SetDisconnectedImage()
			{
				base.Image = null;
				this.RefreshItem();
			}

			// Token: 0x06000C5D RID: 3165 RVA: 0x00066160 File Offset: 0x00064360
			public void SetScreenshotError(string errorMessage)
			{
				base.Image = null;
				this.ErrorMessage = errorMessage;
				this.RefreshItem();
			}

			// Token: 0x06000C5E RID: 3166 RVA: 0x00066176 File Offset: 0x00064376
			public void SetScreenshotImage(Image screenshoot)
			{
				base.Image = screenshoot;
				this.ErrorMessage = null;
			}

			// Token: 0x06000C5F RID: 3167 RVA: 0x00066186 File Offset: 0x00064386
			private void DeviceItemOnPropertyChanged(object sender, PropertyChangedEventArgs e)
			{
				if (e.PropertyName == "DeviceIconIndexes")
				{
					this.RefreshItem();
				}
			}
		}

		// Token: 0x020001C8 RID: 456
		private class ThumbnailInfo
		{
			// Token: 0x06000C60 RID: 3168 RVA: 0x000661A0 File Offset: 0x000643A0
			public ThumbnailInfo(Size thumbnailSize, Size thumbnailContentSize, Size screenshotSize, Size shadowSize, int descriptionHeight, int frameMargin)
			{
				this.ThumbnailSize = thumbnailSize;
				this.ThumbnailContentSize = thumbnailContentSize;
				this.ScreenshotSize = screenshotSize;
				this.ShadowSize = shadowSize;
				this.DescriptionHeight = descriptionHeight;
				this.FrameMargin = frameMargin;
			}

			// Token: 0x17000316 RID: 790
			// (get) Token: 0x06000C61 RID: 3169 RVA: 0x000661D5 File Offset: 0x000643D5
			// (set) Token: 0x06000C62 RID: 3170 RVA: 0x000661DD File Offset: 0x000643DD
			public int DescriptionHeight { get; set; }

			// Token: 0x17000317 RID: 791
			// (get) Token: 0x06000C63 RID: 3171 RVA: 0x000661E6 File Offset: 0x000643E6
			// (set) Token: 0x06000C64 RID: 3172 RVA: 0x000661EE File Offset: 0x000643EE
			public int FrameMargin { get; set; }

			// Token: 0x17000318 RID: 792
			// (get) Token: 0x06000C65 RID: 3173 RVA: 0x000661F7 File Offset: 0x000643F7
			// (set) Token: 0x06000C66 RID: 3174 RVA: 0x000661FF File Offset: 0x000643FF
			public Size ScreenshotSize { get; set; }

			// Token: 0x17000319 RID: 793
			// (get) Token: 0x06000C67 RID: 3175 RVA: 0x00066208 File Offset: 0x00064408
			// (set) Token: 0x06000C68 RID: 3176 RVA: 0x00066210 File Offset: 0x00064410
			public Size ShadowSize { get; set; }

			// Token: 0x1700031A RID: 794
			// (get) Token: 0x06000C69 RID: 3177 RVA: 0x00066219 File Offset: 0x00064419
			// (set) Token: 0x06000C6A RID: 3178 RVA: 0x00066221 File Offset: 0x00064421
			public Size ThumbnailContentSize { get; set; }

			// Token: 0x1700031B RID: 795
			// (get) Token: 0x06000C6B RID: 3179 RVA: 0x0006622A File Offset: 0x0006442A
			// (set) Token: 0x06000C6C RID: 3180 RVA: 0x00066232 File Offset: 0x00064432
			public Size ThumbnailSize { get; set; }
		}
	}
}
