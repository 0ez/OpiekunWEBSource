﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000A9 RID: 169
	public class ProcessesView : BaseView
	{
		// Token: 0x060008A7 RID: 2215 RVA: 0x0004E0E0 File Offset: 0x0004C2E0
		public ProcessesView()
		{
			this.InitializeComponent();
		}

		// Token: 0x060008A8 RID: 2216 RVA: 0x0004E0F0 File Offset: 0x0004C2F0
		public ProcessesView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree, ApiClient apiClient) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._processesList = new BindingList<ProcessesView.AgentItemAndProcessInfo>();
			this._agentTaskThrottler = new AgentTaskThrottler(10);
			RealTimeSource rts = new RealTimeSource
			{
				DataSource = this._processesList
			};
			this.gridProcessList.DataSource = rts;
			List<KeyAndValue<ProcessesToReturn, string>> kv = EnumHelpers.GetEnumValuesAsStringKeyAndValue<ProcessesToReturn>(null);
			kv.Remove(kv.Find((KeyAndValue<ProcessesToReturn, string> x) => x.Key == ProcessesToReturn.UserAndSystemProcesses));
			EnumHelpers.InitializeComboBoxAsStringKeyAndValue<ProcessesToReturn>(this.barEditProcessesToReturn, kv, ProcessesToReturn.UserApps);
			this._formsSettings.RestoreObjectState(base.Name, this.barEditProcessesToReturn, null);
			RefreshTimes.InitializeComboBoxRefreshTimes(this.repositoryComboBoxRefreshTime);
			this.barEditRefreshTime.EditValue = RefreshTimes.GetDefaultText();
			this._refreshTimer = new Timer
			{
				Enabled = false
			};
			this._refreshTimer.Tick += this.RefreshTimerOnTick;
			this._objectsToSaveState.Add(this.barEditRefreshTime);
		}

		// Token: 0x060008A9 RID: 2217 RVA: 0x0004E1F9 File Offset: 0x0004C3F9
		protected override void AfterRestoreState()
		{
			this.SetRefreshTimer(RefreshTimes.GetRefreshTime(this.barEditRefreshTime.EditValue as string));
		}

		// Token: 0x060008AA RID: 2218 RVA: 0x0004E218 File Offset: 0x0004C418
		protected Bitmap BytesToBitmap(byte[] bytes)
		{
			int imwidth = 16;
			int imheight = 16;
			Bitmap bitmap = new Bitmap(imwidth, imheight, PixelFormat.Format32bppRgb);
			BitmapData bmpData = bitmap.LockBits(new Rectangle(0, 0, imwidth, imheight), ImageLockMode.WriteOnly, PixelFormat.Format32bppRgb);
			IntPtr ptr = bmpData.Scan0;
			int psize = bmpData.Stride * imheight;
			Marshal.Copy(bytes, 0, ptr, psize);
			bitmap.UnlockBits(bmpData);
			return bitmap;
		}

		// Token: 0x060008AB RID: 2219 RVA: 0x0004E270 File Offset: 0x0004C470
		protected override void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			if (!base.IsCurrentView)
			{
				return;
			}
			base.OnSelectedDeviceChanged(selection);
			BindingList<ProcessesView.AgentItemAndProcessInfo> processesList = this._processesList;
			lock (processesList)
			{
				this.gridProcessList.BeginUpdate();
				foreach (AgentItem agentItem in selection.SelectionChanges.AgentItemsRemoved)
				{
					this._agentTaskThrottler.CancelAgentTask(agentItem);
					this.RemoveItemsForAgentItem(agentItem);
				}
				this.gridProcessList.EndUpdate();
			}
			this.GetProcessesListFromAgents(selection.SelectionChanges.AgentItemsAdded);
		}

		// Token: 0x060008AC RID: 2220 RVA: 0x0004E334 File Offset: 0x0004C534
		protected override void ViewActivate()
		{
			base.ViewActivate();
			this.btnTerminateProcess.Enabled = this._apiClient.IsLoggedUserHasRemotePermission("TerminateProcess");
			this.btnRefresh_ItemClick(this, null);
		}

		// Token: 0x060008AD RID: 2221 RVA: 0x0004E35F File Offset: 0x0004C55F
		protected override void ViewDeactivate()
		{
			this._agentTaskThrottler.CancelAllTask();
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x0004E36C File Offset: 0x0004C56C
		private void AgentProcessesListReceived(AgentItem agentItem, ProcessesListResponse response)
		{
			BindingList<ProcessesView.AgentItemAndProcessInfo> processesList = this._processesList;
			lock (processesList)
			{
				if (response == null)
				{
					this.gridProcessList.BeginUpdate();
					this.RemoveItemsForAgentItem(agentItem);
					this.gridProcessList.EndUpdate();
				}
				else if (this._devicesTree.Selection.AgentsList.IndexOf(agentItem) != -1)
				{
					IEnumerable<ProcessesView.AgentItemAndProcessInfo> oldDeviceProcessesList = from x in this._processesList
					where x.AgentItem.DeviceItem == agentItem.DeviceItem
					select x;
					foreach (ProcessesView.AgentItemAndProcessInfo processInfo2 in (from x in oldDeviceProcessesList
					where !response.Items.Any((ProcessInfo y) => y.Pid == x.ProcessInfo.Pid)
					select x).ToList<ProcessesView.AgentItemAndProcessInfo>())
					{
						this._processesList.Remove(processInfo2);
					}
					using (IEnumerator<ProcessInfo> enumerator2 = response.Items.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							ProcessInfo processInfo = enumerator2.Current;
							ProcessesView.AgentItemAndProcessInfo oldItem = oldDeviceProcessesList.FirstOrDefault((ProcessesView.AgentItemAndProcessInfo x) => x.ProcessInfo.Pid == processInfo.Pid);
							if (oldItem != null)
							{
								oldItem.ProcessInfo = processInfo;
							}
							else
							{
								this._processesList.Add(new ProcessesView.AgentItemAndProcessInfo(agentItem, processInfo));
							}
						}
					}
				}
			}
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x0004E534 File Offset: 0x0004C734
		private void btnRefresh_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._agentTaskThrottler.CancelAllTask();
			this._processesList.Clear();
			this.GetProcessesList();
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x0004E554 File Offset: 0x0004C754
		private void btnTerminateProcess_ItemClick(object sender, ItemClickEventArgs e)
		{
			ProcessesView.<btnTerminateProcess_ItemClick>d__15 <btnTerminateProcess_ItemClick>d__;
			<btnTerminateProcess_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<btnTerminateProcess_ItemClick>d__.<>4__this = this;
			<btnTerminateProcess_ItemClick>d__.<>1__state = -1;
			<btnTerminateProcess_ItemClick>d__.<>t__builder.Start<ProcessesView.<btnTerminateProcess_ItemClick>d__15>(ref <btnTerminateProcess_ItemClick>d__);
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x0004E58C File Offset: 0x0004C78C
		private void comboBoxProcessesToReturn_EditValueChanged(object sender, EventArgs e)
		{
			KeyAndValue<ProcessesToReturn, string> kv = (KeyAndValue<ProcessesToReturn, string>)this.barEditProcessesToReturn.EditValue;
			if (kv == null)
			{
				return;
			}
			this._processesToReturn = kv.Key;
			if (base.IsCurrentView)
			{
				this._formsSettings.SaveObjectState(base.Name, this.barEditProcessesToReturn);
				this.btnRefresh_ItemClick(this, null);
			}
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x0004E5E4 File Offset: 0x0004C7E4
		private ProcessesView.AgentItemAndProcessInfo GetGridItemFromRowHandle(int rowHandle)
		{
			int index = this.gridViewProcessList.GetDataSourceRowIndex(rowHandle);
			if (index < 0 || index > this._processesList.Count - 1)
			{
				return null;
			}
			return this._processesList[index];
		}

		// Token: 0x060008B3 RID: 2227 RVA: 0x0004E620 File Offset: 0x0004C820
		private void GetProcessesList()
		{
			this._refreshTimer.Enabled = false;
			this.GetProcessesListFromAgents(this._devicesTree.Selection.AgentsList);
			this._refreshTimer.Enabled = true;
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x0004E650 File Offset: 0x0004C850
		private void GetProcessesListFromAgent(AgentItem agentItem)
		{
			ProcessesView.<>c__DisplayClass19_0 CS$<>8__locals1 = new ProcessesView.<>c__DisplayClass19_0();
			CS$<>8__locals1.agentItem = agentItem;
			CS$<>8__locals1.<>4__this = this;
			this._agentTaskThrottler.StartNewTask<Task>(delegate
			{
				ProcessesView.<>c__DisplayClass19_0.<<GetProcessesListFromAgent>b__0>d <<GetProcessesListFromAgent>b__0>d;
				<<GetProcessesListFromAgent>b__0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
				<<GetProcessesListFromAgent>b__0>d.<>4__this = CS$<>8__locals1;
				<<GetProcessesListFromAgent>b__0>d.<>1__state = -1;
				<<GetProcessesListFromAgent>b__0>d.<>t__builder.Start<ProcessesView.<>c__DisplayClass19_0.<<GetProcessesListFromAgent>b__0>d>(ref <<GetProcessesListFromAgent>b__0>d);
				return <<GetProcessesListFromAgent>b__0>d.<>t__builder.Task;
			});
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x0004E68C File Offset: 0x0004C88C
		private void GetProcessesListFromAgents(List<AgentItem> agentsList)
		{
			foreach (AgentItem item in agentsList)
			{
				this.GetProcessesListFromAgent(item);
			}
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x0004E6DC File Offset: 0x0004C8DC
		private void gridViewProcessList_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			if (e.Column == this.columnMemWorkingSize)
			{
				object value = e.Value;
				if (value is ulong)
				{
					ulong memWorkingSize = (ulong)value;
					e.DisplayText = LangStringUtils.StringRepresentingFileSize(memWorkingSize);
				}
			}
		}

		// Token: 0x060008B7 RID: 2231 RVA: 0x0004E71C File Offset: 0x0004C91C
		private void gridViewProcessList_RowStyle(object sender, RowStyleEventArgs e)
		{
			if (this._processesToReturn != ProcessesToReturn.ForegroundApp)
			{
				ProcessesView.AgentItemAndProcessInfo agentItemAndProcessInfo = this.GetGridItemFromRowHandle(e.RowHandle);
				if (agentItemAndProcessInfo != null && agentItemAndProcessInfo.ProcessInfo.IsForegroundApp)
				{
					e.Appearance.FontStyleDelta = FontStyle.Bold;
					e.Appearance.FontSizeDelta = 1;
					e.HighPriority = true;
				}
			}
		}

		// Token: 0x060008B8 RID: 2232 RVA: 0x0004E76D File Offset: 0x0004C96D
		private void RefreshTimerOnTick(object sender, EventArgs eventArgs)
		{
			if (base.IsCurrentView && !IdleTime.IsIdleTime())
			{
				this.GetProcessesList();
			}
		}

		// Token: 0x060008B9 RID: 2233 RVA: 0x0004E784 File Offset: 0x0004C984
		private void RemoveItemsForAgentItem(AgentItem agentItem)
		{
			foreach (ProcessesView.AgentItemAndProcessInfo processInfo in (from x in this._processesList
			where x.AgentItem == agentItem
			select x).ToList<ProcessesView.AgentItemAndProcessInfo>())
			{
				this._processesList.Remove(processInfo);
			}
		}

		// Token: 0x060008BA RID: 2234 RVA: 0x0004E800 File Offset: 0x0004CA00
		private void repositoryComboBoxRefreshTime_EditValueChanged(object sender, EventArgs e)
		{
			this.SetRefreshTimer(RefreshTimes.GetRefreshTime((ComboBoxEdit)sender));
		}

		// Token: 0x060008BB RID: 2235 RVA: 0x0004E813 File Offset: 0x0004CA13
		private void SetRefreshTimer(int seconds)
		{
			this._refreshTimer.Enabled = (seconds > 0);
			this._refreshTimer.Interval = ((seconds == 0) ? 1 : (seconds * 1000));
		}

		// Token: 0x060008BC RID: 2236 RVA: 0x0004E83C File Offset: 0x0004CA3C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060008BD RID: 2237 RVA: 0x0004E85C File Offset: 0x0004CA5C
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager resources = new ComponentResourceManager(typeof(ProcessesView));
			this.barDockControlRight = new BarDockControl();
			this.barManager = new BarManager(this.components);
			this.barMenu = new Bar();
			this.barEditProcessesToReturn = new BarEditItem();
			this.repositoryComboBoxProcessesToReturn = new RepositoryItemComboBox();
			this.btnRefresh = new BarButtonItem();
			this.barEditRefreshTime = new BarEditItem();
			this.repositoryComboBoxRefreshTime = new RepositoryItemComboBox();
			this.btnTerminateProcess = new BarButtonItem();
			this.barButtonExport = new BarButtonItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControl1 = new BarDockControl();
			this.gridProcessList = new GridControl();
			this.gridViewProcessList = new GridView();
			this.columnDeviceName = new GridColumn();
			this.columnAppName = new GridColumn();
			this.columnFileDescription = new GridColumn();
			this.columnMemWorkingSize = new GridColumn();
			this.columnUserName = new GridColumn();
			this.columnPid = new GridColumn();
			this.columnWindowText = new GridColumn();
			this.columnCpuUsage = new GridColumn();
			this.columSessionID = new GridColumn();
			this.columnProcessType = new GridColumn();
			this.columnProcessTypeAsString = new GridColumn();
			((ISupportInitialize)this.barManager).BeginInit();
			((ISupportInitialize)this.repositoryComboBoxProcessesToReturn).BeginInit();
			((ISupportInitialize)this.repositoryComboBoxRefreshTime).BeginInit();
			((ISupportInitialize)this.gridProcessList).BeginInit();
			((ISupportInitialize)this.gridViewProcessList).BeginInit();
			base.SuspendLayout();
			this.barDockControlRight.CausesValidation = false;
			resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
			this.barDockControlRight.Manager = null;
			this.barManager.AllowCustomization = false;
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.barMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControl1);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.btnRefresh,
				this.barEditRefreshTime,
				this.barEditProcessesToReturn,
				this.btnTerminateProcess,
				this.barButtonExport
			});
			this.barManager.MainMenu = this.barMenu;
			this.barManager.MaxItemId = 9;
			this.barManager.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryComboBoxRefreshTime,
				this.repositoryComboBoxProcessesToReturn
			});
			this.barMenu.BarName = "Main menu";
			this.barMenu.CanDockStyle = BarCanDockStyle.Top;
			this.barMenu.DockCol = 0;
			this.barMenu.DockRow = 0;
			this.barMenu.DockStyle = BarDockStyle.Top;
			this.barMenu.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barEditProcessesToReturn),
				new LinkPersistInfo(this.btnRefresh),
				new LinkPersistInfo(this.barEditRefreshTime),
				new LinkPersistInfo(this.btnTerminateProcess),
				new LinkPersistInfo(this.barButtonExport)
			});
			this.barMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMenu.OptionsBar.MultiLine = true;
			this.barMenu.OptionsBar.UseWholeRow = true;
			resources.ApplyResources(this.barMenu, "barMenu");
			resources.ApplyResources(this.barEditProcessesToReturn, "barEditProcessesToReturn");
			this.barEditProcessesToReturn.Edit = this.repositoryComboBoxProcessesToReturn;
			this.barEditProcessesToReturn.Id = 6;
			this.barEditProcessesToReturn.Name = "barEditProcessesToReturn";
			this.barEditProcessesToReturn.PaintStyle = BarItemPaintStyle.Caption;
			this.barEditProcessesToReturn.EditValueChanged += this.comboBoxProcessesToReturn_EditValueChanged;
			resources.ApplyResources(this.repositoryComboBoxProcessesToReturn, "repositoryComboBoxProcessesToReturn");
			this.repositoryComboBoxProcessesToReturn.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryComboBoxProcessesToReturn.Buttons"))
			});
			this.repositoryComboBoxProcessesToReturn.Name = "repositoryComboBoxProcessesToReturn";
			this.repositoryComboBoxProcessesToReturn.TextEditStyle = TextEditStyles.DisableTextEditor;
			this.btnRefresh.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnRefresh, "btnRefresh");
			this.btnRefresh.Id = 1;
			this.btnRefresh.ImageOptions.Image = Resources.refresh2_16x16;
			this.btnRefresh.ImageOptions.LargeImage = Resources.refresh2_32x32;
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnRefresh.ItemClick += this.btnRefresh_ItemClick;
			resources.ApplyResources(this.barEditRefreshTime, "barEditRefreshTime");
			this.barEditRefreshTime.Edit = this.repositoryComboBoxRefreshTime;
			this.barEditRefreshTime.Id = 3;
			this.barEditRefreshTime.Name = "barEditRefreshTime";
			this.barEditRefreshTime.PaintStyle = BarItemPaintStyle.Caption;
			this.repositoryComboBoxRefreshTime.AutoComplete = false;
			resources.ApplyResources(this.repositoryComboBoxRefreshTime, "repositoryComboBoxRefreshTime");
			this.repositoryComboBoxRefreshTime.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryComboBoxRefreshTime.Buttons"))
			});
			this.repositoryComboBoxRefreshTime.Name = "repositoryComboBoxRefreshTime";
			this.repositoryComboBoxRefreshTime.EditValueChanged += this.repositoryComboBoxRefreshTime_EditValueChanged;
			this.btnTerminateProcess.Border = BorderStyles.Simple;
			resources.ApplyResources(this.btnTerminateProcess, "btnTerminateProcess");
			this.btnTerminateProcess.Id = 7;
			this.btnTerminateProcess.ImageOptions.Image = Resources.cancel_16x161;
			this.btnTerminateProcess.ImageOptions.LargeImage = Resources.cancel_32x321;
			this.btnTerminateProcess.Name = "btnTerminateProcess";
			this.btnTerminateProcess.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.btnTerminateProcess.ItemClick += this.btnTerminateProcess_ItemClick;
			resources.ApplyResources(this.barButtonExport, "barButtonExport");
			this.barButtonExport.Id = 8;
			this.barButtonExport.Name = "barButtonExport";
			this.barButtonExport.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonExport.Visibility = BarItemVisibility.Never;
			this.barDockControlTop.CausesValidation = false;
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlBottom.CausesValidation = false;
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlLeft.CausesValidation = false;
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControl1.CausesValidation = false;
			resources.ApplyResources(this.barDockControl1, "barDockControl1");
			this.barDockControl1.Manager = this.barManager;
			resources.ApplyResources(this.gridProcessList, "gridProcessList");
			this.gridProcessList.MainView = this.gridViewProcessList;
			this.gridProcessList.MenuManager = this.barManager;
			this.gridProcessList.Name = "gridProcessList";
			this.gridProcessList.ViewCollection.AddRange(new BaseView[]
			{
				this.gridViewProcessList
			});
			this.gridViewProcessList.Columns.AddRange(new GridColumn[]
			{
				this.columnDeviceName,
				this.columnAppName,
				this.columnFileDescription,
				this.columnMemWorkingSize,
				this.columnUserName,
				this.columnPid,
				this.columnWindowText,
				this.columnCpuUsage,
				this.columSessionID,
				this.columnProcessType,
				this.columnProcessTypeAsString
			});
			this.gridViewProcessList.GridControl = this.gridProcessList;
			this.gridViewProcessList.Name = "gridViewProcessList";
			this.gridViewProcessList.OptionsBehavior.AlignGroupSummaryInGroupRow = DefaultBoolean.False;
			this.gridViewProcessList.OptionsBehavior.Editable = false;
			this.gridViewProcessList.OptionsMenu.ShowFooterItem = true;
			this.gridViewProcessList.OptionsSelection.MultiSelect = true;
			this.gridViewProcessList.OptionsView.EnableAppearanceEvenRow = true;
			this.gridViewProcessList.SortInfo.AddRange(new GridColumnSortInfo[]
			{
				new GridColumnSortInfo(this.columnAppName, ColumnSortOrder.Ascending)
			});
			this.gridViewProcessList.RowStyle += this.gridViewProcessList_RowStyle;
			this.gridViewProcessList.CustomColumnDisplayText += this.gridViewProcessList_CustomColumnDisplayText;
			this.columnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDeviceName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDeviceName, "columnDeviceName");
			this.columnDeviceName.FieldName = "AgentItem.DeviceItem.Name";
			this.columnDeviceName.Name = "columnDeviceName";
			this.columnAppName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnAppName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnAppName, "columnAppName");
			this.columnAppName.FieldName = "ProcessInfo.Name";
			this.columnAppName.Name = "columnAppName";
			this.columnFileDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnFileDescription.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnFileDescription, "columnFileDescription");
			this.columnFileDescription.FieldName = "ProcessInfo.FileDescription";
			this.columnFileDescription.Name = "columnFileDescription";
			this.columnMemWorkingSize.AppearanceCell.Options.UseTextOptions = true;
			this.columnMemWorkingSize.AppearanceCell.TextOptions.HAlignment = HorzAlignment.Far;
			this.columnMemWorkingSize.AppearanceHeader.Options.UseTextOptions = true;
			this.columnMemWorkingSize.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnMemWorkingSize, "columnMemWorkingSize");
			this.columnMemWorkingSize.FieldName = "ProcessInfo.MemWorkingSize";
			this.columnMemWorkingSize.Name = "columnMemWorkingSize";
			this.columnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUserName, "columnUserName");
			this.columnUserName.FieldName = "ProcessInfo.UserName";
			this.columnUserName.Name = "columnUserName";
			this.columnPid.AppearanceHeader.Options.UseTextOptions = true;
			this.columnPid.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnPid, "columnPid");
			this.columnPid.DisplayFormat.FormatType = FormatType.Numeric;
			this.columnPid.FieldName = "ProcessInfo.Pid";
			this.columnPid.Name = "columnPid";
			this.columnWindowText.AppearanceHeader.Options.UseTextOptions = true;
			this.columnWindowText.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnWindowText, "columnWindowText");
			this.columnWindowText.FieldName = "ProcessInfo.WindowText";
			this.columnWindowText.Name = "columnWindowText";
			this.columnCpuUsage.AppearanceHeader.Options.UseTextOptions = true;
			this.columnCpuUsage.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnCpuUsage, "columnCpuUsage");
			this.columnCpuUsage.DisplayFormat.FormatString = "n2";
			this.columnCpuUsage.DisplayFormat.FormatType = FormatType.Numeric;
			this.columnCpuUsage.FieldName = "ProcessInfo.CpuUsage";
			this.columnCpuUsage.Name = "columnCpuUsage";
			this.columSessionID.AppearanceHeader.Options.UseTextOptions = true;
			this.columSessionID.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columSessionID, "columSessionID");
			this.columSessionID.FieldName = "ProcessInfo.Session";
			this.columSessionID.MinWidth = 25;
			this.columSessionID.Name = "columSessionID";
			this.columnProcessType.AppearanceHeader.Options.UseTextOptions = true;
			this.columnProcessType.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnProcessType, "columnProcessType");
			this.columnProcessType.FieldName = "ProcessType";
			this.columnProcessType.MinWidth = 25;
			this.columnProcessType.Name = "columnProcessType";
			this.columnProcessType.OptionsColumn.ShowInCustomizationForm = false;
			this.columnProcessType.OptionsColumn.ShowInExpressionEditor = false;
			this.columnProcessTypeAsString.AppearanceHeader.Options.UseTextOptions = true;
			this.columnProcessTypeAsString.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnProcessTypeAsString, "columnProcessTypeAsString");
			this.columnProcessTypeAsString.FieldName = "ProcessTypeAsString";
			this.columnProcessTypeAsString.MinWidth = 25;
			this.columnProcessTypeAsString.Name = "columnProcessTypeAsString";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.gridProcessList);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControl1);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "ProcessesView";
			((ISupportInitialize)this.barManager).EndInit();
			((ISupportInitialize)this.repositoryComboBoxProcessesToReturn).EndInit();
			((ISupportInitialize)this.repositoryComboBoxRefreshTime).EndInit();
			((ISupportInitialize)this.gridProcessList).EndInit();
			((ISupportInitialize)this.gridViewProcessList).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040006B1 RID: 1713
		private readonly Timer _refreshTimer;

		// Token: 0x040006B2 RID: 1714
		private AgentTaskThrottler _agentTaskThrottler;

		// Token: 0x040006B3 RID: 1715
		private ApiClient _apiClient;

		// Token: 0x040006B4 RID: 1716
		private BindingList<ProcessesView.AgentItemAndProcessInfo> _processesList;

		// Token: 0x040006B5 RID: 1717
		private ProcessesToReturn _processesToReturn;

		// Token: 0x040006B6 RID: 1718
		private IContainer components;

		// Token: 0x040006B7 RID: 1719
		private BarDockControl barDockControlRight;

		// Token: 0x040006B8 RID: 1720
		private BarManager barManager;

		// Token: 0x040006B9 RID: 1721
		private Bar barMenu;

		// Token: 0x040006BA RID: 1722
		private BarButtonItem btnRefresh;

		// Token: 0x040006BB RID: 1723
		private BarEditItem barEditRefreshTime;

		// Token: 0x040006BC RID: 1724
		private RepositoryItemComboBox repositoryComboBoxRefreshTime;

		// Token: 0x040006BD RID: 1725
		private BarDockControl barDockControlTop;

		// Token: 0x040006BE RID: 1726
		private BarDockControl barDockControlBottom;

		// Token: 0x040006BF RID: 1727
		private BarDockControl barDockControlLeft;

		// Token: 0x040006C0 RID: 1728
		private GridControl gridProcessList;

		// Token: 0x040006C1 RID: 1729
		private GridView gridViewProcessList;

		// Token: 0x040006C2 RID: 1730
		private GridColumn columnPid;

		// Token: 0x040006C3 RID: 1731
		private GridColumn columnAppName;

		// Token: 0x040006C4 RID: 1732
		private GridColumn columnFileDescription;

		// Token: 0x040006C5 RID: 1733
		private GridColumn columnMemWorkingSize;

		// Token: 0x040006C6 RID: 1734
		private GridColumn columnUserName;

		// Token: 0x040006C7 RID: 1735
		private GridColumn columnDeviceName;

		// Token: 0x040006C8 RID: 1736
		private GridColumn columnWindowText;

		// Token: 0x040006C9 RID: 1737
		private BarEditItem barEditProcessesToReturn;

		// Token: 0x040006CA RID: 1738
		private BarDockControl barDockControl1;

		// Token: 0x040006CB RID: 1739
		private GridColumn columnCpuUsage;

		// Token: 0x040006CC RID: 1740
		private BarButtonItem btnTerminateProcess;

		// Token: 0x040006CD RID: 1741
		private BarButtonItem barButtonExport;

		// Token: 0x040006CE RID: 1742
		private GridColumn columSessionID;

		// Token: 0x040006CF RID: 1743
		private RepositoryItemComboBox repositoryComboBoxProcessesToReturn;

		// Token: 0x040006D0 RID: 1744
		private GridColumn columnProcessType;

		// Token: 0x040006D1 RID: 1745
		private GridColumn columnProcessTypeAsString;

		// Token: 0x020001BE RID: 446
		public enum ProcessType
		{
			// Token: 0x04000B5B RID: 2907
			Application,
			// Token: 0x04000B5C RID: 2908
			Background,
			// Token: 0x04000B5D RID: 2909
			System
		}

		// Token: 0x020001BF RID: 447
		private class AgentItemAndProcessInfo : INotifyPropertyChanged
		{
			// Token: 0x06000C30 RID: 3120 RVA: 0x00065B4E File Offset: 0x00063D4E
			public AgentItemAndProcessInfo(AgentItem agentItem, ProcessInfo processInfo)
			{
				this.AgentItem = agentItem;
				this.ProcessInfo = processInfo;
			}

			// Token: 0x1400000B RID: 11
			// (add) Token: 0x06000C31 RID: 3121 RVA: 0x00065B64 File Offset: 0x00063D64
			// (remove) Token: 0x06000C32 RID: 3122 RVA: 0x00065B9C File Offset: 0x00063D9C
			public event PropertyChangedEventHandler PropertyChanged;

			// Token: 0x1700030B RID: 779
			// (get) Token: 0x06000C33 RID: 3123 RVA: 0x00065BD1 File Offset: 0x00063DD1
			// (set) Token: 0x06000C34 RID: 3124 RVA: 0x00065BD9 File Offset: 0x00063DD9
			public AgentItem AgentItem { get; private set; }

			// Token: 0x1700030C RID: 780
			// (get) Token: 0x06000C35 RID: 3125 RVA: 0x00065BE2 File Offset: 0x00063DE2
			// (set) Token: 0x06000C36 RID: 3126 RVA: 0x00065BEA File Offset: 0x00063DEA
			public string MemWorkingSizeAsString { get; private set; }

			// Token: 0x1700030D RID: 781
			// (get) Token: 0x06000C37 RID: 3127 RVA: 0x00065BF3 File Offset: 0x00063DF3
			// (set) Token: 0x06000C38 RID: 3128 RVA: 0x00065BFC File Offset: 0x00063DFC
			public ProcessInfo ProcessInfo
			{
				get
				{
					return this._processInfo;
				}
				set
				{
					this._processInfo = value;
					this.MemWorkingSizeAsString = LangStringUtils.StringRepresentingFileSize(this._processInfo.MemWorkingSize);
					if (this._processInfo.IsWorkingUserApp)
					{
						this.ProcessType = ProcessesView.ProcessType.Application;
					}
					else if (this._processInfo.IsSystemProcess)
					{
						this.ProcessType = ProcessesView.ProcessType.System;
					}
					else
					{
						this.ProcessType = ProcessesView.ProcessType.Background;
					}
					this.ProcessTypeAsString = SsStringUtils.GetEnumDescriptionFromResource<ProcessesView.ProcessType>(this.ProcessType, Resources.ResourceManager, null);
					this.NotifyPropertyChanged("ProcessInfo");
					this.NotifyPropertyChanged("ProcessType");
					this.NotifyPropertyChanged("ProcessTypeAsString");
				}
			}

			// Token: 0x1700030E RID: 782
			// (get) Token: 0x06000C39 RID: 3129 RVA: 0x00065C91 File Offset: 0x00063E91
			// (set) Token: 0x06000C3A RID: 3130 RVA: 0x00065C99 File Offset: 0x00063E99
			public ProcessesView.ProcessType ProcessType { get; private set; }

			// Token: 0x1700030F RID: 783
			// (get) Token: 0x06000C3B RID: 3131 RVA: 0x00065CA2 File Offset: 0x00063EA2
			// (set) Token: 0x06000C3C RID: 3132 RVA: 0x00065CAA File Offset: 0x00063EAA
			public string ProcessTypeAsString { get; private set; }

			// Token: 0x06000C3D RID: 3133 RVA: 0x00065CB3 File Offset: 0x00063EB3
			private void NotifyPropertyChanged(string name)
			{
				PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
				if (propertyChanged == null)
				{
					return;
				}
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}

			// Token: 0x04000B5E RID: 2910
			private ProcessInfo _processInfo;
		}
	}
}
