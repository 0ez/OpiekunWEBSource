﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.XtraBars;
using OpiekunWEB.Console.Choco;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000A8 RID: 168
	public class PackagesView : BaseView
	{
		// Token: 0x060008A2 RID: 2210 RVA: 0x0004DBBF File Offset: 0x0004BDBF
		public PackagesView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree, IChocolateyService chocoWebService) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this._chocoWebService = chocoWebService;
			this.InitializeComponent();
		}

		// Token: 0x060008A3 RID: 2211 RVA: 0x0004DBDA File Offset: 0x0004BDDA
		public PackagesView()
		{
			this.InitializeComponent();
		}

		// Token: 0x060008A4 RID: 2212 RVA: 0x0004DBE8 File Offset: 0x0004BDE8
		private void barButtonInstallPackage_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<ChocolateyFindPackageForm>(FormAction.Unknown);
		}

		// Token: 0x060008A5 RID: 2213 RVA: 0x0004DBF7 File Offset: 0x0004BDF7
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060008A6 RID: 2214 RVA: 0x0004DC18 File Offset: 0x0004BE18
		private void InitializeComponent()
		{
			this.barManager = new BarManager();
			this.bar2 = new Bar();
			this.barButtonInstallPackage = new BarButtonItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControlRight = new BarDockControl();
			this.barButtonRefresh = new BarButtonItem();
			this.barButtonDeinstallPackage = new BarButtonItem();
			((ISupportInitialize)this.barManager).BeginInit();
			base.SuspendLayout();
			this.barManager.AllowCustomization = false;
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.bar2
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.barButtonInstallPackage,
				this.barButtonRefresh,
				this.barButtonDeinstallPackage
			});
			this.barManager.MainMenu = this.bar2;
			this.barManager.MaxItemId = 3;
			this.bar2.BarName = "Main menu";
			this.bar2.DockCol = 0;
			this.bar2.DockRow = 0;
			this.bar2.DockStyle = BarDockStyle.Top;
			this.bar2.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barButtonInstallPackage),
				new LinkPersistInfo(this.barButtonDeinstallPackage),
				new LinkPersistInfo(this.barButtonRefresh)
			});
			this.bar2.OptionsBar.AllowQuickCustomization = false;
			this.bar2.OptionsBar.MultiLine = true;
			this.bar2.OptionsBar.UseWholeRow = true;
			this.bar2.Text = "Main menu";
			this.barButtonInstallPackage.Caption = "Instaluj pakiet";
			this.barButtonInstallPackage.Id = 0;
			this.barButtonInstallPackage.Name = "barButtonInstallPackage";
			this.barButtonInstallPackage.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonInstallPackage.ItemClick += this.barButtonInstallPackage_ItemClick;
			this.barDockControlTop.CausesValidation = false;
			this.barDockControlTop.Dock = DockStyle.Top;
			this.barDockControlTop.Location = new Point(0, 0);
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlTop.Size = new Size(800, 30);
			this.barDockControlBottom.CausesValidation = false;
			this.barDockControlBottom.Dock = DockStyle.Bottom;
			this.barDockControlBottom.Location = new Point(0, 450);
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlBottom.Size = new Size(800, 0);
			this.barDockControlLeft.CausesValidation = false;
			this.barDockControlLeft.Dock = DockStyle.Left;
			this.barDockControlLeft.Location = new Point(0, 30);
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControlLeft.Size = new Size(0, 420);
			this.barDockControlRight.CausesValidation = false;
			this.barDockControlRight.Dock = DockStyle.Right;
			this.barDockControlRight.Location = new Point(800, 30);
			this.barDockControlRight.Manager = this.barManager;
			this.barDockControlRight.Size = new Size(0, 420);
			this.barButtonRefresh.Caption = "Odśwież";
			this.barButtonRefresh.Id = 1;
			this.barButtonRefresh.ImageOptions.Image = Resources.refresh2_16x16;
			this.barButtonRefresh.Name = "barButtonRefresh";
			this.barButtonRefresh.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonDeinstallPackage.Caption = "Odinstaluj pakiet";
			this.barButtonDeinstallPackage.Id = 2;
			this.barButtonDeinstallPackage.Name = "barButtonDeinstallPackage";
			base.AutoScaleDimensions = new SizeF(7f, 16f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "PackagesView";
			base.Size = new Size(800, 450);
			((ISupportInitialize)this.barManager).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040006A6 RID: 1702
		private IChocolateyService _chocoWebService;

		// Token: 0x040006A7 RID: 1703
		private IContainer components;

		// Token: 0x040006A8 RID: 1704
		private BarManager barManager;

		// Token: 0x040006A9 RID: 1705
		private Bar bar2;

		// Token: 0x040006AA RID: 1706
		private BarDockControl barDockControlTop;

		// Token: 0x040006AB RID: 1707
		private BarDockControl barDockControlBottom;

		// Token: 0x040006AC RID: 1708
		private BarDockControl barDockControlLeft;

		// Token: 0x040006AD RID: 1709
		private BarDockControl barDockControlRight;

		// Token: 0x040006AE RID: 1710
		private BarButtonItem barButtonInstallPackage;

		// Token: 0x040006AF RID: 1711
		private BarButtonItem barButtonDeinstallPackage;

		// Token: 0x040006B0 RID: 1712
		private BarButtonItem barButtonRefresh;
	}
}
