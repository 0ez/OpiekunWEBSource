﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.Utils.Svg;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTab;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000A7 RID: 167
	public class HistoryView : BaseView
	{
		// Token: 0x06000893 RID: 2195 RVA: 0x0004BFE0 File Offset: 0x0004A1E0
		public HistoryView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, ApiClient apiClient, DevicesTree devicesTree) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			List<KeyAndValue<TimePeriods, string>> periods = PeriodTimesExtension.GetValuesAsStringKeyAndValue();
			this.repositoryItemHistoryPeriod.Items.AddRange(periods);
			this.barEditHistoryPeriod.EditValue = periods.Find((KeyAndValue<TimePeriods, string> x) => x.Key == TimePeriods.ThisWeek);
			this.xtraTabMain.ShowTabHeader = DefaultBoolean.False;
			this.barEditUrlViewType.EditValue = this.repositoryComboBoxUrlViewType.Items[0];
			this.barButtonDeleteHistory.Enabled = this._apiClient.IsLoggedUserHasAdminPermission();
			this._objectsToSaveState.Add(this.gridViewHistoryLog);
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x0004C09C File Offset: 0x0004A29C
		protected override void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			base.OnSelectedDeviceChanged(selection);
			this.RefreshFilter();
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x0004C0AB File Offset: 0x0004A2AB
		protected void RefreshFilter()
		{
			this.SetFilter(this._dateFromFiltr, this._dateToFiltr);
		}

		// Token: 0x06000896 RID: 2198 RVA: 0x0004C0BF File Offset: 0x0004A2BF
		protected override void ViewActivate()
		{
			base.ViewActivate();
			this.RefreshFilter();
		}

		// Token: 0x06000897 RID: 2199 RVA: 0x0004C0CD File Offset: 0x0004A2CD
		private void barButtonDeleteHistory_ItemClick(object sender, ItemClickEventArgs e)
		{
			if (this._formCreator.Show<DeleteHistoryForm>())
			{
				this._lastSql = "";
				this.RefreshFilter();
			}
		}

		// Token: 0x06000898 RID: 2200 RVA: 0x0004C0F0 File Offset: 0x0004A2F0
		private void barButtonDownloadHistory_ItemClick(object sender, ItemClickEventArgs e)
		{
			HistoryView.<barButtonDownloadHistory_ItemClick>d__9 <barButtonDownloadHistory_ItemClick>d__;
			<barButtonDownloadHistory_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<barButtonDownloadHistory_ItemClick>d__.<>4__this = this;
			<barButtonDownloadHistory_ItemClick>d__.<>1__state = -1;
			<barButtonDownloadHistory_ItemClick>d__.<>t__builder.Start<HistoryView.<barButtonDownloadHistory_ItemClick>d__9>(ref <barButtonDownloadHistory_ItemClick>d__);
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x0004C127 File Offset: 0x0004A327
		private void barButtonExportHistory_ItemClick(object sender, ItemClickEventArgs e)
		{
			DataExporter.Export(this.gridViewHistoryLog);
		}

		// Token: 0x0600089A RID: 2202 RVA: 0x0004C134 File Offset: 0x0004A334
		private void barEditHistoryPeriod_EditValueChanged(object sender, EventArgs e)
		{
			HistoryView.<barEditHistoryPeriod_EditValueChanged>d__11 <barEditHistoryPeriod_EditValueChanged>d__;
			<barEditHistoryPeriod_EditValueChanged>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<barEditHistoryPeriod_EditValueChanged>d__.<>4__this = this;
			<barEditHistoryPeriod_EditValueChanged>d__.<>1__state = -1;
			<barEditHistoryPeriod_EditValueChanged>d__.<>t__builder.Start<HistoryView.<barEditHistoryPeriod_EditValueChanged>d__11>(ref <barEditHistoryPeriod_EditValueChanged>d__);
		}

		// Token: 0x0600089B RID: 2203 RVA: 0x0004C16B File Offset: 0x0004A36B
		private void barEditUrlViewType_EditValueChanged(object sender, EventArgs e)
		{
			this.RefreshFilter();
		}

		// Token: 0x0600089C RID: 2204 RVA: 0x0004C174 File Offset: 0x0004A374
		private void HistoryDownloaderDayBegin(object sender, DateTime dateTime)
		{
			this.labelInfo.InvokeIfRequired(delegate
			{
				this.labelInfo.Text = string.Format(Resources.HistoryView_DownloadDayBegin, dateTime.ToShortDateString());
			});
		}

		// Token: 0x0600089D RID: 2205 RVA: 0x0004C1AC File Offset: 0x0004A3AC
		private void SetFilter(DateTime dateFrom, DateTime dateTo)
		{
			if (dateFrom == DateTime.MinValue || dateTo == DateTime.MinValue)
			{
				return;
			}
			this._dateFromFiltr = dateFrom;
			this._dateToFiltr = dateTo;
			string sql = string.Format("select *, datetime(Timestamp,'unixepoch','localtime') as DateTime from WebHistoryItem where Timestamp >= '{0}' and Timestamp < '{1}'", ApiUtils.DateTimeToUnixTime(this._dateFromFiltr.ToUniversalTime()), ApiUtils.DateTimeToUnixTime(this._dateToFiltr.ToUniversalTime()));
			if (!this._devicesTree.Selection.IsAllDevicesGroupSelected)
			{
				sql = sql + " and DeviceId in (" + this._devicesTree.Selection.GetDevicesIdListCommaSeparated() + ")";
			}
			int itemFlagsToFilter = 0;
			if (this.barEditUrlViewType.EditValue == this.repositoryComboBoxUrlViewType.Items[1])
			{
				itemFlagsToFilter = 2;
			}
			else if (this.barEditUrlViewType.EditValue == this.repositoryComboBoxUrlViewType.Items[2])
			{
				itemFlagsToFilter = 4;
			}
			else if (this.barEditUrlViewType.EditValue == this.repositoryComboBoxUrlViewType.Items[3])
			{
				itemFlagsToFilter = 6;
			}
			if (itemFlagsToFilter != 0)
			{
				sql += string.Format(" and (ItemFlags & {0}) = {1}", itemFlagsToFilter, itemFlagsToFilter);
			}
			if (sql != this._lastSql)
			{
				this._lastSql = sql;
				this.gridHistoryLog.DataSource = this._apiClient.GetlDataTableForSql(sql, null);
				return;
			}
			this.gridHistoryLog.RefreshDataSource();
		}

		// Token: 0x0600089E RID: 2206 RVA: 0x0004C30C File Offset: 0x0004A50C
		private Task SetWebHistoryOldestDate()
		{
			HistoryView.<SetWebHistoryOldestDate>d__15 <SetWebHistoryOldestDate>d__;
			<SetWebHistoryOldestDate>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SetWebHistoryOldestDate>d__.<>4__this = this;
			<SetWebHistoryOldestDate>d__.<>1__state = -1;
			<SetWebHistoryOldestDate>d__.<>t__builder.Start<HistoryView.<SetWebHistoryOldestDate>d__15>(ref <SetWebHistoryOldestDate>d__);
			return <SetWebHistoryOldestDate>d__.<>t__builder.Task;
		}

		// Token: 0x0600089F RID: 2207 RVA: 0x0004C350 File Offset: 0x0004A550
		private Task UpdateWebHistory(DateTime dateFrom, DateTime dateTo)
		{
			HistoryView.<UpdateWebHistory>d__16 <UpdateWebHistory>d__;
			<UpdateWebHistory>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UpdateWebHistory>d__.<>4__this = this;
			<UpdateWebHistory>d__.dateFrom = dateFrom;
			<UpdateWebHistory>d__.dateTo = dateTo;
			<UpdateWebHistory>d__.<>1__state = -1;
			<UpdateWebHistory>d__.<>t__builder.Start<HistoryView.<UpdateWebHistory>d__16>(ref <UpdateWebHistory>d__);
			return <UpdateWebHistory>d__.<>t__builder.Task;
		}

		// Token: 0x060008A0 RID: 2208 RVA: 0x0004C3A3 File Offset: 0x0004A5A3
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060008A1 RID: 2209 RVA: 0x0004C3C4 File Offset: 0x0004A5C4
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager resources = new ComponentResourceManager(typeof(HistoryView));
			this.barManager = new BarManager(this.components);
			this.barMenu = new Bar();
			this.barEditUrlViewType = new BarEditItem();
			this.repositoryComboBoxUrlViewType = new RepositoryItemComboBox();
			this.barEditHistoryPeriod = new BarEditItem();
			this.repositoryItemHistoryPeriod = new RepositoryItemComboBox();
			this.barEditDateFrom = new BarEditItem();
			this.repositoryDateEditFrom = new RepositoryItemDateEdit();
			this.barEditDateTo = new BarEditItem();
			this.repositoryDateEditDateTo = new RepositoryItemDateEdit();
			this.barButtonDownloadHistory = new BarButtonItem();
			this.barButtonExportHistory = new BarButtonItem();
			this.barButtonDeleteHistory = new BarButtonItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControlRight = new BarDockControl();
			this.repositoryComboBoxEditPeriod = new RepositoryItemComboBox();
			this.xtraTabMain = new XtraTabControl();
			this.xtraTabPageInfo = new XtraTabPage();
			this.labelInfo = new LabelControl();
			this.xtraTabPageGrid = new XtraTabPage();
			this.gridHistoryLog = new GridControl();
			this.bindingSourceWebHistoryItem = new BindingSource(this.components);
			this.gridViewHistoryLog = new GridView();
			this.columnDateTime = new GridColumn();
			this.repositoryDateEditHistoryItemDate = new RepositoryItemDateEdit();
			this.columnUrl = new GridColumn();
			this.columnTitle = new GridColumn();
			this.columnDeviceName = new GridColumn();
			this.columnDomainName = new GridColumn();
			this.columnUserName = new GridColumn();
			this.columnCategoryName = new GridColumn();
			this.columnTimeStamp = new GridColumn();
			((ISupportInitialize)this.barManager).BeginInit();
			((ISupportInitialize)this.repositoryComboBoxUrlViewType).BeginInit();
			((ISupportInitialize)this.repositoryItemHistoryPeriod).BeginInit();
			((ISupportInitialize)this.repositoryDateEditFrom).BeginInit();
			((ISupportInitialize)this.repositoryDateEditFrom.CalendarTimeProperties).BeginInit();
			((ISupportInitialize)this.repositoryDateEditDateTo).BeginInit();
			((ISupportInitialize)this.repositoryDateEditDateTo.CalendarTimeProperties).BeginInit();
			((ISupportInitialize)this.repositoryComboBoxEditPeriod).BeginInit();
			((ISupportInitialize)this.xtraTabMain).BeginInit();
			this.xtraTabMain.SuspendLayout();
			this.xtraTabPageInfo.SuspendLayout();
			this.xtraTabPageGrid.SuspendLayout();
			((ISupportInitialize)this.gridHistoryLog).BeginInit();
			((ISupportInitialize)this.bindingSourceWebHistoryItem).BeginInit();
			((ISupportInitialize)this.gridViewHistoryLog).BeginInit();
			((ISupportInitialize)this.repositoryDateEditHistoryItemDate).BeginInit();
			((ISupportInitialize)this.repositoryDateEditHistoryItemDate.CalendarTimeProperties).BeginInit();
			base.SuspendLayout();
			this.barManager.AllowCustomization = false;
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.barMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.barEditDateFrom,
				this.barEditDateTo,
				this.barButtonDownloadHistory,
				this.barButtonExportHistory,
				this.barEditUrlViewType,
				this.barButtonDeleteHistory,
				this.barEditHistoryPeriod
			});
			this.barManager.MainMenu = this.barMenu;
			this.barManager.MaxItemId = 11;
			this.barManager.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryComboBoxEditPeriod,
				this.repositoryDateEditFrom,
				this.repositoryDateEditDateTo,
				this.repositoryComboBoxUrlViewType,
				this.repositoryItemHistoryPeriod
			});
			this.barMenu.BarName = "Main menu";
			this.barMenu.CanDockStyle = BarCanDockStyle.Top;
			this.barMenu.DockCol = 0;
			this.barMenu.DockRow = 0;
			this.barMenu.DockStyle = BarDockStyle.Top;
			this.barMenu.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barEditUrlViewType),
				new LinkPersistInfo(this.barEditHistoryPeriod),
				new LinkPersistInfo(this.barEditDateFrom),
				new LinkPersistInfo(this.barEditDateTo),
				new LinkPersistInfo(this.barButtonDownloadHistory),
				new LinkPersistInfo(this.barButtonExportHistory),
				new LinkPersistInfo(this.barButtonDeleteHistory)
			});
			this.barMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMenu.OptionsBar.DrawDragBorder = false;
			this.barMenu.OptionsBar.MultiLine = true;
			this.barMenu.OptionsBar.UseWholeRow = true;
			resources.ApplyResources(this.barMenu, "barMenu");
			resources.ApplyResources(this.barEditUrlViewType, "barEditUrlViewType");
			this.barEditUrlViewType.Edit = this.repositoryComboBoxUrlViewType;
			this.barEditUrlViewType.Id = 8;
			this.barEditUrlViewType.ImageOptions.ImageIndex = (int)resources.GetObject("barEditUrlViewType.ImageOptions.ImageIndex");
			this.barEditUrlViewType.ImageOptions.LargeImageIndex = (int)resources.GetObject("barEditUrlViewType.ImageOptions.LargeImageIndex");
			this.barEditUrlViewType.ImageOptions.SvgImage = (SvgImage)resources.GetObject("barEditUrlViewType.ImageOptions.SvgImage");
			this.barEditUrlViewType.Name = "barEditUrlViewType";
			this.barEditUrlViewType.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barEditUrlViewType.EditValueChanged += this.barEditUrlViewType_EditValueChanged;
			resources.ApplyResources(this.repositoryComboBoxUrlViewType, "repositoryComboBoxUrlViewType");
			this.repositoryComboBoxUrlViewType.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryComboBoxUrlViewType.Buttons"))
			});
			this.repositoryComboBoxUrlViewType.Items.AddRange(new object[]
			{
				resources.GetString("repositoryComboBoxUrlViewType.Items"),
				resources.GetString("repositoryComboBoxUrlViewType.Items1"),
				resources.GetString("repositoryComboBoxUrlViewType.Items2"),
				resources.GetString("repositoryComboBoxUrlViewType.Items3")
			});
			this.repositoryComboBoxUrlViewType.Name = "repositoryComboBoxUrlViewType";
			this.repositoryComboBoxUrlViewType.TextEditStyle = TextEditStyles.DisableTextEditor;
			resources.ApplyResources(this.barEditHistoryPeriod, "barEditHistoryPeriod");
			this.barEditHistoryPeriod.Edit = this.repositoryItemHistoryPeriod;
			this.barEditHistoryPeriod.Id = 10;
			this.barEditHistoryPeriod.ImageOptions.ImageIndex = (int)resources.GetObject("barEditHistoryPeriod.ImageOptions.ImageIndex");
			this.barEditHistoryPeriod.ImageOptions.LargeImageIndex = (int)resources.GetObject("barEditHistoryPeriod.ImageOptions.LargeImageIndex");
			this.barEditHistoryPeriod.ImageOptions.SvgImage = (SvgImage)resources.GetObject("barEditHistoryPeriod.ImageOptions.SvgImage");
			this.barEditHistoryPeriod.Name = "barEditHistoryPeriod";
			this.barEditHistoryPeriod.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barEditHistoryPeriod.EditValueChanged += this.barEditHistoryPeriod_EditValueChanged;
			resources.ApplyResources(this.repositoryItemHistoryPeriod, "repositoryItemHistoryPeriod");
			this.repositoryItemHistoryPeriod.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemHistoryPeriod.Buttons"))
			});
			this.repositoryItemHistoryPeriod.Name = "repositoryItemHistoryPeriod";
			this.repositoryItemHistoryPeriod.TextEditStyle = TextEditStyles.DisableTextEditor;
			resources.ApplyResources(this.barEditDateFrom, "barEditDateFrom");
			this.barEditDateFrom.Edit = this.repositoryDateEditFrom;
			this.barEditDateFrom.Id = 2;
			this.barEditDateFrom.ImageOptions.ImageIndex = (int)resources.GetObject("barEditDateFrom.ImageOptions.ImageIndex");
			this.barEditDateFrom.ImageOptions.LargeImageIndex = (int)resources.GetObject("barEditDateFrom.ImageOptions.LargeImageIndex");
			this.barEditDateFrom.ImageOptions.SvgImage = (SvgImage)resources.GetObject("barEditDateFrom.ImageOptions.SvgImage");
			this.barEditDateFrom.Name = "barEditDateFrom";
			this.barEditDateFrom.PaintStyle = BarItemPaintStyle.Caption;
			resources.ApplyResources(this.repositoryDateEditFrom, "repositoryDateEditFrom");
			this.repositoryDateEditFrom.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryDateEditFrom.Buttons"))
			});
			this.repositoryDateEditFrom.CalendarTimeProperties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryDateEditFrom.CalendarTimeProperties.Buttons"))
			});
			this.repositoryDateEditFrom.CalendarTimeProperties.Mask.EditMask = resources.GetString("repositoryDateEditFrom.CalendarTimeProperties.Mask.EditMask");
			this.repositoryDateEditFrom.Mask.EditMask = resources.GetString("repositoryDateEditFrom.Mask.EditMask");
			this.repositoryDateEditFrom.Name = "repositoryDateEditFrom";
			resources.ApplyResources(this.barEditDateTo, "barEditDateTo");
			this.barEditDateTo.Edit = this.repositoryDateEditDateTo;
			this.barEditDateTo.Id = 3;
			this.barEditDateTo.ImageOptions.ImageIndex = (int)resources.GetObject("barEditDateTo.ImageOptions.ImageIndex");
			this.barEditDateTo.ImageOptions.LargeImageIndex = (int)resources.GetObject("barEditDateTo.ImageOptions.LargeImageIndex");
			this.barEditDateTo.ImageOptions.SvgImage = (SvgImage)resources.GetObject("barEditDateTo.ImageOptions.SvgImage");
			this.barEditDateTo.Name = "barEditDateTo";
			this.barEditDateTo.PaintStyle = BarItemPaintStyle.Caption;
			resources.ApplyResources(this.repositoryDateEditDateTo, "repositoryDateEditDateTo");
			this.repositoryDateEditDateTo.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryDateEditDateTo.Buttons"))
			});
			this.repositoryDateEditDateTo.CalendarTimeProperties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryDateEditDateTo.CalendarTimeProperties.Buttons"))
			});
			this.repositoryDateEditDateTo.CalendarTimeProperties.Mask.EditMask = resources.GetString("repositoryDateEditDateTo.CalendarTimeProperties.Mask.EditMask");
			this.repositoryDateEditDateTo.Mask.EditMask = resources.GetString("repositoryDateEditDateTo.Mask.EditMask");
			this.repositoryDateEditDateTo.Name = "repositoryDateEditDateTo";
			resources.ApplyResources(this.barButtonDownloadHistory, "barButtonDownloadHistory");
			this.barButtonDownloadHistory.Id = 4;
			this.barButtonDownloadHistory.ImageOptions.Image = Resources.refresh2_16x16;
			this.barButtonDownloadHistory.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonDownloadHistory.ImageOptions.ImageIndex");
			this.barButtonDownloadHistory.ImageOptions.LargeImage = Resources.refresh2_32x32;
			this.barButtonDownloadHistory.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonDownloadHistory.ImageOptions.LargeImageIndex");
			this.barButtonDownloadHistory.ImageOptions.SvgImage = (SvgImage)resources.GetObject("barButtonDownloadHistory.ImageOptions.SvgImage");
			this.barButtonDownloadHistory.Name = "barButtonDownloadHistory";
			this.barButtonDownloadHistory.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonDownloadHistory.ItemClick += this.barButtonDownloadHistory_ItemClick;
			resources.ApplyResources(this.barButtonExportHistory, "barButtonExportHistory");
			this.barButtonExportHistory.Id = 5;
			this.barButtonExportHistory.ImageOptions.Image = Resources.exporttoxls_16x16;
			this.barButtonExportHistory.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonExportHistory.ImageOptions.ImageIndex");
			this.barButtonExportHistory.ImageOptions.LargeImage = Resources.exporttoxls_32x32;
			this.barButtonExportHistory.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonExportHistory.ImageOptions.LargeImageIndex");
			this.barButtonExportHistory.ImageOptions.SvgImage = (SvgImage)resources.GetObject("barButtonExportHistory.ImageOptions.SvgImage");
			this.barButtonExportHistory.Name = "barButtonExportHistory";
			this.barButtonExportHistory.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonExportHistory.ItemClick += this.barButtonExportHistory_ItemClick;
			resources.ApplyResources(this.barButtonDeleteHistory, "barButtonDeleteHistory");
			this.barButtonDeleteHistory.Id = 9;
			this.barButtonDeleteHistory.ImageOptions.Image = Resources.deletelist_16x16;
			this.barButtonDeleteHistory.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonDeleteHistory.ImageOptions.ImageIndex");
			this.barButtonDeleteHistory.ImageOptions.LargeImage = Resources.deletelist_32x32;
			this.barButtonDeleteHistory.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonDeleteHistory.ImageOptions.LargeImageIndex");
			this.barButtonDeleteHistory.ImageOptions.SvgImage = (SvgImage)resources.GetObject("barButtonDeleteHistory.ImageOptions.SvgImage");
			this.barButtonDeleteHistory.Name = "barButtonDeleteHistory";
			this.barButtonDeleteHistory.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonDeleteHistory.ItemClick += this.barButtonDeleteHistory_ItemClick;
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.CausesValidation = false;
			this.barDockControlTop.Manager = this.barManager;
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.CausesValidation = false;
			this.barDockControlBottom.Manager = this.barManager;
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.CausesValidation = false;
			this.barDockControlLeft.Manager = this.barManager;
			resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
			this.barDockControlRight.CausesValidation = false;
			this.barDockControlRight.Manager = this.barManager;
			resources.ApplyResources(this.repositoryComboBoxEditPeriod, "repositoryComboBoxEditPeriod");
			this.repositoryComboBoxEditPeriod.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryComboBoxEditPeriod.Buttons"))
			});
			this.repositoryComboBoxEditPeriod.Items.AddRange(new object[]
			{
				resources.GetString("repositoryComboBoxEditPeriod.Items"),
				resources.GetString("repositoryComboBoxEditPeriod.Items1"),
				resources.GetString("repositoryComboBoxEditPeriod.Items2"),
				resources.GetString("repositoryComboBoxEditPeriod.Items3"),
				resources.GetString("repositoryComboBoxEditPeriod.Items4")
			});
			this.repositoryComboBoxEditPeriod.Name = "repositoryComboBoxEditPeriod";
			resources.ApplyResources(this.xtraTabMain, "xtraTabMain");
			this.xtraTabMain.Name = "xtraTabMain";
			this.xtraTabMain.SelectedTabPage = this.xtraTabPageInfo;
			this.xtraTabMain.TabPages.AddRange(new XtraTabPage[]
			{
				this.xtraTabPageInfo,
				this.xtraTabPageGrid
			});
			resources.ApplyResources(this.xtraTabPageInfo, "xtraTabPageInfo");
			this.xtraTabPageInfo.Controls.Add(this.labelInfo);
			this.xtraTabPageInfo.Name = "xtraTabPageInfo";
			resources.ApplyResources(this.labelInfo, "labelInfo");
			this.labelInfo.Appearance.Font = (Font)resources.GetObject("labelInfo.Appearance.Font");
			this.labelInfo.Appearance.Options.UseFont = true;
			this.labelInfo.Appearance.Options.UseTextOptions = true;
			this.labelInfo.Appearance.TextOptions.HAlignment = HorzAlignment.Center;
			this.labelInfo.Appearance.TextOptions.WordWrap = WordWrap.Wrap;
			this.labelInfo.LineLocation = LineLocation.Center;
			this.labelInfo.LineOrientation = LabelLineOrientation.Horizontal;
			this.labelInfo.Name = "labelInfo";
			resources.ApplyResources(this.xtraTabPageGrid, "xtraTabPageGrid");
			this.xtraTabPageGrid.Controls.Add(this.gridHistoryLog);
			this.xtraTabPageGrid.Name = "xtraTabPageGrid";
			resources.ApplyResources(this.gridHistoryLog, "gridHistoryLog");
			this.gridHistoryLog.DataSource = this.bindingSourceWebHistoryItem;
			this.gridHistoryLog.EmbeddedNavigator.AccessibleDescription = resources.GetString("gridHistoryLog.EmbeddedNavigator.AccessibleDescription");
			this.gridHistoryLog.EmbeddedNavigator.AccessibleName = resources.GetString("gridHistoryLog.EmbeddedNavigator.AccessibleName");
			this.gridHistoryLog.EmbeddedNavigator.AllowHtmlTextInToolTip = (DefaultBoolean)resources.GetObject("gridHistoryLog.EmbeddedNavigator.AllowHtmlTextInToolTip");
			this.gridHistoryLog.EmbeddedNavigator.Anchor = (AnchorStyles)resources.GetObject("gridHistoryLog.EmbeddedNavigator.Anchor");
			this.gridHistoryLog.EmbeddedNavigator.BackgroundImage = (Image)resources.GetObject("gridHistoryLog.EmbeddedNavigator.BackgroundImage");
			this.gridHistoryLog.EmbeddedNavigator.BackgroundImageLayout = (ImageLayout)resources.GetObject("gridHistoryLog.EmbeddedNavigator.BackgroundImageLayout");
			this.gridHistoryLog.EmbeddedNavigator.ImeMode = (ImeMode)resources.GetObject("gridHistoryLog.EmbeddedNavigator.ImeMode");
			this.gridHistoryLog.EmbeddedNavigator.MaximumSize = (Size)resources.GetObject("gridHistoryLog.EmbeddedNavigator.MaximumSize");
			this.gridHistoryLog.EmbeddedNavigator.TextLocation = (NavigatorButtonsTextLocation)resources.GetObject("gridHistoryLog.EmbeddedNavigator.TextLocation");
			this.gridHistoryLog.EmbeddedNavigator.ToolTip = resources.GetString("gridHistoryLog.EmbeddedNavigator.ToolTip");
			this.gridHistoryLog.EmbeddedNavigator.ToolTipIconType = (ToolTipIconType)resources.GetObject("gridHistoryLog.EmbeddedNavigator.ToolTipIconType");
			this.gridHistoryLog.EmbeddedNavigator.ToolTipTitle = resources.GetString("gridHistoryLog.EmbeddedNavigator.ToolTipTitle");
			this.gridHistoryLog.MainView = this.gridViewHistoryLog;
			this.gridHistoryLog.MenuManager = this.barManager;
			this.gridHistoryLog.Name = "gridHistoryLog";
			this.gridHistoryLog.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryDateEditHistoryItemDate
			});
			this.gridHistoryLog.ViewCollection.AddRange(new BaseView[]
			{
				this.gridViewHistoryLog
			});
			this.bindingSourceWebHistoryItem.DataSource = typeof(WebHistoryItem);
			resources.ApplyResources(this.gridViewHistoryLog, "gridViewHistoryLog");
			this.gridViewHistoryLog.Columns.AddRange(new GridColumn[]
			{
				this.columnDateTime,
				this.columnUrl,
				this.columnTitle,
				this.columnDeviceName,
				this.columnDomainName,
				this.columnUserName,
				this.columnCategoryName,
				this.columnTimeStamp
			});
			this.gridViewHistoryLog.GridControl = this.gridHistoryLog;
			this.gridViewHistoryLog.Name = "gridViewHistoryLog";
			this.gridViewHistoryLog.OptionsBehavior.ReadOnly = true;
			this.gridViewHistoryLog.OptionsView.EnableAppearanceEvenRow = true;
			this.gridViewHistoryLog.SortInfo.AddRange(new GridColumnSortInfo[]
			{
				new GridColumnSortInfo(this.columnDateTime, ColumnSortOrder.Descending)
			});
			this.columnDateTime.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDateTime.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDateTime, "columnDateTime");
			this.columnDateTime.ColumnEdit = this.repositoryDateEditHistoryItemDate;
			this.columnDateTime.DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";
			this.columnDateTime.DisplayFormat.FormatType = FormatType.DateTime;
			this.columnDateTime.FieldName = "DateTime";
			this.columnDateTime.Name = "columnDateTime";
			this.columnDateTime.Summary.AddRange(new GridSummaryItem[]
			{
				new GridColumnSummaryItem()
			});
			resources.ApplyResources(this.repositoryDateEditHistoryItemDate, "repositoryDateEditHistoryItemDate");
			this.repositoryDateEditHistoryItemDate.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryDateEditHistoryItemDate.Buttons"))
			});
			this.repositoryDateEditHistoryItemDate.CalendarTimeProperties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryDateEditHistoryItemDate.CalendarTimeProperties.Buttons"))
			});
			this.repositoryDateEditHistoryItemDate.CalendarTimeProperties.Mask.EditMask = resources.GetString("repositoryDateEditHistoryItemDate.CalendarTimeProperties.Mask.EditMask");
			this.repositoryDateEditHistoryItemDate.Mask.EditMask = resources.GetString("repositoryDateEditHistoryItemDate.Mask.EditMask");
			this.repositoryDateEditHistoryItemDate.Name = "repositoryDateEditHistoryItemDate";
			this.columnUrl.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUrl.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUrl, "columnUrl");
			this.columnUrl.FieldName = "Url";
			this.columnUrl.Name = "columnUrl";
			this.columnUrl.UnboundType = UnboundColumnType.String;
			this.columnTitle.AppearanceHeader.Options.UseTextOptions = true;
			this.columnTitle.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnTitle, "columnTitle");
			this.columnTitle.FieldName = "Title";
			this.columnTitle.Name = "columnTitle";
			this.columnTitle.UnboundType = UnboundColumnType.String;
			this.columnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDeviceName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDeviceName, "columnDeviceName");
			this.columnDeviceName.FieldName = "DeviceName";
			this.columnDeviceName.Name = "columnDeviceName";
			this.columnDeviceName.UnboundType = UnboundColumnType.String;
			this.columnDomainName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDomainName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDomainName, "columnDomainName");
			this.columnDomainName.FieldName = "DomainName";
			this.columnDomainName.MinWidth = 25;
			this.columnDomainName.Name = "columnDomainName";
			this.columnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUserName, "columnUserName");
			this.columnUserName.FieldName = "UserName";
			this.columnUserName.Name = "columnUserName";
			this.columnUserName.UnboundType = UnboundColumnType.String;
			this.columnCategoryName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnCategoryName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnCategoryName, "columnCategoryName");
			this.columnCategoryName.FieldName = "CategoryName";
			this.columnCategoryName.Name = "columnCategoryName";
			this.columnCategoryName.UnboundType = UnboundColumnType.String;
			resources.ApplyResources(this.columnTimeStamp, "columnTimeStamp");
			this.columnTimeStamp.FieldName = "Timestamp";
			this.columnTimeStamp.Name = "columnTimeStamp";
			this.columnTimeStamp.OptionsColumn.ShowInCustomizationForm = false;
			this.columnTimeStamp.UnboundType = UnboundColumnType.DateTime;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.xtraTabMain);
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "HistoryView";
			((ISupportInitialize)this.barManager).EndInit();
			((ISupportInitialize)this.repositoryComboBoxUrlViewType).EndInit();
			((ISupportInitialize)this.repositoryItemHistoryPeriod).EndInit();
			((ISupportInitialize)this.repositoryDateEditFrom.CalendarTimeProperties).EndInit();
			((ISupportInitialize)this.repositoryDateEditFrom).EndInit();
			((ISupportInitialize)this.repositoryDateEditDateTo.CalendarTimeProperties).EndInit();
			((ISupportInitialize)this.repositoryDateEditDateTo).EndInit();
			((ISupportInitialize)this.repositoryComboBoxEditPeriod).EndInit();
			((ISupportInitialize)this.xtraTabMain).EndInit();
			this.xtraTabMain.ResumeLayout(false);
			this.xtraTabPageInfo.ResumeLayout(false);
			this.xtraTabPageGrid.ResumeLayout(false);
			((ISupportInitialize)this.gridHistoryLog).EndInit();
			((ISupportInitialize)this.bindingSourceWebHistoryItem).EndInit();
			((ISupportInitialize)this.gridViewHistoryLog).EndInit();
			((ISupportInitialize)this.repositoryDateEditHistoryItemDate.CalendarTimeProperties).EndInit();
			((ISupportInitialize)this.repositoryDateEditHistoryItemDate).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400067F RID: 1663
		private readonly ApiClient _apiClient;

		// Token: 0x04000680 RID: 1664
		private DateTime _dateFromFiltr;

		// Token: 0x04000681 RID: 1665
		private DateTime _dateToFiltr;

		// Token: 0x04000682 RID: 1666
		private string _lastSql;

		// Token: 0x04000683 RID: 1667
		private IContainer components;

		// Token: 0x04000684 RID: 1668
		private BarManager barManager;

		// Token: 0x04000685 RID: 1669
		private Bar barMenu;

		// Token: 0x04000686 RID: 1670
		private BarDockControl barDockControlTop;

		// Token: 0x04000687 RID: 1671
		private BarDockControl barDockControlBottom;

		// Token: 0x04000688 RID: 1672
		private BarDockControl barDockControlLeft;

		// Token: 0x04000689 RID: 1673
		private BarDockControl barDockControlRight;

		// Token: 0x0400068A RID: 1674
		private RepositoryItemComboBox repositoryComboBoxEditPeriod;

		// Token: 0x0400068B RID: 1675
		private BarEditItem barEditDateFrom;

		// Token: 0x0400068C RID: 1676
		private RepositoryItemDateEdit repositoryDateEditFrom;

		// Token: 0x0400068D RID: 1677
		private BarEditItem barEditDateTo;

		// Token: 0x0400068E RID: 1678
		private RepositoryItemDateEdit repositoryDateEditDateTo;

		// Token: 0x0400068F RID: 1679
		private BarButtonItem barButtonDownloadHistory;

		// Token: 0x04000690 RID: 1680
		private XtraTabControl xtraTabMain;

		// Token: 0x04000691 RID: 1681
		private XtraTabPage xtraTabPageInfo;

		// Token: 0x04000692 RID: 1682
		private XtraTabPage xtraTabPageGrid;

		// Token: 0x04000693 RID: 1683
		private LabelControl labelInfo;

		// Token: 0x04000694 RID: 1684
		private GridControl gridHistoryLog;

		// Token: 0x04000695 RID: 1685
		private GridView gridViewHistoryLog;

		// Token: 0x04000696 RID: 1686
		private GridColumn columnUrl;

		// Token: 0x04000697 RID: 1687
		private GridColumn columnDeviceName;

		// Token: 0x04000698 RID: 1688
		private GridColumn columnDateTime;

		// Token: 0x04000699 RID: 1689
		private GridColumn columnUserName;

		// Token: 0x0400069A RID: 1690
		private GridColumn columnCategoryName;

		// Token: 0x0400069B RID: 1691
		private RepositoryItemDateEdit repositoryDateEditHistoryItemDate;

		// Token: 0x0400069C RID: 1692
		private BarButtonItem barButtonExportHistory;

		// Token: 0x0400069D RID: 1693
		private BarEditItem barEditUrlViewType;

		// Token: 0x0400069E RID: 1694
		private RepositoryItemComboBox repositoryComboBoxUrlViewType;

		// Token: 0x0400069F RID: 1695
		private GridColumn columnTimeStamp;

		// Token: 0x040006A0 RID: 1696
		private GridColumn columnTitle;

		// Token: 0x040006A1 RID: 1697
		private BindingSource bindingSourceWebHistoryItem;

		// Token: 0x040006A2 RID: 1698
		private BarButtonItem barButtonDeleteHistory;

		// Token: 0x040006A3 RID: 1699
		private BarEditItem barEditHistoryPeriod;

		// Token: 0x040006A4 RID: 1700
		private RepositoryItemComboBox repositoryItemHistoryPeriod;

		// Token: 0x040006A5 RID: 1701
		private GridColumn columnDomainName;
	}
}
