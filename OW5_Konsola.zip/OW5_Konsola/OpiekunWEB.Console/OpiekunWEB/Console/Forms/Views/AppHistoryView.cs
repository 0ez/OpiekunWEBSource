﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Navigation;
using DevExpress.XtraCharts;
using DevExpress.XtraCharts.Printing;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraReports.UI;
using DevExpress.XtraTab;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;
using OpiekunWEB.Console.Reports;
using Owpb;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000A3 RID: 163
	public class AppHistoryView : BaseView
	{
		// Token: 0x0600083C RID: 2108 RVA: 0x00045E18 File Offset: 0x00044018
		public AppHistoryView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, ApiClient apiClient, DevicesTree devicesTree) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this.xtraTabMain.ShowTabHeader = DefaultBoolean.False;
			List<KeyAndValue<TimePeriods, string>> periods = PeriodTimesExtension.GetValuesAsStringKeyAndValue();
			this.repositoryItemHistoryPeriod.Items.AddRange(periods);
			this.barEditHistoryPeriod.EditValue = periods.Find((KeyAndValue<TimePeriods, string> x) => x.Key == TimePeriods.ThisWeek);
			this.comboBoxDevices.Properties.Items.Add(Resources.AppHistoryView_AllDevices);
			this.comboBoxDevices.Properties.Items.Add(Resources.AppHistoryView_SelectedDevices);
			this.comboBoxDevices.EditValue = Resources.AppHistoryView_AllDevices;
			this._allUsersItem = new DomainAndUser
			{
				UserName = "*",
				DomainName = "*",
				FullName = Resources.AppHistoryView_AllUsers
			};
			this.chartAppStats.Series[0].ArgumentDataMember = "ExeDescription";
			this.chartAppStats.Series[0].ValueDataMembers.AddRange(new string[]
			{
				"Duration"
			});
			this.chartAppStats.Series[0].ToolTipHintDataMember = "Hint";
			this.chartUrlDomainStats.Series[0].ArgumentDataMember = "UrlDomain";
			this.chartUrlDomainStats.Series[0].ValueDataMembers.AddRange(new string[]
			{
				"Duration"
			});
			this.chartUrlDomainStats.Series[0].ToolTipHintDataMember = "Hint";
			this.SetPeriodChangedView();
			this._objectsToSaveState.Add(this.gridViewAppHistoryLog);
		}

		// Token: 0x0600083D RID: 2109 RVA: 0x00045FD8 File Offset: 0x000441D8
		protected override void AfterRestoreState()
		{
			base.AfterRestoreState();
			foreach (object obj in this.gridViewAppHistoryLog.GroupSummary)
			{
				GridGroupSummaryItem groupSummary = obj as GridGroupSummaryItem;
				if (groupSummary != null && groupSummary.FieldName == "Duration")
				{
					groupSummary.Format = new AppHistoryView.DurationTimeFormater();
				}
			}
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x00046058 File Offset: 0x00044258
		protected override void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			base.OnSelectedDeviceChanged(selection);
			if (base.IsCurrentView)
			{
				this.RefreshFilter(false);
			}
		}

		// Token: 0x0600083F RID: 2111 RVA: 0x00046070 File Offset: 0x00044270
		protected void RefreshFilter(bool fullRefresh)
		{
			AppHistoryView.<RefreshFilter>d__11 <RefreshFilter>d__;
			<RefreshFilter>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<RefreshFilter>d__.<>4__this = this;
			<RefreshFilter>d__.fullRefresh = fullRefresh;
			<RefreshFilter>d__.<>1__state = -1;
			<RefreshFilter>d__.<>t__builder.Start<AppHistoryView.<RefreshFilter>d__11>(ref <RefreshFilter>d__);
		}

		// Token: 0x06000840 RID: 2112 RVA: 0x000460AF File Offset: 0x000442AF
		protected override void ViewActivate()
		{
			base.ViewActivate();
			this.RefreshFilter(false);
		}

		// Token: 0x06000841 RID: 2113 RVA: 0x000460BE File Offset: 0x000442BE
		private void accordionElementAppHistory_Click(object sender, EventArgs e)
		{
			if (!this._appHistoryDetailDownloaded)
			{
				this.xtraTabMain.SelectedTabPage = this.xtraTabPageAppHistoryDownload;
				return;
			}
			this.xtraTabMain.SelectedTabPage = this.xtraTabPageAppHistory;
		}

		// Token: 0x06000842 RID: 2114 RVA: 0x000460EB File Offset: 0x000442EB
		private void accordionElementAppStats_Click(object sender, EventArgs e)
		{
			this.xtraTabMain.SelectedTabPage = this.xtraTabPageAppStats;
		}

		// Token: 0x06000843 RID: 2115 RVA: 0x000460FE File Offset: 0x000442FE
		private void accordionElementDomainStats_Click(object sender, EventArgs e)
		{
			this.xtraTabMain.SelectedTabPage = this.xtraTabPageDomainStats;
		}

		// Token: 0x06000844 RID: 2116 RVA: 0x00046111 File Offset: 0x00044311
		private void barButtonDeleteHistory_ItemClick(object sender, ItemClickEventArgs e)
		{
			if (this._formCreator.Show<DeleteHistoryForm>())
			{
				this._lastSql = "";
				this.RefreshFilter(true);
			}
		}

		// Token: 0x06000845 RID: 2117 RVA: 0x00046134 File Offset: 0x00044334
		private void barButtonDownload_ItemClick(object sender, ItemClickEventArgs e)
		{
			AppHistoryView.<barButtonDownload_ItemClick>d__17 <barButtonDownload_ItemClick>d__;
			<barButtonDownload_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<barButtonDownload_ItemClick>d__.<>4__this = this;
			<barButtonDownload_ItemClick>d__.<>1__state = -1;
			<barButtonDownload_ItemClick>d__.<>t__builder.Start<AppHistoryView.<barButtonDownload_ItemClick>d__17>(ref <barButtonDownload_ItemClick>d__);
		}

		// Token: 0x06000846 RID: 2118 RVA: 0x0004616C File Offset: 0x0004436C
		private void barButtonExport_ItemClick(object sender, ItemClickEventArgs e)
		{
			if (this.xtraTabMain.SelectedTabPage == this.xtraTabPageAppStats)
			{
				this.ShowAppHistoryStatsReport();
			}
			if (this.xtraTabMain.SelectedTabPage == this.xtraTabPageDomainStats)
			{
				this.ShowDomainHistoryStatsReport();
			}
			if (this.xtraTabMain.SelectedTabPage == this.xtraTabPageAppHistory)
			{
				DataExporter.Export(this.gridViewAppHistoryLog);
			}
		}

		// Token: 0x06000847 RID: 2119 RVA: 0x000461CC File Offset: 0x000443CC
		private void barEditHistoryPeriod_EditValueChanged(object sender, EventArgs e)
		{
			AppHistoryView.<barEditHistoryPeriod_EditValueChanged>d__19 <barEditHistoryPeriod_EditValueChanged>d__;
			<barEditHistoryPeriod_EditValueChanged>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<barEditHistoryPeriod_EditValueChanged>d__.<>4__this = this;
			<barEditHistoryPeriod_EditValueChanged>d__.<>1__state = -1;
			<barEditHistoryPeriod_EditValueChanged>d__.<>t__builder.Start<AppHistoryView.<barEditHistoryPeriod_EditValueChanged>d__19>(ref <barEditHistoryPeriod_EditValueChanged>d__);
		}

		// Token: 0x06000848 RID: 2120 RVA: 0x00046203 File Offset: 0x00044403
		private void chartAppStats_ObjectHotTracked(object sender, HotTrackEventArgs e)
		{
			if (e.HitInfo.InChartTitle)
			{
				e.Cancel = true;
			}
		}

		// Token: 0x06000849 RID: 2121 RVA: 0x00046203 File Offset: 0x00044403
		private void chartUrlDomainStats_ObjectHotTracked(object sender, HotTrackEventArgs e)
		{
			if (e.HitInfo.InChartTitle)
			{
				e.Cancel = true;
			}
		}

		// Token: 0x0600084A RID: 2122 RVA: 0x00046219 File Offset: 0x00044419
		private void comboBoxDevices_EditValueChanged(object sender, EventArgs e)
		{
			this.RefreshFilter(true);
		}

		// Token: 0x0600084B RID: 2123 RVA: 0x00046222 File Offset: 0x00044422
		private bool FilteredByDevices()
		{
			return this.comboBoxDevices.SelectedIndex != 0 && !this._devicesTree.Selection.IsAllDevicesGroupSelected;
		}

		// Token: 0x0600084C RID: 2124 RVA: 0x00046248 File Offset: 0x00044448
		private Task GetAppHistoryStats(DateTime dateFrom, DateTime dateTo, uint take)
		{
			AppHistoryView.<GetAppHistoryStats>d__24 <GetAppHistoryStats>d__;
			<GetAppHistoryStats>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<GetAppHistoryStats>d__.<>4__this = this;
			<GetAppHistoryStats>d__.dateFrom = dateFrom;
			<GetAppHistoryStats>d__.dateTo = dateTo;
			<GetAppHistoryStats>d__.take = take;
			<GetAppHistoryStats>d__.<>1__state = -1;
			<GetAppHistoryStats>d__.<>t__builder.Start<AppHistoryView.<GetAppHistoryStats>d__24>(ref <GetAppHistoryStats>d__);
			return <GetAppHistoryStats>d__.<>t__builder.Task;
		}

		// Token: 0x0600084D RID: 2125 RVA: 0x000462A4 File Offset: 0x000444A4
		private Task GetAppHistoryUsers()
		{
			AppHistoryView.<GetAppHistoryUsers>d__25 <GetAppHistoryUsers>d__;
			<GetAppHistoryUsers>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<GetAppHistoryUsers>d__.<>4__this = this;
			<GetAppHistoryUsers>d__.<>1__state = -1;
			<GetAppHistoryUsers>d__.<>t__builder.Start<AppHistoryView.<GetAppHistoryUsers>d__25>(ref <GetAppHistoryUsers>d__);
			return <GetAppHistoryUsers>d__.<>t__builder.Task;
		}

		// Token: 0x0600084E RID: 2126 RVA: 0x000462E8 File Offset: 0x000444E8
		private DateTime GetDateFrom()
		{
			return ApiUtils.DateTimeForDayBegin((this.barEditDateFrom.EditValue as DateTime?).Value);
		}

		// Token: 0x0600084F RID: 2127 RVA: 0x00046318 File Offset: 0x00044518
		private DateTime GetDateTo()
		{
			return ApiUtils.DateTimeForDayEnd((this.barEditDateTo.EditValue as DateTime?).Value);
		}

		// Token: 0x06000850 RID: 2128 RVA: 0x00046347 File Offset: 0x00044547
		private List<string> GetDevicesFilter()
		{
			if (this.FilteredByDevices())
			{
				return this._devicesTree.Selection.GetDevicesIdList();
			}
			return null;
		}

		// Token: 0x06000851 RID: 2129 RVA: 0x00046364 File Offset: 0x00044564
		private string GetReportDescription()
		{
			string devices = this.comboBoxDevices.Text;
			if (this.comboBoxDevices.SelectedIndex != 0)
			{
				devices = this._devicesTree.Selection.GetSelectedNames();
			}
			return string.Format(Resources.AppHistoryView_ReportDescription, new object[]
			{
				this.searchLookUpUsers.Text,
				devices,
				this.GetDateFrom().ToString("yyyy-MM-dd"),
				this.GetDateTo().ToString("yyyy-MM-dd")
			});
		}

		// Token: 0x06000852 RID: 2130 RVA: 0x000463EC File Offset: 0x000445EC
		private Task GetStats(DateTime dateFrom, DateTime dateTo, uint take)
		{
			AppHistoryView.<GetStats>d__30 <GetStats>d__;
			<GetStats>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<GetStats>d__.<>4__this = this;
			<GetStats>d__.dateFrom = dateFrom;
			<GetStats>d__.dateTo = dateTo;
			<GetStats>d__.take = take;
			<GetStats>d__.<>1__state = -1;
			<GetStats>d__.<>t__builder.Start<AppHistoryView.<GetStats>d__30>(ref <GetStats>d__);
			return <GetStats>d__.<>t__builder.Task;
		}

		// Token: 0x06000853 RID: 2131 RVA: 0x00046447 File Offset: 0x00044647
		private uint GetTake()
		{
			return decimal.ToUInt32((decimal)this.barEditItemTake.EditValue);
		}

		// Token: 0x06000854 RID: 2132 RVA: 0x00046460 File Offset: 0x00044660
		private Task GetUrlDomainHistoryStats(DateTime dateFrom, DateTime dateTo, uint take)
		{
			AppHistoryView.<GetUrlDomainHistoryStats>d__32 <GetUrlDomainHistoryStats>d__;
			<GetUrlDomainHistoryStats>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<GetUrlDomainHistoryStats>d__.<>4__this = this;
			<GetUrlDomainHistoryStats>d__.dateFrom = dateFrom;
			<GetUrlDomainHistoryStats>d__.dateTo = dateTo;
			<GetUrlDomainHistoryStats>d__.take = take;
			<GetUrlDomainHistoryStats>d__.<>1__state = -1;
			<GetUrlDomainHistoryStats>d__.<>t__builder.Start<AppHistoryView.<GetUrlDomainHistoryStats>d__32>(ref <GetUrlDomainHistoryStats>d__);
			return <GetUrlDomainHistoryStats>d__.<>t__builder.Task;
		}

		// Token: 0x06000855 RID: 2133 RVA: 0x000464BC File Offset: 0x000446BC
		private List<DomainAndUser> GetUsersFilter()
		{
			if (this.searchLookUpUsers.EditValue != null)
			{
				DomainAndUser user = this._appHistoryUsers.Items.FirstOrDefault((DomainAndUser x) => x.Id == this.searchLookUpUsers.EditValue as string);
				if (user != null && user.Id != this._allUsersItem.Id)
				{
					return new List<DomainAndUser>
					{
						user
					};
				}
			}
			return null;
		}

		// Token: 0x06000856 RID: 2134 RVA: 0x0004651C File Offset: 0x0004471C
		private void gridViewAppHistoryLog_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			if (e.Column == this.columnExeDescription)
			{
				GridView gridView = sender as GridView;
				object obj = (gridView != null) ? gridView.GetListSourceRowCellValue(e.ListSourceRowIndex, "ItemType") : null;
				if (obj is long)
				{
					long longVal = (long)obj;
					if ((int)longVal == 1)
					{
						e.DisplayText = Resources.AppHistoryView_AppIdleTime;
					}
				}
			}
		}

		// Token: 0x06000857 RID: 2135 RVA: 0x00046574 File Offset: 0x00044774
		private void gridViewAppHistoryLog_RowStyle(object sender, RowStyleEventArgs e)
		{
			GridView gridView = sender as GridView;
			object obj = (gridView != null) ? gridView.GetRowCellValue(e.RowHandle, "ItemType") : null;
			if (obj is long)
			{
				long longVal = (long)obj;
				if ((int)longVal == 1)
				{
					e.Appearance.ForeColor = Color.BlueViolet;
					e.HighPriority = true;
				}
			}
		}

		// Token: 0x06000858 RID: 2136 RVA: 0x000465CC File Offset: 0x000447CC
		private void labelDownloadAppHistory_Click(object sender, EventArgs e)
		{
			AppHistoryView.<labelDownloadAppHistory_Click>d__36 <labelDownloadAppHistory_Click>d__;
			<labelDownloadAppHistory_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<labelDownloadAppHistory_Click>d__.<>4__this = this;
			<labelDownloadAppHistory_Click>d__.<>1__state = -1;
			<labelDownloadAppHistory_Click>d__.<>t__builder.Start<AppHistoryView.<labelDownloadAppHistory_Click>d__36>(ref <labelDownloadAppHistory_Click>d__);
		}

		// Token: 0x06000859 RID: 2137 RVA: 0x00046604 File Offset: 0x00044804
		private void OnHistoryDownloaderDayBegin(object sender, DateTime dateTime)
		{
			this.labelClickAndDownloadInfo.InvokeIfRequired(delegate
			{
				this.labelClickAndDownloadInfo.Text = string.Format(Resources.HistoryView_DownloadDayBegin, dateTime.ToShortDateString());
			});
		}

		// Token: 0x0600085A RID: 2138 RVA: 0x0004663C File Offset: 0x0004483C
		private void RefreshDetailAppHistoryFilter()
		{
			if (this._appHistoryDetailDownloaded)
			{
				this.SetAppHistoryDetailFilter(this.GetDateFrom(), this.GetDateTo());
			}
		}

		// Token: 0x0600085B RID: 2139 RVA: 0x00046658 File Offset: 0x00044858
		private Task ReloadStats()
		{
			AppHistoryView.<ReloadStats>d__39 <ReloadStats>d__;
			<ReloadStats>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ReloadStats>d__.<>4__this = this;
			<ReloadStats>d__.<>1__state = -1;
			<ReloadStats>d__.<>t__builder.Start<AppHistoryView.<ReloadStats>d__39>(ref <ReloadStats>d__);
			return <ReloadStats>d__.<>t__builder.Task;
		}

		// Token: 0x0600085C RID: 2140 RVA: 0x0004669C File Offset: 0x0004489C
		private void searchLookUpUsers_EditValueChanged(object sender, EventArgs e)
		{
			AppHistoryView.<searchLookUpUsers_EditValueChanged>d__40 <searchLookUpUsers_EditValueChanged>d__;
			<searchLookUpUsers_EditValueChanged>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<searchLookUpUsers_EditValueChanged>d__.<>4__this = this;
			<searchLookUpUsers_EditValueChanged>d__.<>1__state = -1;
			<searchLookUpUsers_EditValueChanged>d__.<>t__builder.Start<AppHistoryView.<searchLookUpUsers_EditValueChanged>d__40>(ref <searchLookUpUsers_EditValueChanged>d__);
		}

		// Token: 0x0600085D RID: 2141 RVA: 0x000466D4 File Offset: 0x000448D4
		private void searchLookUpUsers_Properties_CustomDisplayText(object sender, CustomDisplayTextEventArgs e)
		{
			if (this._appHistoryUsers != null)
			{
				DomainAndUser user = this._appHistoryUsers.Items.FirstOrDefault((DomainAndUser x) => x.Id == e.Value as string);
				if (user != null)
				{
					e.DisplayText = user.FullNameOrDomainName;
				}
			}
		}

		// Token: 0x0600085E RID: 2142 RVA: 0x00046728 File Offset: 0x00044928
		private void SetAppHistoryDetailFilter(DateTime dateFrom, DateTime dateTo)
		{
			if (!this._appHistoryDetailDownloaded)
			{
				return;
			}
			string sql = "select datetime(Timestamp,'unixepoch','localtime') as DateTime, (10000000*Duration) as DurationTimeSpan, Duration,DeviceName,UserName,DomainName,FullName,ItemType,ExeName,ExeDescription,Title,Url,UrlDomain " + string.Format("from AppHistoryItem where Timestamp >= '{0}' and Timestamp < '{1}'", ApiUtils.DateTimeToUnixTime(dateFrom.ToUniversalTime()), ApiUtils.DateTimeToUnixTime(dateTo.ToUniversalTime()));
			if (this.FilteredByDevices())
			{
				sql = sql + " and DeviceId in (" + this._devicesTree.Selection.GetDevicesIdListCommaSeparated() + ")";
			}
			List<DomainAndUser> userFilter = this.GetUsersFilter();
			if (userFilter != null)
			{
				sql = string.Concat(new string[]
				{
					sql,
					" and DomainName = '",
					userFilter[0].DomainName,
					"' and UserName = '",
					userFilter[0].UserName,
					"'"
				});
			}
			if (sql != this._lastSql)
			{
				this._lastSql = sql;
				List<DataColumn> columns = new List<DataColumn>();
				columns.Add(new DataColumn(this.columnDurationTimeSpan.FieldName, typeof(TimeSpan)));
				columns.Add(new DataColumn(this.columnDateTime.FieldName, typeof(DateTime)));
				this.gridAppHistoryLog.DataSource = this._apiClient.GetlDataTableForSql(sql, columns);
				return;
			}
			this.gridAppHistoryLog.RefreshDataSource();
		}

		// Token: 0x0600085F RID: 2143 RVA: 0x00046870 File Offset: 0x00044A70
		private Task SetAppHistoryOldestDate()
		{
			AppHistoryView.<SetAppHistoryOldestDate>d__43 <SetAppHistoryOldestDate>d__;
			<SetAppHistoryOldestDate>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SetAppHistoryOldestDate>d__.<>4__this = this;
			<SetAppHistoryOldestDate>d__.<>1__state = -1;
			<SetAppHistoryOldestDate>d__.<>t__builder.Start<AppHistoryView.<SetAppHistoryOldestDate>d__43>(ref <SetAppHistoryOldestDate>d__);
			return <SetAppHistoryOldestDate>d__.<>t__builder.Task;
		}

		// Token: 0x06000860 RID: 2144 RVA: 0x000468B3 File Offset: 0x00044AB3
		private void SetException(Exception ex)
		{
			this.xtraTabMain.SelectedTabPage = this.xtraTabPageError;
			this.labelError.Text = string.Format(Resources.HistoryView_DownloadHistoryError, ex.Message);
		}

		// Token: 0x06000861 RID: 2145 RVA: 0x000468E4 File Offset: 0x00044AE4
		private void SetPeriodChangedView()
		{
			this.labelClickAndDownloadInfo.Text = Resources.AppHistoryView_ClickAndDownloadInfo;
			this.xtraTabMain.SelectedTabPage = this.xtraTabPageInfo;
			this.accordionControl.Visible = false;
			this._appHistoryUsers = null;
			this._appHistoryDetailDownloaded = false;
			this._appStatsDownloaded = false;
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x00046934 File Offset: 0x00044B34
		private void ShowAppHistoryStatsReport()
		{
			AppHistoryStatsCollection appHistoryStatsCollection = this._appHistoryStatsCollection;
			if (appHistoryStatsCollection != null && appHistoryStatsCollection.Items.Any<AppHistoryStatsItem>())
			{
				new ReportPrintTool(new AppHistoryStatsReport(this._apiClient.KeyName, this.GetReportDescription(), this.chartAppStats)
				{
					DataSource = this._appHistoryStatsCollection.Items
				}, false).ShowPreview();
			}
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x00046994 File Offset: 0x00044B94
		private void ShowDomainHistoryStatsReport()
		{
			UrlDomainHistoryStatsCollection urlDomainHistoryStatsCollection = this._urlDomainHistoryStatsCollection;
			if (urlDomainHistoryStatsCollection != null && urlDomainHistoryStatsCollection.Items.Any<UrlDomainHistoryStatsItem>())
			{
				new ReportPrintTool(new DomainHistoryStatsReport(this._apiClient.KeyName, this.GetReportDescription(), this.chartUrlDomainStats)
				{
					DataSource = this._urlDomainHistoryStatsCollection.Items
				}, false).ShowPreview();
			}
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x000469F2 File Offset: 0x00044BF2
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x00046A14 File Offset: 0x00044C14
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager resources = new ComponentResourceManager(typeof(AppHistoryView));
			Series series = new Series();
			PieSeriesLabel pieSeriesLabel = new PieSeriesLabel();
			PieSeriesView pieSeriesView = new PieSeriesView();
			ChartTitle chartTitle = new ChartTitle();
			ChartTitle chartTitle2 = new ChartTitle();
			Series series2 = new Series();
			PieSeriesLabel pieSeriesLabel2 = new PieSeriesLabel();
			PieSeriesView pieSeriesView2 = new PieSeriesView();
			ChartTitle chartTitle3 = new ChartTitle();
			ChartTitle chartTitle4 = new ChartTitle();
			this.barManager = new BarManager(this.components);
			this.barMenu = new Bar();
			this.barEditHistoryPeriod = new BarEditItem();
			this.repositoryItemHistoryPeriod = new RepositoryItemComboBox();
			this.barEditDateFrom = new BarEditItem();
			this.repositoryItemDateFrom = new RepositoryItemDateEdit();
			this.barEditDateTo = new BarEditItem();
			this.repositoryItemDateTo = new RepositoryItemDateEdit();
			this.barEditItemTake = new BarEditItem();
			this.repositoryItemSpinEditTake = new RepositoryItemSpinEdit();
			this.barButtonDownload = new BarButtonItem();
			this.barButtonExport = new BarButtonItem();
			this.barButtonDeleteHistory = new BarButtonItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControlRight = new BarDockControl();
			this.barButtonItem1 = new BarButtonItem();
			this.xtraTabMain = new XtraTabControl();
			this.xtraTabPageAppStats = new XtraTabPage();
			this.chartAppStats = new ChartControl();
			this.toolTipControllerCharts = new ToolTipController(this.components);
			this.accordionContentContainer1 = new AccordionContentContainer();
			this.comboBoxDevices = new ComboBoxEdit();
			this.searchLookUpUsers = new SearchLookUpEdit();
			this.searchLookUpUsersView = new GridView();
			this.columnLookupUserDomain = new GridColumn();
			this.columLookupUserName = new GridColumn();
			this.columnLookupUserFullName = new GridColumn();
			this.xtraTabPageInfo = new XtraTabPage();
			this.labelClickAndDownloadInfo = new LabelControl();
			this.xtraTabPageError = new XtraTabPage();
			this.labelError = new LabelControl();
			this.xtraTabPageDomainStats = new XtraTabPage();
			this.chartUrlDomainStats = new ChartControl();
			this.xtraTabPageAppHistory = new XtraTabPage();
			this.gridAppHistoryLog = new GridControl();
			this.gridViewAppHistoryLog = new GridView();
			this.columnDateTime = new GridColumn();
			this.columnExeDescription = new GridColumn();
			this.columnExeName = new GridColumn();
			this.columnTitle = new GridColumn();
			this.columnUrl = new GridColumn();
			this.columnDeviceName = new GridColumn();
			this.columnDomainName = new GridColumn();
			this.columnUserName = new GridColumn();
			this.columnItemType = new GridColumn();
			this.columnDurationTimeSpan = new GridColumn();
			this.repositoryItemTimeSpanDuration = new RepositoryItemTimeSpanEdit();
			this.columnUrlDomain = new GridColumn();
			this.xtraTabPageAppHistoryDownload = new XtraTabPage();
			this.labelDownloadAppHistory = new HyperlinkLabelControl();
			this.accordionControl = new AccordionControl();
			this.accordionElementUsers = new AccordionControlElement();
			this.accordionControlElement2 = new AccordionControlElement();
			this.accordionElementStats = new AccordionControlElement();
			this.accordionElementAppStats = new AccordionControlElement();
			this.accordionElementDomainStats = new AccordionControlElement();
			this.accordionElementAppHistory = new AccordionControlElement();
			((ISupportInitialize)this.barManager).BeginInit();
			((ISupportInitialize)this.repositoryItemHistoryPeriod).BeginInit();
			((ISupportInitialize)this.repositoryItemDateFrom).BeginInit();
			((ISupportInitialize)this.repositoryItemDateFrom.CalendarTimeProperties).BeginInit();
			((ISupportInitialize)this.repositoryItemDateTo).BeginInit();
			((ISupportInitialize)this.repositoryItemDateTo.CalendarTimeProperties).BeginInit();
			((ISupportInitialize)this.repositoryItemSpinEditTake).BeginInit();
			((ISupportInitialize)this.xtraTabMain).BeginInit();
			this.xtraTabMain.SuspendLayout();
			this.xtraTabPageAppStats.SuspendLayout();
			((ISupportInitialize)this.chartAppStats).BeginInit();
			((ISupportInitialize)series).BeginInit();
			((ISupportInitialize)pieSeriesLabel).BeginInit();
			((ISupportInitialize)pieSeriesView).BeginInit();
			this.accordionContentContainer1.SuspendLayout();
			((ISupportInitialize)this.comboBoxDevices.Properties).BeginInit();
			((ISupportInitialize)this.searchLookUpUsers.Properties).BeginInit();
			((ISupportInitialize)this.searchLookUpUsersView).BeginInit();
			this.xtraTabPageInfo.SuspendLayout();
			this.xtraTabPageError.SuspendLayout();
			this.xtraTabPageDomainStats.SuspendLayout();
			((ISupportInitialize)this.chartUrlDomainStats).BeginInit();
			((ISupportInitialize)series2).BeginInit();
			((ISupportInitialize)pieSeriesLabel2).BeginInit();
			((ISupportInitialize)pieSeriesView2).BeginInit();
			this.xtraTabPageAppHistory.SuspendLayout();
			((ISupportInitialize)this.gridAppHistoryLog).BeginInit();
			((ISupportInitialize)this.gridViewAppHistoryLog).BeginInit();
			((ISupportInitialize)this.repositoryItemTimeSpanDuration).BeginInit();
			this.xtraTabPageAppHistoryDownload.SuspendLayout();
			((ISupportInitialize)this.accordionControl).BeginInit();
			this.accordionControl.SuspendLayout();
			base.SuspendLayout();
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.barMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.barEditDateFrom,
				this.barEditDateTo,
				this.barButtonDownload,
				this.barEditHistoryPeriod,
				this.barButtonDeleteHistory,
				this.barButtonExport,
				this.barButtonItem1,
				this.barEditItemTake
			});
			this.barManager.MainMenu = this.barMenu;
			this.barManager.MaxItemId = 14;
			this.barManager.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryItemDateFrom,
				this.repositoryItemDateTo,
				this.repositoryItemHistoryPeriod,
				this.repositoryItemSpinEditTake
			});
			this.barMenu.BarName = "Main menu";
			this.barMenu.CanDockStyle = BarCanDockStyle.Top;
			this.barMenu.DockCol = 0;
			this.barMenu.DockRow = 0;
			this.barMenu.DockStyle = BarDockStyle.Top;
			this.barMenu.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barEditHistoryPeriod),
				new LinkPersistInfo(this.barEditDateFrom),
				new LinkPersistInfo(this.barEditDateTo),
				new LinkPersistInfo(this.barEditItemTake),
				new LinkPersistInfo(this.barButtonDownload),
				new LinkPersistInfo(this.barButtonExport),
				new LinkPersistInfo(this.barButtonDeleteHistory)
			});
			this.barMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMenu.OptionsBar.DrawDragBorder = false;
			this.barMenu.OptionsBar.MultiLine = true;
			this.barMenu.OptionsBar.UseWholeRow = true;
			resources.ApplyResources(this.barMenu, "barMenu");
			resources.ApplyResources(this.barEditHistoryPeriod, "barEditHistoryPeriod");
			this.barEditHistoryPeriod.Edit = this.repositoryItemHistoryPeriod;
			this.barEditHistoryPeriod.Id = 3;
			this.barEditHistoryPeriod.ImageOptions.ImageIndex = (int)resources.GetObject("barEditHistoryPeriod.ImageOptions.ImageIndex");
			this.barEditHistoryPeriod.ImageOptions.LargeImageIndex = (int)resources.GetObject("barEditHistoryPeriod.ImageOptions.LargeImageIndex");
			this.barEditHistoryPeriod.Name = "barEditHistoryPeriod";
			this.barEditHistoryPeriod.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barEditHistoryPeriod.EditValueChanged += this.barEditHistoryPeriod_EditValueChanged;
			resources.ApplyResources(this.repositoryItemHistoryPeriod, "repositoryItemHistoryPeriod");
			this.repositoryItemHistoryPeriod.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemHistoryPeriod.Buttons"))
			});
			this.repositoryItemHistoryPeriod.Name = "repositoryItemHistoryPeriod";
			this.repositoryItemHistoryPeriod.TextEditStyle = TextEditStyles.DisableTextEditor;
			resources.ApplyResources(this.barEditDateFrom, "barEditDateFrom");
			this.barEditDateFrom.Edit = this.repositoryItemDateFrom;
			this.barEditDateFrom.Id = 0;
			this.barEditDateFrom.ImageOptions.ImageIndex = (int)resources.GetObject("barEditDateFrom.ImageOptions.ImageIndex");
			this.barEditDateFrom.ImageOptions.LargeImageIndex = (int)resources.GetObject("barEditDateFrom.ImageOptions.LargeImageIndex");
			this.barEditDateFrom.Name = "barEditDateFrom";
			this.barEditDateFrom.PaintStyle = BarItemPaintStyle.Caption;
			resources.ApplyResources(this.repositoryItemDateFrom, "repositoryItemDateFrom");
			this.repositoryItemDateFrom.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemDateFrom.Buttons"))
			});
			this.repositoryItemDateFrom.CalendarTimeProperties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemDateFrom.CalendarTimeProperties.Buttons"))
			});
			this.repositoryItemDateFrom.CalendarTimeProperties.Mask.EditMask = resources.GetString("repositoryItemDateFrom.CalendarTimeProperties.Mask.EditMask");
			this.repositoryItemDateFrom.Mask.EditMask = resources.GetString("repositoryItemDateFrom.Mask.EditMask");
			this.repositoryItemDateFrom.Name = "repositoryItemDateFrom";
			resources.ApplyResources(this.barEditDateTo, "barEditDateTo");
			this.barEditDateTo.Edit = this.repositoryItemDateTo;
			this.barEditDateTo.Id = 1;
			this.barEditDateTo.ImageOptions.ImageIndex = (int)resources.GetObject("barEditDateTo.ImageOptions.ImageIndex");
			this.barEditDateTo.ImageOptions.LargeImageIndex = (int)resources.GetObject("barEditDateTo.ImageOptions.LargeImageIndex");
			this.barEditDateTo.Name = "barEditDateTo";
			this.barEditDateTo.PaintStyle = BarItemPaintStyle.Caption;
			resources.ApplyResources(this.repositoryItemDateTo, "repositoryItemDateTo");
			this.repositoryItemDateTo.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemDateTo.Buttons"))
			});
			this.repositoryItemDateTo.CalendarTimeProperties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemDateTo.CalendarTimeProperties.Buttons"))
			});
			this.repositoryItemDateTo.CalendarTimeProperties.Mask.EditMask = resources.GetString("repositoryItemDateTo.CalendarTimeProperties.Mask.EditMask");
			this.repositoryItemDateTo.Mask.EditMask = resources.GetString("repositoryItemDateTo.Mask.EditMask");
			this.repositoryItemDateTo.Name = "repositoryItemDateTo";
			resources.ApplyResources(this.barEditItemTake, "barEditItemTake");
			this.barEditItemTake.Edit = this.repositoryItemSpinEditTake;
			BarEditItem barEditItem = this.barEditItemTake;
			int[] array = new int[4];
			array[0] = 20;
			barEditItem.EditValue = new decimal(array);
			this.barEditItemTake.Id = 13;
			this.barEditItemTake.Name = "barEditItemTake";
			this.barEditItemTake.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			resources.ApplyResources(this.repositoryItemSpinEditTake, "repositoryItemSpinEditTake");
			this.repositoryItemSpinEditTake.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemSpinEditTake.Buttons"))
			});
			this.repositoryItemSpinEditTake.Mask.EditMask = resources.GetString("repositoryItemSpinEditTake.Mask.EditMask");
			RepositoryItemSpinEdit repositoryItemSpinEdit = this.repositoryItemSpinEditTake;
			int[] array2 = new int[4];
			array2[0] = 500;
			repositoryItemSpinEdit.MaxValue = new decimal(array2);
			RepositoryItemSpinEdit repositoryItemSpinEdit2 = this.repositoryItemSpinEditTake;
			int[] array3 = new int[4];
			array3[0] = 3;
			repositoryItemSpinEdit2.MinValue = new decimal(array3);
			this.repositoryItemSpinEditTake.Name = "repositoryItemSpinEditTake";
			resources.ApplyResources(this.barButtonDownload, "barButtonDownload");
			this.barButtonDownload.Id = 2;
			this.barButtonDownload.ImageOptions.Image = Resources.refresh2_16x16;
			this.barButtonDownload.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonDownload.ImageOptions.ImageIndex");
			this.barButtonDownload.ImageOptions.LargeImage = Resources.refresh2_32x32;
			this.barButtonDownload.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonDownload.ImageOptions.LargeImageIndex");
			this.barButtonDownload.Name = "barButtonDownload";
			this.barButtonDownload.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonDownload.ItemClick += this.barButtonDownload_ItemClick;
			resources.ApplyResources(this.barButtonExport, "barButtonExport");
			this.barButtonExport.Enabled = false;
			this.barButtonExport.Id = 11;
			this.barButtonExport.ImageOptions.Image = Resources.exporttoxls_16x16;
			this.barButtonExport.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonExport.ImageOptions.ImageIndex");
			this.barButtonExport.ImageOptions.LargeImage = Resources.exporttoxls_32x32;
			this.barButtonExport.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonExport.ImageOptions.LargeImageIndex");
			this.barButtonExport.Name = "barButtonExport";
			this.barButtonExport.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonExport.ItemClick += this.barButtonExport_ItemClick;
			resources.ApplyResources(this.barButtonDeleteHistory, "barButtonDeleteHistory");
			this.barButtonDeleteHistory.Id = 10;
			this.barButtonDeleteHistory.ImageOptions.Image = Resources.deletelist_16x16;
			this.barButtonDeleteHistory.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonDeleteHistory.ImageOptions.ImageIndex");
			this.barButtonDeleteHistory.ImageOptions.LargeImage = Resources.deletelist_32x32;
			this.barButtonDeleteHistory.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonDeleteHistory.ImageOptions.LargeImageIndex");
			this.barButtonDeleteHistory.Name = "barButtonDeleteHistory";
			this.barButtonDeleteHistory.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonDeleteHistory.ItemClick += this.barButtonDeleteHistory_ItemClick;
			this.barDockControlTop.CausesValidation = false;
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlBottom.CausesValidation = false;
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlLeft.CausesValidation = false;
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControlRight.CausesValidation = false;
			resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
			this.barDockControlRight.Manager = this.barManager;
			this.barButtonItem1.Id = 12;
			this.barButtonItem1.Name = "barButtonItem1";
			resources.ApplyResources(this.xtraTabMain, "xtraTabMain");
			this.xtraTabMain.Name = "xtraTabMain";
			this.xtraTabMain.SelectedTabPage = this.xtraTabPageAppStats;
			this.xtraTabMain.TabPages.AddRange(new XtraTabPage[]
			{
				this.xtraTabPageInfo,
				this.xtraTabPageError,
				this.xtraTabPageAppStats,
				this.xtraTabPageDomainStats,
				this.xtraTabPageAppHistory,
				this.xtraTabPageAppHistoryDownload
			});
			this.xtraTabPageAppStats.Controls.Add(this.chartAppStats);
			this.xtraTabPageAppStats.Name = "xtraTabPageAppStats";
			resources.ApplyResources(this.xtraTabPageAppStats, "xtraTabPageAppStats");
			resources.ApplyResources(this.chartAppStats, "chartAppStats");
			this.chartAppStats.EmptyChartText.Text = resources.GetString("chartAppStats.EmptyChartText.Text");
			this.chartAppStats.EmptyChartText.TextColor = Color.Maroon;
			this.chartAppStats.Legend.AlignmentHorizontal = (LegendAlignmentHorizontal)resources.GetObject("chartAppStats.Legend.AlignmentHorizontal");
			this.chartAppStats.Legend.AlignmentVertical = (LegendAlignmentVertical)resources.GetObject("chartAppStats.Legend.AlignmentVertical");
			this.chartAppStats.Legend.MaxVerticalPercentage = 30.0;
			this.chartAppStats.Legend.Name = "Default Legend";
			this.chartAppStats.Name = "chartAppStats";
			this.chartAppStats.OptionsPrint.ImageFormat = DevExpress.XtraCharts.Printing.PrintImageFormat.Metafile;
			this.chartAppStats.OptionsPrint.SizeMode = PrintSizeMode.Stretch;
			this.chartAppStats.SelectionMode = ElementSelectionMode.Single;
			this.chartAppStats.SeriesSelectionMode = SeriesSelectionMode.Point;
			series.CrosshairContentShowMode = CrosshairContentShowMode.Legend;
			pieSeriesLabel.Position = PieSeriesLabelPosition.TwoColumns;
			pieSeriesLabel.ResolveOverlappingMode = ResolveOverlappingMode.Default;
			pieSeriesLabel.TextPattern = "{VP:0.00%}";
			series.Label = pieSeriesLabel;
			series.LabelsVisibility = DefaultBoolean.True;
			series.LegendName = "Default Legend";
			series.LegendTextPattern = "{A} {HINT} ({VP:0.00%})";
			resources.ApplyResources(series, "series1");
			series.ToolTipPointPattern = "{A} {HINT} ({VP:0.00%})";
			series.View = pieSeriesView;
			this.chartAppStats.SeriesSerializable = new Series[]
			{
				series
			};
			resources.ApplyResources(chartTitle, "chartTitle1");
			chartTitle.TextColor = Color.FromArgb(112, 48, 160);
			resources.ApplyResources(chartTitle2, "chartTitle2");
			this.chartAppStats.Titles.AddRange(new ChartTitle[]
			{
				chartTitle,
				chartTitle2
			});
			this.chartAppStats.ToolTipController = this.toolTipControllerCharts;
			this.chartAppStats.ToolTipEnabled = DefaultBoolean.True;
			this.chartAppStats.ToolTipOptions.ShowForSeries = true;
			this.chartAppStats.ObjectHotTracked += this.chartAppStats_ObjectHotTracked;
			this.toolTipControllerCharts.ShowBeak = true;
			this.accordionContentContainer1.Controls.Add(this.comboBoxDevices);
			this.accordionContentContainer1.Controls.Add(this.searchLookUpUsers);
			this.accordionContentContainer1.Name = "accordionContentContainer1";
			resources.ApplyResources(this.accordionContentContainer1, "accordionContentContainer1");
			this.toolTipControllerCharts.SetToolTipIconType(this.accordionContentContainer1, (ToolTipIconType)resources.GetObject("accordionContentContainer1.ToolTipIconType"));
			resources.ApplyResources(this.comboBoxDevices, "comboBoxDevices");
			this.comboBoxDevices.MenuManager = this.barManager;
			this.comboBoxDevices.Name = "comboBoxDevices";
			this.comboBoxDevices.Properties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("comboBoxDevices.Properties.Buttons"))
			});
			this.comboBoxDevices.Properties.TextEditStyle = TextEditStyles.DisableTextEditor;
			this.comboBoxDevices.EditValueChanged += this.comboBoxDevices_EditValueChanged;
			resources.ApplyResources(this.searchLookUpUsers, "searchLookUpUsers");
			this.searchLookUpUsers.MenuManager = this.barManager;
			this.searchLookUpUsers.Name = "searchLookUpUsers";
			this.searchLookUpUsers.Properties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("searchLookUpUsers.Properties.Buttons"))
			});
			this.searchLookUpUsers.Properties.DisplayMember = "FullName";
			this.searchLookUpUsers.Properties.PopupView = this.searchLookUpUsersView;
			this.searchLookUpUsers.Properties.ValueMember = "Id";
			this.searchLookUpUsers.Properties.CustomDisplayText += this.searchLookUpUsers_Properties_CustomDisplayText;
			this.searchLookUpUsers.EditValueChanged += this.searchLookUpUsers_EditValueChanged;
			this.searchLookUpUsersView.Columns.AddRange(new GridColumn[]
			{
				this.columnLookupUserDomain,
				this.columLookupUserName,
				this.columnLookupUserFullName
			});
			this.searchLookUpUsersView.FocusRectStyle = DrawFocusRectStyle.RowFocus;
			this.searchLookUpUsersView.Name = "searchLookUpUsersView";
			this.searchLookUpUsersView.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.searchLookUpUsersView.OptionsView.ShowGroupPanel = false;
			this.columnLookupUserDomain.AppearanceHeader.Options.UseTextOptions = true;
			this.columnLookupUserDomain.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnLookupUserDomain, "columnLookupUserDomain");
			this.columnLookupUserDomain.FieldName = "DomainName";
			this.columnLookupUserDomain.Name = "columnLookupUserDomain";
			this.columLookupUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columLookupUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columLookupUserName, "columLookupUserName");
			this.columLookupUserName.FieldName = "UserName";
			this.columLookupUserName.Name = "columLookupUserName";
			this.columnLookupUserFullName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnLookupUserFullName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnLookupUserFullName, "columnLookupUserFullName");
			this.columnLookupUserFullName.FieldName = "FullName";
			this.columnLookupUserFullName.Name = "columnLookupUserFullName";
			this.xtraTabPageInfo.Controls.Add(this.labelClickAndDownloadInfo);
			this.xtraTabPageInfo.Name = "xtraTabPageInfo";
			resources.ApplyResources(this.xtraTabPageInfo, "xtraTabPageInfo");
			this.labelClickAndDownloadInfo.Appearance.Font = (Font)resources.GetObject("labelClickAndDownloadInfo.Appearance.Font");
			this.labelClickAndDownloadInfo.Appearance.Options.UseFont = true;
			this.labelClickAndDownloadInfo.Appearance.Options.UseTextOptions = true;
			this.labelClickAndDownloadInfo.Appearance.TextOptions.HAlignment = HorzAlignment.Center;
			this.labelClickAndDownloadInfo.Appearance.TextOptions.WordWrap = WordWrap.Wrap;
			resources.ApplyResources(this.labelClickAndDownloadInfo, "labelClickAndDownloadInfo");
			this.labelClickAndDownloadInfo.LineLocation = LineLocation.Center;
			this.labelClickAndDownloadInfo.LineOrientation = LabelLineOrientation.Horizontal;
			this.labelClickAndDownloadInfo.Name = "labelClickAndDownloadInfo";
			this.xtraTabPageError.Controls.Add(this.labelError);
			this.xtraTabPageError.Name = "xtraTabPageError";
			resources.ApplyResources(this.xtraTabPageError, "xtraTabPageError");
			this.labelError.Appearance.Font = (Font)resources.GetObject("labelError.Appearance.Font");
			this.labelError.Appearance.Options.UseFont = true;
			this.labelError.Appearance.Options.UseTextOptions = true;
			this.labelError.Appearance.TextOptions.HAlignment = HorzAlignment.Center;
			this.labelError.Appearance.TextOptions.WordWrap = WordWrap.Wrap;
			resources.ApplyResources(this.labelError, "labelError");
			this.labelError.LineLocation = LineLocation.Center;
			this.labelError.LineOrientation = LabelLineOrientation.Horizontal;
			this.labelError.Name = "labelError";
			this.xtraTabPageDomainStats.Controls.Add(this.chartUrlDomainStats);
			this.xtraTabPageDomainStats.Name = "xtraTabPageDomainStats";
			resources.ApplyResources(this.xtraTabPageDomainStats, "xtraTabPageDomainStats");
			resources.ApplyResources(this.chartUrlDomainStats, "chartUrlDomainStats");
			this.chartUrlDomainStats.EmptyChartText.Text = resources.GetString("chartUrlDomainStats.EmptyChartText.Text");
			this.chartUrlDomainStats.EmptyChartText.TextColor = Color.Maroon;
			this.chartUrlDomainStats.Legend.AlignmentHorizontal = (LegendAlignmentHorizontal)resources.GetObject("chartUrlDomainStats.Legend.AlignmentHorizontal");
			this.chartUrlDomainStats.Legend.AlignmentVertical = (LegendAlignmentVertical)resources.GetObject("chartUrlDomainStats.Legend.AlignmentVertical");
			this.chartUrlDomainStats.Legend.MaxVerticalPercentage = 30.0;
			this.chartUrlDomainStats.Legend.Name = "Default Legend";
			this.chartUrlDomainStats.Name = "chartUrlDomainStats";
			this.chartUrlDomainStats.OptionsPrint.ImageFormat = DevExpress.XtraCharts.Printing.PrintImageFormat.Metafile;
			this.chartUrlDomainStats.OptionsPrint.SizeMode = PrintSizeMode.Stretch;
			this.chartUrlDomainStats.SelectionMode = ElementSelectionMode.Single;
			this.chartUrlDomainStats.SeriesSelectionMode = SeriesSelectionMode.Point;
			pieSeriesLabel2.Position = PieSeriesLabelPosition.TwoColumns;
			pieSeriesLabel2.ResolveOverlappingMode = ResolveOverlappingMode.Default;
			pieSeriesLabel2.TextPattern = "{VP:0.00%}";
			series2.Label = pieSeriesLabel2;
			series2.LabelsVisibility = DefaultBoolean.True;
			series2.LegendName = "Default Legend";
			series2.LegendTextPattern = "{A} {HINT} ({VP:0.00%})";
			resources.ApplyResources(series2, "series2");
			series2.ToolTipEnabled = DefaultBoolean.True;
			series2.ToolTipPointPattern = "{A} {HINT} ({VP:0.00%})";
			series2.View = pieSeriesView2;
			this.chartUrlDomainStats.SeriesSerializable = new Series[]
			{
				series2
			};
			resources.ApplyResources(chartTitle3, "chartTitle3");
			chartTitle3.TextColor = Color.FromArgb(112, 48, 160);
			resources.ApplyResources(chartTitle4, "chartTitle4");
			this.chartUrlDomainStats.Titles.AddRange(new ChartTitle[]
			{
				chartTitle3,
				chartTitle4
			});
			this.chartUrlDomainStats.ToolTipController = this.toolTipControllerCharts;
			this.chartUrlDomainStats.ToolTipEnabled = DefaultBoolean.True;
			this.chartUrlDomainStats.ObjectHotTracked += this.chartUrlDomainStats_ObjectHotTracked;
			this.xtraTabPageAppHistory.Controls.Add(this.gridAppHistoryLog);
			this.xtraTabPageAppHistory.Name = "xtraTabPageAppHistory";
			resources.ApplyResources(this.xtraTabPageAppHistory, "xtraTabPageAppHistory");
			resources.ApplyResources(this.gridAppHistoryLog, "gridAppHistoryLog");
			this.gridAppHistoryLog.EmbeddedNavigator.AllowHtmlTextInToolTip = (DefaultBoolean)resources.GetObject("gridAppHistoryLog.EmbeddedNavigator.AllowHtmlTextInToolTip");
			this.gridAppHistoryLog.EmbeddedNavigator.Anchor = (AnchorStyles)resources.GetObject("gridAppHistoryLog.EmbeddedNavigator.Anchor");
			this.gridAppHistoryLog.EmbeddedNavigator.BackgroundImageLayout = (ImageLayout)resources.GetObject("gridAppHistoryLog.EmbeddedNavigator.BackgroundImageLayout");
			this.gridAppHistoryLog.EmbeddedNavigator.ImeMode = (ImeMode)resources.GetObject("gridAppHistoryLog.EmbeddedNavigator.ImeMode");
			this.gridAppHistoryLog.EmbeddedNavigator.TextLocation = (NavigatorButtonsTextLocation)resources.GetObject("gridAppHistoryLog.EmbeddedNavigator.TextLocation");
			this.gridAppHistoryLog.EmbeddedNavigator.ToolTipIconType = (ToolTipIconType)resources.GetObject("gridAppHistoryLog.EmbeddedNavigator.ToolTipIconType");
			this.gridAppHistoryLog.MainView = this.gridViewAppHistoryLog;
			this.gridAppHistoryLog.MenuManager = this.barManager;
			this.gridAppHistoryLog.Name = "gridAppHistoryLog";
			this.gridAppHistoryLog.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryItemTimeSpanDuration
			});
			this.gridAppHistoryLog.ViewCollection.AddRange(new BaseView[]
			{
				this.gridViewAppHistoryLog
			});
			this.gridViewAppHistoryLog.Columns.AddRange(new GridColumn[]
			{
				this.columnDateTime,
				this.columnExeDescription,
				this.columnExeName,
				this.columnTitle,
				this.columnUrl,
				this.columnDeviceName,
				this.columnDomainName,
				this.columnUserName,
				this.columnItemType,
				this.columnDurationTimeSpan,
				this.columnUrlDomain
			});
			this.gridViewAppHistoryLog.GridControl = this.gridAppHistoryLog;
			this.gridViewAppHistoryLog.GroupSummary.AddRange(new GridSummaryItem[]
			{
				new GridGroupSummaryItem((SummaryItemType)resources.GetObject("gridViewAppHistoryLog.GroupSummary"), resources.GetString("gridViewAppHistoryLog.GroupSummary1"), (GridColumn)resources.GetObject("gridViewAppHistoryLog.GroupSummary2"), resources.GetString("gridViewAppHistoryLog.GroupSummary3"))
			});
			this.gridViewAppHistoryLog.Name = "gridViewAppHistoryLog";
			this.gridViewAppHistoryLog.OptionsBehavior.ReadOnly = true;
			this.gridViewAppHistoryLog.OptionsMenu.EnableGroupRowMenu = true;
			this.gridViewAppHistoryLog.OptionsMenu.ShowAddNewSummaryItem = DefaultBoolean.True;
			this.gridViewAppHistoryLog.OptionsMenu.ShowFooterItem = true;
			this.gridViewAppHistoryLog.OptionsMenu.ShowGroupSummaryEditorItem = true;
			this.gridViewAppHistoryLog.OptionsView.EnableAppearanceEvenRow = true;
			this.gridViewAppHistoryLog.OptionsView.ShowAutoFilterRow = true;
			this.gridViewAppHistoryLog.OptionsView.ShowFooter = true;
			this.gridViewAppHistoryLog.SortInfo.AddRange(new GridColumnSortInfo[]
			{
				new GridColumnSortInfo(this.columnDateTime, ColumnSortOrder.Descending)
			});
			this.gridViewAppHistoryLog.RowStyle += this.gridViewAppHistoryLog_RowStyle;
			this.gridViewAppHistoryLog.CustomColumnDisplayText += this.gridViewAppHistoryLog_CustomColumnDisplayText;
			this.columnDateTime.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDateTime.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDateTime, "columnDateTime");
			this.columnDateTime.DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";
			this.columnDateTime.DisplayFormat.FormatType = FormatType.DateTime;
			this.columnDateTime.FieldName = "DateTime";
			this.columnDateTime.Name = "columnDateTime";
			this.columnDateTime.UnboundType = UnboundColumnType.DateTime;
			this.columnExeDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnExeDescription.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnExeDescription, "columnExeDescription");
			this.columnExeDescription.FieldName = "ExeDescription";
			this.columnExeDescription.MinWidth = 25;
			this.columnExeDescription.Name = "columnExeDescription";
			this.columnExeDescription.UnboundType = UnboundColumnType.String;
			this.columnExeName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnExeName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnExeName, "columnExeName");
			this.columnExeName.FieldName = "ExeName";
			this.columnExeName.MinWidth = 25;
			this.columnExeName.Name = "columnExeName";
			this.columnTitle.AppearanceHeader.Options.UseTextOptions = true;
			this.columnTitle.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnTitle, "columnTitle");
			this.columnTitle.FieldName = "Title";
			this.columnTitle.Name = "columnTitle";
			this.columnTitle.UnboundType = UnboundColumnType.String;
			this.columnUrl.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUrl.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUrl, "columnUrl");
			this.columnUrl.FieldName = "Url";
			this.columnUrl.Name = "columnUrl";
			this.columnUrl.UnboundType = UnboundColumnType.String;
			this.columnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDeviceName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDeviceName, "columnDeviceName");
			this.columnDeviceName.FieldName = "DeviceName";
			this.columnDeviceName.Name = "columnDeviceName";
			this.columnDeviceName.UnboundType = UnboundColumnType.String;
			this.columnDomainName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDomainName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDomainName, "columnDomainName");
			this.columnDomainName.FieldName = "DomainName";
			this.columnDomainName.MinWidth = 25;
			this.columnDomainName.Name = "columnDomainName";
			this.columnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserName.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUserName, "columnUserName");
			this.columnUserName.FieldName = "UserName";
			this.columnUserName.Name = "columnUserName";
			this.columnUserName.UnboundType = UnboundColumnType.String;
			resources.ApplyResources(this.columnItemType, "columnItemType");
			this.columnItemType.FieldName = "ItemType";
			this.columnItemType.MinWidth = 25;
			this.columnItemType.Name = "columnItemType";
			this.columnItemType.OptionsColumn.ShowInCustomizationForm = false;
			this.columnItemType.OptionsColumn.ShowInExpressionEditor = false;
			this.columnDurationTimeSpan.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDurationTimeSpan.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnDurationTimeSpan, "columnDurationTimeSpan");
			this.columnDurationTimeSpan.ColumnEdit = this.repositoryItemTimeSpanDuration;
			this.columnDurationTimeSpan.FieldName = "DurationTimeSpan";
			this.columnDurationTimeSpan.MinWidth = 25;
			this.columnDurationTimeSpan.Name = "columnDurationTimeSpan";
			resources.ApplyResources(this.repositoryItemTimeSpanDuration, "repositoryItemTimeSpanDuration");
			this.repositoryItemTimeSpanDuration.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton((ButtonPredefines)resources.GetObject("repositoryItemTimeSpanDuration.Buttons"))
			});
			this.repositoryItemTimeSpanDuration.Mask.EditMask = resources.GetString("repositoryItemTimeSpanDuration.Mask.EditMask");
			this.repositoryItemTimeSpanDuration.Name = "repositoryItemTimeSpanDuration";
			this.columnUrlDomain.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUrlDomain.AppearanceHeader.TextOptions.HAlignment = HorzAlignment.Center;
			resources.ApplyResources(this.columnUrlDomain, "columnUrlDomain");
			this.columnUrlDomain.FieldName = "UrlDomain";
			this.columnUrlDomain.MinWidth = 25;
			this.columnUrlDomain.Name = "columnUrlDomain";
			this.xtraTabPageAppHistoryDownload.Controls.Add(this.labelDownloadAppHistory);
			this.xtraTabPageAppHistoryDownload.Name = "xtraTabPageAppHistoryDownload";
			resources.ApplyResources(this.xtraTabPageAppHistoryDownload, "xtraTabPageAppHistoryDownload");
			this.labelDownloadAppHistory.Appearance.Font = (Font)resources.GetObject("labelDownloadAppHistory.Appearance.Font");
			this.labelDownloadAppHistory.Appearance.Options.UseFont = true;
			this.labelDownloadAppHistory.Appearance.Options.UseTextOptions = true;
			this.labelDownloadAppHistory.Appearance.TextOptions.HAlignment = HorzAlignment.Center;
			this.labelDownloadAppHistory.Appearance.TextOptions.VAlignment = VertAlignment.Center;
			resources.ApplyResources(this.labelDownloadAppHistory, "labelDownloadAppHistory");
			this.labelDownloadAppHistory.Name = "labelDownloadAppHistory";
			this.labelDownloadAppHistory.Click += this.labelDownloadAppHistory_Click;
			this.accordionControl.AllowItemSelection = true;
			this.accordionControl.Controls.Add(this.accordionContentContainer1);
			resources.ApplyResources(this.accordionControl, "accordionControl");
			this.accordionControl.Elements.AddRange(new AccordionControlElement[]
			{
				this.accordionElementUsers,
				this.accordionElementStats
			});
			this.accordionControl.ExpandGroupOnHeaderClick = false;
			this.accordionControl.ExpandItemOnHeaderClick = false;
			this.accordionControl.Name = "accordionControl";
			this.accordionControl.OptionsMinimizing.AllowMinimizeMode = DefaultBoolean.False;
			this.accordionControl.ScrollBarMode = ScrollBarMode.Hidden;
			this.accordionControl.ShowGroupExpandButtons = false;
			this.accordionControl.ShowItemExpandButtons = false;
			this.accordionElementUsers.Elements.AddRange(new AccordionControlElement[]
			{
				this.accordionControlElement2
			});
			this.accordionElementUsers.Expanded = true;
			this.accordionElementUsers.ImageOptions.Image = Resources.usergroup_32x32;
			this.accordionElementUsers.Name = "accordionElementUsers";
			resources.ApplyResources(this.accordionElementUsers, "accordionElementUsers");
			this.accordionControlElement2.ContentContainer = this.accordionContentContainer1;
			this.accordionControlElement2.Expanded = true;
			this.accordionControlElement2.HeaderVisible = false;
			this.accordionControlElement2.Name = "accordionControlElement2";
			this.accordionControlElement2.Style = ElementStyle.Item;
			this.accordionElementStats.Elements.AddRange(new AccordionControlElement[]
			{
				this.accordionElementAppStats,
				this.accordionElementDomainStats,
				this.accordionElementAppHistory
			});
			this.accordionElementStats.Expanded = true;
			this.accordionElementStats.HeaderVisible = false;
			this.accordionElementStats.ImageOptions.Image = (Image)resources.GetObject("accordionElementStats.ImageOptions.Image");
			this.accordionElementStats.Name = "accordionElementStats";
			this.accordionElementAppStats.ImageOptions.Image = (Image)resources.GetObject("accordionElementAppStats.ImageOptions.Image");
			this.accordionElementAppStats.Name = "accordionElementAppStats";
			this.accordionElementAppStats.Style = ElementStyle.Item;
			resources.ApplyResources(this.accordionElementAppStats, "accordionElementAppStats");
			this.accordionElementAppStats.Click += this.accordionElementAppStats_Click;
			this.accordionElementDomainStats.ImageOptions.Image = (Image)resources.GetObject("accordionElementDomainStats.ImageOptions.Image");
			this.accordionElementDomainStats.Name = "accordionElementDomainStats";
			this.accordionElementDomainStats.Style = ElementStyle.Item;
			resources.ApplyResources(this.accordionElementDomainStats, "accordionElementDomainStats");
			this.accordionElementDomainStats.Click += this.accordionElementDomainStats_Click;
			this.accordionElementAppHistory.ImageOptions.Image = (Image)resources.GetObject("accordionElementAppHistory.ImageOptions.Image");
			this.accordionElementAppHistory.Name = "accordionElementAppHistory";
			this.accordionElementAppHistory.Style = ElementStyle.Item;
			resources.ApplyResources(this.accordionElementAppHistory, "accordionElementAppHistory");
			this.accordionElementAppHistory.Click += this.accordionElementAppHistory_Click;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.xtraTabMain);
			base.Controls.Add(this.accordionControl);
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "AppHistoryView";
			this.toolTipControllerCharts.SetToolTipIconType(this, (ToolTipIconType)resources.GetObject("$this.ToolTipIconType"));
			((ISupportInitialize)this.barManager).EndInit();
			((ISupportInitialize)this.repositoryItemHistoryPeriod).EndInit();
			((ISupportInitialize)this.repositoryItemDateFrom.CalendarTimeProperties).EndInit();
			((ISupportInitialize)this.repositoryItemDateFrom).EndInit();
			((ISupportInitialize)this.repositoryItemDateTo.CalendarTimeProperties).EndInit();
			((ISupportInitialize)this.repositoryItemDateTo).EndInit();
			((ISupportInitialize)this.repositoryItemSpinEditTake).EndInit();
			((ISupportInitialize)this.xtraTabMain).EndInit();
			this.xtraTabMain.ResumeLayout(false);
			this.xtraTabPageAppStats.ResumeLayout(false);
			((ISupportInitialize)pieSeriesLabel).EndInit();
			((ISupportInitialize)pieSeriesView).EndInit();
			((ISupportInitialize)series).EndInit();
			((ISupportInitialize)this.chartAppStats).EndInit();
			this.accordionContentContainer1.ResumeLayout(false);
			((ISupportInitialize)this.comboBoxDevices.Properties).EndInit();
			((ISupportInitialize)this.searchLookUpUsers.Properties).EndInit();
			((ISupportInitialize)this.searchLookUpUsersView).EndInit();
			this.xtraTabPageInfo.ResumeLayout(false);
			this.xtraTabPageError.ResumeLayout(false);
			this.xtraTabPageDomainStats.ResumeLayout(false);
			((ISupportInitialize)pieSeriesLabel2).EndInit();
			((ISupportInitialize)pieSeriesView2).EndInit();
			((ISupportInitialize)series2).EndInit();
			((ISupportInitialize)this.chartUrlDomainStats).EndInit();
			this.xtraTabPageAppHistory.ResumeLayout(false);
			((ISupportInitialize)this.gridAppHistoryLog).EndInit();
			((ISupportInitialize)this.gridViewAppHistoryLog).EndInit();
			((ISupportInitialize)this.repositoryItemTimeSpanDuration).EndInit();
			this.xtraTabPageAppHistoryDownload.ResumeLayout(false);
			((ISupportInitialize)this.accordionControl).EndInit();
			this.accordionControl.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040005F7 RID: 1527
		private readonly DomainAndUser _allUsersItem;

		// Token: 0x040005F8 RID: 1528
		private readonly ApiClient _apiClient;

		// Token: 0x040005F9 RID: 1529
		private bool _appHistoryDetailDownloaded;

		// Token: 0x040005FA RID: 1530
		private AppHistoryStatsCollection _appHistoryStatsCollection;

		// Token: 0x040005FB RID: 1531
		private DomainAndUserCollection _appHistoryUsers;

		// Token: 0x040005FC RID: 1532
		private bool _appStatsDownloaded;

		// Token: 0x040005FD RID: 1533
		private string _lastSql;

		// Token: 0x040005FE RID: 1534
		private UrlDomainHistoryStatsCollection _urlDomainHistoryStatsCollection;

		// Token: 0x040005FF RID: 1535
		private IContainer components;

		// Token: 0x04000600 RID: 1536
		private BarManager barManager;

		// Token: 0x04000601 RID: 1537
		private Bar barMenu;

		// Token: 0x04000602 RID: 1538
		private BarDockControl barDockControlTop;

		// Token: 0x04000603 RID: 1539
		private BarDockControl barDockControlBottom;

		// Token: 0x04000604 RID: 1540
		private BarDockControl barDockControlLeft;

		// Token: 0x04000605 RID: 1541
		private BarDockControl barDockControlRight;

		// Token: 0x04000606 RID: 1542
		private BarEditItem barEditDateFrom;

		// Token: 0x04000607 RID: 1543
		private RepositoryItemDateEdit repositoryItemDateFrom;

		// Token: 0x04000608 RID: 1544
		private BarEditItem barEditDateTo;

		// Token: 0x04000609 RID: 1545
		private RepositoryItemDateEdit repositoryItemDateTo;

		// Token: 0x0400060A RID: 1546
		private BarButtonItem barButtonDownload;

		// Token: 0x0400060B RID: 1547
		private XtraTabControl xtraTabMain;

		// Token: 0x0400060C RID: 1548
		private XtraTabPage xtraTabPageAppStats;

		// Token: 0x0400060D RID: 1549
		private XtraTabPage xtraTabPageInfo;

		// Token: 0x0400060E RID: 1550
		private BarEditItem barEditHistoryPeriod;

		// Token: 0x0400060F RID: 1551
		private RepositoryItemComboBox repositoryItemHistoryPeriod;

		// Token: 0x04000610 RID: 1552
		private LabelControl labelClickAndDownloadInfo;

		// Token: 0x04000611 RID: 1553
		private XtraTabPage xtraTabPageAppHistory;

		// Token: 0x04000612 RID: 1554
		private GridControl gridAppHistoryLog;

		// Token: 0x04000613 RID: 1555
		private GridView gridViewAppHistoryLog;

		// Token: 0x04000614 RID: 1556
		private GridColumn columnDateTime;

		// Token: 0x04000615 RID: 1557
		private GridColumn columnUrl;

		// Token: 0x04000616 RID: 1558
		private GridColumn columnTitle;

		// Token: 0x04000617 RID: 1559
		private GridColumn columnDeviceName;

		// Token: 0x04000618 RID: 1560
		private GridColumn columnUserName;

		// Token: 0x04000619 RID: 1561
		private GridColumn columnExeDescription;

		// Token: 0x0400061A RID: 1562
		private GridColumn columnExeName;

		// Token: 0x0400061B RID: 1563
		private GridColumn columnItemType;

		// Token: 0x0400061C RID: 1564
		private XtraTabPage xtraTabPageDomainStats;

		// Token: 0x0400061D RID: 1565
		private AccordionControl accordionControl;

		// Token: 0x0400061E RID: 1566
		private AccordionContentContainer accordionContentContainer1;

		// Token: 0x0400061F RID: 1567
		private AccordionControlElement accordionElementUsers;

		// Token: 0x04000620 RID: 1568
		private AccordionControlElement accordionControlElement2;

		// Token: 0x04000621 RID: 1569
		private AccordionControlElement accordionElementAppStats;

		// Token: 0x04000622 RID: 1570
		private AccordionControlElement accordionElementDomainStats;

		// Token: 0x04000623 RID: 1571
		private AccordionControlElement accordionElementAppHistory;

		// Token: 0x04000624 RID: 1572
		private AccordionControlElement accordionElementStats;

		// Token: 0x04000625 RID: 1573
		private ChartControl chartAppStats;

		// Token: 0x04000626 RID: 1574
		private ChartControl chartUrlDomainStats;

		// Token: 0x04000627 RID: 1575
		private GridColumn columnDurationTimeSpan;

		// Token: 0x04000628 RID: 1576
		private ToolTipController toolTipControllerCharts;

		// Token: 0x04000629 RID: 1577
		private SearchLookUpEdit searchLookUpUsers;

		// Token: 0x0400062A RID: 1578
		private GridView searchLookUpUsersView;

		// Token: 0x0400062B RID: 1579
		private GridColumn columLookupUserName;

		// Token: 0x0400062C RID: 1580
		private GridColumn columnLookupUserFullName;

		// Token: 0x0400062D RID: 1581
		private GridColumn columnLookupUserDomain;

		// Token: 0x0400062E RID: 1582
		private XtraTabPage xtraTabPageError;

		// Token: 0x0400062F RID: 1583
		private LabelControl labelError;

		// Token: 0x04000630 RID: 1584
		private XtraTabPage xtraTabPageAppHistoryDownload;

		// Token: 0x04000631 RID: 1585
		private HyperlinkLabelControl labelDownloadAppHistory;

		// Token: 0x04000632 RID: 1586
		private RepositoryItemTimeSpanEdit repositoryItemTimeSpanDuration;

		// Token: 0x04000633 RID: 1587
		private GridColumn columnDomainName;

		// Token: 0x04000634 RID: 1588
		private GridColumn columnUrlDomain;

		// Token: 0x04000635 RID: 1589
		private ComboBoxEdit comboBoxDevices;

		// Token: 0x04000636 RID: 1590
		private BarButtonItem barButtonDeleteHistory;

		// Token: 0x04000637 RID: 1591
		private BarButtonItem barButtonExport;

		// Token: 0x04000638 RID: 1592
		private BarButtonItem barButtonItem1;

		// Token: 0x04000639 RID: 1593
		private BarEditItem barEditItemTake;

		// Token: 0x0400063A RID: 1594
		private RepositoryItemSpinEdit repositoryItemSpinEditTake;

		// Token: 0x0200019D RID: 413
		private class DurationTimeFormater : IFormatProvider, ICustomFormatter
		{
			// Token: 0x06000BDF RID: 3039 RVA: 0x00063DC6 File Offset: 0x00061FC6
			public string Format(string format, object arg, IFormatProvider formatProvider)
			{
				return LangStringUtils.StringRepresentingHMSWorkTime(new long?((long)arg));
			}

			// Token: 0x06000BE0 RID: 3040 RVA: 0x0005250A File Offset: 0x0005070A
			public object GetFormat(Type type)
			{
				return this;
			}
		}
	}
}
