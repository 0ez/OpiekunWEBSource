﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.XtraBars;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;

namespace OpiekunWEB.Console.Forms.Views
{
	// Token: 0x020000A5 RID: 165
	public class ConfigDevicesInfoView : BaseView
	{
		// Token: 0x06000889 RID: 2185 RVA: 0x0004ABBC File Offset: 0x00048DBC
		public ConfigDevicesInfoView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree) : base(formsSettings, formCreator, observableAgregator, devicesTree)
		{
			this.InitializeComponent();
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x0004ABCF File Offset: 0x00048DCF
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600088B RID: 2187 RVA: 0x0004ABF0 File Offset: 0x00048DF0
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager resources = new ComponentResourceManager(typeof(ConfigDevicesInfoView));
			this.gridSystemInfo = new GridControl();
			this.gridViewSystemInfo = new GridView();
			this.gridColumnDisplayName = new GridColumn();
			this.barManager = new BarManager(this.components);
			this.barMenu = new Bar();
			this.barButtonGetComputerInfo = new BarButtonItem();
			this.barButtonExport = new BarButtonItem();
			this.barDockControlTop = new BarDockControl();
			this.barDockControlBottom = new BarDockControl();
			this.barDockControlLeft = new BarDockControl();
			this.barDockControlRight = new BarDockControl();
			this.repositoryItembarEditPeriod = new RepositoryItemComboBox();
			this.repositoryItemDateFrom = new RepositoryItemDateEdit();
			this.repositoryItemDateTo = new RepositoryItemDateEdit();
			GridColumn gridColumnDeviceName = new GridColumn();
			GridColumn gridColumnIpDescription = new GridColumn();
			GridColumn gridColumnDisplayResolution = new GridColumn();
			GridColumn gridColumnHddDescription = new GridColumn();
			GridColumn gridColumnWindowsDescription = new GridColumn();
			GridColumn gridColumnMemoryTotal = new GridColumn();
			GridColumn gridColumnCpu = new GridColumn();
			((ISupportInitialize)this.gridSystemInfo).BeginInit();
			((ISupportInitialize)this.gridViewSystemInfo).BeginInit();
			((ISupportInitialize)this.barManager).BeginInit();
			((ISupportInitialize)this.repositoryItembarEditPeriod).BeginInit();
			((ISupportInitialize)this.repositoryItemDateFrom).BeginInit();
			((ISupportInitialize)this.repositoryItemDateFrom.CalendarTimeProperties).BeginInit();
			((ISupportInitialize)this.repositoryItemDateTo).BeginInit();
			((ISupportInitialize)this.repositoryItemDateTo.CalendarTimeProperties).BeginInit();
			base.SuspendLayout();
			gridColumnDeviceName.Caption = "Komputer";
			gridColumnDeviceName.FieldName = "DeviceName";
			gridColumnDeviceName.Name = "gridColumnDeviceName";
			gridColumnDeviceName.UnboundType = UnboundColumnType.String;
			gridColumnDeviceName.Visible = true;
			gridColumnDeviceName.VisibleIndex = 0;
			gridColumnIpDescription.Caption = "Adres IP";
			gridColumnIpDescription.FieldName = "IpDescription";
			gridColumnIpDescription.Name = "gridColumnIpDescription";
			gridColumnIpDescription.UnboundType = UnboundColumnType.String;
			gridColumnIpDescription.Visible = true;
			gridColumnIpDescription.VisibleIndex = 1;
			gridColumnDisplayResolution.Caption = "Rozdzielczość";
			gridColumnDisplayResolution.FieldName = "DisplayResolution";
			gridColumnDisplayResolution.Name = "gridColumnDisplayResolution";
			gridColumnDisplayResolution.UnboundType = UnboundColumnType.String;
			gridColumnDisplayResolution.Visible = true;
			gridColumnDisplayResolution.VisibleIndex = 3;
			gridColumnHddDescription.Caption = "Dysk";
			gridColumnHddDescription.FieldName = "HddDescription";
			gridColumnHddDescription.Name = "gridColumnHddDescription";
			gridColumnHddDescription.UnboundType = UnboundColumnType.String;
			gridColumnHddDescription.Visible = true;
			gridColumnHddDescription.VisibleIndex = 4;
			gridColumnWindowsDescription.Caption = "System";
			gridColumnWindowsDescription.FieldName = "WindowsDescription";
			gridColumnWindowsDescription.Name = "gridColumnWindowsDescription";
			gridColumnWindowsDescription.UnboundType = UnboundColumnType.String;
			gridColumnWindowsDescription.Visible = true;
			gridColumnWindowsDescription.VisibleIndex = 5;
			gridColumnMemoryTotal.Caption = "Pamięć";
			gridColumnMemoryTotal.FieldName = "MemoryTotal";
			gridColumnMemoryTotal.Name = "gridColumnMemoryTotal";
			gridColumnMemoryTotal.UnboundType = UnboundColumnType.String;
			gridColumnMemoryTotal.Visible = true;
			gridColumnMemoryTotal.VisibleIndex = 6;
			gridColumnCpu.Caption = "Procesor";
			gridColumnCpu.FieldName = "Cpu";
			gridColumnCpu.Name = "gridColumnCpu";
			gridColumnCpu.UnboundType = UnboundColumnType.String;
			gridColumnCpu.Visible = true;
			gridColumnCpu.VisibleIndex = 7;
			this.gridSystemInfo.Dock = DockStyle.Fill;
			this.gridSystemInfo.Location = new Point(0, 32);
			this.gridSystemInfo.MainView = this.gridViewSystemInfo;
			this.gridSystemInfo.Name = "gridSystemInfo";
			this.gridSystemInfo.Size = new Size(547, 314);
			this.gridSystemInfo.TabIndex = 0;
			this.gridSystemInfo.ViewCollection.AddRange(new BaseView[]
			{
				this.gridViewSystemInfo
			});
			this.gridViewSystemInfo.Columns.AddRange(new GridColumn[]
			{
				gridColumnDeviceName,
				gridColumnWindowsDescription,
				gridColumnIpDescription,
				this.gridColumnDisplayName,
				gridColumnDisplayResolution,
				gridColumnCpu,
				gridColumnMemoryTotal,
				gridColumnHddDescription
			});
			this.gridViewSystemInfo.GridControl = this.gridSystemInfo;
			this.gridViewSystemInfo.Name = "gridViewSystemInfo";
			this.gridViewSystemInfo.OptionsBehavior.Editable = false;
			this.gridViewSystemInfo.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewSystemInfo.OptionsView.EnableAppearanceEvenRow = true;
			this.gridViewSystemInfo.OptionsView.ShowGroupPanel = false;
			this.gridViewSystemInfo.SortInfo.AddRange(new GridColumnSortInfo[]
			{
				new GridColumnSortInfo(gridColumnDeviceName, ColumnSortOrder.Ascending)
			});
			this.gridColumnDisplayName.Caption = "Grafika";
			this.gridColumnDisplayName.FieldName = "DisplayName";
			this.gridColumnDisplayName.Name = "gridColumnDisplayName";
			this.gridColumnDisplayName.Visible = true;
			this.gridColumnDisplayName.VisibleIndex = 2;
			this.barManager.AllowCustomization = false;
			this.barManager.Bars.AddRange(new Bar[]
			{
				this.barMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new BarItem[]
			{
				this.barButtonGetComputerInfo,
				this.barButtonExport
			});
			this.barManager.MainMenu = this.barMenu;
			this.barManager.MaxItemId = 8;
			this.barManager.RepositoryItems.AddRange(new RepositoryItem[]
			{
				this.repositoryItembarEditPeriod,
				this.repositoryItemDateFrom,
				this.repositoryItemDateTo
			});
			this.barMenu.BarName = "Main menu";
			this.barMenu.CanDockStyle = BarCanDockStyle.Top;
			this.barMenu.DockCol = 0;
			this.barMenu.DockRow = 0;
			this.barMenu.DockStyle = BarDockStyle.Top;
			this.barMenu.LinksPersistInfo.AddRange(new LinkPersistInfo[]
			{
				new LinkPersistInfo(this.barButtonGetComputerInfo),
				new LinkPersistInfo(this.barButtonExport)
			});
			this.barMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMenu.OptionsBar.DrawDragBorder = false;
			this.barMenu.OptionsBar.MultiLine = true;
			this.barMenu.OptionsBar.UseWholeRow = true;
			this.barMenu.Text = "Main menu";
			this.barButtonGetComputerInfo.Border = BorderStyles.Simple;
			this.barButtonGetComputerInfo.Caption = "Odśwież";
			this.barButtonGetComputerInfo.Id = 6;
			this.barButtonGetComputerInfo.ImageOptions.Image = (Image)resources.GetObject("barButtonGetComputerInfo.ImageOptions.Image");
			this.barButtonGetComputerInfo.ImageOptions.LargeImage = (Image)resources.GetObject("barButtonGetComputerInfo.ImageOptions.LargeImage");
			this.barButtonGetComputerInfo.Name = "barButtonGetComputerInfo";
			this.barButtonGetComputerInfo.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barButtonExport.Caption = "Eksport";
			this.barButtonExport.Id = 7;
			this.barButtonExport.ImageOptions.Image = (Image)resources.GetObject("barButtonExport.ImageOptions.Image");
			this.barButtonExport.ImageOptions.LargeImage = (Image)resources.GetObject("barButtonExport.ImageOptions.LargeImage");
			this.barButtonExport.Name = "barButtonExport";
			this.barButtonExport.PaintStyle = BarItemPaintStyle.CaptionGlyph;
			this.barDockControlTop.CausesValidation = false;
			this.barDockControlTop.Dock = DockStyle.Top;
			this.barDockControlTop.Location = new Point(0, 0);
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlTop.Size = new Size(547, 32);
			this.barDockControlBottom.CausesValidation = false;
			this.barDockControlBottom.Dock = DockStyle.Bottom;
			this.barDockControlBottom.Location = new Point(0, 346);
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlBottom.Size = new Size(547, 0);
			this.barDockControlLeft.CausesValidation = false;
			this.barDockControlLeft.Dock = DockStyle.Left;
			this.barDockControlLeft.Location = new Point(0, 32);
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControlLeft.Size = new Size(0, 314);
			this.barDockControlRight.CausesValidation = false;
			this.barDockControlRight.Dock = DockStyle.Right;
			this.barDockControlRight.Location = new Point(547, 32);
			this.barDockControlRight.Manager = this.barManager;
			this.barDockControlRight.Size = new Size(0, 314);
			this.repositoryItembarEditPeriod.AutoHeight = false;
			this.repositoryItembarEditPeriod.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton(ButtonPredefines.Combo)
			});
			this.repositoryItembarEditPeriod.Items.AddRange(new object[]
			{
				"dziś",
				"wczoraj",
				"wczoraj i dziś",
				"ostatni tydzień",
				"ostatni miesiąc "
			});
			this.repositoryItembarEditPeriod.Name = "repositoryItembarEditPeriod";
			this.repositoryItemDateFrom.AutoHeight = false;
			this.repositoryItemDateFrom.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton(ButtonPredefines.Combo)
			});
			this.repositoryItemDateFrom.CalendarTimeProperties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton(ButtonPredefines.Combo)
			});
			this.repositoryItemDateFrom.Name = "repositoryItemDateFrom";
			this.repositoryItemDateTo.AutoHeight = false;
			this.repositoryItemDateTo.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton(ButtonPredefines.Combo)
			});
			this.repositoryItemDateTo.CalendarTimeProperties.Buttons.AddRange(new EditorButton[]
			{
				new EditorButton(ButtonPredefines.Combo)
			});
			this.repositoryItemDateTo.Name = "repositoryItemDateTo";
			base.AutoScaleDimensions = new SizeF(7f, 16f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Controls.Add(this.gridSystemInfo);
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.Name = "ConfigDevicesInfoView";
			base.Size = new Size(547, 346);
			((ISupportInitialize)this.gridSystemInfo).EndInit();
			((ISupportInitialize)this.gridViewSystemInfo).EndInit();
			((ISupportInitialize)this.barManager).EndInit();
			((ISupportInitialize)this.repositoryItembarEditPeriod).EndInit();
			((ISupportInitialize)this.repositoryItemDateFrom.CalendarTimeProperties).EndInit();
			((ISupportInitialize)this.repositoryItemDateFrom).EndInit();
			((ISupportInitialize)this.repositoryItemDateTo.CalendarTimeProperties).EndInit();
			((ISupportInitialize)this.repositoryItemDateTo).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000664 RID: 1636
		private IContainer components;

		// Token: 0x04000665 RID: 1637
		private GridControl gridSystemInfo;

		// Token: 0x04000666 RID: 1638
		private GridView gridViewSystemInfo;

		// Token: 0x04000667 RID: 1639
		private GridColumn gridColumnDisplayName;

		// Token: 0x04000668 RID: 1640
		private BarManager barManager;

		// Token: 0x04000669 RID: 1641
		private Bar barMenu;

		// Token: 0x0400066A RID: 1642
		private BarButtonItem barButtonGetComputerInfo;

		// Token: 0x0400066B RID: 1643
		private BarDockControl barDockControlTop;

		// Token: 0x0400066C RID: 1644
		private BarDockControl barDockControlBottom;

		// Token: 0x0400066D RID: 1645
		private BarDockControl barDockControlLeft;

		// Token: 0x0400066E RID: 1646
		private BarDockControl barDockControlRight;

		// Token: 0x0400066F RID: 1647
		private RepositoryItemComboBox repositoryItembarEditPeriod;

		// Token: 0x04000670 RID: 1648
		private RepositoryItemDateEdit repositoryItemDateFrom;

		// Token: 0x04000671 RID: 1649
		private RepositoryItemDateEdit repositoryItemDateTo;

		// Token: 0x04000672 RID: 1650
		private BarButtonItem barButtonExport;
	}
}
