﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000058 RID: 88
	public partial class BaseForm : XtraForm
	{
		// Token: 0x060004B0 RID: 1200 RVA: 0x00017D55 File Offset: 0x00015F55
		public BaseForm()
		{
			this.Action = FormAction.Unknown;
			this.CanCloseByEsc = true;
			this._objectsToSaveState = new List<object>();
			this._textEditsToIsNotEmptyValidation = new List<TextEdit>();
			this.InitializeComponent();
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x00017D87 File Offset: 0x00015F87
		public BaseForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action) : this()
		{
			this._formsSettings = formsSettings;
			this._formCreator = formCreator;
			this.Action = action;
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x060004B2 RID: 1202 RVA: 0x00017DA4 File Offset: 0x00015FA4
		// (set) Token: 0x060004B3 RID: 1203 RVA: 0x00017DAC File Offset: 0x00015FAC
		public FormAction Action { get; set; }

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x060004B4 RID: 1204 RVA: 0x00017DB5 File Offset: 0x00015FB5
		// (set) Token: 0x060004B5 RID: 1205 RVA: 0x00017DBD File Offset: 0x00015FBD
		public bool CanCloseByEsc { get; set; }

		// Token: 0x060004B6 RID: 1206 RVA: 0x00017DC6 File Offset: 0x00015FC6
		public void AddTextEditToIsNotEmptyValidation(TextEdit textEdit)
		{
			this._textEditsToIsNotEmptyValidation.Add(textEdit);
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x00017DD4 File Offset: 0x00015FD4
		public void CenterInParent()
		{
			Form owner = Application.OpenForms[0];
			if (owner != null)
			{
				base.StartPosition = FormStartPosition.Manual;
				base.Location = new Point(owner.Location.X + (owner.Width - base.Width) / 2, owner.Location.Y + (owner.Height - base.Height) / 2);
			}
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x00017E3E File Offset: 0x0001603E
		public void DisableCloseButton()
		{
			WindowsApi.EnableMenuItem(WindowsApi.GetSystemMenu(base.Handle, false), 61536U, 1U);
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x00017E58 File Offset: 0x00016058
		public bool ValidateNonEmptyTextEdits()
		{
			foreach (TextEdit textEdit in from x in this._textEditsToIsNotEmptyValidation
			orderby x.TabIndex
			select x)
			{
				if (string.IsNullOrEmpty(textEdit.Text))
				{
					textEdit.Focus();
					textEdit.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
					if (textEdit.Properties.Mask.BeepOnError)
					{
						WindowsApi.MessageBeep(16U);
					}
					return false;
				}
			}
			return true;
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x00017F08 File Offset: 0x00016108
		protected virtual void AfterRestoreState()
		{
			this.SetIsModifiedInDevExEdits();
			this.AddAllTextEditToIsNotEmptyValidation();
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void BeforeRestoreState()
		{
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x00017F16 File Offset: 0x00016116
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (this.CanCloseByEsc && keyData == Keys.Escape)
			{
				base.Close();
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x00017F34 File Offset: 0x00016134
		protected void SetWindowTitle(string text)
		{
			string s = this.Action.GetDescription();
			if (!string.IsNullOrEmpty(s))
			{
				this.Text = text + " [" + s + "]";
				return;
			}
			this.Text = text;
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x00017F74 File Offset: 0x00016174
		private void AddAllTextEditToIsNotEmptyValidation()
		{
			List<Control> controls = new List<Control>();
			ControlsExtensions.GetControls(base.Controls, controls);
			foreach (TextEdit textEdit in controls.OfType<TextEdit>())
			{
				if (textEdit.Properties.Mask.MaskType == MaskType.None && textEdit.Properties.Mask.EditMask == "nonEmpty")
				{
					this.AddTextEditToIsNotEmptyValidation(textEdit);
				}
			}
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x00018004 File Offset: 0x00016204
		private void FormBase_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (this._formsSettings != null && (!base.Modal || base.DialogResult == DialogResult.OK || base.DialogResult == DialogResult.Cancel))
			{
				this._formsSettings.SaveObjectsState(base.Name, this._objectsToSaveState);
			}
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0001803F File Offset: 0x0001623F
		private void FormBase_Load(object sender, EventArgs e)
		{
			this.SetWindowTitle(this.Text);
			this.BeforeRestoreState();
			FormsSettings formsSettings = this._formsSettings;
			if (formsSettings != null)
			{
				formsSettings.RestoreObjectsState(base.Name, this._objectsToSaveState);
			}
			this.AfterRestoreState();
		}

		// Token: 0x04000213 RID: 531
		protected readonly IFormCreator _formCreator;

		// Token: 0x04000214 RID: 532
		protected readonly FormsSettings _formsSettings;

		// Token: 0x04000215 RID: 533
		protected List<object> _objectsToSaveState;

		// Token: 0x04000216 RID: 534
		protected List<TextEdit> _textEditsToIsNotEmptyValidation;
	}
}
