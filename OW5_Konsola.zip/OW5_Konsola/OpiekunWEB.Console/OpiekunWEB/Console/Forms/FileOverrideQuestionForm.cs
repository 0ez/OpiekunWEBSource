﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000069 RID: 105
	public partial class FileOverrideQuestionForm : BaseForm
	{
		// Token: 0x06000595 RID: 1429 RVA: 0x00023D00 File Offset: 0x00021F00
		public FileOverrideQuestionForm(FileOverrideQuestionFormParams @params)
		{
			this.InitializeComponent();
			this._params = @params;
			base.CanCloseByEsc = false;
			string computer = @params.IsLocalFile ? Resources.FileOverrideQuestionForm_LocalFile : Resources.FileOverrideQuestionForm_RemoteFile;
			this.labelFileInfo.Text = string.Format(Resources.FileOverrideQuestionForm_FileInfo, computer, @params.FileName);
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x00023D58 File Offset: 0x00021F58
		private void buttonCancel_Click(object sender, EventArgs e)
		{
			this._params.Action = FileOverrideAction.Cancel;
			base.Close();
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00023D6C File Offset: 0x00021F6C
		private void buttonOverride_Click(object sender, EventArgs e)
		{
			this._params.Action = FileOverrideAction.Override;
			base.Close();
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x00023D80 File Offset: 0x00021F80
		private void buttonOverrideAllways_Click(object sender, EventArgs e)
		{
			this._params.Action = FileOverrideAction.OverrideAllways;
			base.Close();
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00023D94 File Offset: 0x00021F94
		private void buttonSkip_Click(object sender, EventArgs e)
		{
			this._params.Action = FileOverrideAction.Skip;
			base.Close();
		}

		// Token: 0x040002F7 RID: 759
		private readonly FileOverrideQuestionFormParams _params;
	}
}
