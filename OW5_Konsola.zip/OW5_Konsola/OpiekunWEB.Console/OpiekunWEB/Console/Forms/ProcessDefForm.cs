﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000076 RID: 118
	public partial class ProcessDefForm : CRUDBaseForm
	{
		// Token: 0x0600062E RID: 1582 RVA: 0x0002F39A File Offset: 0x0002D59A
		public ProcessDefForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600062F RID: 1583 RVA: 0x0002F3A8 File Offset: 0x0002D5A8
		public ProcessDefForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, ProcessDefFormParams @params) : base(formsSettings, formCreator, action, apiClient)
		{
			this.InitializeComponent();
			this._params = @params;
			this._macroList = Macros.GetDirMacrosAsStringKeyValueList(true);
			this._anyDirectoryMacro = this._macroList.Find((StringKeyAndValue x) => x.Key == "{?}");
			this.comboBoxMacro.Properties.Items.AddRange(this._macroList);
			this.comboBoxMacro.SelectedItem = this._anyDirectoryMacro;
			this._showModesList = this.GetWindowShowModesList();
			this.comboBoxShowMode.Properties.Items.AddRange(this._showModesList);
			this.comboBoxShowMode.SelectedItem = this._showModesList.Find((KeyAndValue<int, string> x) => x.Key == 5);
			if (action == FormAction.Unknown)
			{
				this.Text = Resources.ProcessDefForm_StartProcessTitle;
				this.textEditAppName.Enabled = false;
				this.checkIsFavorite.Enabled = false;
				this.checkEditAvailableForAll.Enabled = false;
				this.checkEditAskForParameters.Enabled = false;
				this.comboBoxMacro.Enabled = false;
				this.textEditFilePath.Enabled = false;
			}
			else
			{
				this.checkEditAvailableForAll.Enabled = this._apiClient.IsLoggedUserHasAdminPermission();
			}
			this.InitData();
		}

		// Token: 0x06000630 RID: 1584 RVA: 0x0002F506 File Offset: 0x0002D706
		protected override bool IsDataUpdated()
		{
			return this.GetProcessDef().ToString() != this._params.ProcessDef.ToString();
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x0002F528 File Offset: 0x0002D728
		protected override bool IsDataValid()
		{
			if (!this.textEditAppName.DoValidate())
			{
				return false;
			}
			if (!this.ValidateLaunchPath())
			{
				this.textEditFilePath.Focus();
				this.textEditFilePath.ErrorText = Resources.ProcessDefForm_InvalidPath;
				return false;
			}
			if (!this.ValidateUserName(this.textEditUserName.Text))
			{
				this.textEditUserName.Focus();
				this.textEditUserName.ErrorText = Resources.ProcessDefForm_InvalidUserName;
				return false;
			}
			return true;
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x0002F59C File Offset: 0x0002D79C
		protected override Task<bool> OnActionCreate()
		{
			ProcessDefForm.<OnActionCreate>d__8 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<ProcessDefForm.<OnActionCreate>d__8>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x0002F5DF File Offset: 0x0002D7DF
		protected override Task<bool> OnActionUnknown()
		{
			if (!this.IsDataValid())
			{
				return Task.FromResult<bool>(false);
			}
			this._params.ProcessDef = this.GetProcessDef();
			return Task.FromResult<bool>(true);
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0002F608 File Offset: 0x0002D808
		protected override Task<bool> OnActionUpdate()
		{
			ProcessDefForm.<OnActionUpdate>d__10 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<ProcessDefForm.<OnActionUpdate>d__10>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0002F64B File Offset: 0x0002D84B
		private void comboBoxMacro_SelectedValueChanged(object sender, EventArgs e)
		{
			this.textEditFilePath.Properties.Buttons[0].Enabled = this.IsAnyDirectorySelected();
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x0002F670 File Offset: 0x0002D870
		private StartProcessDef GetProcessDef()
		{
			StartProcessUserType userType = (this.radioGroupUserType.SelectedIndex == 0) ? StartProcessUserType.AsCurrentUser : StartProcessUserType.AsSpecifiedUser;
			StartProcessDef startProcessDef = new StartProcessDef();
			startProcessDef.DisplayName = this.textEditAppName.Text;
			startProcessDef.IsFavorite = this.checkIsFavorite.Checked;
			startProcessDef.AskForParametrs = this.checkEditAskForParameters.Checked;
			StartProcessRequest startProcessRequest = new StartProcessRequest();
			StringKeyAndValue selectedMacro = this.GetSelectedMacro();
			startProcessRequest.FileName = Macros.MacroAndFileNameToString((selectedMacro != null) ? selectedMacro.Key : null, this.textEditFilePath.Text);
			startProcessRequest.Params = this.textEditParams.Text;
			startProcessRequest.ShowMode = ((KeyAndValue<int, string>)this.comboBoxShowMode.SelectedItem).Key;
			startProcessRequest.UserType = userType;
			startProcessRequest.UserName = this.textEditUserName.Text;
			startProcessRequest.UserPasswd = AesCrypt.EncryptStringToHex(this.textEditUserPasswd.Text, AesCrypt.AesKeyForAgent());
			startProcessDef.AgentRequest = startProcessRequest;
			StartProcessDef result = startProcessDef;
			if (this.checkEditAvailableForAll.Checked)
			{
				result.AvailableForUsers.Add("*");
			}
			else
			{
				result.AvailableForUsers.Add(this._apiClient.UserId);
			}
			return result;
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x0002F790 File Offset: 0x0002D990
		private StringKeyAndValue GetSelectedMacro()
		{
			return (StringKeyAndValue)this.comboBoxMacro.SelectedItem;
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x0002F7A4 File Offset: 0x0002D9A4
		private List<KeyAndValue<int, string>> GetWindowShowModesList()
		{
			List<KeyAndValue<int, string>> list = new List<KeyAndValue<int, string>>();
			list.Add(new KeyAndValue<int, string>(0, Resources.WindowShowMode_Hide));
			list.Add(new KeyAndValue<int, string>(3, Resources.WindowShowMode_Maximize));
			list.Add(new KeyAndValue<int, string>(5, Resources.WindowShowMode_Show));
			list.Add(new KeyAndValue<int, string>(6, Resources.WindowShowMode_Minimize));
			return (from x in list
			orderby x.Value
			select x).ToList<KeyAndValue<int, string>>();
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x0002F824 File Offset: 0x0002DA24
		private void InitData()
		{
			if (base.Action != FormAction.Create)
			{
				this.textEditAppName.Text = this._params.ProcessDef.DisplayName;
				this.checkIsFavorite.Checked = this._params.ProcessDef.IsFavorite;
				this.checkEditAskForParameters.Checked = this._params.ProcessDef.AskForParametrs;
				StartProcessRequest agentRequest = this._params.ProcessDef.AgentRequest;
				System.ValueTuple<StringKeyAndValue, string> valueTuple = Macros.SplitFileNameToMacroAndFileName(this._macroList, agentRequest.FileName);
				StringKeyAndValue macro = valueTuple.Item1;
				string fileName = valueTuple.Item2;
				this.comboBoxMacro.SelectedItem = macro;
				this.textEditFilePath.Text = fileName;
				this.comboBoxShowMode.SelectedItem = this._showModesList.Find((KeyAndValue<int, string> x) => x.Key == this._params.ProcessDef.AgentRequest.ShowMode);
				this.textEditParams.Text = agentRequest.Params;
				this.radioGroupUserType.SelectedIndex = (int)agentRequest.UserType;
				this.textEditUserName.Text = agentRequest.UserName;
				this.textEditUserPasswd.Text = AesCrypt.DecrytpStringFromHex(agentRequest.UserPasswd, AesCrypt.AesKeyForAgent());
				this.checkEditAvailableForAll.Checked = this._params.ProcessDef.AvailableForUsers.Contains("*");
			}
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x0002F96A File Offset: 0x0002DB6A
		private bool IsAnyDirectorySelected()
		{
			return this.GetSelectedMacro() == this._anyDirectoryMacro;
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x0002F97C File Offset: 0x0002DB7C
		private void radioGroupUserType_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.textEditUserName.Enabled = (this.radioGroupUserType.SelectedIndex == 1);
			this.textEditUserPasswd.Enabled = (this.radioGroupUserType.SelectedIndex == 1);
			this.labelUserHelp.Enabled = (this.radioGroupUserType.SelectedIndex == 1);
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0002F9D4 File Offset: 0x0002DBD4
		private void textEditFilePath_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			using (XtraOpenFileDialog dlg = new XtraOpenFileDialog())
			{
				dlg.Title = Resources.ProcessDefForm_OpenFileDialogTitle;
				dlg.Filter = Resources.ProcessDefForm_OpenFileDialogFilter;
				if (dlg.ShowDialog() == DialogResult.OK)
				{
					this.textEditFilePath.Text = dlg.FileName;
				}
			}
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x0002FA34 File Offset: 0x0002DC34
		private bool ValidateLaunchPath()
		{
			string modifiedPath;
			bool result = Macros.ValidateMacroAndPath(this.GetSelectedMacro().Key, this.textEditFilePath.Text, out modifiedPath, FileOrFolder.File);
			this.textEditFilePath.Text = modifiedPath;
			return result;
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0002FA6B File Offset: 0x0002DC6B
		private bool ValidateUserName(string userName)
		{
			return this.radioGroupUserType.SelectedIndex != 1 || userName.Length > 0;
		}

		// Token: 0x040003D2 RID: 978
		private readonly StringKeyAndValue _anyDirectoryMacro;

		// Token: 0x040003D3 RID: 979
		private readonly List<StringKeyAndValue> _macroList;

		// Token: 0x040003D4 RID: 980
		private readonly ProcessDefFormParams _params;

		// Token: 0x040003D5 RID: 981
		private readonly List<KeyAndValue<int, string>> _showModesList;
	}
}
