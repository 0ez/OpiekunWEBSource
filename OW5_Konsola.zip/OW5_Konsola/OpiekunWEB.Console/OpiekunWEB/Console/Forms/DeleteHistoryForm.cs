﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005F RID: 95
	public partial class DeleteHistoryForm : BaseForm
	{
		// Token: 0x0600050D RID: 1293 RVA: 0x0001ACD8 File Offset: 0x00018ED8
		public DeleteHistoryForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x0001ACF0 File Offset: 0x00018EF0
		private void buttonSave_Click(object sender, EventArgs e)
		{
			DeleteHistoryForm.<buttonSave_Click>d__2 <buttonSave_Click>d__;
			<buttonSave_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonSave_Click>d__.<>4__this = this;
			<buttonSave_Click>d__.<>1__state = -1;
			<buttonSave_Click>d__.<>t__builder.Start<DeleteHistoryForm.<buttonSave_Click>d__2>(ref <buttonSave_Click>d__);
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x0001AD28 File Offset: 0x00018F28
		private Task DeleteHistory(DateTime ltTimestamp)
		{
			DeleteHistoryForm.<DeleteHistory>d__3 <DeleteHistory>d__;
			<DeleteHistory>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<DeleteHistory>d__.<>4__this = this;
			<DeleteHistory>d__.ltTimestamp = ltTimestamp;
			<DeleteHistory>d__.<>1__state = -1;
			<DeleteHistory>d__.<>t__builder.Start<DeleteHistoryForm.<DeleteHistory>d__3>(ref <DeleteHistory>d__);
			return <DeleteHistory>d__.<>t__builder.Task;
		}

		// Token: 0x04000245 RID: 581
		private readonly ApiClient _apiClient;
	}
}
