﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Data;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006C RID: 108
	public partial class DevicesSelectionForm : BaseForm, IDisposable
	{
		// Token: 0x060005CA RID: 1482 RVA: 0x00026F80 File Offset: 0x00025180
		public DevicesSelectionForm(FormsSettings formsSettings, IFormCreator formCreator, DevicesTree devicesTree, IIconsProvider iconsProvider, DevicesSelectionFormParams @params) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this._devicesTree = devicesTree;
			this._params = @params;
			this.InitializeComponent();
			this.treeDevices.SelectImageList = iconsProvider.DevicesTreeImages24x24;
			this._selectionList = new AgentOrDeviceSelectionList();
			this._selectionList.SelectItems(@params.SelectedItems);
			this._emptyItemTextEdit = new RepositoryItemTextEdit();
			this.checkEditShowOnlyConnected.Checked = @params.ShowOnlyConnected;
			if (@params.SelectedItems.Count((DeviceTreeItemBase x) => !x.IsConnected) > 0)
			{
				this.checkEditShowOnlyConnected.Checked = false;
			}
			this.treeDevices.GetNodeDisplayValue += this.treeStations_OnGetNodeDisplayValue;
			this.treeDevices.DataSource = this._devicesTree.ItemList;
			this.treeDevices.ExpandAll();
			this._objectsToSaveState.Add(this);
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x00027078 File Offset: 0x00025278
		private void buttonOk_Click(object sender, EventArgs e)
		{
			this._params.SelectedItems.Clear();
			this._params.SelectedItems.AddRange(this._selectionList.GetItems(this._devicesTree, this._params.ItemsToReturn));
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x060005CC RID: 1484 RVA: 0x000270C8 File Offset: 0x000252C8
		private bool CanSelectItem(DeviceTreeItemBase item)
		{
			return this.IsItemIncluded(this._params.ItemsToSelect, item);
		}

		// Token: 0x060005CD RID: 1485 RVA: 0x000270DC File Offset: 0x000252DC
		private void checkEditShowOnlyConnected_CheckStateChanged(object sender, EventArgs e)
		{
			if (this.checkEditShowOnlyConnected.Checked)
			{
				this._selectionList.RemoveNotConnected();
			}
			this.treeDevices.RefreshDataSource();
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x00027104 File Offset: 0x00025304
		private bool IsItemIncluded(DeviceTreeItemsType itemsType, DeviceTreeItemBase item)
		{
			bool result = itemsType.IsItemTypeIncluded(item);
			if (itemsType.IsItemTypeIncluded(DeviceTreeItemsType.Agent | DeviceTreeItemsType.Device))
			{
				DeviceItem deviceItem = item as DeviceItem;
				if (deviceItem != null)
				{
					result = ((itemsType.IsItemTypeIncluded(DeviceTreeItemsType.Agent) && deviceItem.GetAgentItemsList().Count == 1) || (itemsType.IsItemTypeIncluded(DeviceTreeItemsType.Device) && deviceItem.GetAgentItemsList().Count < 2));
				}
			}
			return result;
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x00027164 File Offset: 0x00025364
		private void treeDevices_CustomNodeCellEdit(object sender, GetCustomNodeCellEditEventArgs e)
		{
			if (e.Column == this.columnIsSelected)
			{
				if ((this.treeDevices.GetDataRecordByNode(e.Node) as DeviceTreeItemBase) is DevicesGroupItem && !this._params.ItemsToShow.IsItemTypeIncluded(DeviceTreeItemsType.DeviceGroup))
				{
					e.RepositoryItem = this._emptyItemTextEdit;
					return;
				}
				e.RepositoryItem = this.repositoryItemCheckBoxIsSelected;
			}
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x000271C8 File Offset: 0x000253C8
		private void treeStations_CellValueChanging(object sender, CellValueChangedEventArgs e)
		{
			if (e.Column == this.columnIsSelected)
			{
				bool isSelected = (bool)e.Value;
				DeviceTreeItemBase baseItem = this.treeDevices.GetDataRecordByNode(e.Node) as DeviceTreeItemBase;
				List<DeviceTreeItemBase> items = new List<DeviceTreeItemBase>();
				if (!this.CanSelectItem(baseItem))
				{
					items.AddRange(from x in this._devicesTree.GetAllItemChildren(baseItem)
					where this.CanSelectItem(x)
					select x);
					isSelected = false;
					foreach (DeviceTreeItemBase item in items)
					{
						if (this._selectionList.IsItemSelected(item))
						{
							isSelected = true;
							break;
						}
					}
					isSelected = !isSelected;
				}
				else if (isSelected)
				{
					this._selectionList.SelectItem(baseItem);
				}
				else
				{
					this._selectionList.UnselectItem(baseItem);
				}
				DevicesGroupItem deviceGroupItem = this.treeDevices.GetDataRecordByNode(e.Node) as DevicesGroupItem;
				if (deviceGroupItem != null)
				{
					items.AddRange(from x in this._devicesTree.GetAllItemChildren(deviceGroupItem)
					where this.CanSelectItem(x)
					select x);
				}
				this._selectionList.UnselectItems(items);
				if (isSelected)
				{
					if (this.checkEditShowOnlyConnected.Checked)
					{
						items = (from x in items
						where x.IsConnected
						select x).ToList<DeviceTreeItemBase>();
					}
					this._selectionList.SelectItems(items);
				}
				this.treeDevices.RefreshDataSource();
			}
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x0002734C File Offset: 0x0002554C
		private void treeStations_CustomRowFilter(object sender, CustomRowFilterEventArgs e)
		{
			if (e.Node != null)
			{
				DeviceTreeItemBase item = e.Row as DeviceTreeItemBase;
				e.Visible = this._params.ItemsToShow.IsItemTypeIncluded(item);
				if (item.Id == this._devicesTree.RootGroupId)
				{
					e.Visible = true;
				}
				else if (!item.IsConnected && this.checkEditShowOnlyConnected.Checked)
				{
					e.Visible = false;
				}
				e.Handled = true;
			}
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x000273C8 File Offset: 0x000255C8
		private void treeStations_CustomUnboundColumnData(object sender, TreeListCustomColumnDataEventArgs e)
		{
			if (e.Column == this.columnIsSelected && e.IsGetData)
			{
				DeviceTreeItemBase selectedItem = e.Row as DeviceTreeItemBase;
				bool isSelected = false;
				if (this.CanSelectItem(selectedItem))
				{
					isSelected = this._selectionList.IsItemSelected(selectedItem);
				}
				e.Value = isSelected;
			}
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x0002741C File Offset: 0x0002561C
		private void treeStations_OnGetNodeDisplayValue(object sender, GetNodeDisplayValueEventArgs e)
		{
			if (e.Column == this.columnIsSelected)
			{
				DeviceTreeItemBase item = this.treeDevices.GetDataRecordByNode(e.Node) as DeviceTreeItemBase;
				if (!this.CanSelectItem(item))
				{
					e.Value = string.Empty;
				}
			}
		}

		// Token: 0x04000345 RID: 837
		private readonly DevicesTree _devicesTree;

		// Token: 0x04000347 RID: 839
		private readonly DevicesSelectionFormParams _params;

		// Token: 0x04000348 RID: 840
		private readonly AgentOrDeviceSelectionList _selectionList;
	}
}
