﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000069 RID: 105
	public partial class FileOverrideQuestionForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600059A RID: 1434 RVA: 0x00023DA8 File Offset: 0x00021FA8
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x00023DC8 File Offset: 0x00021FC8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.FileOverrideQuestionForm));
			this.buttonOverrideAllways = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonOverride = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonSkip = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonCancel = new global::DevExpress.XtraEditors.SimpleButton();
			this.labelFileInfo = new global::DevExpress.XtraEditors.LabelControl();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonOverrideAllways, "buttonOverrideAllways");
			this.buttonOverrideAllways.ImageOptions.ImageIndex = (int)resources.GetObject("buttonOverrideAllways.ImageOptions.ImageIndex");
			this.buttonOverrideAllways.Name = "buttonOverrideAllways";
			this.buttonOverrideAllways.Click += new global::System.EventHandler(this.buttonOverrideAllways_Click);
			resources.ApplyResources(this.buttonOverride, "buttonOverride");
			this.buttonOverride.ImageOptions.ImageIndex = (int)resources.GetObject("buttonOverride.ImageOptions.ImageIndex");
			this.buttonOverride.Name = "buttonOverride";
			this.buttonOverride.Click += new global::System.EventHandler(this.buttonOverride_Click);
			resources.ApplyResources(this.buttonSkip, "buttonSkip");
			this.buttonSkip.ImageOptions.ImageIndex = (int)resources.GetObject("buttonSkip.ImageOptions.ImageIndex");
			this.buttonSkip.Name = "buttonSkip";
			this.buttonSkip.Click += new global::System.EventHandler(this.buttonSkip_Click);
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.ImageOptions.ImageIndex = (int)resources.GetObject("buttonCancel.ImageOptions.ImageIndex");
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Click += new global::System.EventHandler(this.buttonCancel_Click);
			resources.ApplyResources(this.labelFileInfo, "labelFileInfo");
			this.labelFileInfo.Name = "labelFileInfo";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ControlBox = false;
			base.Controls.Add(this.labelFileInfo);
			base.Controls.Add(this.buttonCancel);
			base.Controls.Add(this.buttonSkip);
			base.Controls.Add(this.buttonOverride);
			base.Controls.Add(this.buttonOverrideAllways);
			base.Name = "FileOverrideQuestionForm";
			base.ResumeLayout(false);
		}

		// Token: 0x040002F8 RID: 760
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002F9 RID: 761
		private global::DevExpress.XtraEditors.SimpleButton buttonOverrideAllways;

		// Token: 0x040002FA RID: 762
		private global::DevExpress.XtraEditors.SimpleButton buttonOverride;

		// Token: 0x040002FB RID: 763
		private global::DevExpress.XtraEditors.SimpleButton buttonSkip;

		// Token: 0x040002FC RID: 764
		private global::DevExpress.XtraEditors.SimpleButton buttonCancel;

		// Token: 0x040002FD RID: 765
		private global::DevExpress.XtraEditors.LabelControl labelFileInfo;
	}
}
