﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000061 RID: 97
	public partial class DesktopForm : CRUDBaseForm
	{
		// Token: 0x06000520 RID: 1312 RVA: 0x0001C767 File Offset: 0x0001A967
		public DesktopForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x0001C778 File Offset: 0x0001A978
		public DesktopForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, Desktop desktop) : base(formsSettings, formCreator, action, apiClient)
		{
			this._desktop = desktop;
			this.InitializeComponent();
			this.lookUpEditWhiteList.Properties.DataSource = (from x in this._apiClient.AppCategories
			where x.CategoryType == AppCategoryType.AppWhiteList
			select x).ToList<AppCategory>();
			if (action != FormAction.Create)
			{
				this.textEditName.Text = desktop.Name;
				this.textEditDescription.Text = desktop.Description;
				if (!string.IsNullOrEmpty(desktop.AppWhiteListId))
				{
					this.lookUpEditWhiteList.EditValue = this._apiClient.AppCategories.FirstOrDefault((AppCategory x) => x.Id == desktop.AppWhiteListId);
				}
			}
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x0001C860 File Offset: 0x0001AA60
		protected override bool IsDataUpdated()
		{
			Desktop desktop = this._desktop;
			if (!(((desktop != null) ? desktop.Name : null) != this.textEditName.Text))
			{
				Desktop desktop2 = this._desktop;
				if (!(((desktop2 != null) ? desktop2.Description : null) != this.textEditDescription.Text))
				{
					return this._desktop.AppWhiteListId != this.GetSelectedAppWhiteListId();
				}
			}
			return true;
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0001C8D0 File Offset: 0x0001AAD0
		protected override Task<bool> OnActionCreate()
		{
			DesktopForm.<OnActionCreate>d__4 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<DesktopForm.<OnActionCreate>d__4>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x0001C914 File Offset: 0x0001AB14
		protected override Task<bool> OnActionUpdate()
		{
			DesktopForm.<OnActionUpdate>d__5 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<DesktopForm.<OnActionUpdate>d__5>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x0001C957 File Offset: 0x0001AB57
		private string GetSelectedAppWhiteListId()
		{
			if (this.lookUpEditWhiteList.EditValue == null)
			{
				return string.Empty;
			}
			AppCategory appCategory = this.lookUpEditWhiteList.EditValue as AppCategory;
			if (appCategory == null)
			{
				return null;
			}
			return appCategory.Id;
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x0001C987 File Offset: 0x0001AB87
		private void lookUpEditWhiteList_ButtonPressed(object sender, ButtonPressedEventArgs e)
		{
			if (e.Button.Kind == ButtonPredefines.Delete)
			{
				this.lookUpEditWhiteList.EditValue = null;
			}
		}

		// Token: 0x04000269 RID: 617
		private readonly Desktop _desktop;
	}
}
