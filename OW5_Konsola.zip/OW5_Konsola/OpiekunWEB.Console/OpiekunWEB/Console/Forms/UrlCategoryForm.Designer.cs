﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000080 RID: 128
	public partial class UrlCategoryForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x060006E8 RID: 1768 RVA: 0x0003B18A File Offset: 0x0003938A
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x0003B1AC File Offset: 0x000393AC
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.UrlCategoryForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.gridCategoryState = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewCategoryState = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnRoleName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRoleType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnState = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxRoleState = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imagesCategoryStates = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imageComboBoxCategoryState = new global::DevExpress.XtraEditors.ImageComboBoxEdit();
			this.textEditCategoryName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlCategoryName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlCategoryState = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGrid = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.textEditCategoryDescription = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlItemCategoryDescription = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridCategoryState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewCategoryState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxRoleState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesCategoryStates).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxCategoryState.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGrid).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryDescription.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemCategoryDescription).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.buttonSave.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.layoutControlMain.Controls.Add(this.textEditCategoryDescription);
			this.layoutControlMain.Controls.Add(this.gridCategoryState);
			this.layoutControlMain.Controls.Add(this.imageComboBoxCategoryState);
			this.layoutControlMain.Controls.Add(this.textEditCategoryName);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2551, 194, 812, 500));
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.gridCategoryState, "gridCategoryState");
			this.gridCategoryState.MainView = this.gridViewCategoryState;
			this.gridCategoryState.Name = "gridCategoryState";
			this.gridCategoryState.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxRoleState
			});
			this.gridCategoryState.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewCategoryState
			});
			this.gridViewCategoryState.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnRoleName,
				this.gridColumnRoleType,
				this.gridColumnState
			});
			this.gridViewCategoryState.GridControl = this.gridCategoryState;
			this.gridViewCategoryState.Name = "gridViewCategoryState";
			this.gridViewCategoryState.OptionsDetail.EnableMasterViewMode = false;
			this.gridViewCategoryState.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewCategoryState.OptionsSelection.UseIndicatorForSelection = false;
			this.gridViewCategoryState.OptionsView.ShowGroupPanel = false;
			this.gridViewCategoryState.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewCategoryState_CustomUnboundColumnData);
			this.gridViewCategoryState.CustomRowFilter += new global::DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridViewCategoryState_CustomRowFilter);
			this.gridColumnRoleName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnRoleName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnRoleName, "gridColumnRoleName");
			this.gridColumnRoleName.FieldName = "Name";
			this.gridColumnRoleName.MinWidth = 25;
			this.gridColumnRoleName.Name = "gridColumnRoleName";
			this.gridColumnRoleName.OptionsColumn.AllowEdit = false;
			this.gridColumnRoleName.OptionsColumn.AllowFocus = false;
			this.gridColumnRoleType.FieldName = "RoleType";
			this.gridColumnRoleType.MinWidth = 25;
			this.gridColumnRoleType.Name = "gridColumnRoleType";
			resources.ApplyResources(this.gridColumnRoleType, "gridColumnRoleType");
			this.gridColumnState.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnState.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnState, "gridColumnState");
			this.gridColumnState.ColumnEdit = this.imageComboBoxRoleState;
			this.gridColumnState.FieldName = "State";
			this.gridColumnState.MinWidth = 25;
			this.gridColumnState.Name = "gridColumnState";
			this.gridColumnState.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			resources.ApplyResources(this.imageComboBoxRoleState, "imageComboBoxRoleState");
			this.imageComboBoxRoleState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxRoleState.Buttons"))
			});
			this.imageComboBoxRoleState.Name = "imageComboBoxRoleState";
			this.imageComboBoxRoleState.SmallImages = this.imagesCategoryStates;
			this.imageComboBoxRoleState.EditValueChanging += new global::DevExpress.XtraEditors.Controls.ChangingEventHandler(this.imageComboBoxRoleState_EditValueChanging);
			this.imagesCategoryStates.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesCategoryStates.ImageStream");
			this.imagesCategoryStates.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_check_16x16, "access_check_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesCategoryStates.Images.SetKeyName(0, "access_check_16x16");
			this.imagesCategoryStates.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_block_16x16, "access_block_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesCategoryStates.Images.SetKeyName(1, "access_block_16x16");
			this.imagesCategoryStates.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_allow_16x16, "access_allow_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 2);
			this.imagesCategoryStates.Images.SetKeyName(2, "access_allow_16x16");
			this.imagesCategoryStates.Images.SetKeyName(3, "employee_16x16.png");
			resources.ApplyResources(this.imageComboBoxCategoryState, "imageComboBoxCategoryState");
			this.imageComboBoxCategoryState.Name = "imageComboBoxCategoryState";
			this.imageComboBoxCategoryState.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxCategoryState.Properties.Buttons"))
			});
			this.imageComboBoxCategoryState.Properties.LargeImages = this.imagesCategoryStates;
			this.imageComboBoxCategoryState.Properties.UseReadOnlyAppearance = false;
			this.imageComboBoxCategoryState.StyleController = this.layoutControlMain;
			this.imageComboBoxCategoryState.EditValueChanged += new global::System.EventHandler(this.imageComboCategoryState_EditValueChanged);
			resources.ApplyResources(this.textEditCategoryName, "textEditCategoryName");
			this.textEditCategoryName.Name = "textEditCategoryName";
			this.textEditCategoryName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditCategoryName.Properties.Mask.BeepOnError");
			this.textEditCategoryName.Properties.Mask.EditMask = resources.GetString("textEditCategoryName.Properties.Mask.EditMask");
			this.textEditCategoryName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditCategoryName.Properties.Mask.IgnoreMaskBlank");
			this.textEditCategoryName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditCategoryName.Properties.Mask.MaskType");
			this.textEditCategoryName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditCategoryName.Properties.Mask.ShowPlaceHolders");
			this.textEditCategoryName.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlCategoryName,
				this.emptySpaceItem1,
				this.layoutControlCategoryState,
				this.layoutControlGrid,
				this.layoutControlItemCategoryDescription
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.OptionsItemText.TextToControlDistance = 4;
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(435, 358);
			this.layoutControlGroupMain.TextVisible = false;
			this.layoutControlCategoryName.Control = this.textEditCategoryName;
			this.layoutControlCategoryName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlCategoryName.Name = "layoutControlCategoryName";
			this.layoutControlCategoryName.Size = new global::System.Drawing.Size(415, 46);
			resources.ApplyResources(this.layoutControlCategoryName, "layoutControlCategoryName");
			this.layoutControlCategoryName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlCategoryName.TextSize = new global::System.Drawing.Size(92, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 138);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(415, 10);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlCategoryState.Control = this.imageComboBoxCategoryState;
			this.layoutControlCategoryState.Location = new global::System.Drawing.Point(0, 92);
			this.layoutControlCategoryState.Name = "layoutControlCategoryState";
			this.layoutControlCategoryState.Size = new global::System.Drawing.Size(415, 46);
			resources.ApplyResources(this.layoutControlCategoryState, "layoutControlCategoryState");
			this.layoutControlCategoryState.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlCategoryState.TextSize = new global::System.Drawing.Size(92, 16);
			this.layoutControlGrid.Control = this.gridCategoryState;
			this.layoutControlGrid.Location = new global::System.Drawing.Point(0, 148);
			this.layoutControlGrid.Name = "layoutControlGrid";
			this.layoutControlGrid.Size = new global::System.Drawing.Size(415, 190);
			this.layoutControlGrid.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlGrid.TextVisible = false;
			resources.ApplyResources(this.textEditCategoryDescription, "textEditCategoryDescription");
			this.textEditCategoryDescription.Name = "textEditCategoryDescription";
			this.textEditCategoryDescription.StyleController = this.layoutControlMain;
			this.layoutControlItemCategoryDescription.Control = this.textEditCategoryDescription;
			this.layoutControlItemCategoryDescription.Location = new global::System.Drawing.Point(0, 46);
			this.layoutControlItemCategoryDescription.Name = "layoutControlItemCategoryDescription";
			this.layoutControlItemCategoryDescription.Size = new global::System.Drawing.Size(415, 46);
			resources.ApplyResources(this.layoutControlItemCategoryDescription, "layoutControlItemCategoryDescription");
			this.layoutControlItemCategoryDescription.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemCategoryDescription.TextSize = new global::System.Drawing.Size(92, 16);
			base.AcceptButton = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.Name = "UrlCategoryForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridCategoryState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewCategoryState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxRoleState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesCategoryStates).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxCategoryState.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGrid).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryDescription.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemCategoryDescription).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040004C2 RID: 1218
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040004C3 RID: 1219
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040004C4 RID: 1220
		private global::DevExpress.XtraEditors.ImageComboBoxEdit imageComboBoxCategoryState;

		// Token: 0x040004C5 RID: 1221
		private global::DevExpress.XtraEditors.TextEdit textEditCategoryName;

		// Token: 0x040004C6 RID: 1222
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040004C7 RID: 1223
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlCategoryName;

		// Token: 0x040004C8 RID: 1224
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040004C9 RID: 1225
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlCategoryState;

		// Token: 0x040004CA RID: 1226
		private global::DevExpress.Utils.ImageCollection imagesCategoryStates;

		// Token: 0x040004CB RID: 1227
		private global::DevExpress.XtraGrid.GridControl gridCategoryState;

		// Token: 0x040004CC RID: 1228
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewCategoryState;

		// Token: 0x040004CD RID: 1229
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlGrid;

		// Token: 0x040004CE RID: 1230
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleName;

		// Token: 0x040004CF RID: 1231
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleType;

		// Token: 0x040004D0 RID: 1232
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnState;

		// Token: 0x040004D1 RID: 1233
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxRoleState;

		// Token: 0x040004D2 RID: 1234
		private global::DevExpress.XtraEditors.TextEdit textEditCategoryDescription;

		// Token: 0x040004D3 RID: 1235
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemCategoryDescription;
	}
}
