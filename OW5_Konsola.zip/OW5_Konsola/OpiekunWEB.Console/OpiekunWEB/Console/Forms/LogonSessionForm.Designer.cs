﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006F RID: 111
	public partial class LogonSessionForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060005E8 RID: 1512 RVA: 0x00028D41 File Offset: 0x00026F41
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x00028D60 File Offset: 0x00026F60
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.LogonSessionForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.checkEditSavePassword = new global::DevExpress.XtraEditors.CheckEdit();
			this.textEditUserName = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditPassword = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditDomainName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlDomainName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlPassword = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlUserName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItem1 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.labelHelp = new global::DevExpress.XtraEditors.LabelControl();
			this.buttonCancel = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditSavePassword.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDomainName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDomainName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPassword).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).BeginInit();
			base.SuspendLayout();
			this.layoutControlMain.AllowCustomization = false;
			this.layoutControlMain.Controls.Add(this.checkEditSavePassword);
			this.layoutControlMain.Controls.Add(this.textEditUserName);
			this.layoutControlMain.Controls.Add(this.textEditPassword);
			this.layoutControlMain.Controls.Add(this.textEditDomainName);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2145, 256, 609, 465));
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.checkEditSavePassword, "checkEditSavePassword");
			this.checkEditSavePassword.Name = "checkEditSavePassword";
			this.checkEditSavePassword.Properties.Caption = resources.GetString("checkEditSavePassword.Properties.Caption");
			this.checkEditSavePassword.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditUserName, "textEditUserName");
			this.textEditUserName.Name = "textEditUserName";
			this.textEditUserName.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditUserName.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditPassword, "textEditPassword");
			this.textEditPassword.Name = "textEditPassword";
			this.textEditPassword.Properties.PasswordChar = '*';
			this.textEditPassword.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditPassword.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditDomainName, "textEditDomainName");
			this.textEditDomainName.Name = "textEditDomainName";
			this.textEditDomainName.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditDomainName.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlDomainName,
				this.layoutControlPassword,
				this.layoutControlUserName,
				this.layoutControlItem1
			});
			this.layoutControlGroupMain.Name = "Root";
			this.layoutControlGroupMain.Padding = new global::DevExpress.XtraLayout.Utils.Padding(12, 12, 12, 12);
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(319, 190);
			this.layoutControlGroupMain.TextVisible = false;
			this.layoutControlDomainName.Control = this.textEditDomainName;
			this.layoutControlDomainName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlDomainName.Name = "layoutControlDomainName";
			this.layoutControlDomainName.Size = new global::System.Drawing.Size(295, 45);
			resources.ApplyResources(this.layoutControlDomainName, "layoutControlDomainName");
			this.layoutControlDomainName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDomainName.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlPassword.Control = this.textEditPassword;
			this.layoutControlPassword.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlPassword.Name = "layoutControlPassword";
			this.layoutControlPassword.Size = new global::System.Drawing.Size(295, 45);
			resources.ApplyResources(this.layoutControlPassword, "layoutControlPassword");
			this.layoutControlPassword.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlPassword.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlUserName.Control = this.textEditUserName;
			this.layoutControlUserName.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlUserName.Name = "layoutControlUserName";
			this.layoutControlUserName.Size = new global::System.Drawing.Size(295, 45);
			resources.ApplyResources(this.layoutControlUserName, "layoutControlUserName");
			this.layoutControlUserName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUserName.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlItem1.Control = this.checkEditSavePassword;
			this.layoutControlItem1.Location = new global::System.Drawing.Point(0, 135);
			this.layoutControlItem1.Name = "layoutControlItem1";
			this.layoutControlItem1.Size = new global::System.Drawing.Size(295, 31);
			this.layoutControlItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem1.TextVisible = false;
			this.labelHelp.Appearance.Image = (global::System.Drawing.Image)resources.GetObject("labelHelp.Appearance.Image");
			this.labelHelp.Appearance.ImageAlign = global::System.Drawing.ContentAlignment.TopLeft;
			this.labelHelp.Appearance.ImageIndex = 0;
			this.labelHelp.Appearance.Options.UseImage = true;
			this.labelHelp.Appearance.Options.UseImageAlign = true;
			this.labelHelp.Appearance.Options.UseImageIndex = true;
			this.labelHelp.Appearance.Options.UseTextOptions = true;
			this.labelHelp.Appearance.TextOptions.WordWrap = global::DevExpress.Utils.WordWrap.Wrap;
			resources.ApplyResources(this.labelHelp, "labelHelp");
			this.labelHelp.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftTop;
			this.labelHelp.Name = "labelHelp";
			this.buttonCancel.DialogResult = global::System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonCancel.ImageOptions.Image");
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.Name = "buttonCancel";
			this.buttonOk.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonOk.ImageOptions.Image");
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			base.AcceptButton = this.buttonOk;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.labelHelp);
			base.Controls.Add(this.buttonCancel);
			base.Controls.Add(this.buttonOk);
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("LogonSessionForm.IconOptions.Icon");
			base.Name = "LogonSessionForm";
			base.Load += new global::System.EventHandler(this.FormLogonWindows_Load);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.checkEditSavePassword.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDomainName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDomainName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPassword).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000367 RID: 871
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000368 RID: 872
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x04000369 RID: 873
		private global::DevExpress.XtraEditors.TextEdit textEditUserName;

		// Token: 0x0400036A RID: 874
		private global::DevExpress.XtraEditors.TextEdit textEditPassword;

		// Token: 0x0400036B RID: 875
		private global::DevExpress.XtraEditors.TextEdit textEditDomainName;

		// Token: 0x0400036C RID: 876
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x0400036D RID: 877
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDomainName;

		// Token: 0x0400036E RID: 878
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlPassword;

		// Token: 0x0400036F RID: 879
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserName;

		// Token: 0x04000370 RID: 880
		private global::DevExpress.XtraEditors.LabelControl labelHelp;

		// Token: 0x04000371 RID: 881
		private global::DevExpress.XtraEditors.SimpleButton buttonCancel;

		// Token: 0x04000372 RID: 882
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x04000373 RID: 883
		private global::DevExpress.XtraEditors.CheckEdit checkEditSavePassword;

		// Token: 0x04000374 RID: 884
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
	}
}
