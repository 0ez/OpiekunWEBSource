﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Images;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraTab;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007D RID: 125
	public partial class RolesForm : RibbonBaseForm
	{
		// Token: 0x06000689 RID: 1673 RVA: 0x000352F4 File Offset: 0x000334F4
		public RolesForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClientClient, IIconsProvider iconsProvider) : base(formsSettings, formCreator)
		{
			this._apiClient = apiClientClient;
			this._iconsProvider = iconsProvider;
			this.InitializeComponent();
			this.imageComboBoxUserStatus.Items.AddEnum<UserStatus>((UserStatus userStatus) => userStatus.GetDescription());
			this.imageComboBoxPermissionValueInetControlState.Items.Clear();
			this.imageComboBoxPermissionValueInetControlState.SmallImages = iconsProvider.InetControlStateImages16x16;
			this.imageComboBoxPermissionValueInetControlState.Items.AddRange(new ImageComboBoxItem[]
			{
				new ImageComboBoxItem(InetControlState.InetAllow.GetDescriptionForPermissionValue(), 2.ToString(), 2),
				new ImageComboBoxItem(InetControlState.InetCheck.GetDescriptionForPermissionValue(), 0.ToString(), 0),
				new ImageComboBoxItem(InetControlState.InetBlock.GetDescriptionForPermissionValue(), 1.ToString(), 1),
				new ImageComboBoxItem(InetControlState.InetStrict.GetDescriptionForPermissionValue(), 4.ToString(), 4)
			});
			this.imageComboBoxSearchEngines.Items.Clear();
			this.imageComboBoxSearchEngines.Items.AddRange(new ImageComboBoxItem[]
			{
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<SearchEnginesFlags>(SearchEnginesFlags.SearchEngineDisabled, null, null), 0.ToString(), -1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<SearchEnginesFlags>(SearchEnginesFlags.ForceSafe, null, null), 1.ToString(), -1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<SearchEnginesFlags>(SearchEnginesFlags.CheckQuery, null, null), 3.ToString(), -1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<SearchEnginesFlags>(SearchEnginesFlags.DenyImages, null, null), 7.ToString(), -1)
			});
			this.imageComboBoxUrlHistoryLogFlags.Items.Clear();
			this.imageComboBoxUrlHistoryLogFlags.Items.AddRange(new ImageComboBoxItem[]
			{
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<WebHistoryLogFlags>(WebHistoryLogFlags.UrlBlocked, null, null), 2.ToString(), 0),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<WebHistoryLogFlags>(WebHistoryLogFlags.UrlVisited, null, null), 6.ToString(), 1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<WebHistoryLogFlags>(WebHistoryLogFlags.WebHistoryLogDisabled, null, null), 0.ToString(), 2)
			});
			this.imageComboBoxAllowedCategories.Items.Clear();
			this.imageComboBoxAllowedCategories.SmallImages = iconsProvider.InetControlStateImages16x16;
			foreach (URLCategory urlCategory in this._apiClient.URLCategories)
			{
				if (this._apiClient.GetURLCategoryControlState(urlCategory.Id) == ControlState.Allow)
				{
					this.imageComboBoxAllowedCategories.Items.Add(new ImageComboBoxItem(urlCategory.Name, urlCategory.Id, 4));
				}
			}
			this.imageComboBoxDeviceGroupsSelectMode.Items.Clear();
			this.imageComboBoxDeviceGroupsSelectMode.Items.AddRange(new ImageComboBoxItem[]
			{
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<DeviceGroupsSelectMode>(DeviceGroupsSelectMode.DeviceGroupsSelectAll, null, null), 1.ToString(), -1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<DeviceGroupsSelectMode>(DeviceGroupsSelectMode.DeviceGroupsSelectDependOnAgentGroup, null, null), 2.ToString(), -1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<DeviceGroupsSelectMode>(DeviceGroupsSelectMode.DeviceGroupsSelectOneGroupByUser, null, null), 3.ToString(), -1)
			});
			ProtoBuffCollection<PermissionDescription, PermissionDescriptionsCollection> permissionDescription = this._apiClient.PermissionDescriptions;
			this._permissionListForApiUser = new BindingList<PermissionDescription>((from x in permissionDescription
			where x.RoleType == RoleType.ApiUsers
			select x).ToList<PermissionDescription>());
			this._permissionListForWindowsUser = new BindingList<PermissionDescription>((from x in permissionDescription
			where x.RoleType == RoleType.WindowsUsers
			select x).ToList<PermissionDescription>());
			this._appControlStateItems = this.CreateAppAccessItems();
			this.repositoryItemTreeListEditAppControlState.DataSource = this._appControlStateItems;
			this.repositoryItemTreeListAppControlState.SelectImageList = iconsProvider.AppControlStateImages16x16;
			this.gridPermissions.DataSource = this._permissionListForApiUser;
			this.gridRoles.DataSource = this._apiClient.Roles;
			this.gridUsers.DataSource = this._apiClient.RoleUsers;
			this.gridColumnPermissionDisplayName.BestFit();
			base.SetGridColumnForEditDeleteCommands(this.gridColumnRoleCommand);
			base.SetGridColumnForEditDeleteCommands(this.gridColumnUserCommand);
			this._objectsToSaveState.Add(this);
			this._objectsToSaveState.Add(this.splitContainerMain);
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x00035714 File Offset: 0x00033914
		protected override void OnGridCommandDeleteClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			RolesForm.<OnGridCommandDeleteClick>d__6 <OnGridCommandDeleteClick>d__;
			<OnGridCommandDeleteClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnGridCommandDeleteClick>d__.<>4__this = this;
			<OnGridCommandDeleteClick>d__.parent = parent;
			<OnGridCommandDeleteClick>d__.<>1__state = -1;
			<OnGridCommandDeleteClick>d__.<>t__builder.Start<RolesForm.<OnGridCommandDeleteClick>d__6>(ref <OnGridCommandDeleteClick>d__);
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x00035754 File Offset: 0x00033954
		protected override void OnGridCommandEditClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			RolesForm.<OnGridCommandEditClick>d__7 <OnGridCommandEditClick>d__;
			<OnGridCommandEditClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnGridCommandEditClick>d__.<>4__this = this;
			<OnGridCommandEditClick>d__.parent = parent;
			<OnGridCommandEditClick>d__.<>1__state = -1;
			<OnGridCommandEditClick>d__.<>t__builder.Start<RolesForm.<OnGridCommandEditClick>d__7>(ref <OnGridCommandEditClick>d__);
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x00035794 File Offset: 0x00033994
		private void AddRole(RoleType roleType)
		{
			RolesForm.<AddRole>d__8 <AddRole>d__;
			<AddRole>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AddRole>d__.<>4__this = this;
			<AddRole>d__.roleType = roleType;
			<AddRole>d__.<>1__state = -1;
			<AddRole>d__.<>t__builder.Start<RolesForm.<AddRole>d__8>(ref <AddRole>d__);
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x000357D3 File Offset: 0x000339D3
		private void barButtonAddApiUserRole_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.AddRole(RoleType.ApiUsers);
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x000357DC File Offset: 0x000339DC
		private void barButtonAddUser_ItemClick(object sender, ItemClickEventArgs e)
		{
			RoleType roleType = (e.Link.Item == this.barButtonAddApiUser) ? RoleType.ApiUsers : RoleType.WindowsUsers;
			Role role = this.GetFocusedRole();
			if (role.RoleType != roleType)
			{
				role = this._apiClient.Roles.FirstOrDefault((Role x) => x.RoleType == roleType);
			}
			if (role != null)
			{
				RoleUserFormParams @params = new RoleUserFormParams(role.Id);
				this._formCreator.Show<RoleUserForm, RoleUserFormParams>(FormAction.Create, @params, out @params);
			}
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x0003585D File Offset: 0x00033A5D
		private void barButtonAddWindowsUserRole_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.AddRole(RoleType.WindowsUsers);
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x0000228D File Offset: 0x0000048D
		private void barButtonClose_ItemClick(object sender, ItemClickEventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x00035866 File Offset: 0x00033A66
		private void barButtonDeleteUser_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.DeleteUsers();
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x00035870 File Offset: 0x00033A70
		private void barButtonImportWindowsUser_ItemClick(object sender, ItemClickEventArgs e)
		{
			Role focusedRole = this.GetFocusedRole();
			string roleId = (focusedRole != null) ? focusedRole.Id : null;
			this._formCreator.Show<DomainUsersImportForm, string>(FormAction.Create, roleId);
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x000358A0 File Offset: 0x00033AA0
		private void buttonShowAvailableDeviceGroups_Click(object sender, EventArgs e)
		{
			RolesForm.<buttonShowAvailableDeviceGroups_Click>d__15 <buttonShowAvailableDeviceGroups_Click>d__;
			<buttonShowAvailableDeviceGroups_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonShowAvailableDeviceGroups_Click>d__.<>4__this = this;
			<buttonShowAvailableDeviceGroups_Click>d__.<>1__state = -1;
			<buttonShowAvailableDeviceGroups_Click>d__.<>t__builder.Start<RolesForm.<buttonShowAvailableDeviceGroups_Click>d__15>(ref <buttonShowAvailableDeviceGroups_Click>d__);
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x000358D8 File Offset: 0x00033AD8
		private BindingList<RolesForm.AppControlStateItem> CreateAppAccessItems()
		{
			BindingList<RolesForm.AppControlStateItem> result = new BindingList<RolesForm.AppControlStateItem>();
			result.Add(new RolesForm.AppControlStateItem(AppControlState.AppCheck, null, null, null));
			result.Add(new RolesForm.AppControlStateItem(AppControlState.AppBlock, null, null, null));
			result.Add(new RolesForm.AppControlStateItem(AppControlState.AppAllow, null, null, null));
			result.Add(new RolesForm.AppControlStateItem(AppControlState.AppStrictToDesktop, null, null, null));
			result.Add(new RolesForm.AppControlStateItem(AppControlState.AppUseBlackList, null, null, null));
			result.Add(new RolesForm.AppControlStateItem(AppControlState.AppUseWhiteList, null, null, null));
			foreach (Desktop desktop in this._apiClient.Desktops)
			{
				result.Add(new RolesForm.AppControlStateItem(AppControlState.AppStrictToDesktop, desktop.Id, new AppControlState?(AppControlState.AppStrictToDesktop), desktop.Name));
			}
			foreach (AppCategory category in this._apiClient.AppCategories)
			{
				if (category.CategoryType == AppCategoryType.AppBlackList)
				{
					result.Add(new RolesForm.AppControlStateItem(AppControlState.AppUseBlackList, category.Id, new AppControlState?(AppControlState.AppUseBlackList), category.Name));
				}
				else if (category.CategoryType == AppCategoryType.AppWhiteList)
				{
					result.Add(new RolesForm.AppControlStateItem(AppControlState.AppUseWhiteList, category.Id, new AppControlState?(AppControlState.AppUseWhiteList), category.Name));
				}
			}
			return result;
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x00035A68 File Offset: 0x00033C68
		private void DeleteUsers()
		{
			RolesForm.<DeleteUsers>d__17 <DeleteUsers>d__;
			<DeleteUsers>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<DeleteUsers>d__.<>4__this = this;
			<DeleteUsers>d__.<>1__state = -1;
			<DeleteUsers>d__.<>t__builder.Start<RolesForm.<DeleteUsers>d__17>(ref <DeleteUsers>d__);
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x00035A9F File Offset: 0x00033C9F
		private PermissionDescription GetFocusedPermission()
		{
			return this.gridViewPermissions.GetFocusedRow() as PermissionDescription;
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x00035AB1 File Offset: 0x00033CB1
		private Role GetFocusedRole()
		{
			return this.gridViewRoles.GetFocusedRow() as Role;
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x00035AC3 File Offset: 0x00033CC3
		private RoleUser GetFocusedUser()
		{
			return this.gridViewUsers.GetFocusedRow() as RoleUser;
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x00035AD8 File Offset: 0x00033CD8
		private string GetPermissionValueForFocusedRole(string permissionId)
		{
			Role role = this.GetFocusedRole();
			if (role != null)
			{
				return this._apiClient.GetPermisionValueForRole(role.Id, permissionId, false);
			}
			return string.Empty;
		}

		// Token: 0x0600069A RID: 1690 RVA: 0x00035B08 File Offset: 0x00033D08
		private void gridViewPermissions_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
		{
			RolesForm.<gridViewPermissions_CellValueChanging>d__22 <gridViewPermissions_CellValueChanging>d__;
			<gridViewPermissions_CellValueChanging>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<gridViewPermissions_CellValueChanging>d__.<>4__this = this;
			<gridViewPermissions_CellValueChanging>d__.e = e;
			<gridViewPermissions_CellValueChanging>d__.<>1__state = -1;
			<gridViewPermissions_CellValueChanging>d__.<>t__builder.Start<RolesForm.<gridViewPermissions_CellValueChanging>d__22>(ref <gridViewPermissions_CellValueChanging>d__);
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x00035B48 File Offset: 0x00033D48
		private void gridViewPermissions_CustomDrawGroupRow(object sender, RowObjectCustomDrawEventArgs e)
		{
			GridGroupRowInfo groupInfo = e.Info as GridGroupRowInfo;
			PermissionType permissionType;
			if (Enum.TryParse<PermissionType>(groupInfo.GroupValueText, out permissionType))
			{
				if (permissionType == PermissionType.WindowsUserDenyRemote)
				{
					permissionType = PermissionType.Remote;
				}
				groupInfo.GroupText = SsStringUtils.GetEnumDescriptionFromResource<PermissionType>(permissionType, null, null);
				return;
			}
			groupInfo.GroupText = groupInfo.GroupValueText;
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00035B94 File Offset: 0x00033D94
		private void gridViewPermissions_CustomRowCellEdit(object sender, CustomRowCellEditEventArgs e)
		{
			if (e.Column == this.gridColumnPermissionValue)
			{
				PermissionDescription permission = (sender as GridView).GetRow(e.RowHandle) as PermissionDescription;
				if (permission == null)
				{
					throw new ArgumentOutOfRangeException();
				}
				PermissionValueType permissionValueType = permission.PermissionValueType;
				PermissionType permissionType = permission.PermissionType;
				switch (permissionValueType)
				{
				case PermissionValueType.Bool:
					if (permissionType == PermissionType.WindowsUserDenyRemote)
					{
						e.RepositoryItem = this.imageComboBoxPermissionTypeWindowsUserDenyRemote;
						return;
					}
					e.RepositoryItem = this.imageComboBoxPermissionValueBool;
					return;
				case PermissionValueType.RemoteControl:
					e.RepositoryItem = this.imageComboBoxPermissionValueRemoteControl;
					return;
				case PermissionValueType.InetControlState:
					e.RepositoryItem = this.imageComboBoxPermissionValueInetControlState;
					return;
				case PermissionValueType.Int:
					if (permission.Id == "UserSearchEnginesFlag")
					{
						e.RepositoryItem = this.imageComboBoxSearchEngines;
						return;
					}
					if (permission.Id == "UserWebHistoryFlags")
					{
						e.RepositoryItem = this.imageComboBoxUrlHistoryLogFlags;
						return;
					}
					if (permission.Id == "ApiDeviceGroupsSelectMode")
					{
						e.RepositoryItem = this.imageComboBoxDeviceGroupsSelectMode;
						return;
					}
					if (permission.Id == "UserAppHistoryFlags")
					{
						e.RepositoryItem = this.imageComboBoxPermissionValueBool;
						return;
					}
					break;
				case PermissionValueType.String:
					if (permission.Id == "UserInetStrictCategory")
					{
						e.RepositoryItem = this.imageComboBoxAllowedCategories;
						return;
					}
					if (permission.Id == "ApiAvailableDeviceGroups")
					{
						e.RepositoryItem = this.buttonShowAvailableDeviceGroups;
					}
					break;
				case PermissionValueType.AppControlState:
					e.RepositoryItem = this.repositoryItemTreeListEditAppControlState;
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x00035D00 File Offset: 0x00033F00
		private void gridViewPermissions_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			if (e.Column.FieldName == "PermissionValue" && e.IsGetData)
			{
				object row = e.Row;
				PermissionDescription permission = row as PermissionDescription;
				if (permission != null)
				{
					PermissionValueType permissionValueType = permission.PermissionValueType;
					if (permissionValueType > PermissionValueType.String)
					{
						if (permissionValueType == PermissionValueType.AppControlState)
						{
							RolesForm.AppControlStateItem item = this._appControlStateItems.FirstOrDefault((RolesForm.AppControlStateItem x) => x.Id == this.GetPermissionValueForFocusedRole(permission.Id));
							e.Value = item;
							if (item != null)
							{
								this.repositoryItemTreeListEditAppControlState.ContextImageOptions.Image = this._iconsProvider.AppControlStateImages16x16.Images[item.ImageIndex];
								return;
							}
						}
					}
					else
					{
						if (permission.Id == "ApiAvailableDeviceGroups")
						{
							List<string> groupsIds = SsStringUtils.SeparatedStringToList(this.GetPermissionValueForFocusedRole(permission.Id), ';');
							List<string> groupNames = this._apiClient.DeviceGroupsIdToNames(groupsIds);
							e.Value = ((groupNames.Count > 0) ? (SsStringUtils.ListToSeparatedString(groupNames, ", ") ?? "") : Resources.AvailableDeviceGoupsEmpty);
							object value = e.Value;
							e.Value = ((value != null) ? value.ToString() : null) + " (" + Resources.RolesForm_ClickToChangeValue + ")";
							return;
						}
						e.Value = this.GetPermissionValueForFocusedRole(permission.Id);
					}
				}
			}
		}

		// Token: 0x0600069E RID: 1694 RVA: 0x00035E78 File Offset: 0x00034078
		private void gridViewPermissions_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			GridView view = (GridView)sender;
			if (e.FocusedRowHandle < 0)
			{
				view.FocusedRowHandle = ((e.PrevFocusedRowHandle == int.MinValue) ? 0 : e.PrevFocusedRowHandle);
				return;
			}
			PermissionDescription permission = this.gridViewPermissions.GetFocusedRow() as PermissionDescription;
			if (permission != null)
			{
				this.labelPermissionDescription.Text = permission.Description;
			}
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x00003A2C File Offset: 0x00001C2C
		private void gridViewPermissions_ShowingEditor(object sender, CancelEventArgs e)
		{
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x00035ED8 File Offset: 0x000340D8
		private void gridViewRole_CustomDrawGroupRow(object sender, RowObjectCustomDrawEventArgs e)
		{
			GridGroupRowInfo groupInfo = e.Info as GridGroupRowInfo;
			if (groupInfo.GroupValueText == "ApiUsers")
			{
				groupInfo.GroupText = SsStringUtils.GetEnumDescriptionFromResource<RoleType>(RoleType.ApiUsers, null, null);
				return;
			}
			if (groupInfo.GroupValueText == "WindowsUsers")
			{
				groupInfo.GroupText = SsStringUtils.GetEnumDescriptionFromResource<RoleType>(RoleType.WindowsUsers, null, null);
				return;
			}
			groupInfo.GroupText = groupInfo.GroupValueText;
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x00035F40 File Offset: 0x00034140
		private void gridViewRole_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			GridView view = (GridView)sender;
			if (e.FocusedRowHandle < 0)
			{
				view.FocusedRowHandle = ((e.PrevFocusedRowHandle == int.MinValue) ? 0 : e.PrevFocusedRowHandle);
				return;
			}
			Role role = this.GetFocusedRole();
			if (role != null)
			{
				RoleType groupType = role.RoleType;
				if (groupType != RoleType.ApiUsers)
				{
					if (groupType != RoleType.WindowsUsers)
					{
						this.gridPermissions.DataSource = null;
					}
					else
					{
						this.xtraTabPagePermissions.Text = Resources.RolesForm_RestrictionsAndSettings;
						this.xtraTabPageUsers.Text = SsStringUtils.GetEnumDescriptionFromResource<RoleType>(RoleType.WindowsUsers, null, null);
						this.gridPermissions.DataSource = this._permissionListForWindowsUser;
						this.gridColumnUserStatus.Visible = false;
					}
				}
				else
				{
					this.xtraTabPagePermissions.Text = Resources.RolesForm_Permissions;
					this.xtraTabPageUsers.Text = SsStringUtils.GetEnumDescriptionFromResource<RoleType>(RoleType.ApiUsers, null, null);
					this.gridPermissions.DataSource = this._permissionListForApiUser;
					this.gridColumnUserStatus.Visible = true;
				}
				this.gridViewUsers.RefreshData();
				this.gridViewPermissions.RefreshData();
			}
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x00036040 File Offset: 0x00034240
		private void gridViews_GroupRowCollapsing(object sender, RowAllowEventArgs e)
		{
			e.Allow = false;
		}

		// Token: 0x060006A3 RID: 1699 RVA: 0x0003604C File Offset: 0x0003424C
		private void gridViewUsers_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			object roleId = (sender as ColumnView).GetListSourceRowCellValue(e.ListSourceRow, "RoleId");
			if (roleId == null)
			{
				return;
			}
			Role focusedRole = this.GetFocusedRole();
			if (focusedRole != null)
			{
				e.Visible = (roleId.ToString() == focusedRole.Id);
				e.Handled = true;
			}
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x0003609C File Offset: 0x0003429C
		private void gridViewUsers_MouseDown(object sender, MouseEventArgs e)
		{
			GridView view = sender as GridView;
			if (e.Button == MouseButtons.Right && view.CalcHitInfo(e.Location).HitTest == GridHitTest.RowCell)
			{
				this.popupMenuUsers.ShowPopup(this.gridUsers.PointToScreen(e.Location));
			}
		}

		// Token: 0x060006A5 RID: 1701 RVA: 0x000360F0 File Offset: 0x000342F0
		private void repositoryItemTreeListAppControlState_BeforeFocusNode(object sender, BeforeFocusNodeEventArgs e)
		{
			RolesForm.AppControlStateItem item = e.Node.TreeList.GetDataRecordByNode(e.Node) as RolesForm.AppControlStateItem;
			if (item != null && (item.AppControlState == AppControlState.AppStrictToDesktop || item.AppControlState == AppControlState.AppUseBlackList || item.AppControlState == AppControlState.AppUseWhiteList))
			{
				e.CanFocus = (item.Id.Length > 2);
			}
		}

		// Token: 0x04000453 RID: 1107
		private readonly ApiClient _apiClient;

		// Token: 0x04000454 RID: 1108
		private readonly BindingList<PermissionDescription> _permissionListForApiUser;

		// Token: 0x04000455 RID: 1109
		private readonly BindingList<PermissionDescription> _permissionListForWindowsUser;

		// Token: 0x04000456 RID: 1110
		private BindingList<RolesForm.AppControlStateItem> _appControlStateItems;

		// Token: 0x04000457 RID: 1111
		private IIconsProvider _iconsProvider;

		// Token: 0x02000168 RID: 360
		private class AppControlStateItem
		{
			// Token: 0x06000B57 RID: 2903 RVA: 0x0005FBD4 File Offset: 0x0005DDD4
			public AppControlStateItem(AppControlState controlState, string subId, AppControlState? parentControlState, string name)
			{
				int num = (int)controlState;
				this.Id = num.ToString();
				if (!string.IsNullOrEmpty(subId))
				{
					this.Id = this.Id + ":" + subId;
				}
				if (parentControlState == null)
				{
					this.ParentId = "-1";
				}
				else
				{
					this.ParentId = ((int)parentControlState.Value).ToString();
				}
				this.Name = (string.IsNullOrEmpty(name) ? controlState.GetDescriptionForPermissionValue() : name);
				this.ImageIndex = controlState;
				this.AppControlState = controlState;
			}

			// Token: 0x170002F9 RID: 761
			// (get) Token: 0x06000B58 RID: 2904 RVA: 0x0005FC67 File Offset: 0x0005DE67
			public AppControlState AppControlState { get; }

			// Token: 0x170002FA RID: 762
			// (get) Token: 0x06000B59 RID: 2905 RVA: 0x0005FC6F File Offset: 0x0005DE6F
			public string Id { get; }

			// Token: 0x170002FB RID: 763
			// (get) Token: 0x06000B5A RID: 2906 RVA: 0x0005FC77 File Offset: 0x0005DE77
			public int ImageIndex { get; }

			// Token: 0x170002FC RID: 764
			// (get) Token: 0x06000B5B RID: 2907 RVA: 0x0005FC7F File Offset: 0x0005DE7F
			public string Name { get; }

			// Token: 0x170002FD RID: 765
			// (get) Token: 0x06000B5C RID: 2908 RVA: 0x0005FC87 File Offset: 0x0005DE87
			public string ParentId { get; }
		}
	}
}
