﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000068 RID: 104
	public partial class FileTransferForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000593 RID: 1427 RVA: 0x0002354B File Offset: 0x0002174B
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0002356C File Offset: 0x0002176C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.FileTransferForm));
			this.progressBarFile = new global::DevExpress.XtraEditors.ProgressBarControl();
			this.labelFileInfo = new global::DevExpress.XtraEditors.LabelControl();
			this.labelAllFilesInfo = new global::DevExpress.XtraEditors.LabelControl();
			this.progressBarAllFiles = new global::DevExpress.XtraEditors.ProgressBarControl();
			this.buttonCancel = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.progressBarFile.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.progressBarAllFiles.Properties).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.progressBarFile, "progressBarFile");
			this.progressBarFile.Name = "progressBarFile";
			this.progressBarFile.Properties.AccessibleDescription = resources.GetString("progressBarFile.Properties.AccessibleDescription");
			this.progressBarFile.Properties.AccessibleName = resources.GetString("progressBarFile.Properties.AccessibleName");
			this.progressBarFile.Properties.Appearance.FontSizeDelta = (int)resources.GetObject("progressBarFile.Properties.Appearance.FontSizeDelta");
			this.progressBarFile.Properties.Appearance.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarFile.Properties.Appearance.FontStyleDelta");
			this.progressBarFile.Properties.Appearance.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarFile.Properties.Appearance.GradientMode");
			this.progressBarFile.Properties.Appearance.Image = (global::System.Drawing.Image)resources.GetObject("progressBarFile.Properties.Appearance.Image");
			this.progressBarFile.Properties.AppearanceDisabled.FontSizeDelta = (int)resources.GetObject("progressBarFile.Properties.AppearanceDisabled.FontSizeDelta");
			this.progressBarFile.Properties.AppearanceDisabled.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarFile.Properties.AppearanceDisabled.FontStyleDelta");
			this.progressBarFile.Properties.AppearanceDisabled.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarFile.Properties.AppearanceDisabled.GradientMode");
			this.progressBarFile.Properties.AppearanceDisabled.Image = (global::System.Drawing.Image)resources.GetObject("progressBarFile.Properties.AppearanceDisabled.Image");
			this.progressBarFile.Properties.AppearanceFocused.FontSizeDelta = (int)resources.GetObject("progressBarFile.Properties.AppearanceFocused.FontSizeDelta");
			this.progressBarFile.Properties.AppearanceFocused.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarFile.Properties.AppearanceFocused.FontStyleDelta");
			this.progressBarFile.Properties.AppearanceFocused.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarFile.Properties.AppearanceFocused.GradientMode");
			this.progressBarFile.Properties.AppearanceFocused.Image = (global::System.Drawing.Image)resources.GetObject("progressBarFile.Properties.AppearanceFocused.Image");
			this.progressBarFile.Properties.AppearanceReadOnly.FontSizeDelta = (int)resources.GetObject("progressBarFile.Properties.AppearanceReadOnly.FontSizeDelta");
			this.progressBarFile.Properties.AppearanceReadOnly.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarFile.Properties.AppearanceReadOnly.FontStyleDelta");
			this.progressBarFile.Properties.AppearanceReadOnly.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarFile.Properties.AppearanceReadOnly.GradientMode");
			this.progressBarFile.Properties.AppearanceReadOnly.Image = (global::System.Drawing.Image)resources.GetObject("progressBarFile.Properties.AppearanceReadOnly.Image");
			this.progressBarFile.Properties.AutoHeight = (bool)resources.GetObject("progressBarFile.Properties.AutoHeight");
			resources.ApplyResources(this.labelFileInfo, "labelFileInfo");
			this.labelFileInfo.AutoEllipsis = true;
			this.labelFileInfo.Name = "labelFileInfo";
			resources.ApplyResources(this.labelAllFilesInfo, "labelAllFilesInfo");
			this.labelAllFilesInfo.AutoEllipsis = true;
			this.labelAllFilesInfo.Name = "labelAllFilesInfo";
			resources.ApplyResources(this.progressBarAllFiles, "progressBarAllFiles");
			this.progressBarAllFiles.Name = "progressBarAllFiles";
			this.progressBarAllFiles.Properties.AccessibleDescription = resources.GetString("progressBarAllFiles.Properties.AccessibleDescription");
			this.progressBarAllFiles.Properties.AccessibleName = resources.GetString("progressBarAllFiles.Properties.AccessibleName");
			this.progressBarAllFiles.Properties.Appearance.FontSizeDelta = (int)resources.GetObject("progressBarAllFiles.Properties.Appearance.FontSizeDelta");
			this.progressBarAllFiles.Properties.Appearance.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarAllFiles.Properties.Appearance.FontStyleDelta");
			this.progressBarAllFiles.Properties.Appearance.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarAllFiles.Properties.Appearance.GradientMode");
			this.progressBarAllFiles.Properties.Appearance.Image = (global::System.Drawing.Image)resources.GetObject("progressBarAllFiles.Properties.Appearance.Image");
			this.progressBarAllFiles.Properties.AppearanceDisabled.FontSizeDelta = (int)resources.GetObject("progressBarAllFiles.Properties.AppearanceDisabled.FontSizeDelta");
			this.progressBarAllFiles.Properties.AppearanceDisabled.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarAllFiles.Properties.AppearanceDisabled.FontStyleDelta");
			this.progressBarAllFiles.Properties.AppearanceDisabled.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarAllFiles.Properties.AppearanceDisabled.GradientMode");
			this.progressBarAllFiles.Properties.AppearanceDisabled.Image = (global::System.Drawing.Image)resources.GetObject("progressBarAllFiles.Properties.AppearanceDisabled.Image");
			this.progressBarAllFiles.Properties.AppearanceFocused.FontSizeDelta = (int)resources.GetObject("progressBarAllFiles.Properties.AppearanceFocused.FontSizeDelta");
			this.progressBarAllFiles.Properties.AppearanceFocused.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarAllFiles.Properties.AppearanceFocused.FontStyleDelta");
			this.progressBarAllFiles.Properties.AppearanceFocused.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarAllFiles.Properties.AppearanceFocused.GradientMode");
			this.progressBarAllFiles.Properties.AppearanceFocused.Image = (global::System.Drawing.Image)resources.GetObject("progressBarAllFiles.Properties.AppearanceFocused.Image");
			this.progressBarAllFiles.Properties.AppearanceReadOnly.FontSizeDelta = (int)resources.GetObject("progressBarAllFiles.Properties.AppearanceReadOnly.FontSizeDelta");
			this.progressBarAllFiles.Properties.AppearanceReadOnly.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("progressBarAllFiles.Properties.AppearanceReadOnly.FontStyleDelta");
			this.progressBarAllFiles.Properties.AppearanceReadOnly.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("progressBarAllFiles.Properties.AppearanceReadOnly.GradientMode");
			this.progressBarAllFiles.Properties.AppearanceReadOnly.Image = (global::System.Drawing.Image)resources.GetObject("progressBarAllFiles.Properties.AppearanceReadOnly.Image");
			this.progressBarAllFiles.Properties.AutoHeight = (bool)resources.GetObject("progressBarAllFiles.Properties.AutoHeight");
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonCancel.ImageOptions.Image");
			this.buttonCancel.ImageOptions.ImageIndex = (int)resources.GetObject("buttonCancel.ImageOptions.ImageIndex");
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Click += new global::System.EventHandler(this.buttonCancel_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ControlBox = false;
			base.Controls.Add(this.buttonCancel);
			base.Controls.Add(this.labelAllFilesInfo);
			base.Controls.Add(this.progressBarAllFiles);
			base.Controls.Add(this.labelFileInfo);
			base.Controls.Add(this.progressBarFile);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.Name = "FileTransferForm";
			base.Shown += new global::System.EventHandler(this.FormFileTransfer_Shown);
			((global::System.ComponentModel.ISupportInitialize)this.progressBarFile.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.progressBarAllFiles.Properties).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040002F1 RID: 753
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002F2 RID: 754
		private global::DevExpress.XtraEditors.ProgressBarControl progressBarFile;

		// Token: 0x040002F3 RID: 755
		private global::DevExpress.XtraEditors.LabelControl labelFileInfo;

		// Token: 0x040002F4 RID: 756
		private global::DevExpress.XtraEditors.LabelControl labelAllFilesInfo;

		// Token: 0x040002F5 RID: 757
		private global::DevExpress.XtraEditors.ProgressBarControl progressBarAllFiles;

		// Token: 0x040002F6 RID: 758
		private global::DevExpress.XtraEditors.SimpleButton buttonCancel;
	}
}
