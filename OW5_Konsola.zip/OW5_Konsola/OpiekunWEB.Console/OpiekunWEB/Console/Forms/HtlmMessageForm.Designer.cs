﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000052 RID: 82
	public partial class HtlmMessageForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600048F RID: 1167 RVA: 0x00015535 File Offset: 0x00013735
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x00015554 File Offset: 0x00013754
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.HtlmMessageForm));
			this.panelBottom = new global::System.Windows.Forms.Panel();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.webBrowser = new global::System.Windows.Forms.WebBrowser();
			this.panelBottom.SuspendLayout();
			base.SuspendLayout();
			this.panelBottom.Controls.Add(this.buttonOk);
			resources.ApplyResources(this.panelBottom, "panelBottom");
			this.panelBottom.Name = "panelBottom";
			this.buttonOk.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.Name = "buttonOk";
			resources.ApplyResources(this.webBrowser, "webBrowser");
			this.webBrowser.Name = "webBrowser";
			this.webBrowser.DocumentCompleted += new global::System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser_DocumentCompleted);
			this.webBrowser.Navigating += new global::System.Windows.Forms.WebBrowserNavigatingEventHandler(this.webBrowser_Navigating);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.CanCloseByEsc = false;
			base.Controls.Add(this.webBrowser);
			base.Controls.Add(this.panelBottom);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("HtlmMessageForm.IconOptions.Icon");
			base.MaximizeBox = true;
			base.Name = "HtlmMessageForm";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.HtlmMessageForm_FormClosing);
			this.panelBottom.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x040001D8 RID: 472
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040001D9 RID: 473
		private global::System.Windows.Forms.Panel panelBottom;

		// Token: 0x040001DA RID: 474
		protected global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x040001DB RID: 475
		private global::System.Windows.Forms.WebBrowser webBrowser;
	}
}
