﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005C RID: 92
	public partial class RibbonBaseForm : global::DevExpress.XtraBars.Ribbon.RibbonForm
	{
		// Token: 0x06000502 RID: 1282 RVA: 0x000191BC File Offset: 0x000173BC
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x000191DC File Offset: 0x000173DC
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.RibbonBaseForm));
			global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions = new global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions2 = new global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject8 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions3 = new global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject9 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject10 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject11 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject12 = new global::DevExpress.Utils.SerializableAppearanceObject();
			this.editorsPersistentRepository = new global::DevExpress.XtraEditors.Repository.PersistentRepository(this.components);
			this.repositoryItemEditAndDelete = new global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
			this.repositoryItemEdit = new global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemEditAndDelete).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemEdit).BeginInit();
			base.SuspendLayout();
			this.editorsPersistentRepository.Items.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryItemEditAndDelete,
				this.repositoryItemEdit
			});
			editorButtonImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.edit_16x16;
			editorButtonImageOptions.Location = global::DevExpress.XtraEditors.ImageLocation.MiddleLeft;
			editorButtonImageOptions2.Image = global::OpiekunWEB.Console.Properties.Resources.deletelist_16x16;
			editorButtonImageOptions2.Location = global::DevExpress.XtraEditors.ImageLocation.MiddleLeft;
			this.repositoryItemEditAndDelete.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryItemEditAndDelete.Buttons"), resources.GetString("repositoryItemEditAndDelete.Buttons1"), (int)resources.GetObject("repositoryItemEditAndDelete.Buttons2"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons3"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons4"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons5"), editorButtonImageOptions, new global::DevExpress.Utils.KeyShortcut(global::System.Windows.Forms.Keys.None), serializableAppearanceObject, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, resources.GetString("repositoryItemEditAndDelete.Buttons6"), resources.GetObject("repositoryItemEditAndDelete.Buttons7"), (global::DevExpress.Utils.SuperToolTip)resources.GetObject("repositoryItemEditAndDelete.Buttons8"), (global::DevExpress.Utils.ToolTipAnchor)resources.GetObject("repositoryItemEditAndDelete.Buttons9")),
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryItemEditAndDelete.Buttons10"), resources.GetString("repositoryItemEditAndDelete.Buttons11"), (int)resources.GetObject("repositoryItemEditAndDelete.Buttons12"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons13"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons14"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons15"), editorButtonImageOptions2, new global::DevExpress.Utils.KeyShortcut(global::System.Windows.Forms.Keys.None), serializableAppearanceObject5, serializableAppearanceObject6, serializableAppearanceObject7, serializableAppearanceObject8, resources.GetString("repositoryItemEditAndDelete.Buttons16"), resources.GetObject("repositoryItemEditAndDelete.Buttons17"), (global::DevExpress.Utils.SuperToolTip)resources.GetObject("repositoryItemEditAndDelete.Buttons18"), (global::DevExpress.Utils.ToolTipAnchor)resources.GetObject("repositoryItemEditAndDelete.Buttons19"))
			});
			this.repositoryItemEditAndDelete.Name = "repositoryItemEditAndDelete";
			this.repositoryItemEditAndDelete.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.repositoryItemEditAndDelete.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemEditAndDelete_ButtonClick);
			editorButtonImageOptions3.Image = global::OpiekunWEB.Console.Properties.Resources.edit_16x16;
			editorButtonImageOptions3.Location = global::DevExpress.XtraEditors.ImageLocation.MiddleLeft;
			this.repositoryItemEdit.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryItemEdit.Buttons"), resources.GetString("repositoryItemEdit.Buttons1"), (int)resources.GetObject("repositoryItemEdit.Buttons2"), (bool)resources.GetObject("repositoryItemEdit.Buttons3"), (bool)resources.GetObject("repositoryItemEdit.Buttons4"), (bool)resources.GetObject("repositoryItemEdit.Buttons5"), editorButtonImageOptions3, new global::DevExpress.Utils.KeyShortcut(global::System.Windows.Forms.Keys.None), serializableAppearanceObject9, serializableAppearanceObject10, serializableAppearanceObject11, serializableAppearanceObject12, resources.GetString("repositoryItemEdit.Buttons6"), resources.GetObject("repositoryItemEdit.Buttons7"), (global::DevExpress.Utils.SuperToolTip)resources.GetObject("repositoryItemEdit.Buttons8"), (global::DevExpress.Utils.ToolTipAnchor)resources.GetObject("repositoryItemEdit.Buttons9"))
			});
			this.repositoryItemEdit.Name = "repositoryItemEdit";
			this.repositoryItemEdit.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.repositoryItemEdit.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repositoryItemEdit_ButtonClick);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Name = "RibbonBaseForm";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.RibbonFormBase_FormClosing);
			base.Load += new global::System.EventHandler(this.RibbonFormBase_Load);
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemEditAndDelete).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemEdit).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000228 RID: 552
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000229 RID: 553
		private global::DevExpress.XtraEditors.Repository.PersistentRepository editorsPersistentRepository;

		// Token: 0x0400022A RID: 554
		private global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemEditAndDelete;

		// Token: 0x0400022B RID: 555
		private global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemEdit;
	}
}
