﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000087 RID: 135
	public partial class MainForm : global::OpiekunWEB.Console.Forms.RibbonBaseForm, global::OpiekunWEB.Console.Interfaces.ICommandTarget, global::OpiekunWEB.Console.Interfaces.IPopupMenuCreator
	{
		// Token: 0x0600078A RID: 1930 RVA: 0x00040E7E File Offset: 0x0003F07E
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x00040EA0 File Offset: 0x0003F0A0
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.MainForm));
			global::DevExpress.Skins.SkinPaddingEdges skinPaddingEdges = new global::DevExpress.Skins.SkinPaddingEdges();
			this.pageInternetAccess = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.miSetDeviceInetAllow = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceInetCheck = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceInetBlock = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceInetStrict = new global::DevExpress.XtraBars.BarButtonItem();
			this.popupMenuUrlAllowedCategories = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.ribbonControl = new global::DevExpress.XtraBars.Ribbon.RibbonControl();
			this.miExit = new global::DevExpress.XtraBars.BarButtonItem();
			this.miHelp = new global::DevExpress.XtraBars.BarButtonItem();
			this.miCreateDevicesGroup = new global::DevExpress.XtraBars.BarButtonItem();
			this.miEditDevicesGroup = new global::DevExpress.XtraBars.BarButtonItem();
			this.miDeleteDevicesGroup = new global::DevExpress.XtraBars.BarButtonItem();
			this.miUrlCategories = new global::DevExpress.XtraBars.BarButtonItem();
			this.miConfigDevicesInfoView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miConfigLogView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miScreenshotsView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miHistoryView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceLockDisabled = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceLockKeyboard = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceLockMouseKeyboardMonitor = new global::DevExpress.XtraBars.BarButtonItem();
			this.miShowMessagesDef = new global::DevExpress.XtraBars.BarButtonItem();
			this.popupMenuFavoriteMessages = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.miRpcSystemShutdown = new global::DevExpress.XtraBars.BarButtonItem();
			this.miRpcSystemReboot = new global::DevExpress.XtraBars.BarButtonItem();
			this.miRpcSessionLogoff = new global::DevExpress.XtraBars.BarButtonItem();
			this.miRpcWakeOnLan = new global::DevExpress.XtraBars.BarButtonItem();
			this.miShowRemoteDesktop = new global::DevExpress.XtraBars.BarButtonItem();
			this.popupMenuRemoteDesktop = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.miStartVNC = new global::DevExpress.XtraBars.BarButtonItem();
			this.miStartRDP = new global::DevExpress.XtraBars.BarButtonItem();
			this.miShowFileManager = new global::DevExpress.XtraBars.BarButtonItem();
			this.miRoles = new global::DevExpress.XtraBars.BarButtonItem();
			this.miShowUpdateAgents = new global::DevExpress.XtraBars.BarButtonItem();
			this.miRpcSessionLogon = new global::DevExpress.XtraBars.BarButtonItem();
			this.miMoveDeviceToGroup = new global::DevExpress.XtraBars.BarButtonItem();
			this.miDefaultFonts = new global::DevExpress.XtraBars.BarButtonItem();
			this.miIsIdle = new global::DevExpress.XtraBars.BarButtonItem();
			this.miShowDistributeFiles = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSelectedDeviceInfo = new global::DevExpress.XtraBars.BarStaticItem();
			this.skinRibbonGallery = new global::DevExpress.XtraBars.SkinRibbonGalleryBarItem();
			this.miPackagesView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miProcessesView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miChangePassword = new global::DevExpress.XtraBars.BarButtonItem();
			this.popupMenuPassword = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.miCreateAppToken = new global::DevExpress.XtraBars.BarButtonItem();
			this.miMoveDevice = new global::DevExpress.XtraBars.BarButtonItem();
			this.barStaticItemServerConnection = new global::DevExpress.XtraBars.BarStaticItem();
			this.barCheckDiagnosticWnd = new global::DevExpress.XtraBars.BarCheckItem();
			this.barStaticSelectionInfo = new global::DevExpress.XtraBars.BarStaticItem();
			this.miCheckAppUpdates = new global::DevExpress.XtraBars.BarButtonItem();
			this.miShowProcessesDef = new global::DevExpress.XtraBars.BarButtonItem();
			this.popupMenuFavoriteProcesses = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.miRules = new global::DevExpress.XtraBars.BarButtonItem();
			this.miDesktops = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceAppAllow = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceAppStrictToDesktop = new global::DevExpress.XtraBars.BarButtonItem();
			this.popupMenuDesktops = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.miShowCollectFiles = new global::DevExpress.XtraBars.BarButtonItem();
			this.miAppHistoryView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miRpcSessionLock = new global::DevExpress.XtraBars.BarButtonItem();
			this.miServicesView = new global::DevExpress.XtraBars.BarButtonItem();
			this.miCustomerInfo = new global::DevExpress.XtraBars.BarButtonItem();
			this.miAppCategories = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceAppBlock = new global::DevExpress.XtraBars.BarButtonItem();
			this.miSetDeviceAppCheck = new global::DevExpress.XtraBars.BarButtonItem();
			this.popupMenuDeviceAppCheck = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.miDeviceAppCheck = new global::DevExpress.XtraBars.BarButtonItem();
			this.miDeviceAppCheckUseWhiteList = new global::DevExpress.XtraBars.BarSubItem();
			this.miDeviceAppCheckUseBlackList = new global::DevExpress.XtraBars.BarSubItem();
			this.pageGroupWelcome = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.pageExit = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageGroupTools = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.pageTools = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageGroupApplications = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.pageProcesses = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageAppViewSelect = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageGroupConfig = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.pageDevices = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageSettings = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageUpdates = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.ribbonPageOther = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageLookSettings = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageConfigViewSelect = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageGroupHelp = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.pageHelp = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.ribbonStatusBar = new global::DevExpress.XtraBars.Ribbon.RibbonStatusBar();
			this.pageAppAccess = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageDeviceLock = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.pageControlViewSelect = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.splitterDiagnosticWnd = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.gridDiagnostic = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewDiagnostic = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridDiagnosticColumnDate = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridDiagnosticColumnSuccess = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryImageComboDiagnosticSuccess = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.gridDiagnosticColumnOperation = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridDiagnosticColumnDeviceName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridDiagnosticColumnMessage = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryMemoDiagnosticMessage = new global::DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
			this.gridDiagnosticColumnSessionNo = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.splitterDevicesTree = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.devicesTreePanel = new global::OpiekunWEB.Console.Controls.DevicesTreePanel();
			this.fontDialog = new global::System.Windows.Forms.FontDialog();
			this.timerCheckIdle = new global::System.Windows.Forms.Timer(this.components);
			this.tabControlWorkspaces = new global::DevExpress.XtraTab.XtraTabControl();
			this.tabWorkspaceFull = new global::DevExpress.XtraTab.XtraTabPage();
			this.tabWorkspaceTree = new global::DevExpress.XtraTab.XtraTabPage();
			this.alertControlAgentUpdate = new global::DevExpress.XtraBars.Alerter.AlertControl(this.components);
			this.miAppHistoryStatsView = new global::DevExpress.XtraBars.BarButtonItem();
			global::DevExpress.XtraBars.Ribbon.RibbonPage pageGroupControl = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuUrlAllowedCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuFavoriteMessages).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuRemoteDesktop).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuPassword).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuFavoriteProcesses).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuDesktops).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuDeviceAppCheck).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDiagnosticWnd).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDiagnosticWnd.Panel1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDiagnosticWnd.Panel2).BeginInit();
			this.splitterDiagnosticWnd.Panel2.SuspendLayout();
			this.splitterDiagnosticWnd.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridDiagnostic).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewDiagnostic).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryImageComboDiagnosticSuccess).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryMemoDiagnosticMessage).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDevicesTree).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDevicesTree.Panel1).BeginInit();
			this.splitterDevicesTree.Panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDevicesTree.Panel2).BeginInit();
			this.splitterDevicesTree.Panel2.SuspendLayout();
			this.splitterDevicesTree.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.tabControlWorkspaces).BeginInit();
			this.tabControlWorkspaces.SuspendLayout();
			this.tabWorkspaceTree.SuspendLayout();
			base.SuspendLayout();
			pageGroupControl.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.pageInternetAccess,
				this.pageAppAccess,
				this.pageDeviceLock,
				this.pageControlViewSelect
			});
			pageGroupControl.Name = "pageGroupControl";
			resources.ApplyResources(pageGroupControl, "pageGroupControl");
			this.pageInternetAccess.CaptionButtonVisible = global::DevExpress.Utils.DefaultBoolean.False;
			this.pageInternetAccess.ItemLinks.Add(this.miSetDeviceInetAllow);
			this.pageInternetAccess.ItemLinks.Add(this.miSetDeviceInetCheck);
			this.pageInternetAccess.ItemLinks.Add(this.miSetDeviceInetBlock);
			this.pageInternetAccess.ItemLinks.Add(this.miSetDeviceInetStrict);
			this.pageInternetAccess.Name = "pageInternetAccess";
			resources.ApplyResources(this.pageInternetAccess, "pageInternetAccess");
			resources.ApplyResources(this.miSetDeviceInetAllow, "miSetDeviceInetAllow");
			this.miSetDeviceInetAllow.Id = 73;
			this.miSetDeviceInetAllow.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.access_allow_16x16;
			this.miSetDeviceInetAllow.ImageOptions.ImageIndex = (int)resources.GetObject("miSetDeviceInetAllow.ImageOptions.ImageIndex");
			this.miSetDeviceInetAllow.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.access_allow_32x32;
			this.miSetDeviceInetAllow.ImageOptions.LargeImageIndex = (int)resources.GetObject("miSetDeviceInetAllow.ImageOptions.LargeImageIndex");
			this.miSetDeviceInetAllow.Name = "miSetDeviceInetAllow";
			this.miSetDeviceInetAllow.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miSetDeviceInetCheck, "miSetDeviceInetCheck");
			this.miSetDeviceInetCheck.Id = 71;
			this.miSetDeviceInetCheck.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.access_check_16x16;
			this.miSetDeviceInetCheck.ImageOptions.ImageIndex = (int)resources.GetObject("miSetDeviceInetCheck.ImageOptions.ImageIndex");
			this.miSetDeviceInetCheck.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.access_check_32x32;
			this.miSetDeviceInetCheck.ImageOptions.LargeImageIndex = (int)resources.GetObject("miSetDeviceInetCheck.ImageOptions.LargeImageIndex");
			this.miSetDeviceInetCheck.Name = "miSetDeviceInetCheck";
			this.miSetDeviceInetCheck.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miSetDeviceInetBlock, "miSetDeviceInetBlock");
			this.miSetDeviceInetBlock.Id = 72;
			this.miSetDeviceInetBlock.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.access_block_16x16;
			this.miSetDeviceInetBlock.ImageOptions.ImageIndex = (int)resources.GetObject("miSetDeviceInetBlock.ImageOptions.ImageIndex");
			this.miSetDeviceInetBlock.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.access_block_32x32;
			this.miSetDeviceInetBlock.ImageOptions.LargeImageIndex = (int)resources.GetObject("miSetDeviceInetBlock.ImageOptions.LargeImageIndex");
			this.miSetDeviceInetBlock.Name = "miSetDeviceInetBlock";
			this.miSetDeviceInetBlock.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.miSetDeviceInetStrict.ActAsDropDown = true;
			this.miSetDeviceInetStrict.AllowHtmlText = global::DevExpress.Utils.DefaultBoolean.False;
			this.miSetDeviceInetStrict.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.miSetDeviceInetStrict, "miSetDeviceInetStrict");
			this.miSetDeviceInetStrict.DropDownControl = this.popupMenuUrlAllowedCategories;
			this.miSetDeviceInetStrict.Id = 106;
			this.miSetDeviceInetStrict.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.access_strict_16x16;
			this.miSetDeviceInetStrict.ImageOptions.ImageIndex = (int)resources.GetObject("miSetDeviceInetStrict.ImageOptions.ImageIndex");
			this.miSetDeviceInetStrict.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.access_strict_32x32;
			this.miSetDeviceInetStrict.ImageOptions.LargeImageIndex = (int)resources.GetObject("miSetDeviceInetStrict.ImageOptions.LargeImageIndex");
			this.miSetDeviceInetStrict.Name = "miSetDeviceInetStrict";
			this.popupMenuUrlAllowedCategories.Name = "popupMenuUrlAllowedCategories";
			this.popupMenuUrlAllowedCategories.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.ribbonControl, "ribbonControl");
			this.ribbonControl.ExpandCollapseItem.Id = 0;
			this.ribbonControl.ExpandCollapseItem.ImageOptions.ImageIndex = (int)resources.GetObject("ribbonControl.ExpandCollapseItem.ImageOptions.ImageIndex");
			this.ribbonControl.ExpandCollapseItem.ImageOptions.LargeImageIndex = (int)resources.GetObject("ribbonControl.ExpandCollapseItem.ImageOptions.LargeImageIndex");
			this.ribbonControl.Items.AddRange(new global::DevExpress.XtraBars.BarItem[]
			{
				this.ribbonControl.ExpandCollapseItem,
				this.ribbonControl.SearchEditItem,
				this.miExit,
				this.miHelp,
				this.miCreateDevicesGroup,
				this.miEditDevicesGroup,
				this.miDeleteDevicesGroup,
				this.miUrlCategories,
				this.miConfigDevicesInfoView,
				this.miConfigLogView,
				this.miSetDeviceInetCheck,
				this.miSetDeviceInetBlock,
				this.miSetDeviceInetAllow,
				this.miScreenshotsView,
				this.miHistoryView,
				this.miSetDeviceLockDisabled,
				this.miSetDeviceLockKeyboard,
				this.miSetDeviceLockMouseKeyboardMonitor,
				this.miShowMessagesDef,
				this.miRpcSystemShutdown,
				this.miRpcSystemReboot,
				this.miRpcSessionLogoff,
				this.miRpcWakeOnLan,
				this.miShowRemoteDesktop,
				this.miShowFileManager,
				this.miRoles,
				this.miShowUpdateAgents,
				this.miRpcSessionLogon,
				this.miMoveDeviceToGroup,
				this.miDefaultFonts,
				this.miIsIdle,
				this.miShowDistributeFiles,
				this.miSelectedDeviceInfo,
				this.skinRibbonGallery,
				this.miPackagesView,
				this.miProcessesView,
				this.miSetDeviceInetStrict,
				this.miChangePassword,
				this.miMoveDevice,
				this.barStaticItemServerConnection,
				this.barCheckDiagnosticWnd,
				this.miCreateAppToken,
				this.barStaticSelectionInfo,
				this.miCheckAppUpdates,
				this.miShowProcessesDef,
				this.miRules,
				this.miDesktops,
				this.miSetDeviceAppAllow,
				this.miSetDeviceAppStrictToDesktop,
				this.miShowCollectFiles,
				this.miAppHistoryView,
				this.miRpcSessionLock,
				this.miServicesView,
				this.miStartVNC,
				this.miStartRDP,
				this.miCustomerInfo,
				this.miAppCategories,
				this.miSetDeviceAppBlock,
				this.miSetDeviceAppCheck,
				this.miDeviceAppCheck,
				this.miDeviceAppCheckUseBlackList,
				this.miDeviceAppCheckUseWhiteList
			});
			this.ribbonControl.MaxItemId = 358;
			this.ribbonControl.Name = "ribbonControl";
			this.ribbonControl.OptionsMenuMinWidth = 515;
			this.ribbonControl.Pages.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPage[]
			{
				this.pageGroupWelcome,
				pageGroupControl,
				this.pageGroupTools,
				this.pageGroupApplications,
				this.pageGroupConfig,
				this.pageGroupHelp
			});
			this.ribbonControl.RibbonStyle = global::DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2010;
			this.ribbonControl.ShowApplicationButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonControl.ShowToolbarCustomizeItem = false;
			this.ribbonControl.StatusBar = this.ribbonStatusBar;
			this.ribbonControl.Toolbar.ShowCustomizeItem = false;
			this.ribbonControl.TransparentEditorsMode = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonControl.SelectedPageChanged += new global::System.EventHandler(this.RibbonSelectedPageChanged);
			resources.ApplyResources(this.miExit, "miExit");
			this.miExit.Id = 20;
			this.miExit.ImageOptions.ImageIndex = (int)resources.GetObject("miExit.ImageOptions.ImageIndex");
			this.miExit.ImageOptions.LargeImageIndex = (int)resources.GetObject("miExit.ImageOptions.LargeImageIndex");
			this.miExit.Name = "miExit";
			resources.ApplyResources(this.miHelp, "miHelp");
			this.miHelp.Id = 24;
			this.miHelp.ImageOptions.ImageIndex = (int)resources.GetObject("miHelp.ImageOptions.ImageIndex");
			this.miHelp.ImageOptions.LargeImageIndex = (int)resources.GetObject("miHelp.ImageOptions.LargeImageIndex");
			this.miHelp.Name = "miHelp";
			resources.ApplyResources(this.miCreateDevicesGroup, "miCreateDevicesGroup");
			this.miCreateDevicesGroup.Id = 62;
			this.miCreateDevicesGroup.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_devicegroup_add_16x16;
			this.miCreateDevicesGroup.ImageOptions.ImageIndex = (int)resources.GetObject("miCreateDevicesGroup.ImageOptions.ImageIndex");
			this.miCreateDevicesGroup.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_devicegroup_add_32x32;
			this.miCreateDevicesGroup.ImageOptions.LargeImageIndex = (int)resources.GetObject("miCreateDevicesGroup.ImageOptions.LargeImageIndex");
			this.miCreateDevicesGroup.Name = "miCreateDevicesGroup";
			this.miCreateDevicesGroup.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCreateDevicesGroup_ItemClick);
			resources.ApplyResources(this.miEditDevicesGroup, "miEditDevicesGroup");
			this.miEditDevicesGroup.Id = 64;
			this.miEditDevicesGroup.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.edit_16x16;
			this.miEditDevicesGroup.ImageOptions.ImageIndex = (int)resources.GetObject("miEditDevicesGroup.ImageOptions.ImageIndex");
			this.miEditDevicesGroup.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.edit_32x32;
			this.miEditDevicesGroup.ImageOptions.LargeImageIndex = (int)resources.GetObject("miEditDevicesGroup.ImageOptions.LargeImageIndex");
			this.miEditDevicesGroup.Name = "miEditDevicesGroup";
			this.miEditDevicesGroup.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miDeviceEdit_ItemClick);
			resources.ApplyResources(this.miDeleteDevicesGroup, "miDeleteDevicesGroup");
			this.miDeleteDevicesGroup.Id = 65;
			this.miDeleteDevicesGroup.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.delete_16x16;
			this.miDeleteDevicesGroup.ImageOptions.ImageIndex = (int)resources.GetObject("miDeleteDevicesGroup.ImageOptions.ImageIndex");
			this.miDeleteDevicesGroup.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.delete_32x32;
			this.miDeleteDevicesGroup.ImageOptions.LargeImageIndex = (int)resources.GetObject("miDeleteDevicesGroup.ImageOptions.LargeImageIndex");
			this.miDeleteDevicesGroup.Name = "miDeleteDevicesGroup";
			this.miDeleteDevicesGroup.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miDeleteDevicesGroup_ItemClick);
			resources.ApplyResources(this.miUrlCategories, "miUrlCategories");
			this.miUrlCategories.Id = 66;
			this.miUrlCategories.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_webcategory_16x16;
			this.miUrlCategories.ImageOptions.ImageIndex = (int)resources.GetObject("miUrlCategories.ImageOptions.ImageIndex");
			this.miUrlCategories.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_webcategory_32x32;
			this.miUrlCategories.ImageOptions.LargeImageIndex = (int)resources.GetObject("miUrlCategories.ImageOptions.LargeImageIndex");
			this.miUrlCategories.Name = "miUrlCategories";
			this.miUrlCategories.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miUrlCategories_ItemClick);
			this.miConfigDevicesInfoView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miConfigDevicesInfoView, "miConfigDevicesInfoView");
			this.miConfigDevicesInfoView.Down = true;
			this.miConfigDevicesInfoView.GroupIndex = 5;
			this.miConfigDevicesInfoView.Id = 67;
			this.miConfigDevicesInfoView.ImageOptions.ImageIndex = (int)resources.GetObject("miConfigDevicesInfoView.ImageOptions.ImageIndex");
			this.miConfigDevicesInfoView.ImageOptions.LargeImageIndex = (int)resources.GetObject("miConfigDevicesInfoView.ImageOptions.LargeImageIndex");
			this.miConfigDevicesInfoView.Name = "miConfigDevicesInfoView";
			this.miConfigDevicesInfoView.Visibility = global::DevExpress.XtraBars.BarItemVisibility.Never;
			this.miConfigDevicesInfoView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			this.miConfigLogView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miConfigLogView, "miConfigLogView");
			this.miConfigLogView.GroupIndex = 5;
			this.miConfigLogView.Id = 68;
			this.miConfigLogView.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.view_diagnostic_16x16;
			this.miConfigLogView.ImageOptions.ImageIndex = (int)resources.GetObject("miConfigLogView.ImageOptions.ImageIndex");
			this.miConfigLogView.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.view_diagnostic_32x32;
			this.miConfigLogView.ImageOptions.LargeImageIndex = (int)resources.GetObject("miConfigLogView.ImageOptions.LargeImageIndex");
			this.miConfigLogView.Name = "miConfigLogView";
			this.miConfigLogView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			this.miScreenshotsView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miScreenshotsView, "miScreenshotsView");
			this.miScreenshotsView.Down = true;
			this.miScreenshotsView.GroupIndex = 3;
			this.miScreenshotsView.Id = 76;
			this.miScreenshotsView.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.view_screenshot_16x16;
			this.miScreenshotsView.ImageOptions.ImageIndex = (int)resources.GetObject("miScreenshotsView.ImageOptions.ImageIndex");
			this.miScreenshotsView.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.view_screenshot_32x32;
			this.miScreenshotsView.ImageOptions.LargeImageIndex = (int)resources.GetObject("miScreenshotsView.ImageOptions.LargeImageIndex");
			this.miScreenshotsView.Name = "miScreenshotsView";
			this.miScreenshotsView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			this.miHistoryView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miHistoryView, "miHistoryView");
			this.miHistoryView.GroupIndex = 3;
			this.miHistoryView.Id = 77;
			this.miHistoryView.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.view_historylog_16x16;
			this.miHistoryView.ImageOptions.ImageIndex = (int)resources.GetObject("miHistoryView.ImageOptions.ImageIndex");
			this.miHistoryView.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.view_historylog_32x32;
			this.miHistoryView.ImageOptions.LargeImageIndex = (int)resources.GetObject("miHistoryView.ImageOptions.LargeImageIndex");
			this.miHistoryView.Name = "miHistoryView";
			this.miHistoryView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			resources.ApplyResources(this.miSetDeviceLockDisabled, "miSetDeviceLockDisabled");
			this.miSetDeviceLockDisabled.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miSetDeviceLockDisabled.Id = 78;
			this.miSetDeviceLockDisabled.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.computer_access_all_16x16;
			this.miSetDeviceLockDisabled.ImageOptions.ImageIndex = (int)resources.GetObject("miSetDeviceLockDisabled.ImageOptions.ImageIndex");
			this.miSetDeviceLockDisabled.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.computer_access_all_32x32;
			this.miSetDeviceLockDisabled.ImageOptions.LargeImageIndex = (int)resources.GetObject("miSetDeviceLockDisabled.ImageOptions.LargeImageIndex");
			this.miSetDeviceLockDisabled.Name = "miSetDeviceLockDisabled";
			this.miSetDeviceLockDisabled.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miSetDeviceLockKeyboard, "miSetDeviceLockKeyboard");
			this.miSetDeviceLockKeyboard.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miSetDeviceLockKeyboard.Id = 79;
			this.miSetDeviceLockKeyboard.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.computer_access_deny_key_16x16;
			this.miSetDeviceLockKeyboard.ImageOptions.ImageIndex = (int)resources.GetObject("miSetDeviceLockKeyboard.ImageOptions.ImageIndex");
			this.miSetDeviceLockKeyboard.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.computer_access_deny_key_32x32;
			this.miSetDeviceLockKeyboard.ImageOptions.LargeImageIndex = (int)resources.GetObject("miSetDeviceLockKeyboard.ImageOptions.LargeImageIndex");
			this.miSetDeviceLockKeyboard.Name = "miSetDeviceLockKeyboard";
			this.miSetDeviceLockKeyboard.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miSetDeviceLockMouseKeyboardMonitor, "miSetDeviceLockMouseKeyboardMonitor");
			this.miSetDeviceLockMouseKeyboardMonitor.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miSetDeviceLockMouseKeyboardMonitor.Id = 80;
			this.miSetDeviceLockMouseKeyboardMonitor.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.computer_access_deny_all_16x16;
			this.miSetDeviceLockMouseKeyboardMonitor.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.computer_access_deny_all_32x32;
			this.miSetDeviceLockMouseKeyboardMonitor.Name = "miSetDeviceLockMouseKeyboardMonitor";
			this.miSetDeviceLockMouseKeyboardMonitor.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.miShowMessagesDef.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.miShowMessagesDef, "miShowMessagesDef");
			this.miShowMessagesDef.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miShowMessagesDef.DropDownControl = this.popupMenuFavoriteMessages;
			this.miShowMessagesDef.Id = 81;
			this.miShowMessagesDef.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.newcomment_16x16;
			this.miShowMessagesDef.ImageOptions.ImageIndex = (int)resources.GetObject("miShowMessagesDef.ImageOptions.ImageIndex");
			this.miShowMessagesDef.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.newcomment_32x32;
			this.miShowMessagesDef.ImageOptions.LargeImageIndex = (int)resources.GetObject("miShowMessagesDef.ImageOptions.LargeImageIndex");
			this.miShowMessagesDef.Name = "miShowMessagesDef";
			this.miShowMessagesDef.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.popupMenuFavoriteMessages.Name = "popupMenuFavoriteMessages";
			this.popupMenuFavoriteMessages.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.miRpcSystemShutdown, "miRpcSystemShutdown");
			this.miRpcSystemShutdown.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miRpcSystemShutdown.Id = 82;
			this.miRpcSystemShutdown.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.windows_shutdown_16x16;
			this.miRpcSystemShutdown.ImageOptions.ImageIndex = (int)resources.GetObject("miRpcSystemShutdown.ImageOptions.ImageIndex");
			this.miRpcSystemShutdown.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.windows_shutdown_32x32;
			this.miRpcSystemShutdown.ImageOptions.LargeImageIndex = (int)resources.GetObject("miRpcSystemShutdown.ImageOptions.LargeImageIndex");
			this.miRpcSystemShutdown.Name = "miRpcSystemShutdown";
			this.miRpcSystemShutdown.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miRpcSystemReboot, "miRpcSystemReboot");
			this.miRpcSystemReboot.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miRpcSystemReboot.Id = 83;
			this.miRpcSystemReboot.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.windows_reboot_16x16;
			this.miRpcSystemReboot.ImageOptions.ImageIndex = (int)resources.GetObject("miRpcSystemReboot.ImageOptions.ImageIndex");
			this.miRpcSystemReboot.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.windows_reboot_32x32;
			this.miRpcSystemReboot.ImageOptions.LargeImageIndex = (int)resources.GetObject("miRpcSystemReboot.ImageOptions.LargeImageIndex");
			this.miRpcSystemReboot.Name = "miRpcSystemReboot";
			this.miRpcSystemReboot.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miRpcSessionLogoff, "miRpcSessionLogoff");
			this.miRpcSessionLogoff.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miRpcSessionLogoff.Id = 84;
			this.miRpcSessionLogoff.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.session_logout_16x16;
			this.miRpcSessionLogoff.ImageOptions.ImageIndex = (int)resources.GetObject("miRpcSessionLogoff.ImageOptions.ImageIndex");
			this.miRpcSessionLogoff.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.session_logout_32x32;
			this.miRpcSessionLogoff.ImageOptions.LargeImageIndex = (int)resources.GetObject("miRpcSessionLogoff.ImageOptions.LargeImageIndex");
			this.miRpcSessionLogoff.Name = "miRpcSessionLogoff";
			this.miRpcSessionLogoff.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miRpcWakeOnLan, "miRpcWakeOnLan");
			this.miRpcWakeOnLan.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miRpcWakeOnLan.Id = 85;
			this.miRpcWakeOnLan.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.windows_wakeon_16x16;
			this.miRpcWakeOnLan.ImageOptions.ImageIndex = (int)resources.GetObject("miRpcWakeOnLan.ImageOptions.ImageIndex");
			this.miRpcWakeOnLan.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.windows_wakeon_32x32;
			this.miRpcWakeOnLan.ImageOptions.LargeImageIndex = (int)resources.GetObject("miRpcWakeOnLan.ImageOptions.LargeImageIndex");
			this.miRpcWakeOnLan.Name = "miRpcWakeOnLan";
			this.miRpcWakeOnLan.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.miShowRemoteDesktop.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.miShowRemoteDesktop, "miShowRemoteDesktop");
			this.miShowRemoteDesktop.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miShowRemoteDesktop.DropDownControl = this.popupMenuRemoteDesktop;
			this.miShowRemoteDesktop.Id = 87;
			this.miShowRemoteDesktop.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.remotedesktop_16x16;
			this.miShowRemoteDesktop.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.remotedesktop_32x32;
			this.miShowRemoteDesktop.Name = "miShowRemoteDesktop";
			this.miShowRemoteDesktop.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.popupMenuRemoteDesktop.ItemLinks.Add(this.miStartVNC);
			this.popupMenuRemoteDesktop.ItemLinks.Add(this.miStartRDP);
			this.popupMenuRemoteDesktop.Name = "popupMenuRemoteDesktop";
			this.popupMenuRemoteDesktop.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.miStartVNC, "miStartVNC");
			this.miStartVNC.Id = 264;
			this.miStartVNC.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.remotedesktop_16x16;
			this.miStartVNC.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.remotedesktop_32x32;
			this.miStartVNC.Name = "miStartVNC";
			this.miStartVNC.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miStartRDP, "miStartRDP");
			this.miStartRDP.Id = 265;
			this.miStartRDP.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.windowsrdp_16x16;
			this.miStartRDP.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.windowsrdp_32x32;
			this.miStartRDP.Name = "miStartRDP";
			this.miStartRDP.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miShowFileManager, "miShowFileManager");
			this.miShowFileManager.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miShowFileManager.Id = 91;
			this.miShowFileManager.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.up_16x16;
			this.miShowFileManager.ImageOptions.ImageIndex = (int)resources.GetObject("miShowFileManager.ImageOptions.ImageIndex");
			this.miShowFileManager.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.up_32x32;
			this.miShowFileManager.ImageOptions.LargeImageIndex = (int)resources.GetObject("miShowFileManager.ImageOptions.LargeImageIndex");
			this.miShowFileManager.Name = "miShowFileManager";
			this.miShowFileManager.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miRoles, "miRoles");
			this.miRoles.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miRoles.Id = 93;
			this.miRoles.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_roles_16x16;
			this.miRoles.ImageOptions.ImageIndex = (int)resources.GetObject("miRoles.ImageOptions.ImageIndex");
			this.miRoles.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_roles_32x32;
			this.miRoles.ImageOptions.LargeImageIndex = (int)resources.GetObject("miRoles.ImageOptions.LargeImageIndex");
			this.miRoles.Name = "miRoles";
			this.miRoles.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miRoles_ItemClick);
			resources.ApplyResources(this.miShowUpdateAgents, "miShowUpdateAgents");
			this.miShowUpdateAgents.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miShowUpdateAgents.Id = 94;
			this.miShowUpdateAgents.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_update_agents_16x16;
			this.miShowUpdateAgents.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_update_agents_32x32;
			this.miShowUpdateAgents.Name = "miShowUpdateAgents";
			this.miShowUpdateAgents.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miRpcSessionLogon, "miRpcSessionLogon");
			this.miRpcSessionLogon.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miRpcSessionLogon.Id = 95;
			this.miRpcSessionLogon.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.session_logon_16x16;
			this.miRpcSessionLogon.ImageOptions.ImageIndex = (int)resources.GetObject("miRpcSessionLogon.ImageOptions.ImageIndex");
			this.miRpcSessionLogon.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.session_logon_32x32;
			this.miRpcSessionLogon.ImageOptions.LargeImageIndex = (int)resources.GetObject("miRpcSessionLogon.ImageOptions.LargeImageIndex");
			this.miRpcSessionLogon.Name = "miRpcSessionLogon";
			this.miRpcSessionLogon.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miMoveDeviceToGroup, "miMoveDeviceToGroup");
			this.miMoveDeviceToGroup.Id = 96;
			this.miMoveDeviceToGroup.ImageOptions.ImageIndex = (int)resources.GetObject("miMoveDeviceToGroup.ImageOptions.ImageIndex");
			this.miMoveDeviceToGroup.ImageOptions.LargeImageIndex = (int)resources.GetObject("miMoveDeviceToGroup.ImageOptions.LargeImageIndex");
			this.miMoveDeviceToGroup.Name = "miMoveDeviceToGroup";
			resources.ApplyResources(this.miDefaultFonts, "miDefaultFonts");
			this.miDefaultFonts.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miDefaultFonts.Id = 97;
			this.miDefaultFonts.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("miDefaultFonts.ImageOptions.Image");
			this.miDefaultFonts.ImageOptions.ImageIndex = (int)resources.GetObject("miDefaultFonts.ImageOptions.ImageIndex");
			this.miDefaultFonts.ImageOptions.LargeImage = (global::System.Drawing.Image)resources.GetObject("miDefaultFonts.ImageOptions.LargeImage");
			this.miDefaultFonts.ImageOptions.LargeImageIndex = (int)resources.GetObject("miDefaultFonts.ImageOptions.LargeImageIndex");
			this.miDefaultFonts.Name = "miDefaultFonts";
			this.miDefaultFonts.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miDefaultFonts_ItemClick);
			resources.ApplyResources(this.miIsIdle, "miIsIdle");
			this.miIsIdle.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miIsIdle.Id = 98;
			this.miIsIdle.ImageOptions.ImageIndex = (int)resources.GetObject("miIsIdle.ImageOptions.ImageIndex");
			this.miIsIdle.ImageOptions.LargeImageIndex = (int)resources.GetObject("miIsIdle.ImageOptions.LargeImageIndex");
			this.miIsIdle.Name = "miIsIdle";
			this.miIsIdle.Visibility = global::DevExpress.XtraBars.BarItemVisibility.Never;
			resources.ApplyResources(this.miShowDistributeFiles, "miShowDistributeFiles");
			this.miShowDistributeFiles.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miShowDistributeFiles.Id = 99;
			this.miShowDistributeFiles.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.distributefiles_16x16;
			this.miShowDistributeFiles.ImageOptions.ImageIndex = (int)resources.GetObject("miShowDistributeFiles.ImageOptions.ImageIndex");
			this.miShowDistributeFiles.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.distributefiles_32x32;
			this.miShowDistributeFiles.ImageOptions.LargeImageIndex = (int)resources.GetObject("miShowDistributeFiles.ImageOptions.LargeImageIndex");
			this.miShowDistributeFiles.Name = "miShowDistributeFiles";
			this.miShowDistributeFiles.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miSelectedDeviceInfo, "miSelectedDeviceInfo");
			this.miSelectedDeviceInfo.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.miSelectedDeviceInfo.Id = 100;
			this.miSelectedDeviceInfo.ImageOptions.ImageIndex = (int)resources.GetObject("miSelectedDeviceInfo.ImageOptions.ImageIndex");
			this.miSelectedDeviceInfo.ImageOptions.LargeImageIndex = (int)resources.GetObject("miSelectedDeviceInfo.ImageOptions.LargeImageIndex");
			this.miSelectedDeviceInfo.Name = "miSelectedDeviceInfo";
			this.miSelectedDeviceInfo.PaintStyle = global::DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
			resources.ApplyResources(this.skinRibbonGallery, "skinRibbonGallery");
			this.skinRibbonGallery.Gallery.AllowHoverImages = true;
			this.skinRibbonGallery.Gallery.ColumnCount = 4;
			this.skinRibbonGallery.Gallery.FixedHoverImageSize = false;
			this.skinRibbonGallery.Gallery.ImageSize = new global::System.Drawing.Size(16, 16);
			this.skinRibbonGallery.Gallery.ItemCheckMode = global::DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
			this.skinRibbonGallery.Gallery.ItemImageLayout = global::DevExpress.Utils.Drawing.ImageLayoutMode.Squeeze;
			this.skinRibbonGallery.Gallery.ItemImageLocation = global::DevExpress.Utils.Locations.Top;
			skinPaddingEdges.Left = 8;
			skinPaddingEdges.Right = 8;
			this.skinRibbonGallery.Gallery.ItemImagePadding = skinPaddingEdges;
			this.skinRibbonGallery.Gallery.ScaleImages = global::DevExpress.Utils.DefaultBoolean.False;
			this.skinRibbonGallery.Id = 102;
			this.skinRibbonGallery.ImageOptions.ImageIndex = (int)resources.GetObject("skinRibbonGallery.ImageOptions.ImageIndex");
			this.skinRibbonGallery.ImageOptions.LargeImageIndex = (int)resources.GetObject("skinRibbonGallery.ImageOptions.LargeImageIndex");
			this.skinRibbonGallery.ImageOptions.SvgImage = (global::DevExpress.Utils.Svg.SvgImage)resources.GetObject("skinRibbonGallery.ImageOptions.SvgImage");
			this.skinRibbonGallery.Name = "skinRibbonGallery";
			this.miPackagesView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miPackagesView, "miPackagesView");
			this.miPackagesView.GroupIndex = 4;
			this.miPackagesView.Id = 104;
			this.miPackagesView.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.chocolatey;
			this.miPackagesView.ImageOptions.ImageIndex = (int)resources.GetObject("miPackagesView.ImageOptions.ImageIndex");
			this.miPackagesView.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.chocolatey;
			this.miPackagesView.ImageOptions.LargeImageIndex = (int)resources.GetObject("miPackagesView.ImageOptions.LargeImageIndex");
			this.miPackagesView.Name = "miPackagesView";
			this.miPackagesView.Visibility = global::DevExpress.XtraBars.BarItemVisibility.Never;
			this.miPackagesView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			this.miProcessesView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miProcessesView, "miProcessesView");
			this.miProcessesView.Down = true;
			this.miProcessesView.GroupIndex = 4;
			this.miProcessesView.Id = 105;
			this.miProcessesView.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.process_hacker;
			this.miProcessesView.ImageOptions.ImageIndex = (int)resources.GetObject("miProcessesView.ImageOptions.ImageIndex");
			this.miProcessesView.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.process_hacker;
			this.miProcessesView.ImageOptions.LargeImageIndex = (int)resources.GetObject("miProcessesView.ImageOptions.LargeImageIndex");
			this.miProcessesView.Name = "miProcessesView";
			this.miProcessesView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			this.miChangePassword.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.miChangePassword, "miChangePassword");
			this.miChangePassword.DropDownControl = this.popupMenuPassword;
			this.miChangePassword.Id = 114;
			this.miChangePassword.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_password_change_16x16;
			this.miChangePassword.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_password_change_32x32;
			this.miChangePassword.Name = "miChangePassword";
			this.miChangePassword.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miChangePassword_ItemClick);
			this.popupMenuPassword.ItemLinks.Add(this.miCreateAppToken);
			this.popupMenuPassword.Name = "popupMenuPassword";
			this.popupMenuPassword.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.miCreateAppToken, "miCreateAppToken");
			this.miCreateAppToken.Id = 159;
			this.miCreateAppToken.ImageOptions.ImageIndex = (int)resources.GetObject("miCreateAppToken.ImageOptions.ImageIndex");
			this.miCreateAppToken.ImageOptions.LargeImageIndex = (int)resources.GetObject("miCreateAppToken.ImageOptions.LargeImageIndex");
			this.miCreateAppToken.Name = "miCreateAppToken";
			this.miCreateAppToken.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCreateAppToken_ItemClick);
			resources.ApplyResources(this.miMoveDevice, "miMoveDevice");
			this.miMoveDevice.Id = 117;
			this.miMoveDevice.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_device_move_16x16;
			this.miMoveDevice.ImageOptions.ImageIndex = (int)resources.GetObject("miMoveDevice.ImageOptions.ImageIndex");
			this.miMoveDevice.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_device_move_32x32;
			this.miMoveDevice.ImageOptions.LargeImageIndex = (int)resources.GetObject("miMoveDevice.ImageOptions.LargeImageIndex");
			this.miMoveDevice.Name = "miMoveDevice";
			this.miMoveDevice.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miMoveDevice_ItemClick);
			resources.ApplyResources(this.barStaticItemServerConnection, "barStaticItemServerConnection");
			this.barStaticItemServerConnection.Id = 133;
			this.barStaticItemServerConnection.ImageOptions.DisabledImage = (global::System.Drawing.Image)resources.GetObject("barStaticItemServerConnection.ImageOptions.DisabledImage");
			this.barStaticItemServerConnection.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.hyperlink_16x16;
			this.barStaticItemServerConnection.ImageOptions.ImageIndex = (int)resources.GetObject("barStaticItemServerConnection.ImageOptions.ImageIndex");
			this.barStaticItemServerConnection.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.hyperlink_32x32;
			this.barStaticItemServerConnection.ImageOptions.LargeImageIndex = (int)resources.GetObject("barStaticItemServerConnection.ImageOptions.LargeImageIndex");
			this.barStaticItemServerConnection.Name = "barStaticItemServerConnection";
			this.barStaticItemServerConnection.PaintStyle = global::DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
			resources.ApplyResources(this.barCheckDiagnosticWnd, "barCheckDiagnosticWnd");
			this.barCheckDiagnosticWnd.Id = 141;
			this.barCheckDiagnosticWnd.ImageOptions.ImageIndex = (int)resources.GetObject("barCheckDiagnosticWnd.ImageOptions.ImageIndex");
			this.barCheckDiagnosticWnd.ImageOptions.LargeImageIndex = (int)resources.GetObject("barCheckDiagnosticWnd.ImageOptions.LargeImageIndex");
			this.barCheckDiagnosticWnd.Name = "barCheckDiagnosticWnd";
			this.barCheckDiagnosticWnd.CheckedChanged += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barCheckDiagnosticWnd_CheckedChanged);
			resources.ApplyResources(this.barStaticSelectionInfo, "barStaticSelectionInfo");
			this.barStaticSelectionInfo.Id = 164;
			this.barStaticSelectionInfo.ImageOptions.ImageIndex = (int)resources.GetObject("barStaticSelectionInfo.ImageOptions.ImageIndex");
			this.barStaticSelectionInfo.ImageOptions.LargeImageIndex = (int)resources.GetObject("barStaticSelectionInfo.ImageOptions.LargeImageIndex");
			this.barStaticSelectionInfo.Name = "barStaticSelectionInfo";
			this.barStaticSelectionInfo.PaintStyle = global::DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
			this.barStaticSelectionInfo.ItemDoubleClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barStaticSelectionInfo_ItemDoubleClick);
			resources.ApplyResources(this.miCheckAppUpdates, "miCheckAppUpdates");
			this.miCheckAppUpdates.Id = 173;
			this.miCheckAppUpdates.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_update_console_16x16;
			this.miCheckAppUpdates.ImageOptions.ImageIndex = (int)resources.GetObject("miCheckAppUpdates.ImageOptions.ImageIndex");
			this.miCheckAppUpdates.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_update_console_32x32;
			this.miCheckAppUpdates.ImageOptions.LargeImageIndex = (int)resources.GetObject("miCheckAppUpdates.ImageOptions.LargeImageIndex");
			this.miCheckAppUpdates.Name = "miCheckAppUpdates";
			this.miCheckAppUpdates.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCheckAppUpdates_ItemClick);
			this.miShowProcessesDef.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.miShowProcessesDef, "miShowProcessesDef");
			this.miShowProcessesDef.DropDownControl = this.popupMenuFavoriteProcesses;
			this.miShowProcessesDef.Id = 186;
			this.miShowProcessesDef.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.media_16x16;
			this.miShowProcessesDef.ImageOptions.ImageIndex = (int)resources.GetObject("miShowProcessesDef.ImageOptions.ImageIndex");
			this.miShowProcessesDef.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.media_32x32;
			this.miShowProcessesDef.ImageOptions.LargeImageIndex = (int)resources.GetObject("miShowProcessesDef.ImageOptions.LargeImageIndex");
			this.miShowProcessesDef.Name = "miShowProcessesDef";
			this.miShowProcessesDef.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.popupMenuFavoriteProcesses.Name = "popupMenuFavoriteProcesses";
			this.popupMenuFavoriteProcesses.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.miRules, "miRules");
			this.miRules.Id = 201;
			this.miRules.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_rules_16x16;
			this.miRules.ImageOptions.ImageIndex = (int)resources.GetObject("miRules.ImageOptions.ImageIndex");
			this.miRules.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_rules_32x32;
			this.miRules.ImageOptions.LargeImageIndex = (int)resources.GetObject("miRules.ImageOptions.LargeImageIndex");
			this.miRules.Name = "miRules";
			this.miRules.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miRules_ItemClick);
			resources.ApplyResources(this.miDesktops, "miDesktops");
			this.miDesktops.Id = 216;
			this.miDesktops.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_desktops_16x16;
			this.miDesktops.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_desktops_32x32;
			this.miDesktops.Name = "miDesktops";
			this.miDesktops.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miDesktops_ItemClick);
			resources.ApplyResources(this.miSetDeviceAppAllow, "miSetDeviceAppAllow");
			this.miSetDeviceAppAllow.Id = 219;
			this.miSetDeviceAppAllow.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.app_access_allow_16x16;
			this.miSetDeviceAppAllow.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.app_access_allow_32x32;
			this.miSetDeviceAppAllow.Name = "miSetDeviceAppAllow";
			this.miSetDeviceAppAllow.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.miSetDeviceAppStrictToDesktop.ActAsDropDown = true;
			this.miSetDeviceAppStrictToDesktop.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.miSetDeviceAppStrictToDesktop, "miSetDeviceAppStrictToDesktop");
			this.miSetDeviceAppStrictToDesktop.DropDownControl = this.popupMenuDesktops;
			this.miSetDeviceAppStrictToDesktop.Id = 220;
			this.miSetDeviceAppStrictToDesktop.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.app_access_strict_16x16;
			this.miSetDeviceAppStrictToDesktop.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.app_access_strict_32x32;
			this.miSetDeviceAppStrictToDesktop.Name = "miSetDeviceAppStrictToDesktop";
			this.popupMenuDesktops.Name = "popupMenuDesktops";
			this.popupMenuDesktops.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.miShowCollectFiles, "miShowCollectFiles");
			this.miShowCollectFiles.Id = 224;
			this.miShowCollectFiles.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.collectfiles_16x16;
			this.miShowCollectFiles.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.collectfiles_32x32;
			this.miShowCollectFiles.Name = "miShowCollectFiles";
			this.miShowCollectFiles.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.miAppHistoryView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miAppHistoryView, "miAppHistoryView");
			this.miAppHistoryView.GroupIndex = 3;
			this.miAppHistoryView.Id = 235;
			this.miAppHistoryView.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.view_apphistory_16x16;
			this.miAppHistoryView.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.view_apphistory_32x32;
			this.miAppHistoryView.Name = "miAppHistoryView";
			this.miAppHistoryView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			resources.ApplyResources(this.miRpcSessionLock, "miRpcSessionLock");
			this.miRpcSessionLock.Id = 246;
			this.miRpcSessionLock.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.session_lock_16x16;
			this.miRpcSessionLock.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.session_lock_32x32;
			this.miRpcSessionLock.Name = "miRpcSessionLock";
			this.miRpcSessionLock.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.miServicesView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			resources.ApplyResources(this.miServicesView, "miServicesView");
			this.miServicesView.GroupIndex = 4;
			this.miServicesView.Id = 259;
			this.miServicesView.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.technology_16x16;
			this.miServicesView.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.technology_32x32;
			this.miServicesView.Name = "miServicesView";
			this.miServicesView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			resources.ApplyResources(this.miCustomerInfo, "miCustomerInfo");
			this.miCustomerInfo.Id = 272;
			this.miCustomerInfo.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_license_16x16;
			this.miCustomerInfo.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_license_32x32;
			this.miCustomerInfo.Name = "miCustomerInfo";
			this.miCustomerInfo.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCustomerInfo_ItemClick);
			resources.ApplyResources(this.miAppCategories, "miAppCategories");
			this.miAppCategories.Id = 293;
			this.miAppCategories.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_appcategory_16x16;
			this.miAppCategories.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.settings_appcategory_32x32;
			this.miAppCategories.Name = "miAppCategories";
			this.miAppCategories.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miAppCategories_ItemClick);
			resources.ApplyResources(this.miSetDeviceAppBlock, "miSetDeviceAppBlock");
			this.miSetDeviceAppBlock.Id = 297;
			this.miSetDeviceAppBlock.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.app_access_blocked_16x16;
			this.miSetDeviceAppBlock.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.app_access_blocked_32x32;
			this.miSetDeviceAppBlock.Name = "miSetDeviceAppBlock";
			this.miSetDeviceAppBlock.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			this.miSetDeviceAppCheck.ActAsDropDown = true;
			this.miSetDeviceAppCheck.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.miSetDeviceAppCheck, "miSetDeviceAppCheck");
			this.miSetDeviceAppCheck.DropDownControl = this.popupMenuDeviceAppCheck;
			this.miSetDeviceAppCheck.Id = 302;
			this.miSetDeviceAppCheck.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.app_access_check_16x16;
			this.miSetDeviceAppCheck.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.app_access_check_32x32;
			this.miSetDeviceAppCheck.Name = "miSetDeviceAppCheck";
			this.popupMenuDeviceAppCheck.ItemLinks.Add(this.miDeviceAppCheck);
			this.popupMenuDeviceAppCheck.ItemLinks.Add(this.miDeviceAppCheckUseWhiteList, true);
			this.popupMenuDeviceAppCheck.ItemLinks.Add(this.miDeviceAppCheckUseBlackList);
			this.popupMenuDeviceAppCheck.MinWidth = 250;
			this.popupMenuDeviceAppCheck.Name = "popupMenuDeviceAppCheck";
			this.popupMenuDeviceAppCheck.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.miDeviceAppCheck, "miDeviceAppCheck");
			this.miDeviceAppCheck.Id = 312;
			this.miDeviceAppCheck.Name = "miDeviceAppCheck";
			this.miDeviceAppCheck.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.miCommandMenuItemClick);
			resources.ApplyResources(this.miDeviceAppCheckUseWhiteList, "miDeviceAppCheckUseWhiteList");
			this.miDeviceAppCheckUseWhiteList.Id = 318;
			this.miDeviceAppCheckUseWhiteList.Name = "miDeviceAppCheckUseWhiteList";
			resources.ApplyResources(this.miDeviceAppCheckUseBlackList, "miDeviceAppCheckUseBlackList");
			this.miDeviceAppCheckUseBlackList.Id = 317;
			this.miDeviceAppCheckUseBlackList.Name = "miDeviceAppCheckUseBlackList";
			this.pageGroupWelcome.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.pageExit
			});
			this.pageGroupWelcome.Name = "pageGroupWelcome";
			resources.ApplyResources(this.pageGroupWelcome, "pageGroupWelcome");
			this.pageGroupWelcome.Visible = false;
			this.pageExit.CaptionButtonVisible = global::DevExpress.Utils.DefaultBoolean.False;
			this.pageExit.ItemLinks.Add(this.miExit);
			this.pageExit.ItemLinks.Add(this.miHelp, true);
			this.pageExit.Name = "pageExit";
			this.pageGroupTools.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.pageTools
			});
			this.pageGroupTools.Name = "pageGroupTools";
			resources.ApplyResources(this.pageGroupTools, "pageGroupTools");
			this.pageTools.ItemLinks.Add(this.miShowRemoteDesktop);
			this.pageTools.ItemLinks.Add(this.miShowProcessesDef);
			this.pageTools.ItemLinks.Add(this.miShowMessagesDef);
			this.pageTools.ItemLinks.Add(this.miShowFileManager);
			this.pageTools.ItemLinks.Add(this.miShowDistributeFiles);
			this.pageTools.ItemLinks.Add(this.miShowCollectFiles);
			this.pageTools.ItemLinks.Add(this.miRpcWakeOnLan, true);
			this.pageTools.ItemLinks.Add(this.miRpcSystemShutdown);
			this.pageTools.ItemLinks.Add(this.miRpcSystemReboot);
			this.pageTools.ItemLinks.Add(this.miRpcSessionLogon, true);
			this.pageTools.ItemLinks.Add(this.miRpcSessionLogoff);
			this.pageTools.ItemLinks.Add(this.miRpcSessionLock);
			this.pageTools.Name = "pageTools";
			resources.ApplyResources(this.pageTools, "pageTools");
			this.pageGroupApplications.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.pageProcesses,
				this.pageAppViewSelect
			});
			this.pageGroupApplications.Name = "pageGroupApplications";
			resources.ApplyResources(this.pageGroupApplications, "pageGroupApplications");
			this.pageProcesses.ItemLinks.Add(this.miShowProcessesDef);
			this.pageProcesses.Name = "pageProcesses";
			resources.ApplyResources(this.pageProcesses, "pageProcesses");
			this.pageAppViewSelect.ItemLinks.Add(this.miProcessesView);
			this.pageAppViewSelect.ItemLinks.Add(this.miServicesView);
			this.pageAppViewSelect.ItemLinks.Add(this.miPackagesView);
			this.pageAppViewSelect.Name = "pageAppViewSelect";
			resources.ApplyResources(this.pageAppViewSelect, "pageAppViewSelect");
			this.pageGroupConfig.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.pageDevices,
				this.pageSettings,
				this.pageUpdates,
				this.ribbonPageOther,
				this.pageLookSettings,
				this.pageConfigViewSelect
			});
			this.pageGroupConfig.Name = "pageGroupConfig";
			resources.ApplyResources(this.pageGroupConfig, "pageGroupConfig");
			this.pageDevices.ItemLinks.Add(this.miCreateDevicesGroup);
			this.pageDevices.ItemLinks.Add(this.miDeleteDevicesGroup);
			this.pageDevices.ItemLinks.Add(this.miEditDevicesGroup);
			this.pageDevices.ItemLinks.Add(this.miMoveDevice);
			this.pageDevices.Name = "pageDevices";
			resources.ApplyResources(this.pageDevices, "pageDevices");
			this.pageSettings.ItemLinks.Add(this.miUrlCategories);
			this.pageSettings.ItemLinks.Add(this.miAppCategories);
			this.pageSettings.ItemLinks.Add(this.miDesktops);
			this.pageSettings.ItemLinks.Add(this.miRoles);
			this.pageSettings.ItemLinks.Add(this.miRules);
			this.pageSettings.Name = "pageSettings";
			resources.ApplyResources(this.pageSettings, "pageSettings");
			this.pageUpdates.ItemLinks.Add(this.miChangePassword);
			this.pageUpdates.ItemLinks.Add(this.miShowUpdateAgents);
			this.pageUpdates.ItemLinks.Add(this.miCheckAppUpdates);
			this.pageUpdates.Name = "pageUpdates";
			resources.ApplyResources(this.pageUpdates, "pageUpdates");
			this.ribbonPageOther.ItemLinks.Add(this.miCustomerInfo);
			this.ribbonPageOther.Name = "ribbonPageOther";
			resources.ApplyResources(this.ribbonPageOther, "ribbonPageOther");
			this.pageLookSettings.CaptionButtonVisible = global::DevExpress.Utils.DefaultBoolean.False;
			this.pageLookSettings.ItemLinks.Add(this.skinRibbonGallery);
			this.pageLookSettings.ItemLinks.Add(this.miDefaultFonts);
			this.pageLookSettings.Name = "pageLookSettings";
			resources.ApplyResources(this.pageLookSettings, "pageLookSettings");
			this.pageConfigViewSelect.ItemLinks.Add(this.miConfigDevicesInfoView);
			this.pageConfigViewSelect.ItemLinks.Add(this.miConfigLogView);
			this.pageConfigViewSelect.Name = "pageConfigViewSelect";
			resources.ApplyResources(this.pageConfigViewSelect, "pageConfigViewSelect");
			this.pageGroupHelp.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.pageHelp
			});
			this.pageGroupHelp.Name = "pageGroupHelp";
			resources.ApplyResources(this.pageGroupHelp, "pageGroupHelp");
			this.pageGroupHelp.Visible = false;
			this.pageHelp.ItemLinks.Add(this.miHelp);
			this.pageHelp.Name = "pageHelp";
			resources.ApplyResources(this.pageHelp, "pageHelp");
			this.ribbonStatusBar.ItemLinks.Add(this.barStaticItemServerConnection);
			this.ribbonStatusBar.ItemLinks.Add(this.miIsIdle, true);
			this.ribbonStatusBar.ItemLinks.Add(this.barStaticSelectionInfo, true);
			this.ribbonStatusBar.ItemLinks.Add(this.barCheckDiagnosticWnd, true);
			resources.ApplyResources(this.ribbonStatusBar, "ribbonStatusBar");
			this.ribbonStatusBar.Name = "ribbonStatusBar";
			this.ribbonStatusBar.Ribbon = this.ribbonControl;
			this.pageAppAccess.AllowTextClipping = false;
			this.pageAppAccess.ItemLinks.Add(this.miSetDeviceAppAllow);
			this.pageAppAccess.ItemLinks.Add(this.miSetDeviceAppCheck);
			this.pageAppAccess.ItemLinks.Add(this.miSetDeviceAppBlock);
			this.pageAppAccess.ItemLinks.Add(this.miSetDeviceAppStrictToDesktop);
			this.pageAppAccess.Name = "pageAppAccess";
			resources.ApplyResources(this.pageAppAccess, "pageAppAccess");
			this.pageDeviceLock.CaptionButtonVisible = global::DevExpress.Utils.DefaultBoolean.False;
			this.pageDeviceLock.ItemLinks.Add(this.miSetDeviceLockDisabled);
			this.pageDeviceLock.ItemLinks.Add(this.miSetDeviceLockKeyboard);
			this.pageDeviceLock.ItemLinks.Add(this.miSetDeviceLockMouseKeyboardMonitor);
			this.pageDeviceLock.Name = "pageDeviceLock";
			resources.ApplyResources(this.pageDeviceLock, "pageDeviceLock");
			this.pageControlViewSelect.ItemLinks.Add(this.miScreenshotsView);
			this.pageControlViewSelect.ItemLinks.Add(this.miHistoryView);
			this.pageControlViewSelect.ItemLinks.Add(this.miAppHistoryView);
			this.pageControlViewSelect.Name = "pageControlViewSelect";
			resources.ApplyResources(this.pageControlViewSelect, "pageControlViewSelect");
			this.splitterDiagnosticWnd.CollapsePanel = global::DevExpress.XtraEditors.SplitCollapsePanel.Panel2;
			resources.ApplyResources(this.splitterDiagnosticWnd, "splitterDiagnosticWnd");
			this.splitterDiagnosticWnd.FixedPanel = global::DevExpress.XtraEditors.SplitFixedPanel.Panel2;
			this.splitterDiagnosticWnd.Horizontal = false;
			this.splitterDiagnosticWnd.Name = "splitterDiagnosticWnd";
			this.splitterDiagnosticWnd.Panel2.Controls.Add(this.gridDiagnostic);
			this.splitterDiagnosticWnd.SplitterPosition = 392;
			resources.ApplyResources(this.gridDiagnostic, "gridDiagnostic");
			this.gridDiagnostic.EmbeddedNavigator.AllowHtmlTextInToolTip = (global::DevExpress.Utils.DefaultBoolean)resources.GetObject("gridDiagnostic.EmbeddedNavigator.AllowHtmlTextInToolTip");
			this.gridDiagnostic.EmbeddedNavigator.Anchor = (global::System.Windows.Forms.AnchorStyles)resources.GetObject("gridDiagnostic.EmbeddedNavigator.Anchor");
			this.gridDiagnostic.EmbeddedNavigator.BackgroundImageLayout = (global::System.Windows.Forms.ImageLayout)resources.GetObject("gridDiagnostic.EmbeddedNavigator.BackgroundImageLayout");
			this.gridDiagnostic.EmbeddedNavigator.ImeMode = (global::System.Windows.Forms.ImeMode)resources.GetObject("gridDiagnostic.EmbeddedNavigator.ImeMode");
			this.gridDiagnostic.EmbeddedNavigator.Margin = (global::System.Windows.Forms.Padding)resources.GetObject("gridDiagnostic.EmbeddedNavigator.Margin");
			this.gridDiagnostic.EmbeddedNavigator.TextLocation = (global::DevExpress.XtraEditors.NavigatorButtonsTextLocation)resources.GetObject("gridDiagnostic.EmbeddedNavigator.TextLocation");
			this.gridDiagnostic.EmbeddedNavigator.ToolTipIconType = (global::DevExpress.Utils.ToolTipIconType)resources.GetObject("gridDiagnostic.EmbeddedNavigator.ToolTipIconType");
			this.gridDiagnostic.MainView = this.gridViewDiagnostic;
			this.gridDiagnostic.Name = "gridDiagnostic";
			this.gridDiagnostic.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryImageComboDiagnosticSuccess,
				this.repositoryMemoDiagnosticMessage
			});
			this.gridDiagnostic.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewDiagnostic
			});
			this.gridViewDiagnostic.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridDiagnosticColumnDate,
				this.gridDiagnosticColumnSuccess,
				this.gridDiagnosticColumnOperation,
				this.gridDiagnosticColumnDeviceName,
				this.gridDiagnosticColumnMessage,
				this.gridDiagnosticColumnSessionNo
			});
			this.gridViewDiagnostic.DetailHeight = 546;
			this.gridViewDiagnostic.GridControl = this.gridDiagnostic;
			this.gridViewDiagnostic.Name = "gridViewDiagnostic";
			this.gridViewDiagnostic.OptionsBehavior.AllowAddRows = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridViewDiagnostic.OptionsBehavior.AllowDeleteRows = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridViewDiagnostic.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewDiagnostic.OptionsSelection.MultiSelect = true;
			this.gridViewDiagnostic.OptionsView.EnableAppearanceEvenRow = true;
			this.gridViewDiagnostic.OptionsView.RowAutoHeight = true;
			this.gridViewDiagnostic.OptionsView.ShowGroupPanel = false;
			this.gridViewDiagnostic.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridDiagnosticColumnDate, global::DevExpress.Data.ColumnSortOrder.Descending)
			});
			this.gridViewDiagnostic.CustomRowFilter += new global::DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridViewDiagnostic_CustomRowFilter);
			this.gridViewDiagnostic.RowCountChanged += new global::System.EventHandler(this.gridViewDiagnostic_RowCountChanged);
			this.gridDiagnosticColumnDate.AppearanceHeader.Options.UseTextOptions = true;
			this.gridDiagnosticColumnDate.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridDiagnosticColumnDate.AppearanceHeader.TextOptions.VAlignment = global::DevExpress.Utils.VertAlignment.Center;
			resources.ApplyResources(this.gridDiagnosticColumnDate, "gridDiagnosticColumnDate");
			this.gridDiagnosticColumnDate.DisplayFormat.FormatString = "yyyy-MM-dd HH:mm:ss";
			this.gridDiagnosticColumnDate.DisplayFormat.FormatType = global::DevExpress.Utils.FormatType.DateTime;
			this.gridDiagnosticColumnDate.FieldName = "DateTime";
			this.gridDiagnosticColumnDate.MinWidth = 31;
			this.gridDiagnosticColumnDate.Name = "gridDiagnosticColumnDate";
			this.gridDiagnosticColumnDate.OptionsColumn.AllowEdit = false;
			this.gridDiagnosticColumnDate.OptionsColumn.FixedWidth = true;
			this.gridDiagnosticColumnDate.OptionsColumn.ReadOnly = true;
			this.gridDiagnosticColumnDate.UnboundType = global::DevExpress.Data.UnboundColumnType.DateTime;
			this.gridDiagnosticColumnSuccess.AppearanceHeader.Options.UseTextOptions = true;
			this.gridDiagnosticColumnSuccess.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridDiagnosticColumnSuccess.AppearanceHeader.TextOptions.VAlignment = global::DevExpress.Utils.VertAlignment.Center;
			resources.ApplyResources(this.gridDiagnosticColumnSuccess, "gridDiagnosticColumnSuccess");
			this.gridDiagnosticColumnSuccess.ColumnEdit = this.repositoryImageComboDiagnosticSuccess;
			this.gridDiagnosticColumnSuccess.FieldName = "Success";
			this.gridDiagnosticColumnSuccess.MinWidth = 31;
			this.gridDiagnosticColumnSuccess.Name = "gridDiagnosticColumnSuccess";
			this.gridDiagnosticColumnSuccess.OptionsColumn.AllowEdit = false;
			this.gridDiagnosticColumnSuccess.OptionsColumn.AllowSort = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridDiagnosticColumnSuccess.OptionsColumn.ReadOnly = true;
			this.gridDiagnosticColumnSuccess.UnboundType = global::DevExpress.Data.UnboundColumnType.Boolean;
			resources.ApplyResources(this.repositoryImageComboDiagnosticSuccess, "repositoryImageComboDiagnosticSuccess");
			this.repositoryImageComboDiagnosticSuccess.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryImageComboDiagnosticSuccess.Buttons"))
			});
			this.repositoryImageComboDiagnosticSuccess.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryImageComboDiagnosticSuccess.Items"), resources.GetObject("repositoryImageComboDiagnosticSuccess.Items1"), (int)resources.GetObject("repositoryImageComboDiagnosticSuccess.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryImageComboDiagnosticSuccess.Items3"), resources.GetObject("repositoryImageComboDiagnosticSuccess.Items4"), (int)resources.GetObject("repositoryImageComboDiagnosticSuccess.Items5"))
			});
			this.repositoryImageComboDiagnosticSuccess.Name = "repositoryImageComboDiagnosticSuccess";
			this.gridDiagnosticColumnOperation.AppearanceHeader.Options.UseTextOptions = true;
			this.gridDiagnosticColumnOperation.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridDiagnosticColumnOperation.AppearanceHeader.TextOptions.VAlignment = global::DevExpress.Utils.VertAlignment.Center;
			resources.ApplyResources(this.gridDiagnosticColumnOperation, "gridDiagnosticColumnOperation");
			this.gridDiagnosticColumnOperation.FieldName = "Description";
			this.gridDiagnosticColumnOperation.MinWidth = 31;
			this.gridDiagnosticColumnOperation.Name = "gridDiagnosticColumnOperation";
			this.gridDiagnosticColumnOperation.OptionsColumn.AllowEdit = false;
			this.gridDiagnosticColumnOperation.OptionsColumn.AllowSort = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridDiagnosticColumnOperation.OptionsColumn.ReadOnly = true;
			this.gridDiagnosticColumnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridDiagnosticColumnDeviceName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridDiagnosticColumnDeviceName.AppearanceHeader.TextOptions.VAlignment = global::DevExpress.Utils.VertAlignment.Center;
			resources.ApplyResources(this.gridDiagnosticColumnDeviceName, "gridDiagnosticColumnDeviceName");
			this.gridDiagnosticColumnDeviceName.FieldName = "DeviceName";
			this.gridDiagnosticColumnDeviceName.MinWidth = 31;
			this.gridDiagnosticColumnDeviceName.Name = "gridDiagnosticColumnDeviceName";
			this.gridDiagnosticColumnDeviceName.OptionsColumn.AllowEdit = false;
			this.gridDiagnosticColumnDeviceName.OptionsColumn.AllowSort = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridDiagnosticColumnDeviceName.OptionsColumn.FixedWidth = true;
			this.gridDiagnosticColumnDeviceName.OptionsColumn.ReadOnly = true;
			this.gridDiagnosticColumnDeviceName.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			this.gridDiagnosticColumnMessage.AppearanceHeader.Options.UseTextOptions = true;
			this.gridDiagnosticColumnMessage.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridDiagnosticColumnMessage.AppearanceHeader.TextOptions.VAlignment = global::DevExpress.Utils.VertAlignment.Center;
			resources.ApplyResources(this.gridDiagnosticColumnMessage, "gridDiagnosticColumnMessage");
			this.gridDiagnosticColumnMessage.ColumnEdit = this.repositoryMemoDiagnosticMessage;
			this.gridDiagnosticColumnMessage.FieldName = "Message";
			this.gridDiagnosticColumnMessage.MinWidth = 31;
			this.gridDiagnosticColumnMessage.Name = "gridDiagnosticColumnMessage";
			this.gridDiagnosticColumnMessage.OptionsColumn.AllowSort = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridDiagnosticColumnMessage.OptionsColumn.ReadOnly = true;
			this.gridDiagnosticColumnMessage.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			this.repositoryMemoDiagnosticMessage.Name = "repositoryMemoDiagnosticMessage";
			this.gridDiagnosticColumnSessionNo.AppearanceHeader.Options.UseTextOptions = true;
			this.gridDiagnosticColumnSessionNo.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridDiagnosticColumnSessionNo, "gridDiagnosticColumnSessionNo");
			this.gridDiagnosticColumnSessionNo.FieldName = "SessionNo";
			this.gridDiagnosticColumnSessionNo.MinWidth = 39;
			this.gridDiagnosticColumnSessionNo.Name = "gridDiagnosticColumnSessionNo";
			this.gridDiagnosticColumnSessionNo.OptionsColumn.AllowEdit = false;
			this.gridDiagnosticColumnSessionNo.OptionsColumn.AllowSort = global::DevExpress.Utils.DefaultBoolean.False;
			this.gridDiagnosticColumnSessionNo.OptionsColumn.ReadOnly = true;
			this.splitterDevicesTree.CollapsePanel = global::DevExpress.XtraEditors.SplitCollapsePanel.Panel1;
			this.splitterDevicesTree.Cursor = global::System.Windows.Forms.Cursors.Default;
			resources.ApplyResources(this.splitterDevicesTree, "splitterDevicesTree");
			this.splitterDevicesTree.Name = "splitterDevicesTree";
			this.splitterDevicesTree.Panel1.Controls.Add(this.devicesTreePanel);
			this.splitterDevicesTree.Panel2.Controls.Add(this.splitterDiagnosticWnd);
			this.splitterDevicesTree.SplitterPosition = 465;
			resources.ApplyResources(this.devicesTreePanel, "devicesTreePanel");
			this.devicesTreePanel.Name = "devicesTreePanel";
			this.timerCheckIdle.Enabled = true;
			this.timerCheckIdle.Interval = 3000;
			this.timerCheckIdle.Tick += new global::System.EventHandler(this.timerCheckIdle_Tick);
			resources.ApplyResources(this.tabControlWorkspaces, "tabControlWorkspaces");
			this.tabControlWorkspaces.Name = "tabControlWorkspaces";
			this.tabControlWorkspaces.SelectedTabPage = this.tabWorkspaceFull;
			this.tabControlWorkspaces.TabPages.AddRange(new global::DevExpress.XtraTab.XtraTabPage[]
			{
				this.tabWorkspaceFull,
				this.tabWorkspaceTree
			});
			resources.ApplyResources(this.tabWorkspaceFull, "tabWorkspaceFull");
			this.tabWorkspaceFull.Name = "tabWorkspaceFull";
			this.tabWorkspaceTree.Controls.Add(this.splitterDevicesTree);
			resources.ApplyResources(this.tabWorkspaceTree, "tabWorkspaceTree");
			this.tabWorkspaceTree.Name = "tabWorkspaceTree";
			this.alertControlAgentUpdate.ShowPinButton = false;
			this.alertControlAgentUpdate.AlertClick += new global::DevExpress.XtraBars.Alerter.AlertClickEventHandler(this.alertControlAgentUpdate_AlertClick);
			this.alertControlAgentUpdate.BeforeFormShow += new global::DevExpress.XtraBars.Alerter.AlertFormEventHandler(this.alertControlAgentUpdate_BeforeFormShow);
			this.miAppHistoryStatsView.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.Check;
			this.miAppHistoryStatsView.GroupIndex = 3;
			this.miAppHistoryStatsView.Id = 235;
			this.miAppHistoryStatsView.Name = "miAppHistoryStatsView";
			this.miAppHistoryStatsView.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.ChangeViewClick);
			base.AllowFormGlass = global::DevExpress.Utils.DefaultBoolean.False;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.tabControlWorkspaces);
			base.Controls.Add(this.ribbonStatusBar);
			base.Controls.Add(this.ribbonControl);
			base.Name = "MainForm";
			this.Ribbon = this.ribbonControl;
			this.StatusBar = this.ribbonStatusBar;
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.MainView_FormClosed);
			base.Load += new global::System.EventHandler(this.MainForm_Load);
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuUrlAllowedCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuFavoriteMessages).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuRemoteDesktop).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuPassword).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuFavoriteProcesses).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuDesktops).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuDeviceAppCheck).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDiagnosticWnd.Panel1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDiagnosticWnd.Panel2).EndInit();
			this.splitterDiagnosticWnd.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitterDiagnosticWnd).EndInit();
			this.splitterDiagnosticWnd.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridDiagnostic).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewDiagnostic).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryImageComboDiagnosticSuccess).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryMemoDiagnosticMessage).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitterDevicesTree.Panel1).EndInit();
			this.splitterDevicesTree.Panel1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitterDevicesTree.Panel2).EndInit();
			this.splitterDevicesTree.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitterDevicesTree).EndInit();
			this.splitterDevicesTree.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.tabControlWorkspaces).EndInit();
			this.tabControlWorkspaces.ResumeLayout(false);
			this.tabWorkspaceTree.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400052D RID: 1325
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400052E RID: 1326
		private global::DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;

		// Token: 0x0400052F RID: 1327
		private global::DevExpress.XtraBars.BarButtonItem miExit;

		// Token: 0x04000530 RID: 1328
		private global::DevExpress.XtraBars.BarButtonItem miHelp;

		// Token: 0x04000531 RID: 1329
		private global::DevExpress.XtraBars.BarButtonItem miCreateDevicesGroup;

		// Token: 0x04000532 RID: 1330
		private global::DevExpress.XtraBars.BarButtonItem miEditDevicesGroup;

		// Token: 0x04000533 RID: 1331
		private global::DevExpress.XtraBars.BarButtonItem miDeleteDevicesGroup;

		// Token: 0x04000534 RID: 1332
		private global::DevExpress.XtraBars.BarButtonItem miUrlCategories;

		// Token: 0x04000535 RID: 1333
		private global::DevExpress.XtraBars.BarButtonItem miConfigDevicesInfoView;

		// Token: 0x04000536 RID: 1334
		private global::DevExpress.XtraBars.BarButtonItem miConfigLogView;

		// Token: 0x04000537 RID: 1335
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceInetCheck;

		// Token: 0x04000538 RID: 1336
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceInetBlock;

		// Token: 0x04000539 RID: 1337
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceInetAllow;

		// Token: 0x0400053A RID: 1338
		private global::DevExpress.XtraBars.BarButtonItem miScreenshotsView;

		// Token: 0x0400053B RID: 1339
		private global::DevExpress.XtraBars.BarButtonItem miHistoryView;

		// Token: 0x0400053C RID: 1340
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceLockDisabled;

		// Token: 0x0400053D RID: 1341
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceLockKeyboard;

		// Token: 0x0400053E RID: 1342
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceLockMouseKeyboardMonitor;

		// Token: 0x0400053F RID: 1343
		private global::DevExpress.XtraBars.BarButtonItem miShowMessagesDef;

		// Token: 0x04000540 RID: 1344
		private global::DevExpress.XtraBars.BarButtonItem miRpcSystemShutdown;

		// Token: 0x04000541 RID: 1345
		private global::DevExpress.XtraBars.BarButtonItem miRpcSystemReboot;

		// Token: 0x04000542 RID: 1346
		private global::DevExpress.XtraBars.BarButtonItem miRpcSessionLogoff;

		// Token: 0x04000543 RID: 1347
		private global::DevExpress.XtraBars.BarButtonItem miRpcWakeOnLan;

		// Token: 0x04000544 RID: 1348
		private global::DevExpress.XtraBars.BarButtonItem miShowRemoteDesktop;

		// Token: 0x04000545 RID: 1349
		private global::DevExpress.XtraBars.BarButtonItem miShowFileManager;

		// Token: 0x04000546 RID: 1350
		private global::DevExpress.XtraBars.BarButtonItem miRoles;

		// Token: 0x04000547 RID: 1351
		private global::DevExpress.XtraBars.BarButtonItem miShowUpdateAgents;

		// Token: 0x04000548 RID: 1352
		private global::DevExpress.XtraBars.BarButtonItem miRpcSessionLogon;

		// Token: 0x04000549 RID: 1353
		private global::DevExpress.XtraBars.BarButtonItem miMoveDeviceToGroup;

		// Token: 0x0400054A RID: 1354
		private global::DevExpress.XtraBars.BarButtonItem miDefaultFonts;

		// Token: 0x0400054B RID: 1355
		private global::DevExpress.XtraBars.BarButtonItem miIsIdle;

		// Token: 0x0400054C RID: 1356
		private global::DevExpress.XtraBars.BarButtonItem miShowDistributeFiles;

		// Token: 0x0400054D RID: 1357
		private global::DevExpress.XtraBars.BarStaticItem miSelectedDeviceInfo;

		// Token: 0x0400054E RID: 1358
		private global::DevExpress.XtraBars.Ribbon.RibbonPage pageGroupWelcome;

		// Token: 0x0400054F RID: 1359
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageExit;

		// Token: 0x04000550 RID: 1360
		private global::DevExpress.XtraBars.Ribbon.RibbonPage pageGroupTools;

		// Token: 0x04000551 RID: 1361
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageTools;

		// Token: 0x04000552 RID: 1362
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageInternetAccess;

		// Token: 0x04000553 RID: 1363
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageDeviceLock;

		// Token: 0x04000554 RID: 1364
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageControlViewSelect;

		// Token: 0x04000555 RID: 1365
		private global::DevExpress.XtraBars.Ribbon.RibbonPage pageGroupApplications;

		// Token: 0x04000556 RID: 1366
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageProcesses;

		// Token: 0x04000557 RID: 1367
		private global::DevExpress.XtraBars.Ribbon.RibbonPage pageGroupConfig;

		// Token: 0x04000558 RID: 1368
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageDevices;

		// Token: 0x04000559 RID: 1369
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageSettings;

		// Token: 0x0400055A RID: 1370
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageLookSettings;

		// Token: 0x0400055B RID: 1371
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageConfigViewSelect;

		// Token: 0x0400055C RID: 1372
		private global::DevExpress.XtraBars.Ribbon.RibbonPage pageGroupHelp;

		// Token: 0x0400055D RID: 1373
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageHelp;

		// Token: 0x0400055E RID: 1374
		private global::DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGallery;

		// Token: 0x0400055F RID: 1375
		private global::DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;

		// Token: 0x04000560 RID: 1376
		private global::System.Windows.Forms.FontDialog fontDialog;

		// Token: 0x04000561 RID: 1377
		private global::DevExpress.XtraBars.BarButtonItem miPackagesView;

		// Token: 0x04000562 RID: 1378
		private global::DevExpress.XtraBars.BarButtonItem miProcessesView;

		// Token: 0x04000563 RID: 1379
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageAppViewSelect;

		// Token: 0x04000564 RID: 1380
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceInetStrict;

		// Token: 0x04000565 RID: 1381
		private global::DevExpress.XtraBars.PopupMenu popupMenuUrlAllowedCategories;

		// Token: 0x04000566 RID: 1382
		private global::DevExpress.XtraBars.BarButtonItem miChangePassword;

		// Token: 0x04000567 RID: 1383
		private global::DevExpress.XtraBars.BarButtonItem miMoveDevice;

		// Token: 0x04000568 RID: 1384
		private global::DevExpress.XtraBars.BarStaticItem barStaticItemServerConnection;

		// Token: 0x04000569 RID: 1385
		private global::System.Windows.Forms.Timer timerCheckIdle;

		// Token: 0x0400056A RID: 1386
		private global::DevExpress.XtraBars.BarCheckItem barCheckDiagnosticWnd;

		// Token: 0x0400056B RID: 1387
		private global::DevExpress.XtraTab.XtraTabControl tabControlWorkspaces;

		// Token: 0x0400056C RID: 1388
		private global::DevExpress.XtraTab.XtraTabPage tabWorkspaceFull;

		// Token: 0x0400056D RID: 1389
		private global::DevExpress.XtraTab.XtraTabPage tabWorkspaceTree;

		// Token: 0x0400056E RID: 1390
		private global::DevExpress.XtraEditors.SplitContainerControl splitterDevicesTree;

		// Token: 0x0400056F RID: 1391
		private global::OpiekunWEB.Console.Controls.DevicesTreePanel devicesTreePanel;

		// Token: 0x04000570 RID: 1392
		private global::DevExpress.XtraEditors.SplitContainerControl splitterDiagnosticWnd;

		// Token: 0x04000571 RID: 1393
		private global::DevExpress.XtraGrid.GridControl gridDiagnostic;

		// Token: 0x04000572 RID: 1394
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewDiagnostic;

		// Token: 0x04000573 RID: 1395
		private global::DevExpress.XtraGrid.Columns.GridColumn gridDiagnosticColumnDate;

		// Token: 0x04000574 RID: 1396
		private global::DevExpress.XtraGrid.Columns.GridColumn gridDiagnosticColumnSuccess;

		// Token: 0x04000575 RID: 1397
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryImageComboDiagnosticSuccess;

		// Token: 0x04000576 RID: 1398
		private global::DevExpress.XtraGrid.Columns.GridColumn gridDiagnosticColumnOperation;

		// Token: 0x04000577 RID: 1399
		private global::DevExpress.XtraGrid.Columns.GridColumn gridDiagnosticColumnDeviceName;

		// Token: 0x04000578 RID: 1400
		private global::DevExpress.XtraGrid.Columns.GridColumn gridDiagnosticColumnMessage;

		// Token: 0x04000579 RID: 1401
		private global::DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryMemoDiagnosticMessage;

		// Token: 0x0400057A RID: 1402
		private global::DevExpress.XtraGrid.Columns.GridColumn gridDiagnosticColumnSessionNo;

		// Token: 0x0400057B RID: 1403
		private global::DevExpress.XtraBars.BarButtonItem miCreateAppToken;

		// Token: 0x0400057C RID: 1404
		private global::DevExpress.XtraBars.PopupMenu popupMenuPassword;

		// Token: 0x0400057D RID: 1405
		private global::DevExpress.XtraBars.BarStaticItem barStaticSelectionInfo;

		// Token: 0x0400057E RID: 1406
		private global::DevExpress.XtraBars.BarButtonItem miCheckAppUpdates;

		// Token: 0x0400057F RID: 1407
		private global::DevExpress.XtraBars.Alerter.AlertControl alertControlAgentUpdate;

		// Token: 0x04000580 RID: 1408
		private global::DevExpress.XtraBars.BarButtonItem miShowProcessesDef;

		// Token: 0x04000581 RID: 1409
		private global::DevExpress.XtraBars.PopupMenu popupMenuFavoriteProcesses;

		// Token: 0x04000582 RID: 1410
		private global::DevExpress.XtraBars.PopupMenu popupMenuFavoriteMessages;

		// Token: 0x04000583 RID: 1411
		private global::DevExpress.XtraBars.BarButtonItem miRules;

		// Token: 0x04000584 RID: 1412
		private global::DevExpress.XtraBars.BarButtonItem miDesktops;

		// Token: 0x04000585 RID: 1413
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceAppAllow;

		// Token: 0x04000586 RID: 1414
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceAppStrictToDesktop;

		// Token: 0x04000587 RID: 1415
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageAppAccess;

		// Token: 0x04000588 RID: 1416
		private global::DevExpress.XtraBars.PopupMenu popupMenuDesktops;

		// Token: 0x04000589 RID: 1417
		private global::DevExpress.XtraBars.BarButtonItem miShowCollectFiles;

		// Token: 0x0400058A RID: 1418
		private global::DevExpress.XtraBars.BarButtonItem miAppHistoryView;

		// Token: 0x0400058B RID: 1419
		private global::DevExpress.XtraBars.BarButtonItem miAppHistoryStatsView;

		// Token: 0x0400058C RID: 1420
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup pageUpdates;

		// Token: 0x0400058D RID: 1421
		private global::DevExpress.XtraBars.BarButtonItem miRpcSessionLock;

		// Token: 0x0400058E RID: 1422
		private global::DevExpress.XtraBars.BarButtonItem miServicesView;

		// Token: 0x0400058F RID: 1423
		private global::DevExpress.XtraBars.PopupMenu popupMenuRemoteDesktop;

		// Token: 0x04000590 RID: 1424
		private global::DevExpress.XtraBars.BarButtonItem miStartVNC;

		// Token: 0x04000591 RID: 1425
		private global::DevExpress.XtraBars.BarButtonItem miStartRDP;

		// Token: 0x04000592 RID: 1426
		private global::DevExpress.XtraBars.BarButtonItem miCustomerInfo;

		// Token: 0x04000593 RID: 1427
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageOther;

		// Token: 0x04000594 RID: 1428
		private global::DevExpress.XtraBars.BarButtonItem miAppCategories;

		// Token: 0x04000595 RID: 1429
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceAppBlock;

		// Token: 0x04000596 RID: 1430
		private global::DevExpress.XtraBars.BarButtonItem miSetDeviceAppCheck;

		// Token: 0x04000597 RID: 1431
		private global::DevExpress.XtraBars.PopupMenu popupMenuDeviceAppCheck;

		// Token: 0x04000598 RID: 1432
		private global::DevExpress.XtraBars.BarButtonItem miDeviceAppCheck;

		// Token: 0x04000599 RID: 1433
		private global::DevExpress.XtraBars.BarSubItem miDeviceAppCheckUseBlackList;

		// Token: 0x0400059A RID: 1434
		private global::DevExpress.XtraBars.BarSubItem miDeviceAppCheckUseWhiteList;
	}
}
