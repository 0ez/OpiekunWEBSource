﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007E RID: 126
	public partial class UrlCategoriesForm : global::OpiekunWEB.Console.Forms.RibbonBaseForm
	{
		// Token: 0x060006CB RID: 1739 RVA: 0x000390AA File Offset: 0x000372AA
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x000390CC File Offset: 0x000372CC
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.UrlCategoriesForm));
			global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions = new global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions2 = new global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject8 = new global::DevExpress.Utils.SerializableAppearanceObject();
			this.splitContainer = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.gridUserCategories = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewUserCategories = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.columnUserCategoryName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnUserCategoryId = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnUserCategoryState = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxUserCategoryState = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imagesCategoryStates = new global::DevExpress.Utils.ImageCollection(this.components);
			this.columnUserCategoryCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnUserCategoryDescription = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.treeContentFilters = new global::DevExpress.XtraTreeList.TreeList();
			this.treeColumnCategoryContent = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.treeColumnContentFilterCommand = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.repositoryItemEditAndDelete = new global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
			this.imagesCategoryContent = new global::DevExpress.Utils.ImageCollection(this.components);
			this.ribbonControl = new global::DevExpress.XtraBars.Ribbon.RibbonControl();
			this.barButtonExit = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddCategory = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddUrl = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddPhrase = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddRegex = new global::DevExpress.XtraBars.BarButtonItem();
			this.ribbonPageMain = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.ribbonPageGroupMain = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.ribbonStatusBar = new global::DevExpress.XtraBars.Ribbon.RibbonStatusBar();
			this.barStaticSelection = new global::DevExpress.XtraBars.BarStaticItem();
			this.tabControlCategories = new global::DevExpress.XtraTab.XtraTabControl();
			this.tabPageUserCategories = new global::DevExpress.XtraTab.XtraTabPage();
			this.tabPageSystemCategories = new global::DevExpress.XtraTab.XtraTabPage();
			this.gridSystemCategories = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewSystemCategories = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.columnSystemCategoryName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnSystemCategoryDescription = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnSystemCategoryState = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxSystemCategoryState = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.columnSystemCategoryCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel1).BeginInit();
			this.splitContainer.Panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel2).BeginInit();
			this.splitContainer.Panel2.SuspendLayout();
			this.splitContainer.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridUserCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUserCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUserCategoryState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesCategoryStates).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeContentFilters).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemEditAndDelete).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesCategoryContent).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.tabControlCategories).BeginInit();
			this.tabControlCategories.SuspendLayout();
			this.tabPageUserCategories.SuspendLayout();
			this.tabPageSystemCategories.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridSystemCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSystemCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxSystemCategoryState).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.splitContainer, "splitContainer");
			this.splitContainer.Horizontal = false;
			this.splitContainer.Name = "splitContainer";
			this.splitContainer.Panel1.Controls.Add(this.gridUserCategories);
			this.splitContainer.Panel2.Controls.Add(this.treeContentFilters);
			this.splitContainer.SplitterPosition = 236;
			resources.ApplyResources(this.gridUserCategories, "gridUserCategories");
			this.gridUserCategories.MainView = this.gridViewUserCategories;
			this.gridUserCategories.Name = "gridUserCategories";
			this.gridUserCategories.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxUserCategoryState
			});
			this.gridUserCategories.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewUserCategories
			});
			this.gridUserCategories.Click += new global::System.EventHandler(this.gridUserCategories_Click);
			this.gridUserCategories.Enter += new global::System.EventHandler(this.Control_Enter);
			this.gridViewUserCategories.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.columnUserCategoryName,
				this.columnUserCategoryId,
				this.columnUserCategoryState,
				this.columnUserCategoryCommand,
				this.columnUserCategoryDescription
			});
			this.gridViewUserCategories.GridControl = this.gridUserCategories;
			this.gridViewUserCategories.Name = "gridViewUserCategories";
			this.gridViewUserCategories.OptionsMenu.EnableColumnMenu = false;
			this.gridViewUserCategories.OptionsNavigation.AutoFocusNewRow = true;
			this.gridViewUserCategories.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewUserCategories.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewUserCategories.OptionsView.ShowGroupPanel = false;
			this.gridViewUserCategories.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.columnUserCategoryName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewUserCategories.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewUserCategories_FocusedRowChanged);
			this.gridViewUserCategories.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewUserCategories_CustomUnboundColumnData);
			this.gridViewUserCategories.RowCountChanged += new global::System.EventHandler(this.gridViewUserCategories_RowCountChanged);
			this.columnUserCategoryName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserCategoryName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnUserCategoryName, "columnUserCategoryName");
			this.columnUserCategoryName.FieldName = "Name";
			this.columnUserCategoryName.Name = "columnUserCategoryName";
			this.columnUserCategoryName.OptionsColumn.AllowEdit = false;
			resources.ApplyResources(this.columnUserCategoryId, "columnUserCategoryId");
			this.columnUserCategoryId.FieldName = "Id";
			this.columnUserCategoryId.Name = "columnUserCategoryId";
			this.columnUserCategoryId.OptionsColumn.ShowCaption = false;
			this.columnUserCategoryId.OptionsColumn.ShowInCustomizationForm = false;
			this.columnUserCategoryId.UnboundType = global::DevExpress.Data.UnboundColumnType.Integer;
			this.columnUserCategoryState.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserCategoryState.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnUserCategoryState, "columnUserCategoryState");
			this.columnUserCategoryState.ColumnEdit = this.imageComboBoxUserCategoryState;
			this.columnUserCategoryState.FieldName = "CategoryState";
			this.columnUserCategoryState.Name = "columnUserCategoryState";
			this.columnUserCategoryState.UnboundType = global::DevExpress.Data.UnboundColumnType.Integer;
			resources.ApplyResources(this.imageComboBoxUserCategoryState, "imageComboBoxUserCategoryState");
			this.imageComboBoxUserCategoryState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxUserCategoryState.Buttons"))
			});
			this.imageComboBoxUserCategoryState.LargeImages = this.imagesCategoryStates;
			this.imageComboBoxUserCategoryState.Name = "imageComboBoxUserCategoryState";
			this.imageComboBoxUserCategoryState.EditValueChanging += new global::DevExpress.XtraEditors.Controls.ChangingEventHandler(this.imageComboUserCategoryState_EditValueChanging);
			this.imagesCategoryStates.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesCategoryStates.ImageStream");
			this.imagesCategoryStates.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_check_16x16, "access_check_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesCategoryStates.Images.SetKeyName(0, "access_check_16x16");
			this.imagesCategoryStates.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_block_16x16, "access_block_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 1);
			this.imagesCategoryStates.Images.SetKeyName(1, "access_block_16x16");
			this.imagesCategoryStates.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_allow_16x16, "access_allow_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 2);
			this.imagesCategoryStates.Images.SetKeyName(2, "access_allow_16x16");
			this.imagesCategoryStates.Images.SetKeyName(3, "employee_16x16.png");
			this.columnUserCategoryCommand.MinWidth = 25;
			this.columnUserCategoryCommand.Name = "columnUserCategoryCommand";
			resources.ApplyResources(this.columnUserCategoryCommand, "columnUserCategoryCommand");
			this.columnUserCategoryDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserCategoryDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnUserCategoryDescription, "columnUserCategoryDescription");
			this.columnUserCategoryDescription.FieldName = "Description";
			this.columnUserCategoryDescription.MinWidth = 25;
			this.columnUserCategoryDescription.Name = "columnUserCategoryDescription";
			this.columnUserCategoryDescription.OptionsColumn.AllowEdit = false;
			this.treeContentFilters.Columns.AddRange(new global::DevExpress.XtraTreeList.Columns.TreeListColumn[]
			{
				this.treeColumnCategoryContent,
				this.treeColumnContentFilterCommand
			});
			this.treeContentFilters.ColumnsImageList = this.imagesCategoryContent;
			resources.ApplyResources(this.treeContentFilters, "treeContentFilters");
			this.treeContentFilters.KeyFieldName = "Id";
			this.treeContentFilters.Name = "treeContentFilters";
			this.treeContentFilters.OptionsMenu.EnableColumnMenu = false;
			this.treeContentFilters.OptionsMenu.EnableNodeMenu = false;
			this.treeContentFilters.OptionsSelection.InvertSelection = true;
			this.treeContentFilters.OptionsView.EnableAppearanceOddRow = true;
			this.treeContentFilters.OptionsView.FocusRectStyle = global::DevExpress.XtraTreeList.DrawFocusRectStyle.RowFocus;
			this.treeContentFilters.ParentFieldName = "ParentId";
			this.treeContentFilters.SelectImageList = this.imagesCategoryContent;
			this.treeContentFilters.BeforeFocusNode += new global::DevExpress.XtraTreeList.BeforeFocusNodeEventHandler(this.treeContentFilters_BeforeFocusNode);
			this.treeContentFilters.FocusedNodeChanged += new global::DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.treeContentFilters_FocusedNodeChanged);
			this.treeContentFilters.Enter += new global::System.EventHandler(this.Control_Enter);
			this.treeColumnCategoryContent.AppearanceHeader.Options.UseTextOptions = true;
			this.treeColumnCategoryContent.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.treeColumnCategoryContent, "treeColumnCategoryContent");
			this.treeColumnCategoryContent.FieldName = "Content";
			this.treeColumnCategoryContent.Name = "treeColumnCategoryContent";
			this.treeColumnCategoryContent.OptionsColumn.AllowEdit = false;
			this.treeColumnContentFilterCommand.ColumnEdit = this.repositoryItemEditAndDelete;
			this.treeColumnContentFilterCommand.Name = "treeColumnContentFilterCommand";
			resources.ApplyResources(this.treeColumnContentFilterCommand, "treeColumnContentFilterCommand");
			resources.ApplyResources(editorButtonImageOptions, "editorButtonImageOptions1");
			editorButtonImageOptions.Location = global::DevExpress.XtraEditors.ImageLocation.MiddleLeft;
			resources.ApplyResources(editorButtonImageOptions2, "editorButtonImageOptions2");
			editorButtonImageOptions2.Location = global::DevExpress.XtraEditors.ImageLocation.MiddleLeft;
			this.repositoryItemEditAndDelete.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryItemEditAndDelete.Buttons"), resources.GetString("repositoryItemEditAndDelete.Buttons1"), (int)resources.GetObject("repositoryItemEditAndDelete.Buttons2"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons3"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons4"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons5"), editorButtonImageOptions, new global::DevExpress.Utils.KeyShortcut(global::System.Windows.Forms.Keys.None), serializableAppearanceObject, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, resources.GetString("repositoryItemEditAndDelete.Buttons6"), resources.GetObject("repositoryItemEditAndDelete.Buttons7"), (global::DevExpress.Utils.SuperToolTip)resources.GetObject("repositoryItemEditAndDelete.Buttons8"), (global::DevExpress.Utils.ToolTipAnchor)resources.GetObject("repositoryItemEditAndDelete.Buttons9")),
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryItemEditAndDelete.Buttons10"), resources.GetString("repositoryItemEditAndDelete.Buttons11"), (int)resources.GetObject("repositoryItemEditAndDelete.Buttons12"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons13"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons14"), (bool)resources.GetObject("repositoryItemEditAndDelete.Buttons15"), editorButtonImageOptions2, new global::DevExpress.Utils.KeyShortcut(global::System.Windows.Forms.Keys.None), serializableAppearanceObject5, serializableAppearanceObject6, serializableAppearanceObject7, serializableAppearanceObject8, resources.GetString("repositoryItemEditAndDelete.Buttons16"), resources.GetObject("repositoryItemEditAndDelete.Buttons17"), (global::DevExpress.Utils.SuperToolTip)resources.GetObject("repositoryItemEditAndDelete.Buttons18"), (global::DevExpress.Utils.ToolTipAnchor)resources.GetObject("repositoryItemEditAndDelete.Buttons19"))
			});
			this.repositoryItemEditAndDelete.Name = "repositoryItemEditAndDelete";
			this.repositoryItemEditAndDelete.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.imagesCategoryContent.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesCategoryContent.ImageStream");
			this.imagesCategoryContent.Images.SetKeyName(0, "viewonweb_16x16.png");
			this.imagesCategoryContent.Images.SetKeyName(1, "contentautoarrange_16x16.png");
			this.ribbonControl.AllowMinimizeRibbon = false;
			this.ribbonControl.ExpandCollapseItem.Id = 0;
			this.ribbonControl.Items.AddRange(new global::DevExpress.XtraBars.BarItem[]
			{
				this.ribbonControl.ExpandCollapseItem,
				this.ribbonControl.SearchEditItem,
				this.barButtonExit,
				this.barButtonAddCategory,
				this.barButtonAddUrl,
				this.barButtonAddPhrase,
				this.barButtonAddRegex
			});
			resources.ApplyResources(this.ribbonControl, "ribbonControl");
			this.ribbonControl.MaxItemId = 9;
			this.ribbonControl.Name = "ribbonControl";
			this.ribbonControl.Pages.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPage[]
			{
				this.ribbonPageMain
			});
			this.ribbonControl.ShowApplicationButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonControl.ShowPageHeadersMode = global::DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
			this.ribbonControl.ShowQatLocationSelector = false;
			this.ribbonControl.ShowToolbarCustomizeItem = false;
			this.ribbonControl.StatusBar = this.ribbonStatusBar;
			this.ribbonControl.Toolbar.ShowCustomizeItem = false;
			resources.ApplyResources(this.barButtonExit, "barButtonExit");
			this.barButtonExit.Id = 1;
			this.barButtonExit.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.close_16x16;
			this.barButtonExit.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.close_32x32;
			this.barButtonExit.Name = "barButtonExit";
			this.barButtonExit.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonExit_ItemClick);
			resources.ApplyResources(this.barButtonAddCategory, "barButtonAddCategory");
			this.barButtonAddCategory.Id = 2;
			this.barButtonAddCategory.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.addheader_16x16;
			this.barButtonAddCategory.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.addheader_32x32;
			this.barButtonAddCategory.Name = "barButtonAddCategory";
			this.barButtonAddCategory.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddCategory_ItemClick);
			resources.ApplyResources(this.barButtonAddUrl, "barButtonAddUrl");
			this.barButtonAddUrl.Id = 3;
			this.barButtonAddUrl.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.viewonweb_16x16;
			this.barButtonAddUrl.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.viewonweb_32x32;
			this.barButtonAddUrl.Name = "barButtonAddUrl";
			this.barButtonAddUrl.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddUrl_ItemClick);
			resources.ApplyResources(this.barButtonAddPhrase, "barButtonAddPhrase");
			this.barButtonAddPhrase.Id = 6;
			this.barButtonAddPhrase.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.richtext_16x16;
			this.barButtonAddPhrase.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.richtext_32x32;
			this.barButtonAddPhrase.Name = "barButtonAddPhrase";
			this.barButtonAddPhrase.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddPhrase_ItemClick);
			resources.ApplyResources(this.barButtonAddRegex, "barButtonAddRegex");
			this.barButtonAddRegex.Id = 8;
			this.barButtonAddRegex.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.gettingstarted_16x16;
			this.barButtonAddRegex.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.gettingstarted_32x32;
			this.barButtonAddRegex.Name = "barButtonAddRegex";
			this.barButtonAddRegex.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddRegex_ItemClick);
			this.ribbonPageMain.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.ribbonPageGroupMain
			});
			this.ribbonPageMain.Name = "ribbonPageMain";
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonExit);
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonAddCategory, true);
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonAddUrl);
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonAddPhrase);
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonAddRegex);
			this.ribbonPageGroupMain.Name = "ribbonPageGroupMain";
			resources.ApplyResources(this.ribbonPageGroupMain, "ribbonPageGroupMain");
			this.ribbonStatusBar.ItemLinks.Add(this.barStaticSelection);
			resources.ApplyResources(this.ribbonStatusBar, "ribbonStatusBar");
			this.ribbonStatusBar.Name = "ribbonStatusBar";
			this.ribbonStatusBar.Ribbon = this.ribbonControl;
			resources.ApplyResources(this.barStaticSelection, "barStaticSelection");
			this.barStaticSelection.Id = 7;
			this.barStaticSelection.Name = "barStaticSelection";
			resources.ApplyResources(this.tabControlCategories, "tabControlCategories");
			this.tabControlCategories.Name = "tabControlCategories";
			this.tabControlCategories.SelectedTabPage = this.tabPageUserCategories;
			this.tabControlCategories.TabPages.AddRange(new global::DevExpress.XtraTab.XtraTabPage[]
			{
				this.tabPageUserCategories,
				this.tabPageSystemCategories
			});
			this.tabControlCategories.SelectedPageChanged += new global::DevExpress.XtraTab.TabPageChangedEventHandler(this.tabControlCategories_SelectedPageChanged);
			this.tabPageUserCategories.Controls.Add(this.splitContainer);
			this.tabPageUserCategories.Name = "tabPageUserCategories";
			resources.ApplyResources(this.tabPageUserCategories, "tabPageUserCategories");
			this.tabPageSystemCategories.Controls.Add(this.gridSystemCategories);
			this.tabPageSystemCategories.Name = "tabPageSystemCategories";
			resources.ApplyResources(this.tabPageSystemCategories, "tabPageSystemCategories");
			resources.ApplyResources(this.gridSystemCategories, "gridSystemCategories");
			this.gridSystemCategories.MainView = this.gridViewSystemCategories;
			this.gridSystemCategories.Name = "gridSystemCategories";
			this.gridSystemCategories.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxSystemCategoryState
			});
			this.gridSystemCategories.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewSystemCategories
			});
			this.gridSystemCategories.Enter += new global::System.EventHandler(this.Control_Enter);
			this.gridViewSystemCategories.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.columnSystemCategoryName,
				this.columnSystemCategoryDescription,
				this.columnSystemCategoryState,
				this.columnSystemCategoryCommand
			});
			this.gridViewSystemCategories.GridControl = this.gridSystemCategories;
			this.gridViewSystemCategories.Name = "gridViewSystemCategories";
			this.gridViewSystemCategories.OptionsMenu.EnableColumnMenu = false;
			this.gridViewSystemCategories.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewSystemCategories.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewSystemCategories.OptionsView.ShowGroupPanel = false;
			this.gridViewSystemCategories.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.columnSystemCategoryName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewSystemCategories.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewSystemCategories_FocusedRowChanged);
			this.gridViewSystemCategories.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewSystemCategories_CustomUnboundColumnData);
			this.columnSystemCategoryName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnSystemCategoryName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnSystemCategoryName, "columnSystemCategoryName");
			this.columnSystemCategoryName.FieldName = "Name";
			this.columnSystemCategoryName.Name = "columnSystemCategoryName";
			this.columnSystemCategoryName.OptionsColumn.AllowEdit = false;
			this.columnSystemCategoryDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnSystemCategoryDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnSystemCategoryDescription, "columnSystemCategoryDescription");
			this.columnSystemCategoryDescription.FieldName = "Description";
			this.columnSystemCategoryDescription.MinWidth = 25;
			this.columnSystemCategoryDescription.Name = "columnSystemCategoryDescription";
			this.columnSystemCategoryDescription.OptionsColumn.AllowEdit = false;
			this.columnSystemCategoryState.AppearanceHeader.Options.UseTextOptions = true;
			this.columnSystemCategoryState.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnSystemCategoryState, "columnSystemCategoryState");
			this.columnSystemCategoryState.ColumnEdit = this.imageComboBoxSystemCategoryState;
			this.columnSystemCategoryState.FieldName = "SystemCategoryState";
			this.columnSystemCategoryState.Name = "columnSystemCategoryState";
			this.columnSystemCategoryState.UnboundType = global::DevExpress.Data.UnboundColumnType.Integer;
			resources.ApplyResources(this.imageComboBoxSystemCategoryState, "imageComboBoxSystemCategoryState");
			this.imageComboBoxSystemCategoryState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxSystemCategoryState.Buttons"))
			});
			this.imageComboBoxSystemCategoryState.LargeImages = this.imagesCategoryStates;
			this.imageComboBoxSystemCategoryState.Name = "imageComboBoxSystemCategoryState";
			this.imageComboBoxSystemCategoryState.EditValueChanging += new global::DevExpress.XtraEditors.Controls.ChangingEventHandler(this.imageComboSystemCategoryState_EditValueChanging);
			this.columnSystemCategoryCommand.MinWidth = 25;
			this.columnSystemCategoryCommand.Name = "columnSystemCategoryCommand";
			resources.ApplyResources(this.columnSystemCategoryCommand, "columnSystemCategoryCommand");
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.tabControlCategories);
			base.Controls.Add(this.ribbonStatusBar);
			base.Controls.Add(this.ribbonControl);
			base.MinimizeBox = false;
			base.Name = "UrlCategoriesForm";
			this.Ribbon = this.ribbonControl;
			base.ShowInTaskbar = false;
			this.StatusBar = this.ribbonStatusBar;
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel1).EndInit();
			this.splitContainer.Panel1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel2).EndInit();
			this.splitContainer.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer).EndInit();
			this.splitContainer.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridUserCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUserCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUserCategoryState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesCategoryStates).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeContentFilters).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemEditAndDelete).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesCategoryContent).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.tabControlCategories).EndInit();
			this.tabControlCategories.ResumeLayout(false);
			this.tabPageUserCategories.ResumeLayout(false);
			this.tabPageSystemCategories.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridSystemCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSystemCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxSystemCategoryState).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000490 RID: 1168
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000491 RID: 1169
		private global::DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;

		// Token: 0x04000492 RID: 1170
		private global::DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageMain;

		// Token: 0x04000493 RID: 1171
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupMain;

		// Token: 0x04000494 RID: 1172
		private global::DevExpress.XtraBars.BarButtonItem barButtonExit;

		// Token: 0x04000495 RID: 1173
		private global::DevExpress.XtraTab.XtraTabControl tabControlCategories;

		// Token: 0x04000496 RID: 1174
		private global::DevExpress.XtraTab.XtraTabPage tabPageUserCategories;

		// Token: 0x04000497 RID: 1175
		private global::DevExpress.XtraTab.XtraTabPage tabPageSystemCategories;

		// Token: 0x04000498 RID: 1176
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddCategory;

		// Token: 0x04000499 RID: 1177
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddUrl;

		// Token: 0x0400049A RID: 1178
		private global::DevExpress.XtraGrid.GridControl gridSystemCategories;

		// Token: 0x0400049B RID: 1179
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewSystemCategories;

		// Token: 0x0400049C RID: 1180
		private global::DevExpress.Utils.ImageCollection imagesCategoryStates;

		// Token: 0x0400049D RID: 1181
		private global::DevExpress.XtraEditors.SplitContainerControl splitContainer;

		// Token: 0x0400049E RID: 1182
		private global::DevExpress.XtraGrid.GridControl gridUserCategories;

		// Token: 0x0400049F RID: 1183
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewUserCategories;

		// Token: 0x040004A0 RID: 1184
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryName;

		// Token: 0x040004A1 RID: 1185
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryId;

		// Token: 0x040004A2 RID: 1186
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryState;

		// Token: 0x040004A3 RID: 1187
		private global::DevExpress.XtraTreeList.TreeList treeContentFilters;

		// Token: 0x040004A4 RID: 1188
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn treeColumnCategoryContent;

		// Token: 0x040004A5 RID: 1189
		private global::DevExpress.Utils.ImageCollection imagesCategoryContent;

		// Token: 0x040004A6 RID: 1190
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddPhrase;

		// Token: 0x040004A7 RID: 1191
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxUserCategoryState;

		// Token: 0x040004A8 RID: 1192
		private global::DevExpress.XtraGrid.Columns.GridColumn columnSystemCategoryName;

		// Token: 0x040004A9 RID: 1193
		private global::DevExpress.XtraGrid.Columns.GridColumn columnSystemCategoryState;

		// Token: 0x040004AA RID: 1194
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxSystemCategoryState;

		// Token: 0x040004AB RID: 1195
		private global::DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;

		// Token: 0x040004AC RID: 1196
		private global::DevExpress.XtraBars.BarStaticItem barStaticSelection;

		// Token: 0x040004AD RID: 1197
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddRegex;

		// Token: 0x040004AE RID: 1198
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryCommand;

		// Token: 0x040004AF RID: 1199
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn treeColumnContentFilterCommand;

		// Token: 0x040004B0 RID: 1200
		private global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemEditAndDelete;

		// Token: 0x040004B1 RID: 1201
		private global::DevExpress.XtraGrid.Columns.GridColumn columnSystemCategoryCommand;

		// Token: 0x040004B2 RID: 1202
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryDescription;

		// Token: 0x040004B3 RID: 1203
		private global::DevExpress.XtraGrid.Columns.GridColumn columnSystemCategoryDescription;
	}
}
