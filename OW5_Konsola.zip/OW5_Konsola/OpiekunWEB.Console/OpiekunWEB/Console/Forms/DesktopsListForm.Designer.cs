﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000062 RID: 98
	public partial class DesktopsListForm : global::OpiekunWEB.Console.Forms.RibbonBaseForm
	{
		// Token: 0x06000535 RID: 1333 RVA: 0x0001D2E2 File Offset: 0x0001B4E2
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x0001D304 File Offset: 0x0001B504
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DesktopsListForm));
			this.splitContainerControl = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.gridDesktops = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewDesktops = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnDesktopName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnDesktopDescription = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnDesktopCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.ribbonControl = new global::DevExpress.XtraBars.Ribbon.RibbonControl();
			this.barButtonExit = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddDesktop = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddItem = new global::DevExpress.XtraBars.BarButtonItem();
			this.ribbonPageMain = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.ribbonPageGroupActions = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.gridDesktopItems = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewDesktopItems = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnAppName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnAppCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerControl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerControl.Panel1).BeginInit();
			this.splitContainerControl.Panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerControl.Panel2).BeginInit();
			this.splitContainerControl.Panel2.SuspendLayout();
			this.splitContainerControl.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridDesktops).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewDesktops).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridDesktopItems).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewDesktopItems).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.splitContainerControl, "splitContainerControl");
			this.splitContainerControl.Name = "splitContainerControl";
			this.splitContainerControl.Panel1.Controls.Add(this.gridDesktops);
			this.splitContainerControl.Panel2.Controls.Add(this.gridDesktopItems);
			this.splitContainerControl.SplitterPosition = 392;
			resources.ApplyResources(this.gridDesktops, "gridDesktops");
			this.gridDesktops.MainView = this.gridViewDesktops;
			this.gridDesktops.MenuManager = this.ribbonControl;
			this.gridDesktops.Name = "gridDesktops";
			this.gridDesktops.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewDesktops
			});
			this.gridViewDesktops.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnDesktopName,
				this.gridColumnDesktopDescription,
				this.gridColumnDesktopCommand
			});
			this.gridViewDesktops.GridControl = this.gridDesktops;
			this.gridViewDesktops.Name = "gridViewDesktops";
			this.gridViewDesktops.OptionsMenu.EnableColumnMenu = false;
			this.gridViewDesktops.OptionsNavigation.AutoFocusNewRow = true;
			this.gridViewDesktops.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewDesktops.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewDesktops.OptionsView.ShowGroupPanel = false;
			this.gridViewDesktops.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnDesktopName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewDesktops.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewDesktops_FocusedRowChanged);
			this.gridViewDesktops.RowCountChanged += new global::System.EventHandler(this.gridViewDesktops_RowCountChanged);
			this.gridColumnDesktopName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDesktopName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnDesktopName, "gridColumnDesktopName");
			this.gridColumnDesktopName.FieldName = "Name";
			this.gridColumnDesktopName.MinWidth = 25;
			this.gridColumnDesktopName.Name = "gridColumnDesktopName";
			this.gridColumnDesktopName.OptionsColumn.AllowEdit = false;
			this.gridColumnDesktopName.OptionsColumn.ReadOnly = true;
			this.gridColumnDesktopDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDesktopDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnDesktopDescription, "gridColumnDesktopDescription");
			this.gridColumnDesktopDescription.FieldName = "Description";
			this.gridColumnDesktopDescription.MinWidth = 25;
			this.gridColumnDesktopDescription.Name = "gridColumnDesktopDescription";
			this.gridColumnDesktopDescription.OptionsColumn.AllowEdit = false;
			this.gridColumnDesktopDescription.OptionsColumn.ReadOnly = true;
			this.gridColumnDesktopCommand.MinWidth = 25;
			this.gridColumnDesktopCommand.Name = "gridColumnDesktopCommand";
			resources.ApplyResources(this.gridColumnDesktopCommand, "gridColumnDesktopCommand");
			this.ribbonControl.AllowMinimizeRibbon = false;
			this.ribbonControl.ExpandCollapseItem.Id = 0;
			this.ribbonControl.Items.AddRange(new global::DevExpress.XtraBars.BarItem[]
			{
				this.ribbonControl.ExpandCollapseItem,
				this.ribbonControl.SearchEditItem,
				this.barButtonExit,
				this.barButtonAddDesktop,
				this.barButtonAddItem
			});
			resources.ApplyResources(this.ribbonControl, "ribbonControl");
			this.ribbonControl.MaxItemId = 8;
			this.ribbonControl.Name = "ribbonControl";
			this.ribbonControl.Pages.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPage[]
			{
				this.ribbonPageMain
			});
			this.ribbonControl.ShowApplicationButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonControl.ShowPageHeadersMode = global::DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
			this.ribbonControl.ShowToolbarCustomizeItem = false;
			this.ribbonControl.Toolbar.ShowCustomizeItem = false;
			resources.ApplyResources(this.barButtonExit, "barButtonExit");
			this.barButtonExit.Id = 1;
			this.barButtonExit.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.close_32x32;
			this.barButtonExit.Name = "barButtonExit";
			this.barButtonExit.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonExit_ItemClick);
			resources.ApplyResources(this.barButtonAddDesktop, "barButtonAddDesktop");
			this.barButtonAddDesktop.Id = 2;
			this.barButtonAddDesktop.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.addheader_16x16;
			this.barButtonAddDesktop.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.addheader_32x32;
			this.barButtonAddDesktop.Name = "barButtonAddDesktop";
			this.barButtonAddDesktop.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddDesktop_ItemClick);
			resources.ApplyResources(this.barButtonAddItem, "barButtonAddItem");
			this.barButtonAddItem.Id = 5;
			this.barButtonAddItem.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.insert_16x16;
			this.barButtonAddItem.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.insert_32x32;
			this.barButtonAddItem.Name = "barButtonAddItem";
			this.barButtonAddItem.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddItem_ItemClick);
			this.ribbonPageMain.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.ribbonPageGroupActions
			});
			this.ribbonPageMain.Name = "ribbonPageMain";
			this.ribbonPageGroupActions.ItemLinks.Add(this.barButtonExit);
			this.ribbonPageGroupActions.ItemLinks.Add(this.barButtonAddDesktop, true);
			this.ribbonPageGroupActions.ItemLinks.Add(this.barButtonAddItem);
			this.ribbonPageGroupActions.Name = "ribbonPageGroupActions";
			resources.ApplyResources(this.ribbonPageGroupActions, "ribbonPageGroupActions");
			resources.ApplyResources(this.gridDesktopItems, "gridDesktopItems");
			this.gridDesktopItems.MainView = this.gridViewDesktopItems;
			this.gridDesktopItems.MenuManager = this.ribbonControl;
			this.gridDesktopItems.Name = "gridDesktopItems";
			this.gridDesktopItems.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewDesktopItems
			});
			this.gridViewDesktopItems.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnAppName,
				this.gridColumnAppCommand
			});
			this.gridViewDesktopItems.GridControl = this.gridDesktopItems;
			this.gridViewDesktopItems.Name = "gridViewDesktopItems";
			this.gridViewDesktopItems.OptionsMenu.EnableColumnMenu = false;
			this.gridViewDesktopItems.OptionsNavigation.AutoFocusNewRow = true;
			this.gridViewDesktopItems.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewDesktopItems.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewDesktopItems.OptionsView.ShowGroupPanel = false;
			this.gridViewDesktopItems.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnAppName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewDesktopItems.CustomRowFilter += new global::DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridViewDesktopItems_CustomRowFilter);
			this.gridColumnAppName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnAppName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnAppName, "gridColumnAppName");
			this.gridColumnAppName.FieldName = "Name";
			this.gridColumnAppName.MinWidth = 25;
			this.gridColumnAppName.Name = "gridColumnAppName";
			this.gridColumnAppName.OptionsColumn.AllowEdit = false;
			this.gridColumnAppCommand.MinWidth = 25;
			this.gridColumnAppCommand.Name = "gridColumnAppCommand";
			resources.ApplyResources(this.gridColumnAppCommand, "gridColumnAppCommand");
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.splitContainerControl);
			base.Controls.Add(this.ribbonControl);
			base.Name = "DesktopsListForm";
			this.Ribbon = this.ribbonControl;
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerControl.Panel1).EndInit();
			this.splitContainerControl.Panel1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerControl.Panel2).EndInit();
			this.splitContainerControl.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerControl).EndInit();
			this.splitContainerControl.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridDesktops).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewDesktops).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridDesktopItems).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewDesktopItems).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000276 RID: 630
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000277 RID: 631
		private global::DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;

		// Token: 0x04000278 RID: 632
		private global::DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageMain;

		// Token: 0x04000279 RID: 633
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupActions;

		// Token: 0x0400027A RID: 634
		private global::DevExpress.XtraBars.BarButtonItem barButtonExit;

		// Token: 0x0400027B RID: 635
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddDesktop;

		// Token: 0x0400027C RID: 636
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddItem;

		// Token: 0x0400027D RID: 637
		private global::DevExpress.XtraEditors.SplitContainerControl splitContainerControl;

		// Token: 0x0400027E RID: 638
		private global::DevExpress.XtraGrid.GridControl gridDesktops;

		// Token: 0x0400027F RID: 639
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewDesktops;

		// Token: 0x04000280 RID: 640
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDesktopName;

		// Token: 0x04000281 RID: 641
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDesktopDescription;

		// Token: 0x04000282 RID: 642
		private global::DevExpress.XtraGrid.GridControl gridDesktopItems;

		// Token: 0x04000283 RID: 643
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewDesktopItems;

		// Token: 0x04000284 RID: 644
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnAppName;

		// Token: 0x04000285 RID: 645
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDesktopCommand;

		// Token: 0x04000286 RID: 646
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnAppCommand;
	}
}
