﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Nodes;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000064 RID: 100
	public partial class DeviceGroupsSelectionForm : BaseForm
	{
		// Token: 0x0600053D RID: 1341 RVA: 0x0001EC20 File Offset: 0x0001CE20
		public DeviceGroupsSelectionForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, DeviceGroupsSelectionFormParams @params) : base(formsSettings, formCreator, action)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._params = @params;
			if (this._params.DisableWindowsCanceling)
			{
				base.CanCloseByEsc = false;
				base.ControlBox = false;
			}
			if (!this._params.CanSelectMultipleGroups)
			{
				this.treeListDeviceGroups.OptionsView.CheckBoxStyle = DefaultNodeCheckBoxStyle.Default;
			}
			bool flag;
			if (this._params.AllowedGroupsId != null)
			{
				List<string> allowedGroupsId = this._params.AllowedGroupsId;
				flag = (allowedGroupsId != null && allowedGroupsId.Contains("*"));
			}
			else
			{
				flag = true;
			}
			if (flag)
			{
				this.treeListDeviceGroups.DataSource = this._apiClient.DevicesGroups;
			}
			else
			{
				this.treeListDeviceGroups.DataSource = new List<DevicesGroup>(from x in this._apiClient.DevicesGroups
				where this._params.AllowedGroupsId.Contains(x.Id)
				select x);
			}
			this.treeListDeviceGroups.ExpandAll();
			this.InitNodeStates();
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x0001ED08 File Offset: 0x0001CF08
		private void buttonOk_Click(object sender, EventArgs e)
		{
			this._params.SelectedGroupsId.Clear();
			if (!this._params.CanSelectMultipleGroups)
			{
				if (this.treeListDeviceGroups.FocusedNode != null)
				{
					DevicesGroup group = this.GetDevicesGroupForNode(this.treeListDeviceGroups.FocusedNode);
					this._params.SelectedGroupsId.Add(group.Id);
				}
				return;
			}
			foreach (TreeListNode node in this.treeListDeviceGroups.GetAllCheckedNodes())
			{
				DevicesGroup group2 = this.GetDevicesGroupForNode(node);
				this._params.SelectedGroupsId.Add(group2.Id);
				if (string.IsNullOrEmpty(group2.ParentId))
				{
					this._params.SelectedGroupsId.Clear();
					this._params.SelectedGroupsId.Add("*");
					break;
				}
			}
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x0001EE00 File Offset: 0x0001D000
		private void DeviceGroupsSelectionForm_Load(object sender, EventArgs e)
		{
			if (this.treeListDeviceGroups.Nodes.Any<TreeListNode>())
			{
				this.treeListDeviceGroups.FocusedNode = this.treeListDeviceGroups.Nodes[0];
			}
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x0001EE30 File Offset: 0x0001D030
		private DevicesGroup GetDevicesGroupForNode(TreeListNode node)
		{
			return this.treeListDeviceGroups.GetDataRecordByNode(node) as DevicesGroup;
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x0001EE44 File Offset: 0x0001D044
		private void InitNodeStates()
		{
			foreach (TreeListNode node in this.treeListDeviceGroups.GetNodeList())
			{
				DevicesGroup group = this.GetDevicesGroupForNode(node);
				node.Checked = this._params.SelectedGroupsId.Contains(group.Id);
				if (string.IsNullOrEmpty(group.ParentId) && (this._params.SelectedGroupsId.Contains("*") || this._params.SelectedGroupsId.Contains(group.Id)))
				{
					this.treeListDeviceGroups.UncheckAll();
					node.Checked = true;
					break;
				}
			}
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x0001EF0C File Offset: 0x0001D10C
		private void treeListDeviceGroups_BeforeCheckNode(object sender, CheckNodeEventArgs e)
		{
			if (string.IsNullOrEmpty(this.GetDevicesGroupForNode(e.Node).ParentId))
			{
				this.treeListDeviceGroups.UncheckAll();
				return;
			}
			foreach (TreeListNode node in this.treeListDeviceGroups.GetAllCheckedNodes())
			{
				if (string.IsNullOrEmpty(this.GetDevicesGroupForNode(node).ParentId))
				{
					node.Checked = false;
					break;
				}
			}
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x0001EFA0 File Offset: 0x0001D1A0
		private void treeListDeviceGroups_DoubleClick(object sender, EventArgs e)
		{
			if (!this._params.CanSelectMultipleGroups)
			{
				this.buttonOk.PerformClick();
			}
		}

		// Token: 0x0400029C RID: 668
		private readonly ApiClient _apiClient;

		// Token: 0x0400029D RID: 669
		private readonly DeviceGroupsSelectionFormParams _params;
	}
}
