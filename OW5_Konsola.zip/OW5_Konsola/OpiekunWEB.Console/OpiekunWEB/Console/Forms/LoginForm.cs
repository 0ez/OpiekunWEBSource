﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.Utils.Behaviors;
using DevExpress.XtraEditors;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000081 RID: 129
	public partial class LoginForm : BaseForm
	{
		// Token: 0x060006EA RID: 1770 RVA: 0x0003BDAC File Offset: 0x00039FAC
		public LoginForm(FormsSettings formsSettings, IFormCreator formCreator, AppConfiguration appConfiguration, ApiClient apiClient, CmdLineParams cmdLineParams) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._cmdLineParams = cmdLineParams;
			this._appConfiguration = appConfiguration;
			this.Text = this.Text + " (" + this._apiClient.AppVersion + ")";
		}

		// Token: 0x060006EB RID: 1771 RVA: 0x0003BE10 File Offset: 0x0003A010
		private void buttonLogin_Click(object sender, EventArgs e)
		{
			LoginForm.<buttonLogin_Click>d__6 <buttonLogin_Click>d__;
			<buttonLogin_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonLogin_Click>d__.<>4__this = this;
			<buttonLogin_Click>d__.<>1__state = -1;
			<buttonLogin_Click>d__.<>t__builder.Start<LoginForm.<buttonLogin_Click>d__6>(ref <buttonLogin_Click>d__);
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x0003BE48 File Offset: 0x0003A048
		private void FormLogin_Load(object sender, EventArgs e)
		{
			LoginForm.LoginInfo loginInfo = this._appConfiguration.ReadEncrytedObjectFromUserRegistry<LoginForm.LoginInfo>("LoginInfo");
			if (loginInfo != null)
			{
				this.checkEditSaveLogin.Checked = loginInfo.SaveLogin;
				this.checkEditSavePassword.Checked = loginInfo.SavePassword;
				this.textEditLogin.Text = (loginInfo.SaveLogin ? loginInfo.Login : "");
				this.textEditPassword.Text = (loginInfo.SavePassword ? loginInfo.Password : "");
			}
			if (!string.IsNullOrEmpty(this._cmdLineParams.Login))
			{
				this.textEditLogin.Text = this._cmdLineParams.Login;
			}
			if (!string.IsNullOrEmpty(this._cmdLineParams.Password))
			{
				this.textEditPassword.Text = this._cmdLineParams.Password;
			}
			if (!string.IsNullOrEmpty(this.textEditLogin.Text))
			{
				base.ActiveControl = this.textEditPassword;
			}
			base.WindowState = FormWindowState.Minimized;
			base.Show();
			base.WindowState = FormWindowState.Normal;
		}

		// Token: 0x060006ED RID: 1773 RVA: 0x0003BF50 File Offset: 0x0003A150
		private void hyperlinkLabelForgotenPassword_Click(object sender, EventArgs e)
		{
			LoginForm.<hyperlinkLabelForgotenPassword_Click>d__8 <hyperlinkLabelForgotenPassword_Click>d__;
			<hyperlinkLabelForgotenPassword_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<hyperlinkLabelForgotenPassword_Click>d__.<>4__this = this;
			<hyperlinkLabelForgotenPassword_Click>d__.<>1__state = -1;
			<hyperlinkLabelForgotenPassword_Click>d__.<>t__builder.Start<LoginForm.<hyperlinkLabelForgotenPassword_Click>d__8>(ref <hyperlinkLabelForgotenPassword_Click>d__);
		}

		// Token: 0x060006EE RID: 1774 RVA: 0x0003BF88 File Offset: 0x0003A188
		private void LogonSuccessed()
		{
			this._formsSettings.SetUserLogin(this.textEditLogin.Text, this._logonResult.CustomerId);
			LoginForm.LoginInfo loginInfo = new LoginForm.LoginInfo
			{
				SaveLogin = this.checkEditSaveLogin.Checked,
				SavePassword = this.checkEditSavePassword.Checked
			};
			if (this.checkEditSaveLogin.Checked)
			{
				loginInfo.Login = this.textEditLogin.Text;
			}
			if (this.checkEditSavePassword.Checked)
			{
				loginInfo.Password = this.textEditPassword.Text;
			}
			this._appConfiguration.WriteEncryptedObjectToUserRegistry<LoginForm.LoginInfo>("loginInfo", loginInfo);
			if (this._logonResult.MessageToShow != null)
			{
				this._formCreator.Show<HtlmMessageForm, MessageWndToShow>(this._logonResult.MessageToShow);
				if (this._logonResult.MessageToShow.CloseApp)
				{
					base.DialogResult = DialogResult.Cancel;
					return;
				}
			}
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x0003C074 File Offset: 0x0003A274
		private Task TryLogon(string customerId)
		{
			LoginForm.<TryLogon>d__10 <TryLogon>d__;
			<TryLogon>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<TryLogon>d__.<>4__this = this;
			<TryLogon>d__.customerId = customerId;
			<TryLogon>d__.<>1__state = -1;
			<TryLogon>d__.<>t__builder.Start<LoginForm.<TryLogon>d__10>(ref <TryLogon>d__);
			return <TryLogon>d__.<>t__builder.Task;
		}

		// Token: 0x040004D4 RID: 1236
		private readonly ApiClient _apiClient;

		// Token: 0x040004D5 RID: 1237
		private readonly AppConfiguration _appConfiguration;

		// Token: 0x040004D6 RID: 1238
		private readonly CmdLineParams _cmdLineParams;

		// Token: 0x040004D7 RID: 1239
		private readonly string _language = "pl";

		// Token: 0x040004D8 RID: 1240
		private ApiLogonResult _logonResult;

		// Token: 0x02000184 RID: 388
		private class LoginInfo
		{
			// Token: 0x17000302 RID: 770
			// (get) Token: 0x06000BA1 RID: 2977 RVA: 0x00061936 File Offset: 0x0005FB36
			// (set) Token: 0x06000BA2 RID: 2978 RVA: 0x0006193E File Offset: 0x0005FB3E
			public string Login { get; set; }

			// Token: 0x17000303 RID: 771
			// (get) Token: 0x06000BA3 RID: 2979 RVA: 0x00061947 File Offset: 0x0005FB47
			// (set) Token: 0x06000BA4 RID: 2980 RVA: 0x0006194F File Offset: 0x0005FB4F
			public string Password { get; set; }

			// Token: 0x17000304 RID: 772
			// (get) Token: 0x06000BA5 RID: 2981 RVA: 0x00061958 File Offset: 0x0005FB58
			// (set) Token: 0x06000BA6 RID: 2982 RVA: 0x00061960 File Offset: 0x0005FB60
			public bool SaveLogin { get; set; }

			// Token: 0x17000305 RID: 773
			// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x00061969 File Offset: 0x0005FB69
			// (set) Token: 0x06000BA8 RID: 2984 RVA: 0x00061971 File Offset: 0x0005FB71
			public bool SavePassword { get; set; }
		}
	}
}
