﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000051 RID: 81
	public partial class CustomerInfoForm : CRUDBaseForm
	{
		// Token: 0x06000481 RID: 1153 RVA: 0x000149F5 File Offset: 0x00012BF5
		public CustomerInfoForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient) : base(formsSettings, formCreator, action, apiClient)
		{
			this.InitializeComponent();
			base.ActiveControl = this.textEditKeyDescription;
			this.textEditKeyDescription.ReadOnly = !apiClient.IsLoggedUserHasAdminPermission();
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x00014A29 File Offset: 0x00012C29
		public CustomerInfoForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x00014A37 File Offset: 0x00012C37
		protected override bool IsDataUpdated()
		{
			return this._customer != null && this._customer.KeyDescription != this.textEditKeyDescription.Text;
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x00014A60 File Offset: 0x00012C60
		protected override Task<bool> OnActionUpdate()
		{
			CustomerInfoForm.<OnActionUpdate>d__4 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<CustomerInfoForm.<OnActionUpdate>d__4>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x00014AA4 File Offset: 0x00012CA4
		private void CustomerInfoForm_Activated(object sender, EventArgs e)
		{
			CustomerInfoForm.<CustomerInfoForm_Activated>d__5 <CustomerInfoForm_Activated>d__;
			<CustomerInfoForm_Activated>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<CustomerInfoForm_Activated>d__.<>4__this = this;
			<CustomerInfoForm_Activated>d__.<>1__state = -1;
			<CustomerInfoForm_Activated>d__.<>t__builder.Start<CustomerInfoForm.<CustomerInfoForm_Activated>d__5>(ref <CustomerInfoForm_Activated>d__);
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x00014ADC File Offset: 0x00012CDC
		private Task FillCustomerInfo()
		{
			CustomerInfoForm.<FillCustomerInfo>d__6 <FillCustomerInfo>d__;
			<FillCustomerInfo>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<FillCustomerInfo>d__.<>4__this = this;
			<FillCustomerInfo>d__.<>1__state = -1;
			<FillCustomerInfo>d__.<>t__builder.Start<CustomerInfoForm.<FillCustomerInfo>d__6>(ref <FillCustomerInfo>d__);
			return <FillCustomerInfo>d__.<>t__builder.Task;
		}

		// Token: 0x040001C9 RID: 457
		private Customer _customer;
	}
}
