﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000076 RID: 118
	public partial class ProcessDefForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x0600063F RID: 1599 RVA: 0x0002FA86 File Offset: 0x0002DC86
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x0002FAA8 File Offset: 0x0002DCA8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ProcessDefForm));
			this.checkIsFavorite = new global::DevExpress.XtraEditors.CheckEdit();
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.checkEditAskForParameters = new global::DevExpress.XtraEditors.CheckEdit();
			this.checkEditAvailableForAll = new global::DevExpress.XtraEditors.CheckEdit();
			this.comboBoxShowMode = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.labelUserHelp = new global::DevExpress.XtraEditors.LabelControl();
			this.textEditFilePath = new global::DevExpress.XtraEditors.ButtonEdit();
			this.textEditUserPasswd = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditUserName = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditAppName = new global::DevExpress.XtraEditors.TextEdit();
			this.radioGroupUserType = new global::DevExpress.XtraEditors.RadioGroup();
			this.comboBoxMacro = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.textEditParams = new global::DevExpress.XtraEditors.TextEdit();
			this.controlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlGroupApp = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlParams = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControMacro = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlAppName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControIsFavorite = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlFilePath = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlShowMode = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControllEditAvailableForAll = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItem1 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroupUser = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlUserType = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlUserName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlUserPasswd = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlUserHelp = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.checkIsFavorite.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditAskForParameters.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditAvailableForAll.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxShowMode.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditFilePath.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserPasswd.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditAppName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.radioGroupUserType.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxMacro.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditParams.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.controlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupApp).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlParams).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControMacro).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlAppName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControIsFavorite).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlFilePath).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlShowMode).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControllEditAvailableForAll).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupUser).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserType).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserPasswd).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserHelp).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			resources.ApplyResources(this.checkIsFavorite, "checkIsFavorite");
			this.checkIsFavorite.Name = "checkIsFavorite";
			this.checkIsFavorite.Properties.Caption = resources.GetString("checkIsFavorite.Properties.Caption");
			this.checkIsFavorite.StyleController = this.layoutControlMain;
			this.layoutControlMain.Controls.Add(this.checkEditAskForParameters);
			this.layoutControlMain.Controls.Add(this.checkEditAvailableForAll);
			this.layoutControlMain.Controls.Add(this.comboBoxShowMode);
			this.layoutControlMain.Controls.Add(this.labelUserHelp);
			this.layoutControlMain.Controls.Add(this.textEditFilePath);
			this.layoutControlMain.Controls.Add(this.textEditUserPasswd);
			this.layoutControlMain.Controls.Add(this.textEditUserName);
			this.layoutControlMain.Controls.Add(this.checkIsFavorite);
			this.layoutControlMain.Controls.Add(this.textEditAppName);
			this.layoutControlMain.Controls.Add(this.radioGroupUserType);
			this.layoutControlMain.Controls.Add(this.comboBoxMacro);
			this.layoutControlMain.Controls.Add(this.textEditParams);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2637, 274, 812, 500));
			this.layoutControlMain.Root = this.controlGroupMain;
			resources.ApplyResources(this.checkEditAskForParameters, "checkEditAskForParameters");
			this.checkEditAskForParameters.Name = "checkEditAskForParameters";
			this.checkEditAskForParameters.Properties.Caption = resources.GetString("checkEditAskForParameters.Properties.Caption");
			this.checkEditAskForParameters.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.checkEditAvailableForAll, "checkEditAvailableForAll");
			this.checkEditAvailableForAll.Name = "checkEditAvailableForAll";
			this.checkEditAvailableForAll.Properties.Caption = resources.GetString("checkEditAvailableForAll.Properties.Caption");
			this.checkEditAvailableForAll.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxShowMode, "comboBoxShowMode");
			this.comboBoxShowMode.Name = "comboBoxShowMode";
			this.comboBoxShowMode.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxShowMode.Properties.Buttons"))
			});
			this.comboBoxShowMode.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxShowMode.StyleController = this.layoutControlMain;
			this.labelUserHelp.Appearance.Image = (global::System.Drawing.Image)resources.GetObject("labelUserHelp.Appearance.Image");
			this.labelUserHelp.Appearance.ImageAlign = global::System.Drawing.ContentAlignment.TopLeft;
			this.labelUserHelp.Appearance.ImageIndex = 0;
			this.labelUserHelp.Appearance.Options.UseImage = true;
			this.labelUserHelp.Appearance.Options.UseImageAlign = true;
			this.labelUserHelp.Appearance.Options.UseImageIndex = true;
			this.labelUserHelp.Appearance.Options.UseTextOptions = true;
			this.labelUserHelp.Appearance.TextOptions.WordWrap = global::DevExpress.Utils.WordWrap.Wrap;
			resources.ApplyResources(this.labelUserHelp, "labelUserHelp");
			this.labelUserHelp.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftTop;
			this.labelUserHelp.Name = "labelUserHelp";
			this.labelUserHelp.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditFilePath, "textEditFilePath");
			this.textEditFilePath.Name = "textEditFilePath";
			this.textEditFilePath.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.textEditFilePath.Properties.Mask.EditMask = resources.GetString("textEditFilePath.Properties.Mask.EditMask");
			this.textEditFilePath.Properties.NullValuePrompt = resources.GetString("textEditFilePath.Properties.NullValuePrompt");
			this.textEditFilePath.StyleController = this.layoutControlMain;
			this.textEditFilePath.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.textEditFilePath_ButtonClick);
			resources.ApplyResources(this.textEditUserPasswd, "textEditUserPasswd");
			this.textEditUserPasswd.Name = "textEditUserPasswd";
			this.textEditUserPasswd.Properties.Mask.EditMask = resources.GetString("textEditUserPasswd.Properties.Mask.EditMask");
			this.textEditUserPasswd.Properties.NullValuePrompt = resources.GetString("textEditUserPasswd.Properties.NullValuePrompt");
			this.textEditUserPasswd.Properties.PasswordChar = '*';
			this.textEditUserPasswd.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditUserName, "textEditUserName");
			this.textEditUserName.Name = "textEditUserName";
			this.textEditUserName.Properties.Mask.EditMask = resources.GetString("textEditUserName.Properties.Mask.EditMask");
			this.textEditUserName.Properties.NullValuePrompt = resources.GetString("textEditUserName.Properties.NullValuePrompt");
			this.textEditUserName.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditAppName, "textEditAppName");
			this.textEditAppName.Name = "textEditAppName";
			this.textEditAppName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditAppName.Properties.Mask.BeepOnError");
			this.textEditAppName.Properties.Mask.EditMask = resources.GetString("textEditAppName.Properties.Mask.EditMask");
			this.textEditAppName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditAppName.Properties.Mask.IgnoreMaskBlank");
			this.textEditAppName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditAppName.Properties.Mask.MaskType");
			this.textEditAppName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditAppName.Properties.Mask.ShowPlaceHolders");
			this.textEditAppName.Properties.NullValuePrompt = resources.GetString("textEditAppName.Properties.NullValuePrompt");
			this.textEditAppName.StyleController = this.layoutControlMain;
			this.radioGroupUserType.AutoSizeInLayoutControl = true;
			resources.ApplyResources(this.radioGroupUserType, "radioGroupUserType");
			this.radioGroupUserType.Name = "radioGroupUserType";
			this.radioGroupUserType.Properties.Appearance.BackColor = global::System.Drawing.Color.Transparent;
			this.radioGroupUserType.Properties.Appearance.Options.UseBackColor = true;
			this.radioGroupUserType.Properties.BorderStyle = global::DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.radioGroupUserType.Properties.Columns = 2;
			this.radioGroupUserType.Properties.GlyphAlignment = global::DevExpress.Utils.HorzAlignment.Default;
			this.radioGroupUserType.Properties.Items.AddRange(new global::DevExpress.XtraEditors.Controls.RadioGroupItem[]
			{
				new global::DevExpress.XtraEditors.Controls.RadioGroupItem(resources.GetObject("radioGroupUserType.Properties.Items"), resources.GetString("radioGroupUserType.Properties.Items1")),
				new global::DevExpress.XtraEditors.Controls.RadioGroupItem(resources.GetObject("radioGroupUserType.Properties.Items2"), resources.GetString("radioGroupUserType.Properties.Items3"))
			});
			this.radioGroupUserType.StyleController = this.layoutControlMain;
			this.radioGroupUserType.SelectedIndexChanged += new global::System.EventHandler(this.radioGroupUserType_SelectedIndexChanged);
			resources.ApplyResources(this.comboBoxMacro, "comboBoxMacro");
			this.comboBoxMacro.Name = "comboBoxMacro";
			this.comboBoxMacro.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxMacro.Properties.Buttons"))
			});
			this.comboBoxMacro.Properties.DropDownRows = 9;
			this.comboBoxMacro.Properties.NullValuePrompt = resources.GetString("comboBoxMacro.Properties.NullValuePrompt");
			this.comboBoxMacro.Properties.ShowToolTipForTrimmedText = global::DevExpress.Utils.DefaultBoolean.False;
			this.comboBoxMacro.Properties.Sorted = true;
			this.comboBoxMacro.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxMacro.StyleController = this.layoutControlMain;
			this.comboBoxMacro.SelectedValueChanged += new global::System.EventHandler(this.comboBoxMacro_SelectedValueChanged);
			resources.ApplyResources(this.textEditParams, "textEditParams");
			this.textEditParams.Name = "textEditParams";
			this.textEditParams.Properties.Mask.EditMask = resources.GetString("textEditParams.Properties.Mask.EditMask");
			this.textEditParams.Properties.NullValuePrompt = resources.GetString("textEditParams.Properties.NullValuePrompt");
			this.textEditParams.StyleController = this.layoutControlMain;
			this.controlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.controlGroupMain.GroupBordersVisible = false;
			this.controlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlGroupApp,
				this.layoutControlGroupUser
			});
			this.controlGroupMain.Name = "Root";
			this.controlGroupMain.Size = new global::System.Drawing.Size(612, 466);
			this.controlGroupMain.TextVisible = false;
			this.layoutControlGroupApp.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlParams,
				this.layoutControMacro,
				this.layoutControlAppName,
				this.layoutControIsFavorite,
				this.layoutControlFilePath,
				this.layoutControlShowMode,
				this.layoutControllEditAvailableForAll,
				this.layoutControlItem1
			});
			this.layoutControlGroupApp.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlGroupApp.Name = "layoutControlGroupApp";
			this.layoutControlGroupApp.Size = new global::System.Drawing.Size(592, 210);
			resources.ApplyResources(this.layoutControlGroupApp, "layoutControlGroupApp");
			this.layoutControlParams.Control = this.textEditParams;
			this.layoutControlParams.Location = new global::System.Drawing.Point(0, 118);
			this.layoutControlParams.Name = "layoutControlParams";
			this.layoutControlParams.Size = new global::System.Drawing.Size(407, 45);
			resources.ApplyResources(this.layoutControlParams, "layoutControlParams");
			this.layoutControlParams.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlParams.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControMacro.Control = this.comboBoxMacro;
			this.layoutControMacro.Location = new global::System.Drawing.Point(0, 72);
			this.layoutControMacro.MinSize = new global::System.Drawing.Size(112, 46);
			this.layoutControMacro.Name = "layoutControMacro";
			this.layoutControMacro.Size = new global::System.Drawing.Size(260, 46);
			this.layoutControMacro.SizeConstraintsType = global::DevExpress.XtraLayout.SizeConstraintsType.Custom;
			resources.ApplyResources(this.layoutControMacro, "layoutControMacro");
			this.layoutControMacro.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControMacro.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControlAppName.Control = this.textEditAppName;
			this.layoutControlAppName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlAppName.Name = "layoutControlAppName";
			this.layoutControlAppName.Size = new global::System.Drawing.Size(311, 72);
			resources.ApplyResources(this.layoutControlAppName, "layoutControlAppName");
			this.layoutControlAppName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlAppName.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControIsFavorite.Control = this.checkIsFavorite;
			this.layoutControIsFavorite.Location = new global::System.Drawing.Point(311, 0);
			this.layoutControIsFavorite.Name = "layoutControIsFavorite";
			this.layoutControIsFavorite.Size = new global::System.Drawing.Size(257, 24);
			resources.ApplyResources(this.layoutControIsFavorite, "layoutControIsFavorite");
			this.layoutControIsFavorite.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControIsFavorite.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControIsFavorite.TextVisible = false;
			this.layoutControlFilePath.Control = this.textEditFilePath;
			this.layoutControlFilePath.Location = new global::System.Drawing.Point(260, 72);
			this.layoutControlFilePath.Name = "layoutControlFilePath";
			this.layoutControlFilePath.Size = new global::System.Drawing.Size(308, 46);
			resources.ApplyResources(this.layoutControlFilePath, "layoutControlFilePath");
			this.layoutControlFilePath.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlFilePath.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControlShowMode.Control = this.comboBoxShowMode;
			this.layoutControlShowMode.Location = new global::System.Drawing.Point(407, 118);
			this.layoutControlShowMode.Name = "layoutControlShowMode";
			this.layoutControlShowMode.Size = new global::System.Drawing.Size(161, 45);
			resources.ApplyResources(this.layoutControlShowMode, "layoutControlShowMode");
			this.layoutControlShowMode.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlShowMode.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControllEditAvailableForAll.Control = this.checkEditAvailableForAll;
			this.layoutControllEditAvailableForAll.Location = new global::System.Drawing.Point(311, 24);
			this.layoutControllEditAvailableForAll.Name = "layoutControllEditAvailableForAll";
			this.layoutControllEditAvailableForAll.Size = new global::System.Drawing.Size(257, 24);
			this.layoutControllEditAvailableForAll.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControllEditAvailableForAll.TextVisible = false;
			this.layoutControlItem1.Control = this.checkEditAskForParameters;
			this.layoutControlItem1.Location = new global::System.Drawing.Point(311, 48);
			this.layoutControlItem1.Name = "layoutControlItem1";
			this.layoutControlItem1.Size = new global::System.Drawing.Size(257, 24);
			this.layoutControlItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem1.TextVisible = false;
			this.layoutControlGroupUser.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlUserType,
				this.layoutControlUserName,
				this.layoutControlUserPasswd,
				this.layoutControlUserHelp
			});
			this.layoutControlGroupUser.Location = new global::System.Drawing.Point(0, 210);
			this.layoutControlGroupUser.Name = "layoutControlGroupUser";
			this.layoutControlGroupUser.Size = new global::System.Drawing.Size(592, 236);
			resources.ApplyResources(this.layoutControlGroupUser, "layoutControlGroupUser");
			this.layoutControlUserType.Control = this.radioGroupUserType;
			this.layoutControlUserType.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlUserType.Name = "layoutControlUserType";
			this.layoutControlUserType.Size = new global::System.Drawing.Size(568, 49);
			resources.ApplyResources(this.layoutControlUserType, "layoutControlUserType");
			this.layoutControlUserType.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUserType.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControlUserName.Control = this.textEditUserName;
			this.layoutControlUserName.Location = new global::System.Drawing.Point(0, 49);
			this.layoutControlUserName.Name = "layoutControlUserName";
			this.layoutControlUserName.Size = new global::System.Drawing.Size(283, 45);
			resources.ApplyResources(this.layoutControlUserName, "layoutControlUserName");
			this.layoutControlUserName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUserName.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControlUserPasswd.Control = this.textEditUserPasswd;
			this.layoutControlUserPasswd.Location = new global::System.Drawing.Point(283, 49);
			this.layoutControlUserPasswd.Name = "layoutControlUserPasswd";
			this.layoutControlUserPasswd.Size = new global::System.Drawing.Size(285, 45);
			resources.ApplyResources(this.layoutControlUserPasswd, "layoutControlUserPasswd");
			this.layoutControlUserPasswd.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUserPasswd.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControlUserHelp.Control = this.labelUserHelp;
			this.layoutControlUserHelp.Location = new global::System.Drawing.Point(0, 94);
			this.layoutControlUserHelp.Name = "layoutControlUserHelp";
			this.layoutControlUserHelp.Size = new global::System.Drawing.Size(568, 95);
			this.layoutControlUserHelp.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlUserHelp.TextVisible = false;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("ProcessDefForm.IconOptions.Icon");
			base.Name = "ProcessDefForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.checkIsFavorite.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.checkEditAskForParameters.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditAvailableForAll.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxShowMode.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditFilePath.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserPasswd.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditAppName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.radioGroupUserType.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxMacro.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditParams.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.controlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupApp).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlParams).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControMacro).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlAppName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControIsFavorite).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlFilePath).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlShowMode).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControllEditAvailableForAll).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupUser).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserType).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserPasswd).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserHelp).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040003D6 RID: 982
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040003D7 RID: 983
		public global::DevExpress.XtraEditors.CheckEdit checkIsFavorite;

		// Token: 0x040003D8 RID: 984
		public global::DevExpress.XtraEditors.TextEdit textEditUserName;

		// Token: 0x040003D9 RID: 985
		public global::DevExpress.XtraEditors.TextEdit textEditUserPasswd;

		// Token: 0x040003DA RID: 986
		public global::DevExpress.XtraEditors.RadioGroup radioGroupUserType;

		// Token: 0x040003DB RID: 987
		public global::DevExpress.XtraEditors.TextEdit textEditAppName;

		// Token: 0x040003DC RID: 988
		public global::DevExpress.XtraEditors.TextEdit textEditParams;

		// Token: 0x040003DD RID: 989
		public global::DevExpress.XtraEditors.ComboBoxEdit comboBoxMacro;

		// Token: 0x040003DE RID: 990
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040003DF RID: 991
		private global::DevExpress.XtraLayout.LayoutControlGroup controlGroupMain;

		// Token: 0x040003E0 RID: 992
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupApp;

		// Token: 0x040003E1 RID: 993
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlParams;

		// Token: 0x040003E2 RID: 994
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControMacro;

		// Token: 0x040003E3 RID: 995
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlAppName;

		// Token: 0x040003E4 RID: 996
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControIsFavorite;

		// Token: 0x040003E5 RID: 997
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupUser;

		// Token: 0x040003E6 RID: 998
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserType;

		// Token: 0x040003E7 RID: 999
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserName;

		// Token: 0x040003E8 RID: 1000
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserPasswd;

		// Token: 0x040003E9 RID: 1001
		private global::DevExpress.XtraEditors.ButtonEdit textEditFilePath;

		// Token: 0x040003EA RID: 1002
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlFilePath;

		// Token: 0x040003EB RID: 1003
		private global::DevExpress.XtraEditors.LabelControl labelUserHelp;

		// Token: 0x040003EC RID: 1004
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserHelp;

		// Token: 0x040003ED RID: 1005
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxShowMode;

		// Token: 0x040003EE RID: 1006
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlShowMode;

		// Token: 0x040003EF RID: 1007
		private global::DevExpress.XtraEditors.CheckEdit checkEditAvailableForAll;

		// Token: 0x040003F0 RID: 1008
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControllEditAvailableForAll;

		// Token: 0x040003F1 RID: 1009
		private global::DevExpress.XtraEditors.CheckEdit checkEditAskForParameters;

		// Token: 0x040003F2 RID: 1010
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
	}
}
