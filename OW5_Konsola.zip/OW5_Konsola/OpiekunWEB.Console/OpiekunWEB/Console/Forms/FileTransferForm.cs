﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000068 RID: 104
	public partial class FileTransferForm : BaseForm
	{
		// Token: 0x06000589 RID: 1417 RVA: 0x00023160 File Offset: 0x00021360
		public FileTransferForm(FormCreator formCreator, FilesTransferFormParams @params) : base(null, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._params = @params;
			this._cts = new CancellationTokenSource();
			this.Text = (this._params.ReadFromRemote ? Resources.FileTransferForm_ReceivingFiles : Resources.FileTransferForm_SendFiles);
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x000231AD File Offset: 0x000213AD
		private void buttonCancel_Click(object sender, EventArgs e)
		{
			this._canceled = true;
			this._cts.Cancel();
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x000231C4 File Offset: 0x000213C4
		private void FormFileTransfer_Shown(object sender, EventArgs e)
		{
			FileTransferForm.<FormFileTransfer_Shown>d__8 <FormFileTransfer_Shown>d__;
			<FormFileTransfer_Shown>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<FormFileTransfer_Shown>d__.<>4__this = this;
			<FormFileTransfer_Shown>d__.<>1__state = -1;
			<FormFileTransfer_Shown>d__.<>t__builder.Start<FileTransferForm.<FormFileTransfer_Shown>d__8>(ref <FormFileTransfer_Shown>d__);
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x000231FB File Offset: 0x000213FB
		private void OnFileHashCalcStart(object sender, AgentFileTransferArgs args)
		{
			this.labelFileInfo.Text = string.Format(Resources.FileTransferForm_CalculatingFileHash, args.FileName);
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x00023218 File Offset: 0x00021418
		private void OnFilesBunchTransferProgres(object sender, AgentFilesBunchTransferProgressArgs args)
		{
			if ((ulong)SystemHelpers.GetTickCount() - this._lastProgressRefreshTick > 350UL)
			{
				this.progressBarAllFiles.Position = args.Progress;
				this.labelAllFilesInfo.Text = string.Format(Resources.FileTransferForm_MultipleFileInfo, new object[]
				{
					args.CurrentFileNo,
					args.FilesCount,
					LangStringUtils.StringRepresentingFileSize(args.BytesTransfered),
					LangStringUtils.StringRepresentingFileSize(args.BytesToTransfer),
					LangStringUtils.StringRepresentingFileSize(args.BytesPerSec),
					LangStringUtils.StringRepresentingRemainSec(args.SecRemain)
				});
				this._lastProgressRefreshTick = (ulong)SystemHelpers.GetTickCount();
			}
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x000232CC File Offset: 0x000214CC
		private void OnFileTransferEnd(object sender, AgentFileTransferEndArgs args)
		{
			this.labelFileInfo.Text = string.Format(Resources.FileTransferForm_FileTransferCompleted, args.FileName);
			FilesTransferFormParams @params = this._params;
			if (@params != null)
			{
				Action<string> messageLogAction = @params.MessageLogAction;
				if (messageLogAction != null)
				{
					messageLogAction(args.Result.GetDescription());
				}
			}
			FilesTransferFormParams params2 = this._params;
			if (params2 != null)
			{
				Action<AgentFileTransferEndArgs> fileTransferEndAction = params2.FileTransferEndAction;
				if (fileTransferEndAction != null)
				{
					fileTransferEndAction(args);
				}
			}
			if (args.Result == AgentFileTransferResult.Success)
			{
				this.progressBarFile.Position = 100;
			}
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x00023350 File Offset: 0x00021550
		private void OnFileTransferProgress(object sender, AgentFileTransferProgressArgs args)
		{
			if ((ulong)SystemHelpers.GetTickCount() - this._lastProgressRefreshTick > 350UL)
			{
				this.progressBarFile.Position = args.Progress;
				this.labelFileInfo.Text = string.Format(Resources.FileTransferForm_SingleFileInfo, new object[]
				{
					args.FileName,
					LangStringUtils.StringRepresentingFileSize(args.BytesTransfered),
					LangStringUtils.StringRepresentingFileSize(args.BytesToTransfer),
					LangStringUtils.StringRepresentingFileSize(args.BytesPerSec),
					LangStringUtils.StringRepresentingRemainSec(args.SecRemain)
				});
			}
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x000233E0 File Offset: 0x000215E0
		private void OnFileTransferStart(object sender, AgentFileTransferArgs args)
		{
			this._lastProgressRefreshTick = 0UL;
			if (this._params.ReadFromRemote)
			{
				string msg = string.Format(Resources.FileTransferForm_FileReceivingStarted, args.FileName);
				this.labelFileInfo.Text = msg;
				FilesTransferFormParams @params = this._params;
				if (@params == null)
				{
					return;
				}
				Action<string> messageLogAction = @params.MessageLogAction;
				if (messageLogAction == null)
				{
					return;
				}
				messageLogAction(msg.Replace("\r", " ").Replace("\n", " "));
				return;
			}
			else
			{
				string msg2 = string.Format(Resources.FileTransferForm_FileSendingStarted, args.FileName);
				this.labelFileInfo.Text = msg2;
				FilesTransferFormParams params2 = this._params;
				if (params2 == null)
				{
					return;
				}
				Action<string> messageLogAction2 = params2.MessageLogAction;
				if (messageLogAction2 == null)
				{
					return;
				}
				messageLogAction2(msg2.Replace("\r", " ").Replace("\n", " "));
				return;
			}
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x000234B0 File Offset: 0x000216B0
		private void ReaderOnFileOverride(object sender, AgentFileTransferOverrideArgs args)
		{
			if (this._overrideAlways)
			{
				args.Action = FileOverrideAction.Override;
				return;
			}
			FileOverrideQuestionFormParams @params = new FileOverrideQuestionFormParams(args.FileName, true);
			this._formCreator.Show<FileOverrideQuestionForm, FileOverrideQuestionFormParams>(FormAction.Unknown, @params, out @params);
			args.Action = @params.Action;
			this._overrideAlways = (args.Action == FileOverrideAction.OverrideAllways);
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x00023508 File Offset: 0x00021708
		private Task StartTransfer()
		{
			FileTransferForm.<StartTransfer>d__15 <StartTransfer>d__;
			<StartTransfer>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<StartTransfer>d__.<>4__this = this;
			<StartTransfer>d__.<>1__state = -1;
			<StartTransfer>d__.<>t__builder.Start<FileTransferForm.<StartTransfer>d__15>(ref <StartTransfer>d__);
			return <StartTransfer>d__.<>t__builder.Task;
		}

		// Token: 0x040002EB RID: 747
		private const int ProgressRefreshTime = 350;

		// Token: 0x040002EC RID: 748
		private readonly CancellationTokenSource _cts;

		// Token: 0x040002ED RID: 749
		private readonly FilesTransferFormParams _params;

		// Token: 0x040002EE RID: 750
		private bool _canceled;

		// Token: 0x040002EF RID: 751
		private ulong _lastProgressRefreshTick;

		// Token: 0x040002F0 RID: 752
		private bool _overrideAlways;
	}
}
