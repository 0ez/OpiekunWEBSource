﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000080 RID: 128
	public partial class UrlCategoryForm : CRUDBaseForm
	{
		// Token: 0x060006D7 RID: 1751 RVA: 0x0003AB8C File Offset: 0x00038D8C
		public UrlCategoryForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, URLCategory urlCategory) : base(formsSettings, formCreator, action, apiClient)
		{
			this._urlCategory = urlCategory;
			this.InitializeComponent();
			this._rolesState = new Dictionary<string, ControlState>();
			this.InitalizeRolesStates();
			this._prevRolesState = new Dictionary<string, ControlState>(this._rolesState);
			this.imageComboBoxCategoryState.Properties.Items.AddEnum<ControlState>((ControlState state) => state.GetDescription());
			this.imageComboBoxRoleState.Items.AddEnum<ControlState>((ControlState state) => state.GetDescription());
			this.imageComboBoxRoleState.Items.RemoveAt(3);
			if (action == FormAction.Update)
			{
				this.textEditCategoryName.Text = this._urlCategory.Name;
				this.textEditCategoryDescription.Text = this._urlCategory.Description;
				if (this.IsSystemCategory())
				{
					this.textEditCategoryName.ReadOnly = true;
					this.textEditCategoryDescription.ReadOnly = true;
				}
				this._prevCategoryState = this._apiClient.GetURLCategoryControlState(this._urlCategory.Id);
			}
			else
			{
				this._prevCategoryState = ControlState.Block;
			}
			this.imageComboBoxCategoryState.EditValue = this._prevCategoryState;
			this.gridCategoryState.DataSource = this._apiClient.Roles;
			this.layoutControlGrid.ContentVisible = (this._prevCategoryState == ControlState.DependsOnUser);
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x0003AD00 File Offset: 0x00038F00
		protected Task CreateURLCategory()
		{
			UrlCategoryForm.<CreateURLCategory>d__5 <CreateURLCategory>d__;
			<CreateURLCategory>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CreateURLCategory>d__.<>4__this = this;
			<CreateURLCategory>d__.<>1__state = -1;
			<CreateURLCategory>d__.<>t__builder.Start<UrlCategoryForm.<CreateURLCategory>d__5>(ref <CreateURLCategory>d__);
			return <CreateURLCategory>d__.<>t__builder.Task;
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x0003AD44 File Offset: 0x00038F44
		protected ControlState GetSelectedCategoryState()
		{
			ControlState? controlState = this.imageComboBoxCategoryState.EditValue as ControlState?;
			if (controlState == null)
			{
				return ControlState.Block;
			}
			return controlState.GetValueOrDefault();
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x0003AD7C File Offset: 0x00038F7C
		protected void InitalizeRolesStates()
		{
			if (base.Action != FormAction.Create)
			{
				foreach (Role role in from x in this._apiClient.Roles
				where x.RoleType == RoleType.WindowsUsers
				select x)
				{
					this._rolesState[role.Id] = this._apiClient.GetURLCategoryControlStateForRole(role.Id, this._urlCategory.Id);
				}
			}
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x0003AE24 File Offset: 0x00039024
		protected override bool IsDataUpdated()
		{
			ControlState? state = this.imageComboBoxCategoryState.EditValue as ControlState?;
			ControlState? controlState = state;
			ControlState controlState2 = ControlState.DependsOnUser;
			bool rolesStateChanged = (controlState.GetValueOrDefault() == controlState2 & controlState != null) && this.IsRolesStateChanged();
			return state.Value != this._prevCategoryState || this.textEditCategoryName.Text != this._urlCategory.Name || this.textEditCategoryDescription.Text != this._urlCategory.Description || rolesStateChanged;
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x0003AEB8 File Offset: 0x000390B8
		protected override Task<bool> OnActionCreate()
		{
			UrlCategoryForm.<OnActionCreate>d__9 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<UrlCategoryForm.<OnActionCreate>d__9>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x0003AEFC File Offset: 0x000390FC
		protected override Task<bool> OnActionUpdate()
		{
			UrlCategoryForm.<OnActionUpdate>d__10 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<UrlCategoryForm.<OnActionUpdate>d__10>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x0003AF40 File Offset: 0x00039140
		protected Task UpdateCategory()
		{
			UrlCategoryForm.<UpdateCategory>d__11 <UpdateCategory>d__;
			<UpdateCategory>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UpdateCategory>d__.<>4__this = this;
			<UpdateCategory>d__.<>1__state = -1;
			<UpdateCategory>d__.<>t__builder.Start<UrlCategoryForm.<UpdateCategory>d__11>(ref <UpdateCategory>d__);
			return <UpdateCategory>d__.<>t__builder.Task;
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x0003AF84 File Offset: 0x00039184
		protected Task UpdateCategoryStateForRoles(string categoryId)
		{
			UrlCategoryForm.<UpdateCategoryStateForRoles>d__12 <UpdateCategoryStateForRoles>d__;
			<UpdateCategoryStateForRoles>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UpdateCategoryStateForRoles>d__.<>4__this = this;
			<UpdateCategoryStateForRoles>d__.categoryId = categoryId;
			<UpdateCategoryStateForRoles>d__.<>1__state = -1;
			<UpdateCategoryStateForRoles>d__.<>t__builder.Start<UrlCategoryForm.<UpdateCategoryStateForRoles>d__12>(ref <UpdateCategoryStateForRoles>d__);
			return <UpdateCategoryStateForRoles>d__.<>t__builder.Task;
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x0003AFCF File Offset: 0x000391CF
		private ControlState GetControlStateForRole(string roleId)
		{
			if (this._rolesState.ContainsKey(roleId))
			{
				return this._rolesState[roleId];
			}
			return ControlState.Block;
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x0003AFED File Offset: 0x000391ED
		private ControlState GetPrevControlStateForRole(string roleId)
		{
			if (this._prevRolesState.ContainsKey(roleId))
			{
				return this._prevRolesState[roleId];
			}
			return ControlState.Block;
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x0003B00C File Offset: 0x0003920C
		private void gridViewCategoryState_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			object roleType = (sender as ColumnView).GetListSourceRowCellValue(e.ListSourceRow, "RoleType");
			e.Visible = (roleType != null && (RoleType)roleType == RoleType.WindowsUsers);
			e.Handled = true;
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x0003B04C File Offset: 0x0003924C
		private void gridViewCategoryState_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			if (e.Column.FieldName == "State" && e.IsGetData && e.IsGetData)
			{
				Role role = e.Row as Role;
				if (role != null)
				{
					e.Value = this.GetControlStateForRole(role.Id);
				}
			}
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x0003B0A8 File Offset: 0x000392A8
		private void imageComboBoxRoleState_EditValueChanging(object sender, ChangingEventArgs e)
		{
			Role role = this.gridViewCategoryState.GetFocusedRow() as Role;
			if (role != null)
			{
				ControlState state = ((ControlState?)e.NewValue).Value;
				this._rolesState[role.Id] = state;
			}
		}

		// Token: 0x060006E5 RID: 1765 RVA: 0x0003B0EF File Offset: 0x000392EF
		private void imageComboCategoryState_EditValueChanged(object sender, EventArgs e)
		{
			this.layoutControlGrid.ContentVisible = (this.GetSelectedCategoryState() == ControlState.DependsOnUser);
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x0003B108 File Offset: 0x00039308
		private bool IsRolesStateChanged()
		{
			return !(from k in this._rolesState
			orderby k.Key
			select k).SequenceEqual(from k in this._prevRolesState
			orderby k.Key
			select k);
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x0003B171 File Offset: 0x00039371
		private bool IsSystemCategory()
		{
			return int.Parse(this._urlCategory.Id) < 128;
		}

		// Token: 0x040004BE RID: 1214
		private readonly ControlState _prevCategoryState;

		// Token: 0x040004BF RID: 1215
		private readonly Dictionary<string, ControlState> _prevRolesState;

		// Token: 0x040004C0 RID: 1216
		private readonly Dictionary<string, ControlState> _rolesState;

		// Token: 0x040004C1 RID: 1217
		private readonly URLCategory _urlCategory;
	}
}
