﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000070 RID: 112
	public partial class AppUpdateForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060005F3 RID: 1523 RVA: 0x000299CB File Offset: 0x00027BCB
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x000299EC File Offset: 0x00027BEC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.AppUpdateForm));
			this.webBrowserLogInfo = new global::System.Windows.Forms.WebBrowser();
			this.labelInfo = new global::DevExpress.XtraEditors.LabelControl();
			this.labelCurrentVersion = new global::DevExpress.XtraEditors.LabelControl();
			this.labelNewVersion = new global::DevExpress.XtraEditors.LabelControl();
			this.panelBottom = new global::System.Windows.Forms.Panel();
			this.buttonDownload = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonUpdate = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonRemindLater = new global::DevExpress.XtraEditors.SimpleButton();
			this.panelBottom.SuspendLayout();
			base.SuspendLayout();
			resources.ApplyResources(this.webBrowserLogInfo, "webBrowserLogInfo");
			this.webBrowserLogInfo.Name = "webBrowserLogInfo";
			this.webBrowserLogInfo.Url = new global::System.Uri("", global::System.UriKind.Relative);
			this.webBrowserLogInfo.DocumentCompleted += new global::System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowserLogInfo_DocumentCompleted);
			resources.ApplyResources(this.labelInfo, "labelInfo");
			this.labelInfo.Appearance.Font = (global::System.Drawing.Font)resources.GetObject("labelInfo.Appearance.Font");
			this.labelInfo.Appearance.Options.UseFont = true;
			this.labelInfo.Name = "labelInfo";
			resources.ApplyResources(this.labelCurrentVersion, "labelCurrentVersion");
			this.labelCurrentVersion.Name = "labelCurrentVersion";
			this.labelNewVersion.Appearance.ForeColor = global::System.Drawing.Color.Teal;
			this.labelNewVersion.Appearance.Options.UseForeColor = true;
			resources.ApplyResources(this.labelNewVersion, "labelNewVersion");
			this.labelNewVersion.Name = "labelNewVersion";
			this.panelBottom.Controls.Add(this.buttonDownload);
			this.panelBottom.Controls.Add(this.buttonUpdate);
			this.panelBottom.Controls.Add(this.buttonRemindLater);
			resources.ApplyResources(this.panelBottom, "panelBottom");
			this.panelBottom.Name = "panelBottom";
			resources.ApplyResources(this.buttonDownload, "buttonDownload");
			this.buttonDownload.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonDownload.ImageOptions.Image");
			this.buttonDownload.ImageOptions.ImageToTextAlignment = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.buttonDownload.Name = "buttonDownload";
			this.buttonDownload.Click += new global::System.EventHandler(this.buttonDownload_Click);
			resources.ApplyResources(this.buttonUpdate, "buttonUpdate");
			this.buttonUpdate.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonUpdate.ImageOptions.Image");
			this.buttonUpdate.ImageOptions.ImageToTextAlignment = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.buttonUpdate.Name = "buttonUpdate";
			this.buttonUpdate.Click += new global::System.EventHandler(this.buttonUpdate_Click);
			resources.ApplyResources(this.buttonRemindLater, "buttonRemindLater");
			this.buttonRemindLater.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonRemindLater.ImageOptions.Image");
			this.buttonRemindLater.ImageOptions.ImageToTextAlignment = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.buttonRemindLater.Name = "buttonRemindLater";
			this.buttonRemindLater.Click += new global::System.EventHandler(this.buttonRemindLater_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.panelBottom);
			base.Controls.Add(this.labelNewVersion);
			base.Controls.Add(this.labelCurrentVersion);
			base.Controls.Add(this.labelInfo);
			base.Controls.Add(this.webBrowserLogInfo);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("AppUpdateForm.IconOptions.Icon");
			base.MaximizeBox = true;
			base.Name = "AppUpdateForm";
			this.panelBottom.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000376 RID: 886
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000377 RID: 887
		private global::System.Windows.Forms.WebBrowser webBrowserLogInfo;

		// Token: 0x04000378 RID: 888
		public global::DevExpress.XtraEditors.LabelControl labelInfo;

		// Token: 0x04000379 RID: 889
		private global::DevExpress.XtraEditors.LabelControl labelCurrentVersion;

		// Token: 0x0400037A RID: 890
		private global::DevExpress.XtraEditors.LabelControl labelNewVersion;

		// Token: 0x0400037B RID: 891
		private global::System.Windows.Forms.Panel panelBottom;

		// Token: 0x0400037C RID: 892
		private global::DevExpress.XtraEditors.SimpleButton buttonDownload;

		// Token: 0x0400037D RID: 893
		private global::DevExpress.XtraEditors.SimpleButton buttonUpdate;

		// Token: 0x0400037E RID: 894
		private global::DevExpress.XtraEditors.SimpleButton buttonRemindLater;
	}
}
