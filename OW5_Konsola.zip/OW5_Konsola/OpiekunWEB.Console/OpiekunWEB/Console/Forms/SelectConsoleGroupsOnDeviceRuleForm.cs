﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Card;
using DevExpress.XtraLayout;
using Google.Protobuf;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000073 RID: 115
	public partial class SelectConsoleGroupsOnDeviceRuleForm : CRUDBaseForm
	{
		// Token: 0x06000609 RID: 1545 RVA: 0x0002B453 File Offset: 0x00029653
		public SelectConsoleGroupsOnDeviceRuleForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x0002B464 File Offset: 0x00029664
		public SelectConsoleGroupsOnDeviceRuleForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, DevicesTree devicesTree, SelectConsoleGroupsOnDeviceRuleFormParams @params) : base(formsSettings, formCreator, action, apiClient)
		{
			this.InitializeComponent();
			this._targetDevices = new List<DeviceItem>();
			this._devicesTree = devicesTree;
			this._params = @params;
			this.imageComboBoxDeviceGroupsSelectMode.Properties.Items.Clear();
			this.imageComboBoxDeviceGroupsSelectMode.Properties.Items.AddRange(new ImageComboBoxItem[]
			{
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<DeviceGroupsSelectMode>(DeviceGroupsSelectMode.DeviceGroupsSelectAll, null, null), DeviceGroupsSelectMode.DeviceGroupsSelectAll, -1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<DeviceGroupsSelectMode>(DeviceGroupsSelectMode.DeviceGroupsSelectDependOnAgentGroup, null, null), DeviceGroupsSelectMode.DeviceGroupsSelectDependOnAgentGroup, -1),
				new ImageComboBoxItem(SsStringUtils.GetEnumDescriptionFromResource<DeviceGroupsSelectMode>(DeviceGroupsSelectMode.DeviceGroupsSelectOneGroupByUser, null, null), DeviceGroupsSelectMode.DeviceGroupsSelectOneGroupByUser, -1)
			});
			this.checkedComboBoxRoles.Properties.DataSource = from x in this._apiClient.Roles
			where x.RoleType == RoleType.ApiUsers
			select x;
			this.InitData();
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x0002B558 File Offset: 0x00029758
		protected Rule GetRule()
		{
			Rule rule = new Rule();
			rule.MergeFrom(this._params.Rule);
			rule.Name = this.textEditRuleName.Text;
			this._selectConsoleGroupsRule.Target.UnrecognizedDevices = this.checkEditApplyForUnrecognized.Checked;
			this._selectConsoleGroupsRule.Target.Roles.Clear();
			this._selectConsoleGroupsRule.Target.Roles.AddRange(this.checkedComboBoxRoles.Properties.Items.GetCheckedValues().Cast<string>());
			this._selectConsoleGroupsRule.DeviceGroupsSelectMode = (DeviceGroupsSelectMode)this.imageComboBoxDeviceGroupsSelectMode.EditValue;
			rule.Payload = ByteString.CopyFrom(this._selectConsoleGroupsRule.ToByteArray());
			return rule;
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x0002B61C File Offset: 0x0002981C
		protected override bool IsDataUpdated()
		{
			return this._params.Rule.ToString() != this.GetRule().ToString();
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x0002B640 File Offset: 0x00029840
		protected override bool IsDataValid()
		{
			if (this.checkedComboBoxRoles.Properties.GetItems().GetCheckedValues().Count == 0)
			{
				this.checkedComboBoxRoles.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
				return false;
			}
			if (this._targetDevices.Count == 0 && !this.checkEditApplyForUnrecognized.Checked)
			{
				this._formCreator.ShowError(Resources.SelectConsoleGroupsOnDeviceRuleForm_MustSelectDevice);
				return false;
			}
			if (this.imageComboBoxDeviceGroupsSelectMode.SelectedItem == null)
			{
				this.imageComboBoxDeviceGroupsSelectMode.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
				return false;
			}
			return true;
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x0002B6D4 File Offset: 0x000298D4
		protected override Task<bool> OnActionCreate()
		{
			SelectConsoleGroupsOnDeviceRuleForm.<OnActionCreate>d__9 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<SelectConsoleGroupsOnDeviceRuleForm.<OnActionCreate>d__9>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x0002B718 File Offset: 0x00029918
		protected override Task<bool> OnActionUpdate()
		{
			SelectConsoleGroupsOnDeviceRuleForm.<OnActionUpdate>d__10 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<SelectConsoleGroupsOnDeviceRuleForm.<OnActionUpdate>d__10>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x0002B75C File Offset: 0x0002995C
		private void buttonEditAvailableDeviceGroups_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			DeviceGroupsSelectionFormParams @params = new DeviceGroupsSelectionFormParams(this._selectConsoleGroupsRule.DeviceGroups.ToList<string>(), true);
			if (this._formCreator.Show<DeviceGroupsSelectionForm, DeviceGroupsSelectionFormParams>(FormAction.Unknown, @params, out @params))
			{
				this._selectConsoleGroupsRule.DeviceGroups.Clear();
				this._selectConsoleGroupsRule.DeviceGroups.AddRange(@params.SelectedGroupsId);
				this.SetAvailableDevicesGroupText();
			}
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x0002B7C0 File Offset: 0x000299C0
		private void buttonSelectDevices_Click(object sender, EventArgs e)
		{
			DevicesSelectionFormParams @params = new DevicesSelectionFormParams(this._targetDevices.Cast<DeviceTreeItemBase>().ToList<DeviceTreeItemBase>(), DeviceTreeItemsType.DeviceGroup | DeviceTreeItemsType.Device, DeviceTreeItemsType.Device, DeviceTreeItemsType.Device, false);
			if (this._formCreator.Show<DevicesSelectionForm, DevicesSelectionFormParams>(FormAction.Unknown, @params, out @params))
			{
				this._targetDevices = @params.SelectedItems.OfType<DeviceItem>().ToList<DeviceItem>();
				this._selectConsoleGroupsRule.Target.Devices.Clear();
				this._selectConsoleGroupsRule.Target.Devices.AddRange((from x in this._targetDevices
				select x.Id).ToList<string>());
				this.gridDevices.DataSource = this._targetDevices;
			}
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x0002B87C File Offset: 0x00029A7C
		private void InitData()
		{
			this._selectConsoleGroupsRule = new SelectConsoleGroupsOnDeviceRule();
			if (base.Action == FormAction.Create)
			{
				this._params.Rule = new Rule
				{
					AppType = AppType.ConsoleApp,
					RuleType = RuleType.SelectConsoleGroupsOnDevice
				};
				this._selectConsoleGroupsRule.DeviceGroupsSelectMode = DeviceGroupsSelectMode.DeviceGroupsSelectAll;
			}
			else
			{
				this._selectConsoleGroupsRule.MergeFrom(this._params.Rule.Payload);
			}
			if (this._selectConsoleGroupsRule.Target == null)
			{
				this._selectConsoleGroupsRule.Target = new RuleTargetRoleAndDevices();
			}
			this.textEditRuleName.Text = this._params.Rule.Name;
			this.imageComboBoxDeviceGroupsSelectMode.EditValue = this._selectConsoleGroupsRule.DeviceGroupsSelectMode;
			this.checkedComboBoxRoles.SetEditValue(this._selectConsoleGroupsRule.Target.Roles.ToList<string>());
			this.checkEditApplyForUnrecognized.Checked = this._selectConsoleGroupsRule.Target.UnrecognizedDevices;
			this._targetDevices = (from x in this._devicesTree.ItemList.OfType<DeviceItem>()
			where this._selectConsoleGroupsRule.Target.Devices.Contains(x.Id)
			select x).ToList<DeviceItem>();
			this.gridDevices.DataSource = this._targetDevices;
			this.SetAvailableDevicesGroupText();
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x0002B9B8 File Offset: 0x00029BB8
		private void SetAvailableDevicesGroupText()
		{
			List<string> groupNames = this._apiClient.DeviceGroupsIdToNames(this._selectConsoleGroupsRule.DeviceGroups.ToList<string>());
			this.buttonEditAvailableDeviceGroups.Text = (groupNames.Any<string>() ? (SsStringUtils.ListToSeparatedString(groupNames, ", ") ?? "") : Resources.AvailableDeviceGoupsEmpty);
		}

		// Token: 0x04000396 RID: 918
		private readonly DevicesTree _devicesTree;

		// Token: 0x04000397 RID: 919
		private readonly SelectConsoleGroupsOnDeviceRuleFormParams _params;

		// Token: 0x04000398 RID: 920
		private SelectConsoleGroupsOnDeviceRule _selectConsoleGroupsRule;

		// Token: 0x04000399 RID: 921
		private List<DeviceItem> _targetDevices;
	}
}
