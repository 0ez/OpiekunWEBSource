﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007F RID: 127
	public partial class ScreenshotZoomForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060006D5 RID: 1749 RVA: 0x0003A95B File Offset: 0x00038B5B
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x0003A97C File Offset: 0x00038B7C
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ScreenshotZoomForm));
			this.pictureScreenshot = new global::DevExpress.XtraEditors.PictureEdit();
			this.timerRefresh = new global::System.Windows.Forms.Timer(this.components);
			((global::System.ComponentModel.ISupportInitialize)this.pictureScreenshot.Properties).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.pictureScreenshot, "pictureScreenshot");
			this.pictureScreenshot.Name = "pictureScreenshot";
			this.pictureScreenshot.Properties.Appearance.BackColor = global::System.Drawing.Color.Black;
			this.pictureScreenshot.Properties.Appearance.ForeColor = global::System.Drawing.Color.White;
			this.pictureScreenshot.Properties.Appearance.Options.UseBackColor = true;
			this.pictureScreenshot.Properties.Appearance.Options.UseForeColor = true;
			this.pictureScreenshot.Properties.NullText = resources.GetString("pictureScreenshot.Properties.NullText");
			this.pictureScreenshot.Properties.PictureInterpolationMode = global::System.Drawing.Drawing2D.InterpolationMode.High;
			this.pictureScreenshot.Properties.ReadOnly = true;
			this.pictureScreenshot.Properties.ShowMenu = false;
			this.pictureScreenshot.Properties.SizeMode = global::DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
			this.pictureScreenshot.MouseClick += new global::System.Windows.Forms.MouseEventHandler(this.pictureScreenshot_MouseClick);
			this.pictureScreenshot.MouseLeave += new global::System.EventHandler(this.pictureScreenshot_MouseLeave);
			this.timerRefresh.Tick += new global::System.EventHandler(this.timerRefresh_Tick);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.None;
			resources.ApplyResources(this, "$this");
			base.Controls.Add(this.pictureScreenshot);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "ScreenshotZoomForm";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.SizeGripStyle = global::System.Windows.Forms.SizeGripStyle.Hide;
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.FormScreenshotZoom_FormClosing);
			base.Shown += new global::System.EventHandler(this.FormScreenshotZoom_Shown);
			((global::System.ComponentModel.ISupportInitialize)this.pictureScreenshot.Properties).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040004BB RID: 1211
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040004BC RID: 1212
		private global::DevExpress.XtraEditors.PictureEdit pictureScreenshot;

		// Token: 0x040004BD RID: 1213
		private global::System.Windows.Forms.Timer timerRefresh;
	}
}
