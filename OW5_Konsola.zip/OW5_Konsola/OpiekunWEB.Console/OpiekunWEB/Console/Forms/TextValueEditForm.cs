﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Mask;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007C RID: 124
	public partial class TextValueEditForm : BaseForm
	{
		// Token: 0x06000685 RID: 1669 RVA: 0x00034EBC File Offset: 0x000330BC
		public TextValueEditForm(IFormCreator formCreator, FormAction action, TextValueEditFormParams @params) : base(null, formCreator, action)
		{
			this._params = @params;
			this.InitializeComponent();
			this.Text = this._params.Title;
			this.textEditValue.Text = this._params.Value;
			this.labelDescription.Text = this._params.Description;
			if (!this.labelDescription.Text.EndsWith(":"))
			{
				LabelControl labelControl = this.labelDescription;
				labelControl.Text += ":";
			}
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x00034F4E File Offset: 0x0003314E
		private void FormTextValueEdit_Load(object sender, EventArgs e)
		{
			this.textEditValue.DataBindings.Add("Text", this._params, "Value");
			base.ActiveControl = this.textEditValue;
		}

		// Token: 0x0400044E RID: 1102
		private readonly TextValueEditFormParams _params;
	}
}
