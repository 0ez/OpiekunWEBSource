﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraWaitForm;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000085 RID: 133
	public partial class WaitForTaskForm : BaseForm
	{
		// Token: 0x06000738 RID: 1848 RVA: 0x0003EF32 File Offset: 0x0003D132
		public WaitForTaskForm(IFormCreator formCreator, WaitForTaskFormParams @params) : base(null, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this.progressPanel.Caption = @params.Title;
			this._params = @params;
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x0003EF5B File Offset: 0x0003D15B
		private void buttonCancel_Click(object sender, EventArgs e)
		{
			this._params.CTS.Cancel();
			base.DialogResult = DialogResult.Cancel;
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x0003EF74 File Offset: 0x0003D174
		private void WaitForTaskForm_Load(object sender, EventArgs e)
		{
			WaitForTaskForm.<WaitForTaskForm_Load>d__3 <WaitForTaskForm_Load>d__;
			<WaitForTaskForm_Load>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<WaitForTaskForm_Load>d__.<>4__this = this;
			<WaitForTaskForm_Load>d__.<>1__state = -1;
			<WaitForTaskForm_Load>d__.<>t__builder.Start<WaitForTaskForm.<WaitForTaskForm_Load>d__3>(ref <WaitForTaskForm_Load>d__);
		}

		// Token: 0x04000514 RID: 1300
		private readonly WaitForTaskFormParams _params;
	}
}
