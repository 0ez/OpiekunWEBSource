﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraLayout;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000074 RID: 116
	public partial class SelectRemoteFileForm : BaseForm
	{
		// Token: 0x06000617 RID: 1559 RVA: 0x0002D708 File Offset: 0x0002B908
		public SelectRemoteFileForm(FormsSettings formsSettings, IFormCreator formCreator, SelectRemoteFileFormParams @params) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._macroList = Macros.GetDirMacrosAsStringKeyValueList(true);
			this.comboBoxSendDestinationDirMacro.Properties.Items.AddRange(this._macroList);
			this.comboBoxSendDestinationDirMacro.SelectedItem = this._macroList.Find((StringKeyAndValue x) => x.Key == "{?}");
			this._params = @params;
			this.Text = ((this._params.SelectionMode == FileOrFolder.File) ? Resources.SelectRemoteFileForm_FileModeCaption : Resources.SelectRemoteFileForm_FolderModeCaption);
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x0002D7A8 File Offset: 0x0002B9A8
		private void buttonOk_Click(object sender, EventArgs e)
		{
			if (!this.ValidateDestinationPath())
			{
				this.textEditDestinationPath.Focus();
				this.textEditDestinationPath.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
				return;
			}
			this._params.FileName = this.GetDestinationDir();
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x0002D7F8 File Offset: 0x0002B9F8
		private string GetDestinationDir()
		{
			StringKeyAndValue macro = this.GetSelectedMacro();
			string result;
			if (Macros.IsAnyDirectoryMacro(macro))
			{
				result = this.textEditDestinationPath.Text;
			}
			else
			{
				result = macro.Key + this.textEditDestinationPath.Text;
			}
			if (this._params.SelectionMode == FileOrFolder.Folder)
			{
				result = Path.Combine(result, "*");
			}
			return result;
		}

		// Token: 0x0600061A RID: 1562 RVA: 0x0002D854 File Offset: 0x0002BA54
		private StringKeyAndValue GetSelectedMacro()
		{
			return (StringKeyAndValue)this.comboBoxSendDestinationDirMacro.SelectedItem;
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x0002D868 File Offset: 0x0002BA68
		private void textEditDestinationPath_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			if (this._params.SelectionMode == FileOrFolder.File)
			{
				using (XtraOpenFileDialog dlg = new XtraOpenFileDialog())
				{
					dlg.Multiselect = true;
					if (dlg.ShowDialog() == DialogResult.OK)
					{
						this.textEditDestinationPath.Text = dlg.FileName;
					}
					return;
				}
			}
			using (XtraFolderBrowserDialog dlg2 = new XtraFolderBrowserDialog())
			{
				if (dlg2.ShowDialog() == DialogResult.OK)
				{
					this.textEditDestinationPath.Text = dlg2.SelectedPath;
				}
			}
		}

		// Token: 0x0600061C RID: 1564 RVA: 0x0002D900 File Offset: 0x0002BB00
		private bool ValidateDestinationPath()
		{
			string modifiedPath;
			bool flag = Macros.ValidateMacroAndPath(this.GetSelectedMacro().Key, this.textEditDestinationPath.Text, out modifiedPath, this._params.SelectionMode);
			if (flag)
			{
				this.textEditDestinationPath.Text = modifiedPath;
			}
			return flag;
		}

		// Token: 0x040003B2 RID: 946
		private readonly List<StringKeyAndValue> _macroList;

		// Token: 0x040003B3 RID: 947
		private readonly SelectRemoteFileFormParams _params;
	}
}
