﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000066 RID: 102
	public partial class HttpDownloadForm : BaseForm
	{
		// Token: 0x06000554 RID: 1364 RVA: 0x00020F81 File Offset: 0x0001F181
		public HttpDownloadForm(IFormCreator formCreator, Uri remoteFilePath, string localFilePath) : base(null, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._remoteFilePath = remoteFilePath;
			this._localFilePath = localFilePath;
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x00020FAB File Offset: 0x0001F1AB
		private void buttonCancel_Click(object sender, EventArgs e)
		{
			WebClient webClient = this._webClient;
			if (webClient != null)
			{
				webClient.CancelAsync();
			}
			base.DialogResult = DialogResult.Cancel;
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x00020FC8 File Offset: 0x0001F1C8
		private void DownloadFile(Uri remoteFileLocation, string localFilePath)
		{
			using (this._webClient = new WebClient())
			{
				this._webClient.DownloadProgressChanged += this.webClient_DownloadProgressChanged;
				this._webClient.DownloadFileCompleted += this.webClient_DownloadCompleted;
				this._stopWatch.Start();
				this._webClient.DownloadFileAsync(remoteFileLocation, localFilePath);
			}
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x00021048 File Offset: 0x0001F248
		private Task<int> GetFileSize(Uri filePath)
		{
			HttpDownloadForm.<GetFileSize>d__8 <GetFileSize>d__;
			<GetFileSize>d__.<>t__builder = AsyncTaskMethodBuilder<int>.Create();
			<GetFileSize>d__.filePath = filePath;
			<GetFileSize>d__.<>1__state = -1;
			<GetFileSize>d__.<>t__builder.Start<HttpDownloadForm.<GetFileSize>d__8>(ref <GetFileSize>d__);
			return <GetFileSize>d__.<>t__builder.Task;
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x0002108C File Offset: 0x0001F28C
		private void HttpDownloadForm_Load(object sender, EventArgs e)
		{
			HttpDownloadForm.<HttpDownloadForm_Load>d__9 <HttpDownloadForm_Load>d__;
			<HttpDownloadForm_Load>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<HttpDownloadForm_Load>d__.<>4__this = this;
			<HttpDownloadForm_Load>d__.<>1__state = -1;
			<HttpDownloadForm_Load>d__.<>t__builder.Start<HttpDownloadForm.<HttpDownloadForm_Load>d__9>(ref <HttpDownloadForm_Load>d__);
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x000210C4 File Offset: 0x0001F2C4
		private Task StartDownload(Uri remoteFilePath, string localFilePath)
		{
			HttpDownloadForm.<StartDownload>d__10 <StartDownload>d__;
			<StartDownload>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<StartDownload>d__.<>4__this = this;
			<StartDownload>d__.remoteFilePath = remoteFilePath;
			<StartDownload>d__.localFilePath = localFilePath;
			<StartDownload>d__.<>1__state = -1;
			<StartDownload>d__.<>t__builder.Start<HttpDownloadForm.<StartDownload>d__10>(ref <StartDownload>d__);
			return <StartDownload>d__.<>t__builder.Task;
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x00021117 File Offset: 0x0001F317
		private void webClient_DownloadCompleted(object sender, AsyncCompletedEventArgs e)
		{
			this._stopWatch.Stop();
			if (!e.Cancelled)
			{
				base.DialogResult = DialogResult.OK;
			}
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x00021134 File Offset: 0x0001F334
		private void webClient_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			string speed = ((double)e.BytesReceived / 1024.0 / this._stopWatch.Elapsed.TotalSeconds).ToString("0.00");
			int step = Convert.ToInt32(e.BytesReceived - this._downloadProgress);
			this.progresBarDownload.Properties.Step = step;
			this._downloadProgress = e.BytesReceived;
			this.progresBarDownload.PerformStep();
			this.progresBarDownload.Update();
			this.labelProgress.Text = string.Format("{0} {1} kB / {2} kB ({3} kb/s)", new object[]
			{
				Resources.HttpDowloadForm_Downloaded,
				e.BytesReceived / 1024L,
				e.TotalBytesToReceive / 1024L,
				speed
			});
		}

		// Token: 0x040002B9 RID: 697
		private readonly string _localFilePath;

		// Token: 0x040002BA RID: 698
		private readonly Uri _remoteFilePath;

		// Token: 0x040002BB RID: 699
		private readonly Stopwatch _stopWatch = new Stopwatch();

		// Token: 0x040002BC RID: 700
		private long _downloadProgress;

		// Token: 0x040002BD RID: 701
		private WebClient _webClient;
	}
}
