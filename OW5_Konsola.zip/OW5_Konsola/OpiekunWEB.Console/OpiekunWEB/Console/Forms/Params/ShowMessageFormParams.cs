﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200009C RID: 156
	public class ShowMessageFormParams
	{
		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x0600081E RID: 2078 RVA: 0x00045CCF File Offset: 0x00043ECF
		// (set) Token: 0x0600081F RID: 2079 RVA: 0x00045CD7 File Offset: 0x00043ED7
		public string Message { get; set; }

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x06000820 RID: 2080 RVA: 0x00045CE0 File Offset: 0x00043EE0
		// (set) Token: 0x06000821 RID: 2081 RVA: 0x00045CE8 File Offset: 0x00043EE8
		public bool NeedConfirmation { get; set; }
	}
}
