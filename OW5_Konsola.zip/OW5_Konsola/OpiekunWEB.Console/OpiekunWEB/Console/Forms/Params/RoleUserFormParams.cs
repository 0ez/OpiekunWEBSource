﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000095 RID: 149
	public class RoleUserFormParams
	{
		// Token: 0x060007F8 RID: 2040 RVA: 0x00045B70 File Offset: 0x00043D70
		public RoleUserFormParams(string roleId)
		{
			this.RoleId = roleId;
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x00045B7F File Offset: 0x00043D7F
		public RoleUserFormParams(string id, string identy, string name, string roleId)
		{
			this.Id = id;
			this.Identy = identy;
			this.Name = name;
			this.RoleId = roleId;
		}

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x060007FA RID: 2042 RVA: 0x00045BA4 File Offset: 0x00043DA4
		// (set) Token: 0x060007FB RID: 2043 RVA: 0x00045BAC File Offset: 0x00043DAC
		public string Id { get; set; }

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x060007FC RID: 2044 RVA: 0x00045BB5 File Offset: 0x00043DB5
		// (set) Token: 0x060007FD RID: 2045 RVA: 0x00045BBD File Offset: 0x00043DBD
		public string Identy { get; set; }

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x060007FE RID: 2046 RVA: 0x00045BC6 File Offset: 0x00043DC6
		// (set) Token: 0x060007FF RID: 2047 RVA: 0x00045BCE File Offset: 0x00043DCE
		public string Name { get; set; }

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x06000800 RID: 2048 RVA: 0x00045BD7 File Offset: 0x00043DD7
		// (set) Token: 0x06000801 RID: 2049 RVA: 0x00045BDF File Offset: 0x00043DDF
		public string RoleId { get; set; }
	}
}
