﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200009F RID: 159
	public enum ScreenshotItemDescription
	{
		// Token: 0x040005E5 RID: 1509
		None,
		// Token: 0x040005E6 RID: 1510
		DeviceName,
		// Token: 0x040005E7 RID: 1511
		DeviceDescription,
		// Token: 0x040005E8 RID: 1512
		DomainAndUserName,
		// Token: 0x040005E9 RID: 1513
		UserFullName,
		// Token: 0x040005EA RID: 1514
		UserName
	}
}
