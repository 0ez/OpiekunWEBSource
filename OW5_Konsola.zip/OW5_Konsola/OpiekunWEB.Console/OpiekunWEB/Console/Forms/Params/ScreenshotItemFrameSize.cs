﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x020000A0 RID: 160
	public enum ScreenshotItemFrameSize
	{
		// Token: 0x040005EC RID: 1516
		Thin = 2,
		// Token: 0x040005ED RID: 1517
		Medium = 5,
		// Token: 0x040005EE RID: 1518
		Thick = 7
	}
}
