﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000088 RID: 136
	public enum AppUpdateMode
	{
		// Token: 0x0400059C RID: 1436
		Update,
		// Token: 0x0400059D RID: 1437
		Download,
		// Token: 0x0400059E RID: 1438
		RemindLater
	}
}
