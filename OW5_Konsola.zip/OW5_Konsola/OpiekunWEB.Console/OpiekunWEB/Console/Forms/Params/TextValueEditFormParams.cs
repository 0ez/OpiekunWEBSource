﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200009D RID: 157
	public class TextValueEditFormParams
	{
		// Token: 0x06000823 RID: 2083 RVA: 0x00045CF1 File Offset: 0x00043EF1
		public TextValueEditFormParams(string title, string description, string value)
		{
			this.Title = title;
			this.Description = description;
			this.Value = value;
		}

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x06000824 RID: 2084 RVA: 0x00045D0E File Offset: 0x00043F0E
		// (set) Token: 0x06000825 RID: 2085 RVA: 0x00045D16 File Offset: 0x00043F16
		public string Description { get; set; }

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x06000826 RID: 2086 RVA: 0x00045D1F File Offset: 0x00043F1F
		// (set) Token: 0x06000827 RID: 2087 RVA: 0x00045D27 File Offset: 0x00043F27
		public string Title { get; set; }

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x06000828 RID: 2088 RVA: 0x00045D30 File Offset: 0x00043F30
		// (set) Token: 0x06000829 RID: 2089 RVA: 0x00045D38 File Offset: 0x00043F38
		public string Value { get; set; }
	}
}
