﻿using System;
using Owpb;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000093 RID: 147
	public class ProcessDefListFormParams
	{
		// Token: 0x1700029A RID: 666
		// (get) Token: 0x060007E6 RID: 2022 RVA: 0x00045AE8 File Offset: 0x00043CE8
		// (set) Token: 0x060007E7 RID: 2023 RVA: 0x00045AF0 File Offset: 0x00043CF0
		public StartProcessDef ProcessDef { get; set; }
	}
}
