﻿using System;
using Owpb;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200009A RID: 154
	public class ShowMessageDefFormParams
	{
		// Token: 0x170002AE RID: 686
		// (get) Token: 0x06000816 RID: 2070 RVA: 0x00045C9C File Offset: 0x00043E9C
		// (set) Token: 0x06000817 RID: 2071 RVA: 0x00045CA4 File Offset: 0x00043EA4
		public string DefinitionId { get; set; }

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x06000818 RID: 2072 RVA: 0x00045CAD File Offset: 0x00043EAD
		// (set) Token: 0x06000819 RID: 2073 RVA: 0x00045CB5 File Offset: 0x00043EB5
		public ShowMessageDef ShowMessageDef { get; set; }
	}
}
