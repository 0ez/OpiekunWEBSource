﻿using System;
using System.Collections.Generic;
using OpiekunWEB.Api;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200008D RID: 141
	public class DistributeFilesFormParams
	{
		// Token: 0x060007B1 RID: 1969 RVA: 0x000458A5 File Offset: 0x00043AA5
		public DistributeFilesFormParams(AgentFileTransferDirection direction, List<AgentItem> agentItems)
		{
			this.Direction = direction;
			this.AgentItems = agentItems;
		}

		// Token: 0x17000282 RID: 642
		// (get) Token: 0x060007B2 RID: 1970 RVA: 0x000458BB File Offset: 0x00043ABB
		// (set) Token: 0x060007B3 RID: 1971 RVA: 0x000458C3 File Offset: 0x00043AC3
		public List<AgentItem> AgentItems { get; set; }

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x060007B4 RID: 1972 RVA: 0x000458CC File Offset: 0x00043ACC
		public AgentFileTransferDirection Direction { get; }
	}
}
