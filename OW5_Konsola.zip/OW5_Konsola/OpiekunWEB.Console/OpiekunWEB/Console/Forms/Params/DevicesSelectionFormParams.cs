﻿using System;
using System.Collections.Generic;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200008C RID: 140
	public class DevicesSelectionFormParams
	{
		// Token: 0x060007A7 RID: 1959 RVA: 0x00045805 File Offset: 0x00043A05
		public DevicesSelectionFormParams()
		{
			this.SelectedItems = new List<DeviceTreeItemBase>();
			this.ShowOnlyConnected = true;
			this.ItemsToShow = DeviceTreeItemsType.Device;
			this.ItemsToSelect = DeviceTreeItemsType.Device;
			this.ItemsToReturn = DeviceTreeItemsType.Device;
		}

		// Token: 0x060007A8 RID: 1960 RVA: 0x00045834 File Offset: 0x00043A34
		public DevicesSelectionFormParams(List<DeviceTreeItemBase> selectedItems, DeviceTreeItemsType itemsToShow, DeviceTreeItemsType itemsToSelect, DeviceTreeItemsType itemsToReturn, bool showOnlyConnected)
		{
			this.SelectedItems = selectedItems;
			this.ItemsToShow = itemsToShow;
			this.ItemsToSelect = itemsToSelect;
			this.ItemsToReturn = itemsToReturn;
			this.ShowOnlyConnected = showOnlyConnected;
		}

		// Token: 0x1700027E RID: 638
		// (get) Token: 0x060007A9 RID: 1961 RVA: 0x00045861 File Offset: 0x00043A61
		// (set) Token: 0x060007AA RID: 1962 RVA: 0x00045869 File Offset: 0x00043A69
		public DeviceTreeItemsType ItemsToReturn { get; set; }

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x060007AB RID: 1963 RVA: 0x00045872 File Offset: 0x00043A72
		// (set) Token: 0x060007AC RID: 1964 RVA: 0x0004587A File Offset: 0x00043A7A
		public DeviceTreeItemsType ItemsToSelect { get; set; }

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x060007AD RID: 1965 RVA: 0x00045883 File Offset: 0x00043A83
		// (set) Token: 0x060007AE RID: 1966 RVA: 0x0004588B File Offset: 0x00043A8B
		public DeviceTreeItemsType ItemsToShow { get; set; }

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x060007AF RID: 1967 RVA: 0x00045894 File Offset: 0x00043A94
		// (set) Token: 0x060007B0 RID: 1968 RVA: 0x0004589C File Offset: 0x00043A9C
		public bool ShowOnlyConnected { get; set; }

		// Token: 0x040005A8 RID: 1448
		public List<DeviceTreeItemBase> SelectedItems;
	}
}
