﻿using System;
using Owpb;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200009B RID: 155
	public class ShowMessageDefListFormParams
	{
		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x0600081B RID: 2075 RVA: 0x00045CBE File Offset: 0x00043EBE
		// (set) Token: 0x0600081C RID: 2076 RVA: 0x00045CC6 File Offset: 0x00043EC6
		public ShowMessageDef ShowMessageDef { get; set; }
	}
}
