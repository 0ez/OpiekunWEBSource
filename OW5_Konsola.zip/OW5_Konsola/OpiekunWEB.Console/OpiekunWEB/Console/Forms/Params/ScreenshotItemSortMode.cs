﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x020000A1 RID: 161
	public enum ScreenshotItemSortMode
	{
		// Token: 0x040005F0 RID: 1520
		DeviceItemAscending,
		// Token: 0x040005F1 RID: 1521
		DeviceItemInGroupAscending
	}
}
