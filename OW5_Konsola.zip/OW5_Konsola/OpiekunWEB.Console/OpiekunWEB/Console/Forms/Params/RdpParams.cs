﻿using System;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000094 RID: 148
	public class RdpParams
	{
		// Token: 0x1700029B RID: 667
		// (get) Token: 0x060007E9 RID: 2025 RVA: 0x00045AF9 File Offset: 0x00043CF9
		// (set) Token: 0x060007EA RID: 2026 RVA: 0x00045B01 File Offset: 0x00043D01
		public RemoteDesktopColorsDepth ColorsDepth { get; set; }

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x060007EB RID: 2027 RVA: 0x00045B0A File Offset: 0x00043D0A
		// (set) Token: 0x060007EC RID: 2028 RVA: 0x00045B12 File Offset: 0x00043D12
		public bool ConnectToConsole { get; set; }

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x060007ED RID: 2029 RVA: 0x00045B1B File Offset: 0x00043D1B
		// (set) Token: 0x060007EE RID: 2030 RVA: 0x00045B23 File Offset: 0x00043D23
		public RemoteDesktopSize DesktopSize { get; set; }

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x060007EF RID: 2031 RVA: 0x00045B2C File Offset: 0x00043D2C
		// (set) Token: 0x060007F0 RID: 2032 RVA: 0x00045B34 File Offset: 0x00043D34
		public string DomainName { get; set; }

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x060007F1 RID: 2033 RVA: 0x00045B3D File Offset: 0x00043D3D
		// (set) Token: 0x060007F2 RID: 2034 RVA: 0x00045B45 File Offset: 0x00043D45
		public string Password { get; set; }

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x060007F3 RID: 2035 RVA: 0x00045B4E File Offset: 0x00043D4E
		// (set) Token: 0x060007F4 RID: 2036 RVA: 0x00045B56 File Offset: 0x00043D56
		public int Port { get; set; }

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x060007F5 RID: 2037 RVA: 0x00045B5F File Offset: 0x00043D5F
		// (set) Token: 0x060007F6 RID: 2038 RVA: 0x00045B67 File Offset: 0x00043D67
		public string UserName { get; set; }
	}
}
