﻿using System;
using System.Collections.Generic;
using OpiekunWEB.Api;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000090 RID: 144
	public class FileTransferFormParams
	{
		// Token: 0x060007CD RID: 1997 RVA: 0x000459F8 File Offset: 0x00043BF8
		public FileTransferFormParams(AgentClient agentClient, List<string> files, string localDir, string remoteDir, bool readFromRemote, Action<string> messageLog)
		{
			this.Files = files;
			this.AgentClient = agentClient;
			this.LocalDir = localDir;
			this.RemoteDir = remoteDir;
			this.ReadFromRemote = readFromRemote;
			this.MessageLog = messageLog;
		}

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x060007CE RID: 1998 RVA: 0x00045A2D File Offset: 0x00043C2D
		// (set) Token: 0x060007CF RID: 1999 RVA: 0x00045A35 File Offset: 0x00043C35
		public AgentClient AgentClient { get; set; }

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x00045A3E File Offset: 0x00043C3E
		// (set) Token: 0x060007D1 RID: 2001 RVA: 0x00045A46 File Offset: 0x00043C46
		public List<string> Files { get; set; }

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x060007D2 RID: 2002 RVA: 0x00045A4F File Offset: 0x00043C4F
		// (set) Token: 0x060007D3 RID: 2003 RVA: 0x00045A57 File Offset: 0x00043C57
		public string LocalDir { get; set; }

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x060007D4 RID: 2004 RVA: 0x00045A60 File Offset: 0x00043C60
		// (set) Token: 0x060007D5 RID: 2005 RVA: 0x00045A68 File Offset: 0x00043C68
		public Action<string> MessageLog { get; set; }

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x00045A71 File Offset: 0x00043C71
		// (set) Token: 0x060007D7 RID: 2007 RVA: 0x00045A79 File Offset: 0x00043C79
		public bool ReadFromRemote { get; set; }

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x060007D8 RID: 2008 RVA: 0x00045A82 File Offset: 0x00043C82
		// (set) Token: 0x060007D9 RID: 2009 RVA: 0x00045A8A File Offset: 0x00043C8A
		public string RemoteDir { get; set; }
	}
}
