﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000096 RID: 150
	public class ScreenshotZoomFormParams
	{
		// Token: 0x06000802 RID: 2050 RVA: 0x00045BE8 File Offset: 0x00043DE8
		public ScreenshotZoomFormParams(DisplayItem displayItem, int quality, int refreshInterval)
		{
			this.DisplayItem = displayItem;
			this.Quality = quality;
			this.RefreshInterval = refreshInterval;
		}

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x06000803 RID: 2051 RVA: 0x00045C05 File Offset: 0x00043E05
		// (set) Token: 0x06000804 RID: 2052 RVA: 0x00045C0D File Offset: 0x00043E0D
		public DisplayItem DisplayItem { get; set; }

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x06000805 RID: 2053 RVA: 0x00045C16 File Offset: 0x00043E16
		// (set) Token: 0x06000806 RID: 2054 RVA: 0x00045C1E File Offset: 0x00043E1E
		public int Quality { get; set; }

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x06000807 RID: 2055 RVA: 0x00045C27 File Offset: 0x00043E27
		// (set) Token: 0x06000808 RID: 2056 RVA: 0x00045C2F File Offset: 0x00043E2F
		public int RefreshInterval { get; set; }
	}
}
