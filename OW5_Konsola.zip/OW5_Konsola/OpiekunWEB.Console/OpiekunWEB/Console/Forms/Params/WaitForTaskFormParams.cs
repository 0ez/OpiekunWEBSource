﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200009E RID: 158
	public class WaitForTaskFormParams
	{
		// Token: 0x0600082A RID: 2090 RVA: 0x00045D41 File Offset: 0x00043F41
		public WaitForTaskFormParams(string title, Task task, CancellationTokenSource cts)
		{
			this.Title = title;
			this.Task = task;
			this.CTS = cts;
		}

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x0600082B RID: 2091 RVA: 0x00045D5E File Offset: 0x00043F5E
		// (set) Token: 0x0600082C RID: 2092 RVA: 0x00045D66 File Offset: 0x00043F66
		public CancellationTokenSource CTS { get; set; }

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x0600082D RID: 2093 RVA: 0x00045D6F File Offset: 0x00043F6F
		// (set) Token: 0x0600082E RID: 2094 RVA: 0x00045D77 File Offset: 0x00043F77
		public Task Task { get; set; }

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x0600082F RID: 2095 RVA: 0x00045D80 File Offset: 0x00043F80
		// (set) Token: 0x06000830 RID: 2096 RVA: 0x00045D88 File Offset: 0x00043F88
		public string Title { get; set; }
	}
}
