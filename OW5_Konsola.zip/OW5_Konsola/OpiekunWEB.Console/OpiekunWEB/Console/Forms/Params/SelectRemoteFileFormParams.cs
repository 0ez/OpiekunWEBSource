﻿using System;
using OpiekunWEB.Console.Helpers;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000099 RID: 153
	public class SelectRemoteFileFormParams
	{
		// Token: 0x170002AC RID: 684
		// (get) Token: 0x06000811 RID: 2065 RVA: 0x00045C7A File Offset: 0x00043E7A
		// (set) Token: 0x06000812 RID: 2066 RVA: 0x00045C82 File Offset: 0x00043E82
		public string FileName { get; set; }

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x06000813 RID: 2067 RVA: 0x00045C8B File Offset: 0x00043E8B
		// (set) Token: 0x06000814 RID: 2068 RVA: 0x00045C93 File Offset: 0x00043E93
		public FileOrFolder SelectionMode { get; set; }
	}
}
