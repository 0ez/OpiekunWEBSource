﻿using System;
using System.Collections.Generic;
using Owpb;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000098 RID: 152
	public class SelectCustomerFormParams
	{
		// Token: 0x0600080C RID: 2060 RVA: 0x00045C49 File Offset: 0x00043E49
		public SelectCustomerFormParams(List<CustomerNameAndId> customerNameAndIds)
		{
			this.CustomerNameAndIds = customerNameAndIds;
		}

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x0600080D RID: 2061 RVA: 0x00045C58 File Offset: 0x00043E58
		// (set) Token: 0x0600080E RID: 2062 RVA: 0x00045C60 File Offset: 0x00043E60
		public string CustomerId { get; set; }

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x0600080F RID: 2063 RVA: 0x00045C69 File Offset: 0x00043E69
		// (set) Token: 0x06000810 RID: 2064 RVA: 0x00045C71 File Offset: 0x00043E71
		public List<CustomerNameAndId> CustomerNameAndIds { get; set; }
	}
}
