﻿using System;
using Owpb;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000092 RID: 146
	public class ProcessDefFormParams
	{
		// Token: 0x17000298 RID: 664
		// (get) Token: 0x060007E1 RID: 2017 RVA: 0x00045AC6 File Offset: 0x00043CC6
		// (set) Token: 0x060007E2 RID: 2018 RVA: 0x00045ACE File Offset: 0x00043CCE
		public string DefinitionId { get; set; }

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x060007E3 RID: 2019 RVA: 0x00045AD7 File Offset: 0x00043CD7
		// (set) Token: 0x060007E4 RID: 2020 RVA: 0x00045ADF File Offset: 0x00043CDF
		public StartProcessDef ProcessDef { get; set; }
	}
}
