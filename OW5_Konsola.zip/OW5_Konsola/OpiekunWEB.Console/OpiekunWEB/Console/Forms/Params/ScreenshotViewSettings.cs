﻿using System;
using System.Collections.Generic;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x020000A2 RID: 162
	public class ScreenshotViewSettings
	{
		// Token: 0x06000831 RID: 2097 RVA: 0x00045D91 File Offset: 0x00043F91
		public ScreenshotViewSettings()
		{
			this.FrameSize = 5;
			this.DrawScreenshotItemShadow = true;
			this.ShowDeviceInetStateIcon = true;
			this.ScreenshotSortMode = ScreenshotItemSortMode.DeviceItemAscending;
			this.ScreenshotItemDescriptionsKind = new List<ScreenshotItemDescription>();
		}

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x06000832 RID: 2098 RVA: 0x00045DC0 File Offset: 0x00043FC0
		// (set) Token: 0x06000833 RID: 2099 RVA: 0x00045DC8 File Offset: 0x00043FC8
		public bool DrawScreenshotItemShadow { get; set; }

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x06000834 RID: 2100 RVA: 0x00045DD1 File Offset: 0x00043FD1
		// (set) Token: 0x06000835 RID: 2101 RVA: 0x00045DD9 File Offset: 0x00043FD9
		public int FrameSize { get; set; }

		// Token: 0x170002BB RID: 699
		// (get) Token: 0x06000836 RID: 2102 RVA: 0x00045DE2 File Offset: 0x00043FE2
		// (set) Token: 0x06000837 RID: 2103 RVA: 0x00045DEA File Offset: 0x00043FEA
		public List<ScreenshotItemDescription> ScreenshotItemDescriptionsKind { get; set; }

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x06000838 RID: 2104 RVA: 0x00045DF3 File Offset: 0x00043FF3
		// (set) Token: 0x06000839 RID: 2105 RVA: 0x00045DFB File Offset: 0x00043FFB
		public ScreenshotItemSortMode ScreenshotSortMode { get; set; }

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x0600083A RID: 2106 RVA: 0x00045E04 File Offset: 0x00044004
		// (set) Token: 0x0600083B RID: 2107 RVA: 0x00045E0C File Offset: 0x0004400C
		public bool ShowDeviceInetStateIcon { get; set; }
	}
}
