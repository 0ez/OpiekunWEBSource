﻿using System;
using Owpb;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000089 RID: 137
	public class AppUpdateFormParams
	{
		// Token: 0x06000791 RID: 1937 RVA: 0x00045723 File Offset: 0x00043923
		public AppUpdateFormParams(InstallerFileInfo installerInfo, string currentAppVersion)
		{
			this.InstallerFileInfo = installerInfo;
			this.CurrentAppVersion = currentAppVersion;
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x06000792 RID: 1938 RVA: 0x00045739 File Offset: 0x00043939
		// (set) Token: 0x06000793 RID: 1939 RVA: 0x00045741 File Offset: 0x00043941
		public string CurrentAppVersion { get; set; }

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x06000794 RID: 1940 RVA: 0x0004574A File Offset: 0x0004394A
		// (set) Token: 0x06000795 RID: 1941 RVA: 0x00045752 File Offset: 0x00043952
		public string DownloadedFile { get; set; }

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x06000796 RID: 1942 RVA: 0x0004575B File Offset: 0x0004395B
		// (set) Token: 0x06000797 RID: 1943 RVA: 0x00045763 File Offset: 0x00043963
		public InstallerFileInfo InstallerFileInfo { get; set; }

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x06000798 RID: 1944 RVA: 0x0004576C File Offset: 0x0004396C
		// (set) Token: 0x06000799 RID: 1945 RVA: 0x00045774 File Offset: 0x00043974
		public AppUpdateMode Result { get; set; }
	}
}
