﻿using System;
using Owpb;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000097 RID: 151
	public class SelectConsoleGroupsOnDeviceRuleFormParams
	{
		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x06000809 RID: 2057 RVA: 0x00045C38 File Offset: 0x00043E38
		// (set) Token: 0x0600080A RID: 2058 RVA: 0x00045C40 File Offset: 0x00043E40
		public Rule Rule { get; set; }
	}
}
