﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200008A RID: 138
	public class DeviceGroupSelectionFormParams
	{
		// Token: 0x17000279 RID: 633
		// (get) Token: 0x0600079A RID: 1946 RVA: 0x0004577D File Offset: 0x0004397D
		// (set) Token: 0x0600079B RID: 1947 RVA: 0x00045785 File Offset: 0x00043985
		public DevicesGroupItem SelectedGroup { get; set; }
	}
}
