﻿using System;
using OpiekunWEB.Api;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200008E RID: 142
	public class FileOverrideQuestionFormParams
	{
		// Token: 0x060007B5 RID: 1973 RVA: 0x000458D4 File Offset: 0x00043AD4
		public FileOverrideQuestionFormParams(string fileName, bool isLocalFile)
		{
			this.FileName = fileName;
			this.IsLocalFile = isLocalFile;
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x060007B6 RID: 1974 RVA: 0x000458EA File Offset: 0x00043AEA
		// (set) Token: 0x060007B7 RID: 1975 RVA: 0x000458F2 File Offset: 0x00043AF2
		public FileOverrideAction Action { get; set; }

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x060007B8 RID: 1976 RVA: 0x000458FB File Offset: 0x00043AFB
		// (set) Token: 0x060007B9 RID: 1977 RVA: 0x00045903 File Offset: 0x00043B03
		public string FileName { get; set; }

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x060007BA RID: 1978 RVA: 0x0004590C File Offset: 0x00043B0C
		// (set) Token: 0x060007BB RID: 1979 RVA: 0x00045914 File Offset: 0x00043B14
		public bool IsLocalFile { get; set; }
	}
}
