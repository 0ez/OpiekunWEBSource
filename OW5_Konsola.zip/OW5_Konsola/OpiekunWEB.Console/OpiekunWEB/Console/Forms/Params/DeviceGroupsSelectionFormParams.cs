﻿using System;
using System.Collections.Generic;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200008B RID: 139
	public class DeviceGroupsSelectionFormParams
	{
		// Token: 0x0600079D RID: 1949 RVA: 0x0004578E File Offset: 0x0004398E
		public DeviceGroupsSelectionFormParams(List<string> selectedGroupsId, bool canSelectMultipleGroups)
		{
			this.SelectedGroupsId = selectedGroupsId;
			this.CanSelectMultipleGroups = canSelectMultipleGroups;
		}

		// Token: 0x0600079E RID: 1950 RVA: 0x000457A4 File Offset: 0x000439A4
		public DeviceGroupsSelectionFormParams(List<string> allowedGroupsId, List<string> selectedGroupsId, bool canSelectMultipleGroups)
		{
			this.AllowedGroupsId = allowedGroupsId;
			this.SelectedGroupsId = selectedGroupsId;
			this.CanSelectMultipleGroups = canSelectMultipleGroups;
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x0600079F RID: 1951 RVA: 0x000457C1 File Offset: 0x000439C1
		// (set) Token: 0x060007A0 RID: 1952 RVA: 0x000457C9 File Offset: 0x000439C9
		public List<string> AllowedGroupsId { get; set; }

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x060007A1 RID: 1953 RVA: 0x000457D2 File Offset: 0x000439D2
		// (set) Token: 0x060007A2 RID: 1954 RVA: 0x000457DA File Offset: 0x000439DA
		public bool CanSelectMultipleGroups { get; set; }

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x060007A3 RID: 1955 RVA: 0x000457E3 File Offset: 0x000439E3
		// (set) Token: 0x060007A4 RID: 1956 RVA: 0x000457EB File Offset: 0x000439EB
		public bool DisableWindowsCanceling { get; set; }

		// Token: 0x1700027D RID: 637
		// (get) Token: 0x060007A5 RID: 1957 RVA: 0x000457F4 File Offset: 0x000439F4
		// (set) Token: 0x060007A6 RID: 1958 RVA: 0x000457FC File Offset: 0x000439FC
		public List<string> SelectedGroupsId { get; set; }
	}
}
