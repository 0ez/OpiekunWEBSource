﻿using System;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x02000091 RID: 145
	public class LogonSessionFormParams
	{
		// Token: 0x17000295 RID: 661
		// (get) Token: 0x060007DA RID: 2010 RVA: 0x00045A93 File Offset: 0x00043C93
		// (set) Token: 0x060007DB RID: 2011 RVA: 0x00045A9B File Offset: 0x00043C9B
		public string DomainName { get; set; }

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x060007DC RID: 2012 RVA: 0x00045AA4 File Offset: 0x00043CA4
		// (set) Token: 0x060007DD RID: 2013 RVA: 0x00045AAC File Offset: 0x00043CAC
		public string Password { get; set; }

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x060007DE RID: 2014 RVA: 0x00045AB5 File Offset: 0x00043CB5
		// (set) Token: 0x060007DF RID: 2015 RVA: 0x00045ABD File Offset: 0x00043CBD
		public string UserName { get; set; }
	}
}
