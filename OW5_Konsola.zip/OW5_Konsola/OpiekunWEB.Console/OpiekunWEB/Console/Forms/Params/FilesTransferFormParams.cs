﻿using System;
using System.Collections.Generic;
using OpiekunWEB.Api;

namespace OpiekunWEB.Console.Forms.Params
{
	// Token: 0x0200008F RID: 143
	public class FilesTransferFormParams
	{
		// Token: 0x060007BC RID: 1980 RVA: 0x00045920 File Offset: 0x00043B20
		public FilesTransferFormParams(AgentClient agentClient, string localDir, string remoteDir, List<string> filesListList, int chunkSize, bool readFromRemote, Action<string> messageLogAction, Action<AgentFileTransferEndArgs> fileTransferEndAction)
		{
			this.FilesList = filesListList;
			this.AgentClient = agentClient;
			this.LocalDir = localDir;
			this.RemoteDir = remoteDir;
			this.ChunkSize = chunkSize;
			this.ReadFromRemote = readFromRemote;
			this.MessageLogAction = messageLogAction;
			this.FileTransferEndAction = fileTransferEndAction;
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x060007BD RID: 1981 RVA: 0x00045970 File Offset: 0x00043B70
		// (set) Token: 0x060007BE RID: 1982 RVA: 0x00045978 File Offset: 0x00043B78
		public AgentClient AgentClient { get; set; }

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x060007BF RID: 1983 RVA: 0x00045981 File Offset: 0x00043B81
		// (set) Token: 0x060007C0 RID: 1984 RVA: 0x00045989 File Offset: 0x00043B89
		public int ChunkSize { get; set; }

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x060007C1 RID: 1985 RVA: 0x00045992 File Offset: 0x00043B92
		// (set) Token: 0x060007C2 RID: 1986 RVA: 0x0004599A File Offset: 0x00043B9A
		public List<string> FilesList { get; set; }

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x060007C3 RID: 1987 RVA: 0x000459A3 File Offset: 0x00043BA3
		// (set) Token: 0x060007C4 RID: 1988 RVA: 0x000459AB File Offset: 0x00043BAB
		public Action<AgentFileTransferEndArgs> FileTransferEndAction { get; set; }

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x060007C5 RID: 1989 RVA: 0x000459B4 File Offset: 0x00043BB4
		// (set) Token: 0x060007C6 RID: 1990 RVA: 0x000459BC File Offset: 0x00043BBC
		public string LocalDir { get; set; }

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x060007C7 RID: 1991 RVA: 0x000459C5 File Offset: 0x00043BC5
		// (set) Token: 0x060007C8 RID: 1992 RVA: 0x000459CD File Offset: 0x00043BCD
		public Action<string> MessageLogAction { get; set; }

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x060007C9 RID: 1993 RVA: 0x000459D6 File Offset: 0x00043BD6
		// (set) Token: 0x060007CA RID: 1994 RVA: 0x000459DE File Offset: 0x00043BDE
		public bool ReadFromRemote { get; set; }

		// Token: 0x1700028E RID: 654
		// (get) Token: 0x060007CB RID: 1995 RVA: 0x000459E7 File Offset: 0x00043BE7
		// (set) Token: 0x060007CC RID: 1996 RVA: 0x000459EF File Offset: 0x00043BEF
		public string RemoteDir { get; set; }
	}
}
