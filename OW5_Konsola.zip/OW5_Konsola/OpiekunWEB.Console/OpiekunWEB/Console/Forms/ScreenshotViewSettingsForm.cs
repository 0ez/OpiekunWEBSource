﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000072 RID: 114
	public partial class ScreenshotViewSettingsForm : BaseForm
	{
		// Token: 0x060005FE RID: 1534 RVA: 0x0002A58F File Offset: 0x0002878F
		public ScreenshotViewSettingsForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x0002A5A0 File Offset: 0x000287A0
		public ScreenshotViewSettingsForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ScreenshotViewSettings @params) : base(formsSettings, formCreator, action)
		{
			this.InitializeComponent();
			this._params = @params;
			foreach (object item in Enum.GetValues(typeof(ScreenshotItemDescription)))
			{
				this.comboBoxEditDescription1.Properties.Items.Add(item);
				this.comboBoxEditDescription2.Properties.Items.Add(item);
			}
			foreach (object item2 in Enum.GetValues(typeof(ScreenshotItemFrameSize)))
			{
				this.comboBoxEditFrameSize.Properties.Items.Add(item2);
			}
			foreach (object item3 in Enum.GetValues(typeof(ScreenshotItemSortMode)))
			{
				this.comboBoxEditSortMode.Properties.Items.Add(item3);
			}
			this.comboBoxEditDescription1.EditValue = ScreenshotItemDescription.None;
			this.comboBoxEditDescription2.EditValue = ScreenshotItemDescription.None;
			if (this._params.ScreenshotItemDescriptionsKind.Count > 0)
			{
				this.comboBoxEditDescription1.EditValue = this._params.ScreenshotItemDescriptionsKind[0];
				if (this._params.ScreenshotItemDescriptionsKind.Count > 1)
				{
					this.comboBoxEditDescription2.EditValue = this._params.ScreenshotItemDescriptionsKind[1];
				}
			}
			this.comboBoxEditFrameSize.EditValue = (ScreenshotItemFrameSize)this._params.FrameSize;
			this.comboBoxEditSortMode.EditValue = this._params.ScreenshotSortMode;
			this.checkEditDrawShadow.Checked = this._params.DrawScreenshotItemShadow;
			this.checkEditShowInetStateIcon.Checked = this._params.ShowDeviceInetStateIcon;
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x0002A7E4 File Offset: 0x000289E4
		private void buttonOk_Click(object sender, EventArgs e)
		{
			this._params.ScreenshotItemDescriptionsKind.Clear();
			ScreenshotItemDescription v = (ScreenshotItemDescription)this.comboBoxEditDescription1.EditValue;
			if (v != ScreenshotItemDescription.None)
			{
				this._params.ScreenshotItemDescriptionsKind.Add(v);
			}
			v = (ScreenshotItemDescription)this.comboBoxEditDescription2.EditValue;
			if (v != ScreenshotItemDescription.None)
			{
				this._params.ScreenshotItemDescriptionsKind.Add(v);
			}
			this._params.FrameSize = (int)this.comboBoxEditFrameSize.EditValue;
			this._params.DrawScreenshotItemShadow = this.checkEditDrawShadow.Checked;
			this._params.ShowDeviceInetStateIcon = this.checkEditShowInetStateIcon.Checked;
			this._params.ScreenshotSortMode = (ScreenshotItemSortMode)this.comboBoxEditSortMode.EditValue;
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x0002A8B4 File Offset: 0x00028AB4
		private void comboBoxEditDescription_Properties_CustomDisplayText(object sender, CustomDisplayTextEventArgs e)
		{
			if (e.Value != null)
			{
				e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<ScreenshotItemDescription>((ScreenshotItemDescription)e.Value, Resources.ResourceManager, null);
			}
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x0002A8DA File Offset: 0x00028ADA
		private void comboBoxEditDescription_Properties_CustomItemDisplayText(object sender, CustomItemDisplayTextEventArgs e)
		{
			e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<ScreenshotItemDescription>((ScreenshotItemDescription)e.Value, Resources.ResourceManager, null);
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x0002A8F8 File Offset: 0x00028AF8
		private void comboBoxEditFrameSize_Properties_CustomDisplayText(object sender, CustomDisplayTextEventArgs e)
		{
			if (e.Value != null)
			{
				e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<ScreenshotItemFrameSize>((ScreenshotItemFrameSize)e.Value, Resources.ResourceManager, null);
			}
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x0002A91E File Offset: 0x00028B1E
		private void comboBoxEditFrameSize_Properties_CustomItemDisplayText(object sender, CustomItemDisplayTextEventArgs e)
		{
			e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<ScreenshotItemFrameSize>((ScreenshotItemFrameSize)e.Value, Resources.ResourceManager, null);
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x0002A93C File Offset: 0x00028B3C
		private void comboBoxEditSortMode_Properties_CustomDisplayText(object sender, CustomDisplayTextEventArgs e)
		{
			if (e.Value != null)
			{
				e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<ScreenshotItemSortMode>((ScreenshotItemSortMode)e.Value, Resources.ResourceManager, null);
			}
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x0002A962 File Offset: 0x00028B62
		private void comboBoxEditSortMode_Properties_CustomItemDisplayText(object sender, CustomItemDisplayTextEventArgs e)
		{
			e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<ScreenshotItemSortMode>((ScreenshotItemSortMode)e.Value, Resources.ResourceManager, null);
		}

		// Token: 0x04000385 RID: 901
		private readonly ScreenshotViewSettings _params;
	}
}
