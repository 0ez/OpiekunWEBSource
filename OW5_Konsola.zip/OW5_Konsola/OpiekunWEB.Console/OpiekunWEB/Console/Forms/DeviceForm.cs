﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraLayout;
using DevExpress.XtraTab;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Nodes;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000063 RID: 99
	public partial class DeviceForm : CRUDBaseForm
	{
		// Token: 0x06000537 RID: 1335 RVA: 0x0001DCF4 File Offset: 0x0001BEF4
		public DeviceForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, DeviceItem deviceItem, ApiClient apiClient) : base(formsSettings, formCreator, action, apiClient)
		{
			this._deviceItem = deviceItem;
			this.InitializeComponent();
			this.textEditDeviceName.Text = deviceItem.Name;
			this.textEditDeviceDescription.Text = deviceItem.Description;
			AppUtils.FillDeviceTypesImageComboBoxItemCollection(this.imageComboBoxDeviceType.Properties.Items);
			this.treeListLookUpDeviceGroup.Properties.DataSource = this._apiClient.DevicesGroups;
			TreeListNode treeItem = this.treeListLookUpGroupsTreeList.FindNodeByKeyID(this._deviceItem.ParentId);
			this.treeListLookUpDeviceGroup.EditValue = this.treeListLookUpGroupsTreeList.GetDataRecordByNode(treeItem);
			this.imageComboBoxDeviceType.EditValue = (int)deviceItem.DeviceType;
			this.gridMacs.DataSource = this._deviceItem.MacList;
		}

		// Token: 0x06000538 RID: 1336 RVA: 0x0001DDCC File Offset: 0x0001BFCC
		protected string GetSelectedGroupId()
		{
			DevicesGroup group = this.treeListLookUpDeviceGroup.GetSelectedDataRow() as DevicesGroup;
			if (group == null)
			{
				return "";
			}
			return group.Id;
		}

		// Token: 0x06000539 RID: 1337 RVA: 0x0001DDFC File Offset: 0x0001BFFC
		protected override bool IsDataUpdated()
		{
			return this._deviceItem.Name != this.textEditDeviceName.Text || this._deviceItem.ParentId != this.GetSelectedGroupId() || this._deviceItem.Description != this.textEditDeviceDescription.Text;
		}

		// Token: 0x0600053A RID: 1338 RVA: 0x0001DE5C File Offset: 0x0001C05C
		protected override Task<bool> OnActionUpdate()
		{
			DeviceForm.<OnActionUpdate>d__4 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<DeviceForm.<OnActionUpdate>d__4>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x04000287 RID: 647
		private readonly DeviceItem _deviceItem;
	}
}
