﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000085 RID: 133
	public partial class WaitForTaskForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600073B RID: 1851 RVA: 0x0003EFAB File Offset: 0x0003D1AB
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x0003EFCC File Offset: 0x0003D1CC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.WaitForTaskForm));
			this.buttonCancel = new global::DevExpress.XtraEditors.SimpleButton();
			this.progressPanel = new global::DevExpress.XtraWaitForm.ProgressPanel();
			base.SuspendLayout();
			componentResourceManager.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Click += new global::System.EventHandler(this.buttonCancel_Click);
			this.progressPanel.Appearance.BackColor = global::System.Drawing.Color.Transparent;
			this.progressPanel.Appearance.Options.UseBackColor = true;
			this.progressPanel.BarAnimationElementThickness = 2;
			componentResourceManager.ApplyResources(this.progressPanel, "progressPanel");
			this.progressPanel.Name = "progressPanel";
			this.progressPanel.ShowDescription = false;
			componentResourceManager.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.progressPanel);
			base.Controls.Add(this.buttonCancel);
			base.Name = "WaitForTaskForm";
			base.Load += new global::System.EventHandler(this.WaitForTaskForm_Load);
			base.ResumeLayout(false);
		}

		// Token: 0x04000515 RID: 1301
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000516 RID: 1302
		private global::DevExpress.XtraEditors.SimpleButton buttonCancel;

		// Token: 0x04000517 RID: 1303
		private global::DevExpress.XtraWaitForm.ProgressPanel progressPanel;
	}
}
