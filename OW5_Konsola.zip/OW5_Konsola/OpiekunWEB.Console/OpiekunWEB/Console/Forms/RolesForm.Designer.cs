﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007D RID: 125
	public partial class RolesForm : global::OpiekunWEB.Console.Forms.RibbonBaseForm
	{
		// Token: 0x060006A6 RID: 1702 RVA: 0x0003614B File Offset: 0x0003434B
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x0003616C File Offset: 0x0003436C
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.RolesForm));
			global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions = new global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new global::DevExpress.Utils.SerializableAppearanceObject();
			this.splitContainerMain = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.gridRoles = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewRoles = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnRoleName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRoleType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRoleCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.xtraTabControl = new global::DevExpress.XtraTab.XtraTabControl();
			this.xtraTabPagePermissions = new global::DevExpress.XtraTab.XtraTabPage();
			this.gridPermissions = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewPermissions = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnPermissionType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnPermissionDisplayName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnPermissionValue = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxPermissionValueBool = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imagesPermissions = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imageComboBoxPermissionValueRemoteControl = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imageComboBoxPermissionValueInetControlState = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imageComboBoxSearchEngines = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imageComboBoxPermissionTypeWindowsUserDenyRemote = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imageComboBoxUrlHistoryLogFlags = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imagesInetHistoryLog = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imageComboBoxAllowedCategories = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.buttonShowAvailableDeviceGroups = new global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
			this.imageComboBoxDeviceGroupsSelectMode = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.repositoryItemTreeListEditAppControlState = new global::DevExpress.XtraEditors.Repository.RepositoryItemTreeListLookUpEdit();
			this.repositoryItemTreeListAppControlState = new global::DevExpress.XtraTreeList.TreeList();
			this.treeColumnAppStateName = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.xtraScrollablePermissionDescription = new global::DevExpress.XtraEditors.XtraScrollableControl();
			this.labelPermissionDescription = new global::DevExpress.XtraEditors.LabelControl();
			this.xtraTabPageUsers = new global::DevExpress.XtraTab.XtraTabPage();
			this.gridUsers = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewUsers = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnUserName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnUserIdenty = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRoleId = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnUserStatus = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxUserStatus = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.gridColumnUserCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.xtraScrollableUsersDescription = new global::DevExpress.XtraEditors.XtraScrollableControl();
			this.labelUsersDescription = new global::DevExpress.XtraEditors.LabelControl();
			this.ribbonControl = new global::DevExpress.XtraBars.Ribbon.RibbonControl();
			this.barButtonAddApiUserRole = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddWindowsUserRole = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddApiUser = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonClose = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddWindowsUser = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonImportWindowsUser = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonDeleteUser = new global::DevExpress.XtraBars.BarButtonItem();
			this.ribbonPage = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.ribbonPageGroupAdd = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.barStaticItemSelection = new global::DevExpress.XtraBars.BarStaticItem();
			this.popupMenuUsers = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.barButtonItem1 = new global::DevExpress.XtraBars.BarButtonItem();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerMain.Panel1).BeginInit();
			this.splitContainerMain.Panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerMain.Panel2).BeginInit();
			this.splitContainerMain.Panel2.SuspendLayout();
			this.splitContainerMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridRoles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewRoles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControl).BeginInit();
			this.xtraTabControl.SuspendLayout();
			this.xtraTabPagePermissions.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridPermissions).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewPermissions).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionValueBool).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesPermissions).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionValueRemoteControl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionValueInetControlState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxSearchEngines).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionTypeWindowsUserDenyRemote).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUrlHistoryLogFlags).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesInetHistoryLog).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxAllowedCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.buttonShowAvailableDeviceGroups).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxDeviceGroupsSelectMode).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemTreeListEditAppControlState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemTreeListAppControlState).BeginInit();
			this.xtraScrollablePermissionDescription.SuspendLayout();
			this.xtraTabPageUsers.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridUsers).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUsers).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUserStatus).BeginInit();
			this.xtraScrollableUsersDescription.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuUsers).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.splitContainerMain, "splitContainerMain");
			this.splitContainerMain.Name = "splitContainerMain";
			this.splitContainerMain.Panel1.Controls.Add(this.gridRoles);
			this.splitContainerMain.Panel2.Controls.Add(this.xtraTabControl);
			this.splitContainerMain.SplitterPosition = 394;
			resources.ApplyResources(this.gridRoles, "gridRoles");
			this.gridRoles.EmbeddedNavigator.AllowHtmlTextInToolTip = (global::DevExpress.Utils.DefaultBoolean)resources.GetObject("gridRoles.EmbeddedNavigator.AllowHtmlTextInToolTip");
			this.gridRoles.EmbeddedNavigator.Anchor = (global::System.Windows.Forms.AnchorStyles)resources.GetObject("gridRoles.EmbeddedNavigator.Anchor");
			this.gridRoles.EmbeddedNavigator.BackgroundImageLayout = (global::System.Windows.Forms.ImageLayout)resources.GetObject("gridRoles.EmbeddedNavigator.BackgroundImageLayout");
			this.gridRoles.EmbeddedNavigator.ImeMode = (global::System.Windows.Forms.ImeMode)resources.GetObject("gridRoles.EmbeddedNavigator.ImeMode");
			this.gridRoles.EmbeddedNavigator.Margin = (global::System.Windows.Forms.Padding)resources.GetObject("gridRoles.EmbeddedNavigator.Margin");
			this.gridRoles.EmbeddedNavigator.TextLocation = (global::DevExpress.XtraEditors.NavigatorButtonsTextLocation)resources.GetObject("gridRoles.EmbeddedNavigator.TextLocation");
			this.gridRoles.EmbeddedNavigator.ToolTipIconType = (global::DevExpress.Utils.ToolTipIconType)resources.GetObject("gridRoles.EmbeddedNavigator.ToolTipIconType");
			this.gridRoles.MainView = this.gridViewRoles;
			this.gridRoles.Name = "gridRoles";
			this.gridRoles.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewRoles
			});
			this.gridViewRoles.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnRoleName,
				this.gridColumnRoleType,
				this.gridColumnRoleCommand
			});
			this.gridViewRoles.DetailHeight = 437;
			this.gridViewRoles.GridControl = this.gridRoles;
			this.gridViewRoles.GroupCount = 1;
			this.gridViewRoles.Name = "gridViewRoles";
			this.gridViewRoles.OptionsBehavior.AutoExpandAllGroups = true;
			this.gridViewRoles.OptionsDetail.EnableMasterViewMode = false;
			this.gridViewRoles.OptionsDetail.ShowDetailTabs = false;
			this.gridViewRoles.OptionsMenu.EnableColumnMenu = false;
			this.gridViewRoles.OptionsNavigation.AutoFocusNewRow = true;
			this.gridViewRoles.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewRoles.OptionsView.ShowGroupPanel = false;
			this.gridViewRoles.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnRoleType, global::DevExpress.Data.ColumnSortOrder.Ascending),
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnRoleName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewRoles.CustomDrawGroupRow += new global::DevExpress.XtraGrid.Views.Base.RowObjectCustomDrawEventHandler(this.gridViewRole_CustomDrawGroupRow);
			this.gridViewRoles.GroupRowCollapsing += new global::DevExpress.XtraGrid.Views.Base.RowAllowEventHandler(this.gridViews_GroupRowCollapsing);
			this.gridViewRoles.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewRole_FocusedRowChanged);
			this.gridColumnRoleName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnRoleName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnRoleName, "gridColumnRoleName");
			this.gridColumnRoleName.FieldName = "Name";
			this.gridColumnRoleName.MinWidth = 25;
			this.gridColumnRoleName.Name = "gridColumnRoleName";
			this.gridColumnRoleName.OptionsColumn.AllowEdit = false;
			this.gridColumnRoleType.FieldName = "RoleType";
			this.gridColumnRoleType.MinWidth = 25;
			this.gridColumnRoleType.Name = "gridColumnRoleType";
			resources.ApplyResources(this.gridColumnRoleType, "gridColumnRoleType");
			this.gridColumnRoleCommand.MinWidth = 25;
			this.gridColumnRoleCommand.Name = "gridColumnRoleCommand";
			resources.ApplyResources(this.gridColumnRoleCommand, "gridColumnRoleCommand");
			resources.ApplyResources(this.xtraTabControl, "xtraTabControl");
			this.xtraTabControl.Name = "xtraTabControl";
			this.xtraTabControl.SelectedTabPage = this.xtraTabPagePermissions;
			this.xtraTabControl.TabPages.AddRange(new global::DevExpress.XtraTab.XtraTabPage[]
			{
				this.xtraTabPagePermissions,
				this.xtraTabPageUsers
			});
			this.xtraTabPagePermissions.Controls.Add(this.gridPermissions);
			this.xtraTabPagePermissions.Controls.Add(this.xtraScrollablePermissionDescription);
			resources.ApplyResources(this.xtraTabPagePermissions, "xtraTabPagePermissions");
			this.xtraTabPagePermissions.Name = "xtraTabPagePermissions";
			resources.ApplyResources(this.gridPermissions, "gridPermissions");
			this.gridPermissions.EmbeddedNavigator.AllowHtmlTextInToolTip = (global::DevExpress.Utils.DefaultBoolean)resources.GetObject("gridPermissions.EmbeddedNavigator.AllowHtmlTextInToolTip");
			this.gridPermissions.EmbeddedNavigator.Anchor = (global::System.Windows.Forms.AnchorStyles)resources.GetObject("gridPermissions.EmbeddedNavigator.Anchor");
			this.gridPermissions.EmbeddedNavigator.BackgroundImageLayout = (global::System.Windows.Forms.ImageLayout)resources.GetObject("gridPermissions.EmbeddedNavigator.BackgroundImageLayout");
			this.gridPermissions.EmbeddedNavigator.ImeMode = (global::System.Windows.Forms.ImeMode)resources.GetObject("gridPermissions.EmbeddedNavigator.ImeMode");
			this.gridPermissions.EmbeddedNavigator.Margin = (global::System.Windows.Forms.Padding)resources.GetObject("gridPermissions.EmbeddedNavigator.Margin");
			this.gridPermissions.EmbeddedNavigator.TextLocation = (global::DevExpress.XtraEditors.NavigatorButtonsTextLocation)resources.GetObject("gridPermissions.EmbeddedNavigator.TextLocation");
			this.gridPermissions.EmbeddedNavigator.ToolTipIconType = (global::DevExpress.Utils.ToolTipIconType)resources.GetObject("gridPermissions.EmbeddedNavigator.ToolTipIconType");
			this.gridPermissions.MainView = this.gridViewPermissions;
			this.gridPermissions.Name = "gridPermissions";
			this.gridPermissions.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxPermissionValueBool,
				this.imageComboBoxPermissionValueRemoteControl,
				this.imageComboBoxPermissionValueInetControlState,
				this.imageComboBoxSearchEngines,
				this.imageComboBoxPermissionTypeWindowsUserDenyRemote,
				this.imageComboBoxUrlHistoryLogFlags,
				this.imageComboBoxAllowedCategories,
				this.buttonShowAvailableDeviceGroups,
				this.imageComboBoxDeviceGroupsSelectMode,
				this.repositoryItemTreeListEditAppControlState
			});
			this.gridPermissions.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewPermissions
			});
			this.gridViewPermissions.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnPermissionType,
				this.gridColumnPermissionDisplayName,
				this.gridColumnPermissionValue
			});
			this.gridViewPermissions.DetailHeight = 437;
			this.gridViewPermissions.GridControl = this.gridPermissions;
			this.gridViewPermissions.GroupCount = 1;
			this.gridViewPermissions.Name = "gridViewPermissions";
			this.gridViewPermissions.OptionsBehavior.AutoExpandAllGroups = true;
			this.gridViewPermissions.OptionsMenu.EnableColumnMenu = false;
			this.gridViewPermissions.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewPermissions.OptionsSelection.UseIndicatorForSelection = false;
			this.gridViewPermissions.OptionsView.ShowDetailButtons = false;
			this.gridViewPermissions.OptionsView.ShowGroupExpandCollapseButtons = false;
			this.gridViewPermissions.OptionsView.ShowGroupPanel = false;
			this.gridViewPermissions.OptionsView.ShowIndicator = false;
			this.gridViewPermissions.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnPermissionType, global::DevExpress.Data.ColumnSortOrder.Ascending),
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnPermissionDisplayName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewPermissions.CustomDrawGroupRow += new global::DevExpress.XtraGrid.Views.Base.RowObjectCustomDrawEventHandler(this.gridViewPermissions_CustomDrawGroupRow);
			this.gridViewPermissions.CustomRowCellEdit += new global::DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventHandler(this.gridViewPermissions_CustomRowCellEdit);
			this.gridViewPermissions.GroupRowCollapsing += new global::DevExpress.XtraGrid.Views.Base.RowAllowEventHandler(this.gridViews_GroupRowCollapsing);
			this.gridViewPermissions.ShowingEditor += new global::System.ComponentModel.CancelEventHandler(this.gridViewPermissions_ShowingEditor);
			this.gridViewPermissions.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewPermissions_FocusedRowChanged);
			this.gridViewPermissions.CellValueChanging += new global::DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridViewPermissions_CellValueChanging);
			this.gridViewPermissions.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewPermissions_CustomUnboundColumnData);
			this.gridColumnPermissionType.FieldName = "PermissionType";
			this.gridColumnPermissionType.MinWidth = 25;
			this.gridColumnPermissionType.Name = "gridColumnPermissionType";
			resources.ApplyResources(this.gridColumnPermissionType, "gridColumnPermissionType");
			this.gridColumnPermissionDisplayName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnPermissionDisplayName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnPermissionDisplayName, "gridColumnPermissionDisplayName");
			this.gridColumnPermissionDisplayName.FieldName = "Name";
			this.gridColumnPermissionDisplayName.MinWidth = 25;
			this.gridColumnPermissionDisplayName.Name = "gridColumnPermissionDisplayName";
			this.gridColumnPermissionDisplayName.OptionsColumn.AllowEdit = false;
			this.gridColumnPermissionValue.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnPermissionValue.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnPermissionValue, "gridColumnPermissionValue");
			this.gridColumnPermissionValue.FieldName = "PermissionValue";
			this.gridColumnPermissionValue.MinWidth = 175;
			this.gridColumnPermissionValue.Name = "gridColumnPermissionValue";
			this.gridColumnPermissionValue.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			resources.ApplyResources(this.imageComboBoxPermissionValueBool, "imageComboBoxPermissionValueBool");
			this.imageComboBoxPermissionValueBool.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxPermissionValueBool.Buttons"))
			});
			this.imageComboBoxPermissionValueBool.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxPermissionValueBool.Items"), resources.GetString("imageComboBoxPermissionValueBool.Items1"), (int)resources.GetObject("imageComboBoxPermissionValueBool.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxPermissionValueBool.Items3"), resources.GetString("imageComboBoxPermissionValueBool.Items4"), (int)resources.GetObject("imageComboBoxPermissionValueBool.Items5"))
			});
			this.imageComboBoxPermissionValueBool.Name = "imageComboBoxPermissionValueBool";
			this.imageComboBoxPermissionValueBool.SmallImages = this.imagesPermissions;
			this.imagesPermissions.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesPermissions.ImageStream");
			this.imagesPermissions.InsertGalleryImage("apply_16x16.png", "images/actions/apply_16x16.png", global::DevExpress.Images.ImageResourceCache.Default.GetImage("images/actions/apply_16x16.png"), 0);
			this.imagesPermissions.Images.SetKeyName(0, "apply_16x16.png");
			this.imagesPermissions.InsertGalleryImage("cancel_16x16.png", "images/actions/cancel_16x16.png", global::DevExpress.Images.ImageResourceCache.Default.GetImage("images/actions/cancel_16x16.png"), 1);
			this.imagesPermissions.Images.SetKeyName(1, "cancel_16x16.png");
			this.imagesPermissions.InsertImage(global::OpiekunWEB.Console.Properties.Resources.depend_on_user_16x16, "depend_on_user_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 2);
			this.imagesPermissions.Images.SetKeyName(2, "depend_on_user_16x16");
			resources.ApplyResources(this.imageComboBoxPermissionValueRemoteControl, "imageComboBoxPermissionValueRemoteControl");
			this.imageComboBoxPermissionValueRemoteControl.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxPermissionValueRemoteControl.Buttons"))
			});
			this.imageComboBoxPermissionValueRemoteControl.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxPermissionValueRemoteControl.Items"), resources.GetString("imageComboBoxPermissionValueRemoteControl.Items1"), (int)resources.GetObject("imageComboBoxPermissionValueRemoteControl.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxPermissionValueRemoteControl.Items3"), resources.GetString("imageComboBoxPermissionValueRemoteControl.Items4"), (int)resources.GetObject("imageComboBoxPermissionValueRemoteControl.Items5")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxPermissionValueRemoteControl.Items6"), resources.GetString("imageComboBoxPermissionValueRemoteControl.Items7"), (int)resources.GetObject("imageComboBoxPermissionValueRemoteControl.Items8"))
			});
			this.imageComboBoxPermissionValueRemoteControl.Name = "imageComboBoxPermissionValueRemoteControl";
			this.imageComboBoxPermissionValueRemoteControl.SmallImages = this.imagesPermissions;
			resources.ApplyResources(this.imageComboBoxPermissionValueInetControlState, "imageComboBoxPermissionValueInetControlState");
			this.imageComboBoxPermissionValueInetControlState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxPermissionValueInetControlState.Buttons"))
			});
			this.imageComboBoxPermissionValueInetControlState.Name = "imageComboBoxPermissionValueInetControlState";
			resources.ApplyResources(this.imageComboBoxSearchEngines, "imageComboBoxSearchEngines");
			this.imageComboBoxSearchEngines.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxSearchEngines.Buttons"))
			});
			this.imageComboBoxSearchEngines.Name = "imageComboBoxSearchEngines";
			resources.ApplyResources(this.imageComboBoxPermissionTypeWindowsUserDenyRemote, "imageComboBoxPermissionTypeWindowsUserDenyRemote");
			this.imageComboBoxPermissionTypeWindowsUserDenyRemote.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxPermissionTypeWindowsUserDenyRemote.Buttons"))
			});
			this.imageComboBoxPermissionTypeWindowsUserDenyRemote.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxPermissionTypeWindowsUserDenyRemote.Items"), resources.GetString("imageComboBoxPermissionTypeWindowsUserDenyRemote.Items1"), (int)resources.GetObject("imageComboBoxPermissionTypeWindowsUserDenyRemote.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxPermissionTypeWindowsUserDenyRemote.Items3"), resources.GetString("imageComboBoxPermissionTypeWindowsUserDenyRemote.Items4"), (int)resources.GetObject("imageComboBoxPermissionTypeWindowsUserDenyRemote.Items5"))
			});
			this.imageComboBoxPermissionTypeWindowsUserDenyRemote.Name = "imageComboBoxPermissionTypeWindowsUserDenyRemote";
			this.imageComboBoxPermissionTypeWindowsUserDenyRemote.SmallImages = this.imagesPermissions;
			resources.ApplyResources(this.imageComboBoxUrlHistoryLogFlags, "imageComboBoxUrlHistoryLogFlags");
			this.imageComboBoxUrlHistoryLogFlags.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxUrlHistoryLogFlags.Buttons"))
			});
			this.imageComboBoxUrlHistoryLogFlags.Name = "imageComboBoxUrlHistoryLogFlags";
			this.imageComboBoxUrlHistoryLogFlags.SmallImages = this.imagesInetHistoryLog;
			this.imagesInetHistoryLog.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imagesInetHistoryLog.ImageStream");
			this.imagesInetHistoryLog.InsertImage(global::OpiekunWEB.Console.Properties.Resources.access_block_16x16, "access_block_16x16", typeof(global::OpiekunWEB.Console.Properties.Resources), 0);
			this.imagesInetHistoryLog.Images.SetKeyName(0, "access_block_16x16");
			this.imagesInetHistoryLog.InsertGalleryImage("viewonweb_16x16.png", "images/miscellaneous/viewonweb_16x16.png", global::DevExpress.Images.ImageResourceCache.Default.GetImage("images/miscellaneous/viewonweb_16x16.png"), 1);
			this.imagesInetHistoryLog.Images.SetKeyName(1, "viewonweb_16x16.png");
			this.imagesInetHistoryLog.InsertGalleryImage("cancel_16x16.png", "images/actions/cancel_16x16.png", global::DevExpress.Images.ImageResourceCache.Default.GetImage("images/actions/cancel_16x16.png"), 2);
			this.imagesInetHistoryLog.Images.SetKeyName(2, "cancel_16x16.png");
			resources.ApplyResources(this.imageComboBoxAllowedCategories, "imageComboBoxAllowedCategories");
			this.imageComboBoxAllowedCategories.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxAllowedCategories.Buttons"))
			});
			this.imageComboBoxAllowedCategories.Name = "imageComboBoxAllowedCategories";
			resources.ApplyResources(this.buttonShowAvailableDeviceGroups, "buttonShowAvailableDeviceGroups");
			this.buttonShowAvailableDeviceGroups.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("buttonShowAvailableDeviceGroups.Buttons"), resources.GetString("buttonShowAvailableDeviceGroups.Buttons1"), (int)resources.GetObject("buttonShowAvailableDeviceGroups.Buttons2"), (bool)resources.GetObject("buttonShowAvailableDeviceGroups.Buttons3"), (bool)resources.GetObject("buttonShowAvailableDeviceGroups.Buttons4"), (bool)resources.GetObject("buttonShowAvailableDeviceGroups.Buttons5"), editorButtonImageOptions, new global::DevExpress.Utils.KeyShortcut(global::System.Windows.Forms.Keys.None), serializableAppearanceObject, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, resources.GetString("buttonShowAvailableDeviceGroups.Buttons6"), resources.GetObject("buttonShowAvailableDeviceGroups.Buttons7"), (global::DevExpress.Utils.SuperToolTip)resources.GetObject("buttonShowAvailableDeviceGroups.Buttons8"), (global::DevExpress.Utils.ToolTipAnchor)resources.GetObject("buttonShowAvailableDeviceGroups.Buttons9"))
			});
			this.buttonShowAvailableDeviceGroups.ButtonsStyle = global::DevExpress.XtraEditors.Controls.BorderStyles.Simple;
			this.buttonShowAvailableDeviceGroups.Mask.EditMask = resources.GetString("buttonShowAvailableDeviceGroups.Mask.EditMask");
			this.buttonShowAvailableDeviceGroups.Name = "buttonShowAvailableDeviceGroups";
			this.buttonShowAvailableDeviceGroups.ReadOnly = true;
			this.buttonShowAvailableDeviceGroups.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.buttonShowAvailableDeviceGroups.Click += new global::System.EventHandler(this.buttonShowAvailableDeviceGroups_Click);
			resources.ApplyResources(this.imageComboBoxDeviceGroupsSelectMode, "imageComboBoxDeviceGroupsSelectMode");
			this.imageComboBoxDeviceGroupsSelectMode.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxDeviceGroupsSelectMode.Buttons"))
			});
			this.imageComboBoxDeviceGroupsSelectMode.Name = "imageComboBoxDeviceGroupsSelectMode";
			resources.ApplyResources(this.repositoryItemTreeListEditAppControlState, "repositoryItemTreeListEditAppControlState");
			this.repositoryItemTreeListEditAppControlState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryItemTreeListEditAppControlState.Buttons"))
			});
			this.repositoryItemTreeListEditAppControlState.DisplayMember = "Name";
			this.repositoryItemTreeListEditAppControlState.Name = "repositoryItemTreeListEditAppControlState";
			this.repositoryItemTreeListEditAppControlState.TreeList = this.repositoryItemTreeListAppControlState;
			this.repositoryItemTreeListAppControlState.Columns.AddRange(new global::DevExpress.XtraTreeList.Columns.TreeListColumn[]
			{
				this.treeColumnAppStateName
			});
			this.repositoryItemTreeListAppControlState.KeyFieldName = "Id";
			resources.ApplyResources(this.repositoryItemTreeListAppControlState, "repositoryItemTreeListAppControlState");
			this.repositoryItemTreeListAppControlState.Name = "repositoryItemTreeListAppControlState";
			this.repositoryItemTreeListAppControlState.OptionsView.ShowColumns = false;
			this.repositoryItemTreeListAppControlState.OptionsView.ShowIndentAsRowStyle = true;
			this.repositoryItemTreeListAppControlState.ParentFieldName = "ParentId";
			this.repositoryItemTreeListAppControlState.BeforeFocusNode += new global::DevExpress.XtraTreeList.BeforeFocusNodeEventHandler(this.repositoryItemTreeListAppControlState_BeforeFocusNode);
			resources.ApplyResources(this.treeColumnAppStateName, "treeColumnAppStateName");
			this.treeColumnAppStateName.FieldName = "Name";
			this.treeColumnAppStateName.Name = "treeColumnAppStateName";
			this.xtraScrollablePermissionDescription.Controls.Add(this.labelPermissionDescription);
			resources.ApplyResources(this.xtraScrollablePermissionDescription, "xtraScrollablePermissionDescription");
			this.xtraScrollablePermissionDescription.Name = "xtraScrollablePermissionDescription";
			this.labelPermissionDescription.AllowHtmlString = true;
			this.labelPermissionDescription.Appearance.Options.UseTextOptions = true;
			this.labelPermissionDescription.Appearance.TextOptions.Trimming = global::DevExpress.Utils.Trimming.EllipsisCharacter;
			this.labelPermissionDescription.Appearance.TextOptions.WordWrap = global::DevExpress.Utils.WordWrap.Wrap;
			this.labelPermissionDescription.AutoEllipsis = true;
			resources.ApplyResources(this.labelPermissionDescription, "labelPermissionDescription");
			this.labelPermissionDescription.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.labelPermissionDescription.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.question_32x32;
			this.labelPermissionDescription.Name = "labelPermissionDescription";
			this.xtraTabPageUsers.Controls.Add(this.gridUsers);
			this.xtraTabPageUsers.Controls.Add(this.xtraScrollableUsersDescription);
			resources.ApplyResources(this.xtraTabPageUsers, "xtraTabPageUsers");
			this.xtraTabPageUsers.Name = "xtraTabPageUsers";
			resources.ApplyResources(this.gridUsers, "gridUsers");
			this.gridUsers.EmbeddedNavigator.Margin = (global::System.Windows.Forms.Padding)resources.GetObject("gridUsers.EmbeddedNavigator.Margin");
			this.gridUsers.MainView = this.gridViewUsers;
			this.gridUsers.Name = "gridUsers";
			this.gridUsers.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxUserStatus
			});
			this.gridUsers.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewUsers
			});
			this.gridViewUsers.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnUserName,
				this.gridColumnUserIdenty,
				this.gridColumnRoleId,
				this.gridColumnUserStatus,
				this.gridColumnUserCommand
			});
			this.gridViewUsers.DetailHeight = 437;
			this.gridViewUsers.GridControl = this.gridUsers;
			this.gridViewUsers.Name = "gridViewUsers";
			this.gridViewUsers.OptionsMenu.EnableColumnMenu = false;
			this.gridViewUsers.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewUsers.OptionsSelection.MultiSelect = true;
			this.gridViewUsers.OptionsSelection.UseIndicatorForSelection = false;
			this.gridViewUsers.OptionsView.ShowDetailButtons = false;
			this.gridViewUsers.OptionsView.ShowGroupExpandCollapseButtons = false;
			this.gridViewUsers.OptionsView.ShowGroupPanel = false;
			this.gridViewUsers.OptionsView.ShowIndicator = false;
			this.gridViewUsers.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnUserName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewUsers.CustomRowFilter += new global::DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridViewUsers_CustomRowFilter);
			this.gridViewUsers.MouseDown += new global::System.Windows.Forms.MouseEventHandler(this.gridViewUsers_MouseDown);
			this.gridColumnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnUserName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnUserName, "gridColumnUserName");
			this.gridColumnUserName.FieldName = "Name";
			this.gridColumnUserName.MinWidth = 25;
			this.gridColumnUserName.Name = "gridColumnUserName";
			this.gridColumnUserName.OptionsColumn.AllowEdit = false;
			this.gridColumnUserName.OptionsColumn.AllowFocus = false;
			this.gridColumnUserIdenty.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnUserIdenty.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnUserIdenty, "gridColumnUserIdenty");
			this.gridColumnUserIdenty.FieldName = "Identy";
			this.gridColumnUserIdenty.MinWidth = 25;
			this.gridColumnUserIdenty.Name = "gridColumnUserIdenty";
			this.gridColumnUserIdenty.OptionsColumn.AllowEdit = false;
			this.gridColumnUserIdenty.OptionsColumn.AllowFocus = false;
			this.gridColumnRoleId.FieldName = "RoleId";
			this.gridColumnRoleId.MinWidth = 31;
			this.gridColumnRoleId.Name = "gridColumnRoleId";
			this.gridColumnRoleId.OptionsColumn.ShowInCustomizationForm = false;
			this.gridColumnRoleId.OptionsColumn.ShowInExpressionEditor = false;
			resources.ApplyResources(this.gridColumnRoleId, "gridColumnRoleId");
			this.gridColumnUserStatus.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnUserStatus.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnUserStatus, "gridColumnUserStatus");
			this.gridColumnUserStatus.ColumnEdit = this.imageComboBoxUserStatus;
			this.gridColumnUserStatus.FieldName = "Status";
			this.gridColumnUserStatus.MinWidth = 31;
			this.gridColumnUserStatus.Name = "gridColumnUserStatus";
			this.gridColumnUserStatus.OptionsColumn.AllowEdit = false;
			this.gridColumnUserStatus.OptionsColumn.AllowFocus = false;
			this.gridColumnUserStatus.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			resources.ApplyResources(this.imageComboBoxUserStatus, "imageComboBoxUserStatus");
			this.imageComboBoxUserStatus.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxUserStatus.Buttons"))
			});
			this.imageComboBoxUserStatus.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxUserStatus.Items"), resources.GetObject("imageComboBoxUserStatus.Items1"), (int)resources.GetObject("imageComboBoxUserStatus.Items2"))
			});
			this.imageComboBoxUserStatus.Name = "imageComboBoxUserStatus";
			this.gridColumnUserCommand.MinWidth = 25;
			this.gridColumnUserCommand.Name = "gridColumnUserCommand";
			resources.ApplyResources(this.gridColumnUserCommand, "gridColumnUserCommand");
			this.xtraScrollableUsersDescription.Controls.Add(this.labelUsersDescription);
			resources.ApplyResources(this.xtraScrollableUsersDescription, "xtraScrollableUsersDescription");
			this.xtraScrollableUsersDescription.Name = "xtraScrollableUsersDescription";
			this.labelUsersDescription.AllowHtmlString = true;
			this.labelUsersDescription.Appearance.Options.UseTextOptions = true;
			this.labelUsersDescription.Appearance.TextOptions.Trimming = global::DevExpress.Utils.Trimming.EllipsisCharacter;
			this.labelUsersDescription.Appearance.TextOptions.WordWrap = global::DevExpress.Utils.WordWrap.Wrap;
			this.labelUsersDescription.AutoEllipsis = true;
			resources.ApplyResources(this.labelUsersDescription, "labelUsersDescription");
			this.labelUsersDescription.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.labelUsersDescription.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.question_32x32;
			this.labelUsersDescription.Name = "labelUsersDescription";
			this.ribbonControl.AllowMinimizeRibbon = false;
			this.ribbonControl.ExpandCollapseItem.Id = 0;
			this.ribbonControl.ExpandCollapseItem.ImageOptions.ImageIndex = (int)resources.GetObject("ribbonControl.ExpandCollapseItem.ImageOptions.ImageIndex");
			this.ribbonControl.ExpandCollapseItem.ImageOptions.LargeImageIndex = (int)resources.GetObject("ribbonControl.ExpandCollapseItem.ImageOptions.LargeImageIndex");
			this.ribbonControl.Items.AddRange(new global::DevExpress.XtraBars.BarItem[]
			{
				this.ribbonControl.ExpandCollapseItem,
				this.ribbonControl.SearchEditItem,
				this.barButtonAddApiUserRole,
				this.barButtonAddWindowsUserRole,
				this.barButtonAddApiUser,
				this.barButtonClose,
				this.barButtonAddWindowsUser,
				this.barButtonImportWindowsUser,
				this.barButtonDeleteUser
			});
			resources.ApplyResources(this.ribbonControl, "ribbonControl");
			this.ribbonControl.MaxItemId = 22;
			this.ribbonControl.Name = "ribbonControl";
			this.ribbonControl.Pages.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPage[]
			{
				this.ribbonPage
			});
			this.ribbonControl.ShowApplicationButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonControl.ShowPageHeadersMode = global::DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
			this.ribbonControl.ShowToolbarCustomizeItem = false;
			this.ribbonControl.Toolbar.ShowCustomizeItem = false;
			resources.ApplyResources(this.barButtonAddApiUserRole, "barButtonAddApiUserRole");
			this.barButtonAddApiUserRole.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.barButtonAddApiUserRole.Id = 12;
			this.barButtonAddApiUserRole.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonAddApiUserRole.ImageOptions.Image");
			this.barButtonAddApiUserRole.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonAddApiUserRole.ImageOptions.ImageIndex");
			this.barButtonAddApiUserRole.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.roles_add_api_usersgroup_32x32;
			this.barButtonAddApiUserRole.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonAddApiUserRole.ImageOptions.LargeImageIndex");
			this.barButtonAddApiUserRole.Name = "barButtonAddApiUserRole";
			this.barButtonAddApiUserRole.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddApiUserRole_ItemClick);
			resources.ApplyResources(this.barButtonAddWindowsUserRole, "barButtonAddWindowsUserRole");
			this.barButtonAddWindowsUserRole.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.barButtonAddWindowsUserRole.Id = 13;
			this.barButtonAddWindowsUserRole.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.usergroup_16x16;
			this.barButtonAddWindowsUserRole.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonAddWindowsUserRole.ImageOptions.ImageIndex");
			this.barButtonAddWindowsUserRole.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.roles_add_usersgroup_32x32;
			this.barButtonAddWindowsUserRole.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonAddWindowsUserRole.ImageOptions.LargeImageIndex");
			this.barButtonAddWindowsUserRole.Name = "barButtonAddWindowsUserRole";
			this.barButtonAddWindowsUserRole.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddWindowsUserRole_ItemClick);
			resources.ApplyResources(this.barButtonAddApiUser, "barButtonAddApiUser");
			this.barButtonAddApiUser.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.barButtonAddApiUser.Id = 14;
			this.barButtonAddApiUser.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonAddApiUser.ImageOptions.Image");
			this.barButtonAddApiUser.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonAddApiUser.ImageOptions.ImageIndex");
			this.barButtonAddApiUser.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.roles_add_api_user32x32;
			this.barButtonAddApiUser.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonAddApiUser.ImageOptions.LargeImageIndex");
			this.barButtonAddApiUser.Name = "barButtonAddApiUser";
			this.barButtonAddApiUser.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddUser_ItemClick);
			resources.ApplyResources(this.barButtonClose, "barButtonClose");
			this.barButtonClose.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.barButtonClose.Id = 16;
			this.barButtonClose.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.close_16x16;
			this.barButtonClose.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonClose.ImageOptions.ImageIndex");
			this.barButtonClose.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.close_32x32;
			this.barButtonClose.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonClose.ImageOptions.LargeImageIndex");
			this.barButtonClose.Name = "barButtonClose";
			this.barButtonClose.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonClose_ItemClick);
			resources.ApplyResources(this.barButtonAddWindowsUser, "barButtonAddWindowsUser");
			this.barButtonAddWindowsUser.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.barButtonAddWindowsUser.Id = 18;
			this.barButtonAddWindowsUser.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.customer_16x16;
			this.barButtonAddWindowsUser.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonAddWindowsUser.ImageOptions.ImageIndex");
			this.barButtonAddWindowsUser.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.roles_add_user_32x32;
			this.barButtonAddWindowsUser.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonAddWindowsUser.ImageOptions.LargeImageIndex");
			this.barButtonAddWindowsUser.Name = "barButtonAddWindowsUser";
			this.barButtonAddWindowsUser.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddUser_ItemClick);
			resources.ApplyResources(this.barButtonImportWindowsUser, "barButtonImportWindowsUser");
			this.barButtonImportWindowsUser.Id = 19;
			this.barButtonImportWindowsUser.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("barButtonImportWindowsUser.ImageOptions.Image");
			this.barButtonImportWindowsUser.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonImportWindowsUser.ImageOptions.ImageIndex");
			this.barButtonImportWindowsUser.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.roles_import_users_32x32;
			this.barButtonImportWindowsUser.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonImportWindowsUser.ImageOptions.LargeImageIndex");
			this.barButtonImportWindowsUser.Name = "barButtonImportWindowsUser";
			this.barButtonImportWindowsUser.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonImportWindowsUser_ItemClick);
			resources.ApplyResources(this.barButtonDeleteUser, "barButtonDeleteUser");
			this.barButtonDeleteUser.Id = 21;
			this.barButtonDeleteUser.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.deletelist_16x16;
			this.barButtonDeleteUser.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.deletelist_32x32;
			this.barButtonDeleteUser.Name = "barButtonDeleteUser";
			this.barButtonDeleteUser.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonDeleteUser_ItemClick);
			this.ribbonPage.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.ribbonPageGroupAdd
			});
			this.ribbonPage.Name = "ribbonPage";
			this.ribbonPageGroupAdd.CaptionButtonVisible = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonPageGroupAdd.ItemLinks.Add(this.barButtonClose);
			this.ribbonPageGroupAdd.ItemLinks.Add(this.barButtonAddApiUser, true);
			this.ribbonPageGroupAdd.ItemLinks.Add(this.barButtonAddApiUserRole);
			this.ribbonPageGroupAdd.ItemLinks.Add(this.barButtonAddWindowsUser, true);
			this.ribbonPageGroupAdd.ItemLinks.Add(this.barButtonAddWindowsUserRole);
			this.ribbonPageGroupAdd.ItemLinks.Add(this.barButtonImportWindowsUser);
			this.ribbonPageGroupAdd.Name = "ribbonPageGroupAdd";
			resources.ApplyResources(this.ribbonPageGroupAdd, "ribbonPageGroupAdd");
			resources.ApplyResources(this.barStaticItemSelection, "barStaticItemSelection");
			this.barStaticItemSelection.Id = 7;
			this.barStaticItemSelection.ImageOptions.ImageIndex = (int)resources.GetObject("barStaticItemSelection.ImageOptions.ImageIndex");
			this.barStaticItemSelection.ImageOptions.LargeImageIndex = (int)resources.GetObject("barStaticItemSelection.ImageOptions.LargeImageIndex");
			this.barStaticItemSelection.Name = "barStaticItemSelection";
			this.barStaticItemSelection.PaintStyle = global::DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
			this.popupMenuUsers.ItemLinks.Add(this.barButtonDeleteUser);
			this.popupMenuUsers.Name = "popupMenuUsers";
			this.popupMenuUsers.Ribbon = this.ribbonControl;
			this.barButtonItem1.CategoryGuid = new global::System.Guid("6ffddb2b-9015-4d97-a4c1-91613e0ef537");
			this.barButtonItem1.Id = 2;
			this.barButtonItem1.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.delete_16x16;
			this.barButtonItem1.ImageOptions.ImageIndex = (int)resources.GetObject("barButtonItem1.ImageOptions.ImageIndex");
			this.barButtonItem1.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.delete_32x32;
			this.barButtonItem1.ImageOptions.LargeImageIndex = (int)resources.GetObject("barButtonItem1.ImageOptions.LargeImageIndex");
			this.barButtonItem1.Name = "barButtonItem1";
			base.AllowFormGlass = global::DevExpress.Utils.DefaultBoolean.False;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.splitContainerMain);
			base.Controls.Add(this.ribbonControl);
			base.Name = "RolesForm";
			this.Ribbon = this.ribbonControl;
			base.ShowInTaskbar = false;
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerMain.Panel1).EndInit();
			this.splitContainerMain.Panel1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerMain.Panel2).EndInit();
			this.splitContainerMain.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerMain).EndInit();
			this.splitContainerMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridRoles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewRoles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControl).EndInit();
			this.xtraTabControl.ResumeLayout(false);
			this.xtraTabPagePermissions.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridPermissions).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewPermissions).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionValueBool).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesPermissions).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionValueRemoteControl).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionValueInetControlState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxSearchEngines).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxPermissionTypeWindowsUserDenyRemote).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUrlHistoryLogFlags).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imagesInetHistoryLog).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxAllowedCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.buttonShowAvailableDeviceGroups).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxDeviceGroupsSelectMode).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemTreeListEditAppControlState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemTreeListAppControlState).EndInit();
			this.xtraScrollablePermissionDescription.ResumeLayout(false);
			this.xtraTabPageUsers.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridUsers).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUsers).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUserStatus).EndInit();
			this.xtraScrollableUsersDescription.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.popupMenuUsers).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000458 RID: 1112
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000459 RID: 1113
		private global::DevExpress.XtraEditors.SplitContainerControl splitContainerMain;

		// Token: 0x0400045A RID: 1114
		private global::DevExpress.XtraGrid.GridControl gridRoles;

		// Token: 0x0400045B RID: 1115
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewRoles;

		// Token: 0x0400045C RID: 1116
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleName;

		// Token: 0x0400045D RID: 1117
		private global::DevExpress.XtraTab.XtraTabControl xtraTabControl;

		// Token: 0x0400045E RID: 1118
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPageUsers;

		// Token: 0x0400045F RID: 1119
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPagePermissions;

		// Token: 0x04000460 RID: 1120
		private global::DevExpress.XtraGrid.GridControl gridUsers;

		// Token: 0x04000461 RID: 1121
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewUsers;

		// Token: 0x04000462 RID: 1122
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnUserName;

		// Token: 0x04000463 RID: 1123
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnUserIdenty;

		// Token: 0x04000464 RID: 1124
		private global::DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;

		// Token: 0x04000465 RID: 1125
		private global::DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage;

		// Token: 0x04000466 RID: 1126
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupAdd;

		// Token: 0x04000467 RID: 1127
		private global::DevExpress.XtraGrid.GridControl gridPermissions;

		// Token: 0x04000468 RID: 1128
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewPermissions;

		// Token: 0x04000469 RID: 1129
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnPermissionDisplayName;

		// Token: 0x0400046A RID: 1130
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnPermissionType;

		// Token: 0x0400046B RID: 1131
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleType;

		// Token: 0x0400046C RID: 1132
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxPermissionValueBool;

		// Token: 0x0400046D RID: 1133
		private global::DevExpress.Utils.ImageCollection imagesPermissions;

		// Token: 0x0400046E RID: 1134
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxPermissionValueRemoteControl;

		// Token: 0x0400046F RID: 1135
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnPermissionValue;

		// Token: 0x04000470 RID: 1136
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxPermissionValueInetControlState;

		// Token: 0x04000471 RID: 1137
		private global::DevExpress.XtraBars.PopupMenu popupMenuUsers;

		// Token: 0x04000472 RID: 1138
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddApiUserRole;

		// Token: 0x04000473 RID: 1139
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddWindowsUserRole;

		// Token: 0x04000474 RID: 1140
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddApiUser;

		// Token: 0x04000475 RID: 1141
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxSearchEngines;

		// Token: 0x04000476 RID: 1142
		private global::DevExpress.XtraBars.BarButtonItem barButtonClose;

		// Token: 0x04000477 RID: 1143
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxPermissionTypeWindowsUserDenyRemote;

		// Token: 0x04000478 RID: 1144
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddWindowsUser;

		// Token: 0x04000479 RID: 1145
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxUrlHistoryLogFlags;

		// Token: 0x0400047A RID: 1146
		private global::DevExpress.XtraBars.BarButtonItem barButtonImportWindowsUser;

		// Token: 0x0400047B RID: 1147
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleId;

		// Token: 0x0400047C RID: 1148
		private global::DevExpress.XtraBars.BarStaticItem barStaticItemSelection;

		// Token: 0x0400047D RID: 1149
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnUserStatus;

		// Token: 0x0400047E RID: 1150
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxUserStatus;

		// Token: 0x0400047F RID: 1151
		private global::DevExpress.XtraEditors.XtraScrollableControl xtraScrollablePermissionDescription;

		// Token: 0x04000480 RID: 1152
		private global::DevExpress.XtraEditors.LabelControl labelPermissionDescription;

		// Token: 0x04000481 RID: 1153
		private global::DevExpress.XtraEditors.XtraScrollableControl xtraScrollableUsersDescription;

		// Token: 0x04000482 RID: 1154
		private global::DevExpress.XtraEditors.LabelControl labelUsersDescription;

		// Token: 0x04000483 RID: 1155
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxAllowedCategories;

		// Token: 0x04000484 RID: 1156
		private global::DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit buttonShowAvailableDeviceGroups;

		// Token: 0x04000485 RID: 1157
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxDeviceGroupsSelectMode;

		// Token: 0x04000486 RID: 1158
		private global::DevExpress.XtraBars.BarButtonItem barButtonItem1;

		// Token: 0x04000487 RID: 1159
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleCommand;

		// Token: 0x04000488 RID: 1160
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnUserCommand;

		// Token: 0x04000489 RID: 1161
		private global::DevExpress.XtraBars.BarButtonItem barButtonDeleteUser;

		// Token: 0x0400048A RID: 1162
		private global::DevExpress.XtraEditors.Repository.RepositoryItemTreeListLookUpEdit repositoryItemTreeListEditAppControlState;

		// Token: 0x0400048B RID: 1163
		private global::DevExpress.XtraTreeList.TreeList repositoryItemTreeListAppControlState;

		// Token: 0x0400048C RID: 1164
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn treeColumnAppStateName;

		// Token: 0x0400048D RID: 1165
		private global::DevExpress.Utils.ImageCollection imagesInetHistoryLog;
	}
}
