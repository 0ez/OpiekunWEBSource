﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000054 RID: 84
	public partial class LogonUserForm : BaseForm
	{
		// Token: 0x06000494 RID: 1172 RVA: 0x00015878 File Offset: 0x00013A78
		public LogonUserForm(FormsSettings formsSettings, IFormCreator formCreator, LogonSessionFormParams @params) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this._params = @params;
			this.InitializeComponent();
			this._objectsToSaveState.Add(this.textEditUserName);
			this._objectsToSaveState.Add(this.textEditDomainName);
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x000158B2 File Offset: 0x00013AB2
		public LogonUserForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x000158C0 File Offset: 0x00013AC0
		private void buttonOk_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this.textEditUserName.Text))
			{
				this._formCreator.ShowError(Resources.LogonSessionFormParams_MustEnterUserName);
				base.ActiveControl = this.textEditUserName;
				return;
			}
			this._params.DomainName = this.textEditDomainName.Text;
			this._params.UserName = this.textEditUserName.Text;
			this._params.Password = this.textEditPassword.Text;
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x040001DE RID: 478
		private readonly LogonSessionFormParams _params;
	}
}
