﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000073 RID: 115
	public partial class SelectConsoleGroupsOnDeviceRuleForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x06000614 RID: 1556 RVA: 0x0002BA0F File Offset: 0x00029C0F
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x0002BA30 File Offset: 0x00029C30
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.SelectConsoleGroupsOnDeviceRuleForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.checkEditApplyForUnrecognized = new global::DevExpress.XtraEditors.CheckEdit();
			this.imageComboBoxDeviceGroupsSelectMode = new global::DevExpress.XtraEditors.ImageComboBoxEdit();
			this.buttonEditAvailableDeviceGroups = new global::DevExpress.XtraEditors.ButtonEdit();
			this.textEditRuleName = new global::DevExpress.XtraEditors.TextEdit();
			this.buttonSelectDevices = new global::DevExpress.XtraEditors.SimpleButton();
			this.gridDevices = new global::DevExpress.XtraGrid.GridControl();
			this.cardViewDevices = new global::DevExpress.XtraGrid.Views.Card.CardView();
			this.gridColumnDeviceName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.checkedComboBoxRoles = new global::DevExpress.XtraEditors.CheckedComboBoxEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlGroupDevices = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlDevices = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlSelectDevices = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlApplyForUnrecognized = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroupRoles = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlEditRoles = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroupRuleName = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlRuleName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroupSettings = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlAvailableDeviceGroups = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlDeviceGroupsSelectMode = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditApplyForUnrecognized.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxDeviceGroupsSelectMode.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.buttonEditAvailableDeviceGroups.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditRuleName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.cardViewDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkedComboBoxRoles.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSelectDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlApplyForUnrecognized).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupRoles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlEditRoles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupRuleName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlRuleName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupSettings).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlAvailableDeviceGroups).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDeviceGroupsSelectMode).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			this.buttonSave.ImageOptions.ImageIndex = (int)resources.GetObject("buttonSave.ImageOptions.ImageIndex");
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutItem.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.Image");
			this.layoutControlMain.Controls.Add(this.checkEditApplyForUnrecognized);
			this.layoutControlMain.Controls.Add(this.imageComboBoxDeviceGroupsSelectMode);
			this.layoutControlMain.Controls.Add(this.buttonEditAvailableDeviceGroups);
			this.layoutControlMain.Controls.Add(this.textEditRuleName);
			this.layoutControlMain.Controls.Add(this.buttonSelectDevices);
			this.layoutControlMain.Controls.Add(this.gridDevices);
			this.layoutControlMain.Controls.Add(this.checkedComboBoxRoles);
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2887, 6, 812, 500));
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.Image");
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.checkEditApplyForUnrecognized, "checkEditApplyForUnrecognized");
			this.checkEditApplyForUnrecognized.Name = "checkEditApplyForUnrecognized";
			this.checkEditApplyForUnrecognized.Properties.AccessibleDescription = resources.GetString("checkEditApplyForUnrecognized.Properties.AccessibleDescription");
			this.checkEditApplyForUnrecognized.Properties.AccessibleName = resources.GetString("checkEditApplyForUnrecognized.Properties.AccessibleName");
			this.checkEditApplyForUnrecognized.Properties.AutoHeight = (bool)resources.GetObject("checkEditApplyForUnrecognized.Properties.AutoHeight");
			this.checkEditApplyForUnrecognized.Properties.Caption = resources.GetString("checkEditApplyForUnrecognized.Properties.Caption");
			this.checkEditApplyForUnrecognized.Properties.DisplayValueChecked = resources.GetString("checkEditApplyForUnrecognized.Properties.DisplayValueChecked");
			this.checkEditApplyForUnrecognized.Properties.DisplayValueGrayed = resources.GetString("checkEditApplyForUnrecognized.Properties.DisplayValueGrayed");
			this.checkEditApplyForUnrecognized.Properties.DisplayValueUnchecked = resources.GetString("checkEditApplyForUnrecognized.Properties.DisplayValueUnchecked");
			this.checkEditApplyForUnrecognized.Properties.GlyphVerticalAlignment = (global::DevExpress.Utils.VertAlignment)resources.GetObject("checkEditApplyForUnrecognized.Properties.GlyphVerticalAlignment");
			this.checkEditApplyForUnrecognized.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.imageComboBoxDeviceGroupsSelectMode, "imageComboBoxDeviceGroupsSelectMode");
			this.imageComboBoxDeviceGroupsSelectMode.Name = "imageComboBoxDeviceGroupsSelectMode";
			this.imageComboBoxDeviceGroupsSelectMode.Properties.AccessibleDescription = resources.GetString("imageComboBoxDeviceGroupsSelectMode.Properties.AccessibleDescription");
			this.imageComboBoxDeviceGroupsSelectMode.Properties.AccessibleName = resources.GetString("imageComboBoxDeviceGroupsSelectMode.Properties.AccessibleName");
			this.imageComboBoxDeviceGroupsSelectMode.Properties.AutoHeight = (bool)resources.GetObject("imageComboBoxDeviceGroupsSelectMode.Properties.AutoHeight");
			this.imageComboBoxDeviceGroupsSelectMode.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxDeviceGroupsSelectMode.Properties.Buttons"))
			});
			this.imageComboBoxDeviceGroupsSelectMode.Properties.GlyphAlignment = (global::DevExpress.Utils.HorzAlignment)resources.GetObject("imageComboBoxDeviceGroupsSelectMode.Properties.GlyphAlignment");
			this.imageComboBoxDeviceGroupsSelectMode.Properties.NullValuePrompt = resources.GetString("imageComboBoxDeviceGroupsSelectMode.Properties.NullValuePrompt");
			this.imageComboBoxDeviceGroupsSelectMode.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("imageComboBoxDeviceGroupsSelectMode.Properties.NullValuePromptShowForEmptyValue");
			this.imageComboBoxDeviceGroupsSelectMode.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.buttonEditAvailableDeviceGroups, "buttonEditAvailableDeviceGroups");
			this.buttonEditAvailableDeviceGroups.Name = "buttonEditAvailableDeviceGroups";
			this.buttonEditAvailableDeviceGroups.Properties.AccessibleDescription = resources.GetString("buttonEditAvailableDeviceGroups.Properties.AccessibleDescription");
			this.buttonEditAvailableDeviceGroups.Properties.AccessibleName = resources.GetString("buttonEditAvailableDeviceGroups.Properties.AccessibleName");
			this.buttonEditAvailableDeviceGroups.Properties.AutoHeight = (bool)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.AutoHeight");
			this.buttonEditAvailableDeviceGroups.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.buttonEditAvailableDeviceGroups.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.AutoComplete");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.BeepOnError = (bool)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.BeepOnError");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.EditMask = resources.GetString("buttonEditAvailableDeviceGroups.Properties.Mask.EditMask");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.IgnoreMaskBlank");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.MaskType");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.PlaceHolder = (char)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.PlaceHolder");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.SaveLiteral = (bool)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.SaveLiteral");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.ShowPlaceHolders");
			this.buttonEditAvailableDeviceGroups.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.Mask.UseMaskAsDisplayFormat");
			this.buttonEditAvailableDeviceGroups.Properties.NullValuePrompt = resources.GetString("buttonEditAvailableDeviceGroups.Properties.NullValuePrompt");
			this.buttonEditAvailableDeviceGroups.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("buttonEditAvailableDeviceGroups.Properties.NullValuePromptShowForEmptyValue");
			this.buttonEditAvailableDeviceGroups.StyleController = this.layoutControlMain;
			this.buttonEditAvailableDeviceGroups.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.buttonEditAvailableDeviceGroups_ButtonClick);
			resources.ApplyResources(this.textEditRuleName, "textEditRuleName");
			this.textEditRuleName.Name = "textEditRuleName";
			this.textEditRuleName.Properties.AccessibleDescription = resources.GetString("textEditRuleName.Properties.AccessibleDescription");
			this.textEditRuleName.Properties.AccessibleName = resources.GetString("textEditRuleName.Properties.AccessibleName");
			this.textEditRuleName.Properties.AutoHeight = (bool)resources.GetObject("textEditRuleName.Properties.AutoHeight");
			this.textEditRuleName.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("textEditRuleName.Properties.Mask.AutoComplete");
			this.textEditRuleName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditRuleName.Properties.Mask.BeepOnError");
			this.textEditRuleName.Properties.Mask.EditMask = resources.GetString("textEditRuleName.Properties.Mask.EditMask");
			this.textEditRuleName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditRuleName.Properties.Mask.IgnoreMaskBlank");
			this.textEditRuleName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditRuleName.Properties.Mask.MaskType");
			this.textEditRuleName.Properties.Mask.PlaceHolder = (char)resources.GetObject("textEditRuleName.Properties.Mask.PlaceHolder");
			this.textEditRuleName.Properties.Mask.SaveLiteral = (bool)resources.GetObject("textEditRuleName.Properties.Mask.SaveLiteral");
			this.textEditRuleName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditRuleName.Properties.Mask.ShowPlaceHolders");
			this.textEditRuleName.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("textEditRuleName.Properties.Mask.UseMaskAsDisplayFormat");
			this.textEditRuleName.Properties.NullValuePrompt = resources.GetString("textEditRuleName.Properties.NullValuePrompt");
			this.textEditRuleName.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("textEditRuleName.Properties.NullValuePromptShowForEmptyValue");
			this.textEditRuleName.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.buttonSelectDevices, "buttonSelectDevices");
			this.buttonSelectDevices.ImageOptions.ImageIndex = (int)resources.GetObject("buttonSelectDevices.ImageOptions.ImageIndex");
			this.buttonSelectDevices.Name = "buttonSelectDevices";
			this.buttonSelectDevices.StyleController = this.layoutControlMain;
			this.buttonSelectDevices.Click += new global::System.EventHandler(this.buttonSelectDevices_Click);
			resources.ApplyResources(this.gridDevices, "gridDevices");
			this.gridDevices.EmbeddedNavigator.AccessibleDescription = resources.GetString("gridDevices.EmbeddedNavigator.AccessibleDescription");
			this.gridDevices.EmbeddedNavigator.AccessibleName = resources.GetString("gridDevices.EmbeddedNavigator.AccessibleName");
			this.gridDevices.EmbeddedNavigator.AllowHtmlTextInToolTip = (global::DevExpress.Utils.DefaultBoolean)resources.GetObject("gridDevices.EmbeddedNavigator.AllowHtmlTextInToolTip");
			this.gridDevices.EmbeddedNavigator.Anchor = (global::System.Windows.Forms.AnchorStyles)resources.GetObject("gridDevices.EmbeddedNavigator.Anchor");
			this.gridDevices.EmbeddedNavigator.BackgroundImage = (global::System.Drawing.Image)resources.GetObject("gridDevices.EmbeddedNavigator.BackgroundImage");
			this.gridDevices.EmbeddedNavigator.BackgroundImageLayout = (global::System.Windows.Forms.ImageLayout)resources.GetObject("gridDevices.EmbeddedNavigator.BackgroundImageLayout");
			this.gridDevices.EmbeddedNavigator.ImeMode = (global::System.Windows.Forms.ImeMode)resources.GetObject("gridDevices.EmbeddedNavigator.ImeMode");
			this.gridDevices.EmbeddedNavigator.MaximumSize = (global::System.Drawing.Size)resources.GetObject("gridDevices.EmbeddedNavigator.MaximumSize");
			this.gridDevices.EmbeddedNavigator.TextLocation = (global::DevExpress.XtraEditors.NavigatorButtonsTextLocation)resources.GetObject("gridDevices.EmbeddedNavigator.TextLocation");
			this.gridDevices.EmbeddedNavigator.ToolTip = resources.GetString("gridDevices.EmbeddedNavigator.ToolTip");
			this.gridDevices.EmbeddedNavigator.ToolTipIconType = (global::DevExpress.Utils.ToolTipIconType)resources.GetObject("gridDevices.EmbeddedNavigator.ToolTipIconType");
			this.gridDevices.EmbeddedNavigator.ToolTipTitle = resources.GetString("gridDevices.EmbeddedNavigator.ToolTipTitle");
			this.gridDevices.MainView = this.cardViewDevices;
			this.gridDevices.Name = "gridDevices";
			this.gridDevices.ShowOnlyPredefinedDetails = true;
			this.gridDevices.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.cardViewDevices
			});
			resources.ApplyResources(this.cardViewDevices, "cardViewDevices");
			this.cardViewDevices.CardInterval = 4;
			this.cardViewDevices.CardWidth = 120;
			this.cardViewDevices.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnDeviceName
			});
			this.cardViewDevices.GridControl = this.gridDevices;
			this.cardViewDevices.Name = "cardViewDevices";
			this.cardViewDevices.OptionsBehavior.Editable = false;
			this.cardViewDevices.OptionsBehavior.ReadOnly = true;
			this.cardViewDevices.OptionsView.ShowCardCaption = false;
			this.cardViewDevices.OptionsView.ShowCardExpandButton = false;
			this.cardViewDevices.OptionsView.ShowEmptyFields = false;
			this.cardViewDevices.OptionsView.ShowFieldCaptions = false;
			this.cardViewDevices.OptionsView.ShowLines = false;
			this.cardViewDevices.OptionsView.ShowQuickCustomizeButton = false;
			this.cardViewDevices.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnDeviceName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.cardViewDevices.VertScrollVisibility = global::DevExpress.XtraGrid.Views.Base.ScrollVisibility.Auto;
			resources.ApplyResources(this.gridColumnDeviceName, "gridColumnDeviceName");
			this.gridColumnDeviceName.FieldName = "Name";
			this.gridColumnDeviceName.ImageOptions.ImageIndex = (int)resources.GetObject("gridColumnDeviceName.ImageOptions.ImageIndex");
			this.gridColumnDeviceName.Name = "gridColumnDeviceName";
			this.gridColumnDeviceName.OptionsColumn.ShowCaption = false;
			resources.ApplyResources(this.checkedComboBoxRoles, "checkedComboBoxRoles");
			this.checkedComboBoxRoles.Name = "checkedComboBoxRoles";
			this.checkedComboBoxRoles.Properties.AccessibleDescription = resources.GetString("checkedComboBoxRoles.Properties.AccessibleDescription");
			this.checkedComboBoxRoles.Properties.AccessibleName = resources.GetString("checkedComboBoxRoles.Properties.AccessibleName");
			this.checkedComboBoxRoles.Properties.AutoHeight = (bool)resources.GetObject("checkedComboBoxRoles.Properties.AutoHeight");
			this.checkedComboBoxRoles.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("checkedComboBoxRoles.Properties.Buttons"))
			});
			this.checkedComboBoxRoles.Properties.DisplayMember = "Name";
			this.checkedComboBoxRoles.Properties.EditValueType = global::DevExpress.XtraEditors.Repository.EditValueTypeCollection.List;
			this.checkedComboBoxRoles.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("checkedComboBoxRoles.Properties.Mask.AutoComplete");
			this.checkedComboBoxRoles.Properties.Mask.BeepOnError = (bool)resources.GetObject("checkedComboBoxRoles.Properties.Mask.BeepOnError");
			this.checkedComboBoxRoles.Properties.Mask.EditMask = resources.GetString("checkedComboBoxRoles.Properties.Mask.EditMask");
			this.checkedComboBoxRoles.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("checkedComboBoxRoles.Properties.Mask.IgnoreMaskBlank");
			this.checkedComboBoxRoles.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("checkedComboBoxRoles.Properties.Mask.MaskType");
			this.checkedComboBoxRoles.Properties.Mask.PlaceHolder = (char)resources.GetObject("checkedComboBoxRoles.Properties.Mask.PlaceHolder");
			this.checkedComboBoxRoles.Properties.Mask.SaveLiteral = (bool)resources.GetObject("checkedComboBoxRoles.Properties.Mask.SaveLiteral");
			this.checkedComboBoxRoles.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("checkedComboBoxRoles.Properties.Mask.ShowPlaceHolders");
			this.checkedComboBoxRoles.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("checkedComboBoxRoles.Properties.Mask.UseMaskAsDisplayFormat");
			this.checkedComboBoxRoles.Properties.NullValuePrompt = resources.GetString("checkedComboBoxRoles.Properties.NullValuePrompt");
			this.checkedComboBoxRoles.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("checkedComboBoxRoles.Properties.NullValuePromptShowForEmptyValue");
			this.checkedComboBoxRoles.Properties.ValueMember = "Id";
			this.checkedComboBoxRoles.StyleController = this.layoutControlMain;
			this.Root.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("Root.BackgroundImageOptions.ImageIndex");
			this.Root.CaptionImageOptions.ImageIndex = (int)resources.GetObject("Root.CaptionImageOptions.ImageIndex");
			this.Root.ContentImageOptions.ImageIndex = (int)resources.GetObject("Root.ContentImageOptions.ImageIndex");
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlGroupDevices,
				this.layoutControlGroupRoles,
				this.layoutControlGroupRuleName,
				this.layoutControlGroupSettings
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(559, 520);
			this.Root.TextVisible = false;
			this.layoutControlGroupDevices.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupDevices.BackgroundImageOptions.ImageIndex");
			this.layoutControlGroupDevices.CaptionImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupDevices.CaptionImageOptions.ImageIndex");
			this.layoutControlGroupDevices.ContentImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupDevices.ContentImageOptions.ImageIndex");
			this.layoutControlGroupDevices.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlDevices,
				this.emptySpaceItem1,
				this.layoutControlSelectDevices,
				this.layoutControlApplyForUnrecognized
			});
			this.layoutControlGroupDevices.Location = new global::System.Drawing.Point(0, 146);
			this.layoutControlGroupDevices.Name = "layoutControlGroupDevices";
			this.layoutControlGroupDevices.Size = new global::System.Drawing.Size(539, 217);
			resources.ApplyResources(this.layoutControlGroupDevices, "layoutControlGroupDevices");
			resources.ApplyResources(this.layoutControlDevices, "layoutControlDevices");
			this.layoutControlDevices.Control = this.gridDevices;
			this.layoutControlDevices.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlDevices.ImageOptions.ImageIndex");
			this.layoutControlDevices.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlDevices.Name = "layoutControlDevices";
			this.layoutControlDevices.Size = new global::System.Drawing.Size(515, 139);
			this.layoutControlDevices.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlDevices.TextVisible = false;
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(203, 139);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(169, 31);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			resources.ApplyResources(this.layoutControlSelectDevices, "layoutControlSelectDevices");
			this.layoutControlSelectDevices.Control = this.buttonSelectDevices;
			this.layoutControlSelectDevices.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlSelectDevices.ImageOptions.ImageIndex");
			this.layoutControlSelectDevices.Location = new global::System.Drawing.Point(372, 139);
			this.layoutControlSelectDevices.Name = "layoutControlSelectDevices";
			this.layoutControlSelectDevices.Size = new global::System.Drawing.Size(143, 31);
			this.layoutControlSelectDevices.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlSelectDevices.TextVisible = false;
			resources.ApplyResources(this.layoutControlApplyForUnrecognized, "layoutControlApplyForUnrecognized");
			this.layoutControlApplyForUnrecognized.Control = this.checkEditApplyForUnrecognized;
			this.layoutControlApplyForUnrecognized.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlApplyForUnrecognized.ImageOptions.ImageIndex");
			this.layoutControlApplyForUnrecognized.Location = new global::System.Drawing.Point(0, 139);
			this.layoutControlApplyForUnrecognized.Name = "layoutControlApplyForUnrecognized";
			this.layoutControlApplyForUnrecognized.Size = new global::System.Drawing.Size(203, 31);
			this.layoutControlApplyForUnrecognized.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlApplyForUnrecognized.TextVisible = false;
			this.layoutControlGroupRoles.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupRoles.BackgroundImageOptions.ImageIndex");
			this.layoutControlGroupRoles.CaptionImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupRoles.CaptionImageOptions.ImageIndex");
			this.layoutControlGroupRoles.ContentImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupRoles.ContentImageOptions.ImageIndex");
			this.layoutControlGroupRoles.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlEditRoles
			});
			this.layoutControlGroupRoles.Location = new global::System.Drawing.Point(0, 73);
			this.layoutControlGroupRoles.Name = "layoutControlGroupRoles";
			this.layoutControlGroupRoles.Size = new global::System.Drawing.Size(539, 73);
			resources.ApplyResources(this.layoutControlGroupRoles, "layoutControlGroupRoles");
			resources.ApplyResources(this.layoutControlEditRoles, "layoutControlEditRoles");
			this.layoutControlEditRoles.Control = this.checkedComboBoxRoles;
			this.layoutControlEditRoles.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlEditRoles.ImageOptions.ImageIndex");
			this.layoutControlEditRoles.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlEditRoles.Name = "layoutControlEditRoles";
			this.layoutControlEditRoles.Size = new global::System.Drawing.Size(515, 26);
			this.layoutControlEditRoles.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlEditRoles.TextVisible = false;
			this.layoutControlGroupRuleName.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupRuleName.BackgroundImageOptions.ImageIndex");
			this.layoutControlGroupRuleName.CaptionImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupRuleName.CaptionImageOptions.ImageIndex");
			this.layoutControlGroupRuleName.ContentImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupRuleName.ContentImageOptions.ImageIndex");
			this.layoutControlGroupRuleName.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlRuleName
			});
			this.layoutControlGroupRuleName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlGroupRuleName.Name = "layoutControlGroupRuleName";
			this.layoutControlGroupRuleName.Size = new global::System.Drawing.Size(539, 73);
			resources.ApplyResources(this.layoutControlGroupRuleName, "layoutControlGroupRuleName");
			resources.ApplyResources(this.layoutControlRuleName, "layoutControlRuleName");
			this.layoutControlRuleName.Control = this.textEditRuleName;
			this.layoutControlRuleName.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlRuleName.ImageOptions.ImageIndex");
			this.layoutControlRuleName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlRuleName.Name = "layoutControlRuleName";
			this.layoutControlRuleName.Size = new global::System.Drawing.Size(515, 26);
			this.layoutControlRuleName.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlRuleName.TextVisible = false;
			this.layoutControlGroupSettings.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupSettings.BackgroundImageOptions.ImageIndex");
			this.layoutControlGroupSettings.CaptionImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupSettings.CaptionImageOptions.ImageIndex");
			this.layoutControlGroupSettings.ContentImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupSettings.ContentImageOptions.ImageIndex");
			this.layoutControlGroupSettings.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlAvailableDeviceGroups,
				this.layoutControlDeviceGroupsSelectMode
			});
			this.layoutControlGroupSettings.Location = new global::System.Drawing.Point(0, 363);
			this.layoutControlGroupSettings.Name = "layoutControlGroupSettings";
			this.layoutControlGroupSettings.Size = new global::System.Drawing.Size(539, 137);
			resources.ApplyResources(this.layoutControlGroupSettings, "layoutControlGroupSettings");
			resources.ApplyResources(this.layoutControlAvailableDeviceGroups, "layoutControlAvailableDeviceGroups");
			this.layoutControlAvailableDeviceGroups.Control = this.buttonEditAvailableDeviceGroups;
			this.layoutControlAvailableDeviceGroups.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlAvailableDeviceGroups.ImageOptions.ImageIndex");
			this.layoutControlAvailableDeviceGroups.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlAvailableDeviceGroups.Name = "layoutControlAvailableDeviceGroups";
			this.layoutControlAvailableDeviceGroups.Size = new global::System.Drawing.Size(515, 45);
			this.layoutControlAvailableDeviceGroups.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlAvailableDeviceGroups.TextSize = new global::System.Drawing.Size(189, 16);
			resources.ApplyResources(this.layoutControlDeviceGroupsSelectMode, "layoutControlDeviceGroupsSelectMode");
			this.layoutControlDeviceGroupsSelectMode.Control = this.imageComboBoxDeviceGroupsSelectMode;
			this.layoutControlDeviceGroupsSelectMode.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlDeviceGroupsSelectMode.ImageOptions.ImageIndex");
			this.layoutControlDeviceGroupsSelectMode.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlDeviceGroupsSelectMode.Name = "layoutControlDeviceGroupsSelectMode";
			this.layoutControlDeviceGroupsSelectMode.Size = new global::System.Drawing.Size(515, 45);
			this.layoutControlDeviceGroupsSelectMode.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDeviceGroupsSelectMode.TextSize = new global::System.Drawing.Size(189, 16);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.Name = "SelectConsoleGroupsOnDeviceRuleForm";
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			base.Controls.SetChildIndex(this.buttonSave, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.checkEditApplyForUnrecognized.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxDeviceGroupsSelectMode.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.buttonEditAvailableDeviceGroups.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditRuleName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.cardViewDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkedComboBoxRoles.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSelectDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlApplyForUnrecognized).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupRoles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlEditRoles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupRuleName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlRuleName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupSettings).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlAvailableDeviceGroups).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDeviceGroupsSelectMode).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400039A RID: 922
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400039B RID: 923
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x0400039C RID: 924
		private global::DevExpress.XtraEditors.CheckedComboBoxEdit checkedComboBoxRoles;

		// Token: 0x0400039D RID: 925
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x0400039E RID: 926
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlEditRoles;

		// Token: 0x0400039F RID: 927
		private global::DevExpress.XtraGrid.GridControl gridDevices;

		// Token: 0x040003A0 RID: 928
		private global::DevExpress.XtraGrid.Views.Card.CardView cardViewDevices;

		// Token: 0x040003A1 RID: 929
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDeviceName;

		// Token: 0x040003A2 RID: 930
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupDevices;

		// Token: 0x040003A3 RID: 931
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDevices;

		// Token: 0x040003A4 RID: 932
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupRoles;

		// Token: 0x040003A5 RID: 933
		private global::DevExpress.XtraEditors.SimpleButton buttonSelectDevices;

		// Token: 0x040003A6 RID: 934
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040003A7 RID: 935
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSelectDevices;

		// Token: 0x040003A8 RID: 936
		private global::DevExpress.XtraEditors.TextEdit textEditRuleName;

		// Token: 0x040003A9 RID: 937
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlRuleName;

		// Token: 0x040003AA RID: 938
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupRuleName;

		// Token: 0x040003AB RID: 939
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupSettings;

		// Token: 0x040003AC RID: 940
		private global::DevExpress.XtraEditors.ButtonEdit buttonEditAvailableDeviceGroups;

		// Token: 0x040003AD RID: 941
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlAvailableDeviceGroups;

		// Token: 0x040003AE RID: 942
		private global::DevExpress.XtraEditors.ImageComboBoxEdit imageComboBoxDeviceGroupsSelectMode;

		// Token: 0x040003AF RID: 943
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDeviceGroupsSelectMode;

		// Token: 0x040003B0 RID: 944
		private global::DevExpress.XtraEditors.CheckEdit checkEditApplyForUnrecognized;

		// Token: 0x040003B1 RID: 945
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlApplyForUnrecognized;
	}
}
