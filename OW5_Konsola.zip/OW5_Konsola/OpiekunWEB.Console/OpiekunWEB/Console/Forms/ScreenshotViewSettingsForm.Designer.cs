﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000072 RID: 114
	public partial class ScreenshotViewSettingsForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000607 RID: 1543 RVA: 0x0002A980 File Offset: 0x00028B80
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x0002A9A0 File Offset: 0x00028BA0
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ScreenshotViewSettingsForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.comboBoxEditSortMode = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.checkEditShowInetStateIcon = new global::DevExpress.XtraEditors.CheckEdit();
			this.comboBoxEditFrameSize = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.checkEditDrawShadow = new global::DevExpress.XtraEditors.CheckEdit();
			this.comboBoxEditDescription2 = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.comboBoxEditDescription1 = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlItemDescription1 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemDescription2 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemFrameSize = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemDrawShadow = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemShowInetStateIcon = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemSortMode = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditSortMode.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditShowInetStateIcon.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditFrameSize.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditDrawShadow.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditDescription2.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditDescription1.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDescription1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDescription2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemFrameSize).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDrawShadow).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemShowInetStateIcon).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemSortMode).BeginInit();
			base.SuspendLayout();
			this.layoutControlMain.Controls.Add(this.comboBoxEditSortMode);
			this.layoutControlMain.Controls.Add(this.checkEditShowInetStateIcon);
			this.layoutControlMain.Controls.Add(this.comboBoxEditFrameSize);
			this.layoutControlMain.Controls.Add(this.checkEditDrawShadow);
			this.layoutControlMain.Controls.Add(this.comboBoxEditDescription2);
			this.layoutControlMain.Controls.Add(this.comboBoxEditDescription1);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2759, 0, 812, 500));
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.comboBoxEditSortMode, "comboBoxEditSortMode");
			this.comboBoxEditSortMode.Name = "comboBoxEditSortMode";
			this.comboBoxEditSortMode.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxEditSortMode.Properties.Buttons"))
			});
			this.comboBoxEditSortMode.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxEditSortMode.Properties.CustomItemDisplayText += new global::DevExpress.XtraEditors.CustomItemDisplayTextEventHandler(this.comboBoxEditSortMode_Properties_CustomItemDisplayText);
			this.comboBoxEditSortMode.Properties.CustomDisplayText += new global::DevExpress.XtraEditors.Controls.CustomDisplayTextEventHandler(this.comboBoxEditSortMode_Properties_CustomDisplayText);
			this.comboBoxEditSortMode.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.checkEditShowInetStateIcon, "checkEditShowInetStateIcon");
			this.checkEditShowInetStateIcon.Name = "checkEditShowInetStateIcon";
			this.checkEditShowInetStateIcon.Properties.Caption = resources.GetString("checkEditShowInetStateIcon.Properties.Caption");
			this.checkEditShowInetStateIcon.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxEditFrameSize, "comboBoxEditFrameSize");
			this.comboBoxEditFrameSize.Name = "comboBoxEditFrameSize";
			this.comboBoxEditFrameSize.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxEditFrameSize.Properties.Buttons"))
			});
			this.comboBoxEditFrameSize.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxEditFrameSize.Properties.CustomItemDisplayText += new global::DevExpress.XtraEditors.CustomItemDisplayTextEventHandler(this.comboBoxEditFrameSize_Properties_CustomItemDisplayText);
			this.comboBoxEditFrameSize.Properties.CustomDisplayText += new global::DevExpress.XtraEditors.Controls.CustomDisplayTextEventHandler(this.comboBoxEditFrameSize_Properties_CustomDisplayText);
			this.comboBoxEditFrameSize.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.checkEditDrawShadow, "checkEditDrawShadow");
			this.checkEditDrawShadow.Name = "checkEditDrawShadow";
			this.checkEditDrawShadow.Properties.Caption = resources.GetString("checkEditDrawShadow.Properties.Caption");
			this.checkEditDrawShadow.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxEditDescription2, "comboBoxEditDescription2");
			this.comboBoxEditDescription2.Name = "comboBoxEditDescription2";
			this.comboBoxEditDescription2.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxEditDescription2.Properties.Buttons"))
			});
			this.comboBoxEditDescription2.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxEditDescription2.Properties.CustomItemDisplayText += new global::DevExpress.XtraEditors.CustomItemDisplayTextEventHandler(this.comboBoxEditDescription_Properties_CustomItemDisplayText);
			this.comboBoxEditDescription2.Properties.CustomDisplayText += new global::DevExpress.XtraEditors.Controls.CustomDisplayTextEventHandler(this.comboBoxEditDescription_Properties_CustomDisplayText);
			this.comboBoxEditDescription2.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxEditDescription1, "comboBoxEditDescription1");
			this.comboBoxEditDescription1.Name = "comboBoxEditDescription1";
			this.comboBoxEditDescription1.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxEditDescription1.Properties.Buttons"))
			});
			this.comboBoxEditDescription1.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxEditDescription1.Properties.CustomItemDisplayText += new global::DevExpress.XtraEditors.CustomItemDisplayTextEventHandler(this.comboBoxEditDescription_Properties_CustomItemDisplayText);
			this.comboBoxEditDescription1.Properties.CustomDisplayText += new global::DevExpress.XtraEditors.Controls.CustomDisplayTextEventHandler(this.comboBoxEditDescription_Properties_CustomDisplayText);
			this.comboBoxEditDescription1.StyleController = this.layoutControlMain;
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlItemDescription1,
				this.layoutControlItemDescription2,
				this.layoutControlItemFrameSize,
				this.layoutControlItemDrawShadow,
				this.layoutControlItemShowInetStateIcon,
				this.layoutControlItemSortMode
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(370, 263);
			this.Root.TextVisible = false;
			this.layoutControlItemDescription1.Control = this.comboBoxEditDescription1;
			this.layoutControlItemDescription1.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlItemDescription1.Name = "layoutControlItemDescription1";
			this.layoutControlItemDescription1.Size = new global::System.Drawing.Size(350, 45);
			resources.ApplyResources(this.layoutControlItemDescription1, "layoutControlItemDescription1");
			this.layoutControlItemDescription1.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemDescription1.TextSize = new global::System.Drawing.Size(113, 16);
			this.layoutControlItemDescription2.Control = this.comboBoxEditDescription2;
			this.layoutControlItemDescription2.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlItemDescription2.Name = "layoutControlItemDescription2";
			this.layoutControlItemDescription2.Size = new global::System.Drawing.Size(350, 45);
			resources.ApplyResources(this.layoutControlItemDescription2, "layoutControlItemDescription2");
			this.layoutControlItemDescription2.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemDescription2.TextSize = new global::System.Drawing.Size(113, 16);
			this.layoutControlItemFrameSize.Control = this.comboBoxEditFrameSize;
			this.layoutControlItemFrameSize.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlItemFrameSize.Name = "layoutControlItemFrameSize";
			this.layoutControlItemFrameSize.Size = new global::System.Drawing.Size(133, 48);
			resources.ApplyResources(this.layoutControlItemFrameSize, "layoutControlItemFrameSize");
			this.layoutControlItemFrameSize.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemFrameSize.TextSize = new global::System.Drawing.Size(113, 16);
			this.layoutControlItemDrawShadow.Control = this.checkEditDrawShadow;
			this.layoutControlItemDrawShadow.Location = new global::System.Drawing.Point(133, 90);
			this.layoutControlItemDrawShadow.Name = "layoutControlItemDrawShadow";
			this.layoutControlItemDrawShadow.Size = new global::System.Drawing.Size(217, 24);
			resources.ApplyResources(this.layoutControlItemDrawShadow, "layoutControlItemDrawShadow");
			this.layoutControlItemDrawShadow.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemDrawShadow.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemDrawShadow.TextVisible = false;
			this.layoutControlItemShowInetStateIcon.Control = this.checkEditShowInetStateIcon;
			this.layoutControlItemShowInetStateIcon.Location = new global::System.Drawing.Point(133, 114);
			this.layoutControlItemShowInetStateIcon.Name = "layoutControlItemShowInetStateIcon";
			this.layoutControlItemShowInetStateIcon.Size = new global::System.Drawing.Size(217, 24);
			this.layoutControlItemShowInetStateIcon.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemShowInetStateIcon.TextVisible = false;
			this.layoutControlItemSortMode.Control = this.comboBoxEditSortMode;
			this.layoutControlItemSortMode.Location = new global::System.Drawing.Point(0, 138);
			this.layoutControlItemSortMode.Name = "layoutControlItemSortMode";
			this.layoutControlItemSortMode.Size = new global::System.Drawing.Size(350, 105);
			resources.ApplyResources(this.layoutControlItemSortMode, "layoutControlItemSortMode");
			this.layoutControlItemSortMode.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemSortMode.TextSize = new global::System.Drawing.Size(113, 16);
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.buttonOk);
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("ScreenshotViewSettingsForm.IconOptions.Icon");
			base.Name = "ScreenshotViewSettingsForm";
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditSortMode.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditShowInetStateIcon.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditFrameSize.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditDrawShadow.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditDescription2.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditDescription1.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDescription1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDescription2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemFrameSize).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemDrawShadow).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemShowInetStateIcon).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemSortMode).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000386 RID: 902
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000387 RID: 903
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x04000388 RID: 904
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x04000389 RID: 905
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxEditDescription1;

		// Token: 0x0400038A RID: 906
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemDescription1;

		// Token: 0x0400038B RID: 907
		private global::DevExpress.XtraEditors.CheckEdit checkEditDrawShadow;

		// Token: 0x0400038C RID: 908
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxEditDescription2;

		// Token: 0x0400038D RID: 909
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemDescription2;

		// Token: 0x0400038E RID: 910
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemDrawShadow;

		// Token: 0x0400038F RID: 911
		protected global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x04000390 RID: 912
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxEditFrameSize;

		// Token: 0x04000391 RID: 913
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemFrameSize;

		// Token: 0x04000392 RID: 914
		private global::DevExpress.XtraEditors.CheckEdit checkEditShowInetStateIcon;

		// Token: 0x04000393 RID: 915
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemShowInetStateIcon;

		// Token: 0x04000394 RID: 916
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxEditSortMode;

		// Token: 0x04000395 RID: 917
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemSortMode;
	}
}
