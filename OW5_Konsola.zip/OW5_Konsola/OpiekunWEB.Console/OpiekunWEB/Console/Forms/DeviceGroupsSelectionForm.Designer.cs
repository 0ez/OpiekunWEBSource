﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000064 RID: 100
	public partial class DeviceGroupsSelectionForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000544 RID: 1348 RVA: 0x0001EFBA File Offset: 0x0001D1BA
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x0001EFDC File Offset: 0x0001D1DC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DeviceGroupsSelectionForm));
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.treeListDeviceGroups = new global::DevExpress.XtraTreeList.TreeList();
			this.treeListColumnDeviceGroupName = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			((global::System.ComponentModel.ISupportInitialize)this.treeListDeviceGroups).BeginInit();
			base.SuspendLayout();
			this.buttonOk.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			this.treeListDeviceGroups.Columns.AddRange(new global::DevExpress.XtraTreeList.Columns.TreeListColumn[]
			{
				this.treeListColumnDeviceGroupName
			});
			resources.ApplyResources(this.treeListDeviceGroups, "treeListDeviceGroups");
			this.treeListDeviceGroups.KeyFieldName = "Id";
			this.treeListDeviceGroups.MinWidth = 17;
			this.treeListDeviceGroups.Name = "treeListDeviceGroups";
			this.treeListDeviceGroups.OptionsBehavior.ReadOnly = true;
			this.treeListDeviceGroups.OptionsSelection.InvertSelection = true;
			this.treeListDeviceGroups.OptionsView.CheckBoxStyle = global::DevExpress.XtraTreeList.DefaultNodeCheckBoxStyle.Check;
			this.treeListDeviceGroups.ParentFieldName = "ParentId";
			this.treeListDeviceGroups.TreeLevelWidth = 16;
			this.treeListDeviceGroups.BeforeCheckNode += new global::DevExpress.XtraTreeList.CheckNodeEventHandler(this.treeListDeviceGroups_BeforeCheckNode);
			this.treeListDeviceGroups.DoubleClick += new global::System.EventHandler(this.treeListDeviceGroups_DoubleClick);
			this.treeListColumnDeviceGroupName.AppearanceHeader.Options.UseTextOptions = true;
			this.treeListColumnDeviceGroupName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.treeListColumnDeviceGroupName, "treeListColumnDeviceGroupName");
			this.treeListColumnDeviceGroupName.FieldName = "Name";
			this.treeListColumnDeviceGroupName.Name = "treeListColumnDeviceGroupName";
			this.treeListColumnDeviceGroupName.OptionsColumn.AllowEdit = false;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.treeListDeviceGroups);
			base.Controls.Add(this.buttonOk);
			base.Name = "DeviceGroupsSelectionForm";
			base.Load += new global::System.EventHandler(this.DeviceGroupsSelectionForm_Load);
			((global::System.ComponentModel.ISupportInitialize)this.treeListDeviceGroups).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400029E RID: 670
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400029F RID: 671
		protected global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x040002A0 RID: 672
		private global::DevExpress.XtraTreeList.TreeList treeListDeviceGroups;

		// Token: 0x040002A1 RID: 673
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumnDeviceGroupName;
	}
}
