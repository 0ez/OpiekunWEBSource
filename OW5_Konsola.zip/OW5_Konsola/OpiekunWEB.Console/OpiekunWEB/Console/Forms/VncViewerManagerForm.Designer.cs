﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000079 RID: 121
	public partial class VncViewerManagerForm : global::OpiekunWEB.Console.Forms.NonModalBaseForm
	{
		// Token: 0x06000672 RID: 1650 RVA: 0x00032D41 File Offset: 0x00030F41
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x00032D60 File Offset: 0x00030F60
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.VncViewerManagerForm));
			this.dockManager = new global::OpiekunWEB.Console.Forms.FullScreenDockManager.FullScreenDockManager(this.components);
			this.documentManager = new global::DevExpress.XtraBars.Docking2010.DocumentManager(this.components);
			this.tabbedView = new global::DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView(this.components);
			this.barManager = new global::DevExpress.XtraBars.BarManager(this.components);
			this.barMainMenu = new global::DevExpress.XtraBars.Bar();
			this.barButtonRemoteConnect = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonRemoteDisconnect = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonFullScreenOn = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonFullScreenOff = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonPrevWindow = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonNextWindow = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonSendCAD = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonRefresh = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonInputMode = new global::DevExpress.XtraBars.BarButtonItem();
			this.remoteInputModeMenu = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.barButtonInputModeAdminAndUser = new global::DevExpress.XtraBars.BarCheckItem();
			this.barButtonInputModeAdmin = new global::DevExpress.XtraBars.BarCheckItem();
			this.barButtonInputModeUser = new global::DevExpress.XtraBars.BarCheckItem();
			this.barButtonStretchMode = new global::DevExpress.XtraBars.BarButtonItem();
			this.remoteStretchModeMenu = new global::DevExpress.XtraBars.PopupMenu(this.components);
			this.barButtonStretchModeFitToWindow = new global::DevExpress.XtraBars.BarCheckItem();
			this.barButtonStretchModeAspectRatio = new global::DevExpress.XtraBars.BarCheckItem();
			this.barButtonStretchModeDisabled = new global::DevExpress.XtraBars.BarCheckItem();
			this.barDockControlTop = new global::DevExpress.XtraBars.BarDockControl();
			this.barDockControlBottom = new global::DevExpress.XtraBars.BarDockControl();
			this.barDockControlLeft = new global::DevExpress.XtraBars.BarDockControl();
			this.barDockControlRight = new global::DevExpress.XtraBars.BarDockControl();
			this.timerMainMenuShow = new global::System.Windows.Forms.Timer(this.components);
			((global::System.ComponentModel.ISupportInitialize)this.dockManager).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.documentManager).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.tabbedView).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.barManager).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.remoteInputModeMenu).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.remoteStretchModeMenu).BeginInit();
			base.SuspendLayout();
			this.dockManager.Form = this;
			this.dockManager.TopZIndexControls.AddRange(new string[]
			{
				"DevExpress.XtraBars.BarDockControl",
				"DevExpress.XtraBars.StandaloneBarDockControl",
				"System.Windows.Forms.StatusBar",
				"System.Windows.Forms.MenuStrip",
				"System.Windows.Forms.StatusStrip",
				"DevExpress.XtraBars.Ribbon.RibbonStatusBar",
				"DevExpress.XtraBars.Ribbon.RibbonControl"
			});
			this.documentManager.ContainerControl = this;
			this.documentManager.View = this.tabbedView;
			this.documentManager.ViewCollection.AddRange(new global::DevExpress.XtraBars.Docking2010.Views.BaseView[]
			{
				this.tabbedView
			});
			this.tabbedView.DocumentActivated += new global::DevExpress.XtraBars.Docking2010.Views.DocumentEventHandler(this.tabbedView_DocumentActivated);
			this.tabbedView.DocumentClosing += new global::DevExpress.XtraBars.Docking2010.Views.DocumentCancelEventHandler(this.tabbedView_DocumentClosing);
			this.tabbedView.DocumentClosed += new global::DevExpress.XtraBars.Docking2010.Views.DocumentEventHandler(this.tabbedView_DocumentClosed);
			this.tabbedView.Floating += new global::DevExpress.XtraBars.Docking2010.Views.DocumentEventHandler(this.tabbedView_Floating);
			this.tabbedView.EndFloating += new global::DevExpress.XtraBars.Docking2010.Views.DocumentEventHandler(this.tabbedView_EndFloating);
			this.barManager.Bars.AddRange(new global::DevExpress.XtraBars.Bar[]
			{
				this.barMainMenu
			});
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Items.AddRange(new global::DevExpress.XtraBars.BarItem[]
			{
				this.barButtonRemoteConnect,
				this.barButtonRemoteDisconnect,
				this.barButtonFullScreenOn,
				this.barButtonFullScreenOff,
				this.barButtonPrevWindow,
				this.barButtonNextWindow,
				this.barButtonSendCAD,
				this.barButtonRefresh,
				this.barButtonInputMode,
				this.barButtonStretchMode,
				this.barButtonInputModeAdminAndUser,
				this.barButtonInputModeAdmin,
				this.barButtonInputModeUser,
				this.barButtonStretchModeAspectRatio,
				this.barButtonStretchModeFitToWindow,
				this.barButtonStretchModeDisabled
			});
			this.barManager.MainMenu = this.barMainMenu;
			this.barManager.MaxItemId = 25;
			this.barManager.UseAltKeyForMenu = false;
			this.barManager.UseF10KeyForMenu = false;
			this.barMainMenu.BarName = "Main menu";
			this.barMainMenu.CanDockStyle = global::DevExpress.XtraBars.BarCanDockStyle.Top;
			this.barMainMenu.DockCol = 0;
			this.barMainMenu.DockRow = 0;
			this.barMainMenu.DockStyle = global::DevExpress.XtraBars.BarDockStyle.Top;
			this.barMainMenu.LinksPersistInfo.AddRange(new global::DevExpress.XtraBars.LinkPersistInfo[]
			{
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonRemoteConnect),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonRemoteDisconnect),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonFullScreenOn),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonFullScreenOff),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonPrevWindow),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonNextWindow),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonSendCAD),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonRefresh),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonInputMode),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonStretchMode)
			});
			this.barMainMenu.OptionsBar.AllowQuickCustomization = false;
			this.barMainMenu.OptionsBar.RotateWhenVertical = false;
			this.barMainMenu.OptionsBar.UseWholeRow = true;
			resources.ApplyResources(this.barMainMenu, "barMainMenu");
			resources.ApplyResources(this.barButtonRemoteConnect, "barButtonRemoteConnect");
			this.barButtonRemoteConnect.Id = 3;
			this.barButtonRemoteConnect.Name = "barButtonRemoteConnect";
			this.barButtonRemoteConnect.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonRemoteConnect_ItemClick);
			resources.ApplyResources(this.barButtonRemoteDisconnect, "barButtonRemoteDisconnect");
			this.barButtonRemoteDisconnect.Id = 4;
			this.barButtonRemoteDisconnect.Name = "barButtonRemoteDisconnect";
			this.barButtonRemoteDisconnect.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonDisconnect_ItemClick);
			resources.ApplyResources(this.barButtonFullScreenOn, "barButtonFullScreenOn");
			this.barButtonFullScreenOn.Id = 5;
			this.barButtonFullScreenOn.Name = "barButtonFullScreenOn";
			this.barButtonFullScreenOn.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonFullScreenOn_ItemClick);
			resources.ApplyResources(this.barButtonFullScreenOff, "barButtonFullScreenOff");
			this.barButtonFullScreenOff.Id = 6;
			this.barButtonFullScreenOff.Name = "barButtonFullScreenOff";
			this.barButtonFullScreenOff.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonFullScreenOff_ItemClick);
			resources.ApplyResources(this.barButtonPrevWindow, "barButtonPrevWindow");
			this.barButtonPrevWindow.Id = 7;
			this.barButtonPrevWindow.Name = "barButtonPrevWindow";
			this.barButtonPrevWindow.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonPrevWindow_ItemClick);
			resources.ApplyResources(this.barButtonNextWindow, "barButtonNextWindow");
			this.barButtonNextWindow.Id = 8;
			this.barButtonNextWindow.Name = "barButtonNextWindow";
			this.barButtonNextWindow.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonNextWindow_ItemClick);
			resources.ApplyResources(this.barButtonSendCAD, "barButtonSendCAD");
			this.barButtonSendCAD.Id = 9;
			this.barButtonSendCAD.Name = "barButtonSendCAD";
			this.barButtonSendCAD.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonSendCAD_ItemClick);
			resources.ApplyResources(this.barButtonRefresh, "barButtonRefresh");
			this.barButtonRefresh.Id = 10;
			this.barButtonRefresh.Name = "barButtonRefresh";
			this.barButtonRefresh.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonRefresh_ItemClick);
			this.barButtonInputMode.ActAsDropDown = true;
			this.barButtonInputMode.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.barButtonInputMode, "barButtonInputMode");
			this.barButtonInputMode.DropDownControl = this.remoteInputModeMenu;
			this.barButtonInputMode.Id = 11;
			this.barButtonInputMode.Name = "barButtonInputMode";
			this.remoteInputModeMenu.LinksPersistInfo.AddRange(new global::DevExpress.XtraBars.LinkPersistInfo[]
			{
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonInputModeAdminAndUser),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonInputModeAdmin),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonInputModeUser)
			});
			this.remoteInputModeMenu.Manager = this.barManager;
			this.remoteInputModeMenu.Name = "remoteInputModeMenu";
			this.barButtonInputModeAdminAndUser.BindableChecked = true;
			resources.ApplyResources(this.barButtonInputModeAdminAndUser, "barButtonInputModeAdminAndUser");
			this.barButtonInputModeAdminAndUser.Checked = true;
			this.barButtonInputModeAdminAndUser.GroupIndex = 1;
			this.barButtonInputModeAdminAndUser.Id = 19;
			this.barButtonInputModeAdminAndUser.Name = "barButtonInputModeAdminAndUser";
			this.barButtonInputModeAdminAndUser.CheckedChanged += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonInputMode_CheckedChanged);
			resources.ApplyResources(this.barButtonInputModeAdmin, "barButtonInputModeAdmin");
			this.barButtonInputModeAdmin.GroupIndex = 1;
			this.barButtonInputModeAdmin.Id = 20;
			this.barButtonInputModeAdmin.Name = "barButtonInputModeAdmin";
			this.barButtonInputModeAdmin.CheckedChanged += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonInputMode_CheckedChanged);
			resources.ApplyResources(this.barButtonInputModeUser, "barButtonInputModeUser");
			this.barButtonInputModeUser.GroupIndex = 1;
			this.barButtonInputModeUser.Id = 21;
			this.barButtonInputModeUser.Name = "barButtonInputModeUser";
			this.barButtonInputModeUser.CheckedChanged += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonInputMode_CheckedChanged);
			this.barButtonStretchMode.ActAsDropDown = true;
			this.barButtonStretchMode.ButtonStyle = global::DevExpress.XtraBars.BarButtonStyle.DropDown;
			resources.ApplyResources(this.barButtonStretchMode, "barButtonStretchMode");
			this.barButtonStretchMode.DropDownControl = this.remoteStretchModeMenu;
			this.barButtonStretchMode.Id = 15;
			this.barButtonStretchMode.Name = "barButtonStretchMode";
			this.remoteStretchModeMenu.LinksPersistInfo.AddRange(new global::DevExpress.XtraBars.LinkPersistInfo[]
			{
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonStretchModeFitToWindow),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonStretchModeAspectRatio),
				new global::DevExpress.XtraBars.LinkPersistInfo(this.barButtonStretchModeDisabled)
			});
			this.remoteStretchModeMenu.Manager = this.barManager;
			this.remoteStretchModeMenu.Name = "remoteStretchModeMenu";
			this.barButtonStretchModeFitToWindow.BindableChecked = true;
			resources.ApplyResources(this.barButtonStretchModeFitToWindow, "barButtonStretchModeFitToWindow");
			this.barButtonStretchModeFitToWindow.Checked = true;
			this.barButtonStretchModeFitToWindow.GroupIndex = 2;
			this.barButtonStretchModeFitToWindow.Id = 23;
			this.barButtonStretchModeFitToWindow.Name = "barButtonStretchModeFitToWindow";
			this.barButtonStretchModeFitToWindow.CheckedChanged += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonStretchMode_CheckedChanged);
			resources.ApplyResources(this.barButtonStretchModeAspectRatio, "barButtonStretchModeAspectRatio");
			this.barButtonStretchModeAspectRatio.GroupIndex = 2;
			this.barButtonStretchModeAspectRatio.Id = 22;
			this.barButtonStretchModeAspectRatio.Name = "barButtonStretchModeAspectRatio";
			this.barButtonStretchModeAspectRatio.CheckedChanged += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonStretchMode_CheckedChanged);
			resources.ApplyResources(this.barButtonStretchModeDisabled, "barButtonStretchModeDisabled");
			this.barButtonStretchModeDisabled.GroupIndex = 2;
			this.barButtonStretchModeDisabled.Id = 24;
			this.barButtonStretchModeDisabled.Name = "barButtonStretchModeDisabled";
			this.barButtonStretchModeDisabled.CheckedChanged += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonStretchMode_CheckedChanged);
			this.barDockControlTop.CausesValidation = false;
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.Manager = this.barManager;
			this.barDockControlBottom.CausesValidation = false;
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.Manager = this.barManager;
			this.barDockControlLeft.CausesValidation = false;
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.Manager = this.barManager;
			this.barDockControlRight.CausesValidation = false;
			resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
			this.barDockControlRight.Manager = this.barManager;
			this.timerMainMenuShow.Interval = 1000;
			this.timerMainMenuShow.Tick += new global::System.EventHandler(this.timerMainMenuShow_Tick);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.barDockControlLeft);
			base.Controls.Add(this.barDockControlRight);
			base.Controls.Add(this.barDockControlBottom);
			base.Controls.Add(this.barDockControlTop);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("VncViewerManagerForm.IconOptions.Icon");
			base.IsMdiContainer = true;
			base.MaximizeBox = true;
			base.MinimizeBox = true;
			base.Name = "VncViewerManagerForm";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.FormVncViewerManager_FormClosing);
			((global::System.ComponentModel.ISupportInitialize)this.dockManager).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.documentManager).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.tabbedView).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.barManager).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.remoteInputModeMenu).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.remoteStretchModeMenu).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400040C RID: 1036
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400040D RID: 1037
		private global::OpiekunWEB.Console.Forms.FullScreenDockManager.FullScreenDockManager dockManager;

		// Token: 0x0400040E RID: 1038
		private global::DevExpress.XtraBars.Docking2010.DocumentManager documentManager;

		// Token: 0x0400040F RID: 1039
		private global::DevExpress.XtraBars.Docking2010.Views.Tabbed.TabbedView tabbedView;

		// Token: 0x04000410 RID: 1040
		private global::DevExpress.XtraBars.BarDockControl barDockControlLeft;

		// Token: 0x04000411 RID: 1041
		private global::DevExpress.XtraBars.BarDockControl barDockControlRight;

		// Token: 0x04000412 RID: 1042
		private global::DevExpress.XtraBars.BarDockControl barDockControlBottom;

		// Token: 0x04000413 RID: 1043
		private global::DevExpress.XtraBars.BarDockControl barDockControlTop;

		// Token: 0x04000414 RID: 1044
		private global::DevExpress.XtraBars.BarManager barManager;

		// Token: 0x04000415 RID: 1045
		private global::DevExpress.XtraBars.Bar barMainMenu;

		// Token: 0x04000416 RID: 1046
		private global::DevExpress.XtraBars.BarButtonItem barButtonRemoteConnect;

		// Token: 0x04000417 RID: 1047
		private global::DevExpress.XtraBars.BarButtonItem barButtonRemoteDisconnect;

		// Token: 0x04000418 RID: 1048
		private global::DevExpress.XtraBars.BarButtonItem barButtonFullScreenOn;

		// Token: 0x04000419 RID: 1049
		private global::DevExpress.XtraBars.BarButtonItem barButtonFullScreenOff;

		// Token: 0x0400041A RID: 1050
		private global::DevExpress.XtraBars.BarButtonItem barButtonPrevWindow;

		// Token: 0x0400041B RID: 1051
		private global::DevExpress.XtraBars.BarButtonItem barButtonNextWindow;

		// Token: 0x0400041C RID: 1052
		private global::System.Windows.Forms.Timer timerMainMenuShow;

		// Token: 0x0400041D RID: 1053
		private global::DevExpress.XtraBars.BarButtonItem barButtonSendCAD;

		// Token: 0x0400041E RID: 1054
		private global::DevExpress.XtraBars.BarButtonItem barButtonRefresh;

		// Token: 0x0400041F RID: 1055
		private global::DevExpress.XtraBars.BarButtonItem barButtonInputMode;

		// Token: 0x04000420 RID: 1056
		private global::DevExpress.XtraBars.PopupMenu remoteInputModeMenu;

		// Token: 0x04000421 RID: 1057
		private global::DevExpress.XtraBars.BarButtonItem barButtonStretchMode;

		// Token: 0x04000422 RID: 1058
		private global::DevExpress.XtraBars.PopupMenu remoteStretchModeMenu;

		// Token: 0x04000423 RID: 1059
		private global::DevExpress.XtraBars.BarCheckItem barButtonInputModeAdminAndUser;

		// Token: 0x04000424 RID: 1060
		private global::DevExpress.XtraBars.BarCheckItem barButtonInputModeAdmin;

		// Token: 0x04000425 RID: 1061
		private global::DevExpress.XtraBars.BarCheckItem barButtonInputModeUser;

		// Token: 0x04000426 RID: 1062
		private global::DevExpress.XtraBars.BarCheckItem barButtonStretchModeAspectRatio;

		// Token: 0x04000427 RID: 1063
		private global::DevExpress.XtraBars.BarCheckItem barButtonStretchModeFitToWindow;

		// Token: 0x04000428 RID: 1064
		private global::DevExpress.XtraBars.BarCheckItem barButtonStretchModeDisabled;
	}
}
