﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200004F RID: 79
	public partial class AppFilterForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x06000479 RID: 1145 RVA: 0x00012EB8 File Offset: 0x000110B8
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x00012ED8 File Offset: 0x000110D8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.AppFilterForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.textEditDescription = new global::DevExpress.XtraEditors.TextEdit();
			this.labelHelp = new global::DevExpress.XtraEditors.LabelControl();
			this.comboBoxMacro = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.textEditFilePath = new global::DevExpress.XtraEditors.ButtonEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlItemHelp = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlDescription = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControMacro = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlFilePath = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDescription.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxMacro.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditFilePath.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemHelp).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDescription).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControMacro).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlFilePath).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.layoutControlMain.Controls.Add(this.textEditDescription);
			this.layoutControlMain.Controls.Add(this.labelHelp);
			this.layoutControlMain.Controls.Add(this.comboBoxMacro);
			this.layoutControlMain.Controls.Add(this.textEditFilePath);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.textEditDescription, "textEditDescription");
			this.textEditDescription.Name = "textEditDescription";
			this.textEditDescription.StyleController = this.layoutControlMain;
			this.labelHelp.AllowHtmlString = true;
			resources.ApplyResources(this.labelHelp, "labelHelp");
			this.labelHelp.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftTop;
			this.labelHelp.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.question_32x32;
			this.labelHelp.Name = "labelHelp";
			this.labelHelp.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxMacro, "comboBoxMacro");
			this.comboBoxMacro.Name = "comboBoxMacro";
			this.comboBoxMacro.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxMacro.Properties.Buttons"))
			});
			this.comboBoxMacro.Properties.DropDownRows = 9;
			this.comboBoxMacro.Properties.NullValuePrompt = resources.GetString("comboBoxMacro.Properties.NullValuePrompt");
			this.comboBoxMacro.Properties.ShowToolTipForTrimmedText = global::DevExpress.Utils.DefaultBoolean.False;
			this.comboBoxMacro.Properties.Sorted = true;
			this.comboBoxMacro.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxMacro.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditFilePath, "textEditFilePath");
			this.textEditFilePath.Name = "textEditFilePath";
			this.textEditFilePath.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.textEditFilePath.Properties.Mask.EditMask = resources.GetString("textEditFilePath.Properties.Mask.EditMask");
			this.textEditFilePath.Properties.NullValuePrompt = resources.GetString("textEditFilePath.Properties.NullValuePrompt");
			this.textEditFilePath.StyleController = this.layoutControlMain;
			this.textEditFilePath.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.textEditFilePath_ButtonClick);
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.emptySpaceItem1,
				this.layoutControlItemHelp,
				this.layoutControlDescription,
				this.layoutControMacro,
				this.layoutControlFilePath
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(417, 349);
			this.layoutControlGroupMain.TextVisible = false;
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 91);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(397, 154);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemHelp.Control = this.labelHelp;
			this.layoutControlItemHelp.Location = new global::System.Drawing.Point(0, 245);
			this.layoutControlItemHelp.Name = "layoutControlItemHelp";
			this.layoutControlItemHelp.Size = new global::System.Drawing.Size(397, 84);
			this.layoutControlItemHelp.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemHelp.TextVisible = false;
			this.layoutControlDescription.Control = this.textEditDescription;
			this.layoutControlDescription.Location = new global::System.Drawing.Point(0, 46);
			this.layoutControlDescription.Name = "layoutControlDescription";
			this.layoutControlDescription.Size = new global::System.Drawing.Size(397, 45);
			resources.ApplyResources(this.layoutControlDescription, "layoutControlDescription");
			this.layoutControlDescription.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDescription.TextSize = new global::System.Drawing.Size(68, 16);
			this.layoutControMacro.Control = this.comboBoxMacro;
			resources.ApplyResources(this.layoutControMacro, "layoutControMacro");
			this.layoutControMacro.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControMacro.MinSize = new global::System.Drawing.Size(112, 46);
			this.layoutControMacro.Name = "layoutControMacro";
			this.layoutControMacro.Size = new global::System.Drawing.Size(177, 46);
			this.layoutControMacro.SizeConstraintsType = global::DevExpress.XtraLayout.SizeConstraintsType.Custom;
			this.layoutControMacro.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControMacro.TextSize = new global::System.Drawing.Size(68, 16);
			this.layoutControlFilePath.Control = this.textEditFilePath;
			resources.ApplyResources(this.layoutControlFilePath, "layoutControlFilePath");
			this.layoutControlFilePath.Location = new global::System.Drawing.Point(177, 0);
			this.layoutControlFilePath.Name = "layoutControlFilePath";
			this.layoutControlFilePath.Size = new global::System.Drawing.Size(220, 46);
			this.layoutControlFilePath.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlFilePath.TextSize = new global::System.Drawing.Size(68, 16);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("AppFilterForm.IconOptions.Icon");
			base.Name = "AppFilterForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditDescription.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxMacro.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditFilePath.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemHelp).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDescription).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControMacro).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlFilePath).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400019E RID: 414
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400019F RID: 415
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040001A0 RID: 416
		private global::DevExpress.XtraEditors.LabelControl labelHelp;

		// Token: 0x040001A1 RID: 417
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040001A2 RID: 418
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040001A3 RID: 419
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemHelp;

		// Token: 0x040001A4 RID: 420
		private global::DevExpress.XtraEditors.TextEdit textEditDescription;

		// Token: 0x040001A5 RID: 421
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDescription;

		// Token: 0x040001A6 RID: 422
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxMacro;

		// Token: 0x040001A7 RID: 423
		private global::DevExpress.XtraEditors.ButtonEdit textEditFilePath;

		// Token: 0x040001A8 RID: 424
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControMacro;

		// Token: 0x040001A9 RID: 425
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlFilePath;
	}
}
