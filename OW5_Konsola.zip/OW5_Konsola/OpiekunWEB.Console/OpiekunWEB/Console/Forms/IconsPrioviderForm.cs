﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.Utils;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006E RID: 110
	public partial class IconsPrioviderForm : Form, IIconsProvider
	{
		// Token: 0x060005DC RID: 1500 RVA: 0x00027FAD File Offset: 0x000261AD
		public IconsPrioviderForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x060005DD RID: 1501 RVA: 0x00027FBB File Offset: 0x000261BB
		public ImageCollection AppControlStateImages16x16
		{
			get
			{
				return this.imagesAppControlState16x16;
			}
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x060005DE RID: 1502 RVA: 0x00027FC3 File Offset: 0x000261C3
		public ImageCollection AppCategoryTypeImages16x16
		{
			get
			{
				return this.imagesAppCategoryType16x16;
			}
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x060005DF RID: 1503 RVA: 0x00027FCB File Offset: 0x000261CB
		public ImageCollection ConnectionTypeImages16x16
		{
			get
			{
				return this.imagesConnectionType16x16;
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x00027FD3 File Offset: 0x000261D3
		public ImageCollection ConnectionTypeImages24x24
		{
			get
			{
				return this.imagesConnectionType24x24;
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x060005E1 RID: 1505 RVA: 0x00027FDB File Offset: 0x000261DB
		public ImageCollection InetControlStateImages16x16
		{
			get
			{
				return this.imagesInetControlState16x16;
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x00027FE3 File Offset: 0x000261E3
		public ImageCollection DevicesTreeImages24x24
		{
			get
			{
				return this.imagesDevicesTree24x24;
			}
		}
	}
}
