﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000062 RID: 98
	public partial class DesktopsListForm : RibbonBaseForm
	{
		// Token: 0x06000529 RID: 1321 RVA: 0x0001D0BF File Offset: 0x0001B2BF
		public DesktopsListForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x0001D0D0 File Offset: 0x0001B2D0
		public DesktopsListForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this.gridDesktops.DataSource = this._apiClient.Desktops;
			this.gridDesktopItems.DataSource = this._apiClient.DesktopItems;
			base.SetGridColumnForEditDeleteCommands(this.gridColumnAppCommand);
			base.SetGridColumnForEditDeleteCommands(this.gridColumnDesktopCommand);
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x0001D138 File Offset: 0x0001B338
		protected override void OnGridCommandDeleteClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			DesktopsListForm.<OnGridCommandDeleteClick>d__4 <OnGridCommandDeleteClick>d__;
			<OnGridCommandDeleteClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnGridCommandDeleteClick>d__.<>4__this = this;
			<OnGridCommandDeleteClick>d__.parent = parent;
			<OnGridCommandDeleteClick>d__.<>1__state = -1;
			<OnGridCommandDeleteClick>d__.<>t__builder.Start<DesktopsListForm.<OnGridCommandDeleteClick>d__4>(ref <OnGridCommandDeleteClick>d__);
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x0001D178 File Offset: 0x0001B378
		protected override void OnGridCommandEditClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			if (parent == this.gridDesktops)
			{
				Desktop desktop = this.GetSelectedDesktop();
				if (desktop != null)
				{
					this._formCreator.ShowAndKeepGridPosition<DesktopForm, Desktop>(this.gridViewDesktops, FormAction.Update, desktop);
					return;
				}
			}
			else if (parent == this.gridDesktopItems)
			{
				DesktopItem desktopItem = this.GetSelectedDesktopItem();
				if (desktopItem != null)
				{
					this._formCreator.ShowAndKeepGridPosition<DesktopItemForm, DesktopItem>(this.gridViewDesktopItems, FormAction.Update, desktopItem);
				}
			}
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x0001D1D4 File Offset: 0x0001B3D4
		private void barButtonAddDesktop_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<DesktopForm, Desktop>(FormAction.Create, null);
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x0001D1E4 File Offset: 0x0001B3E4
		private void barButtonAddItem_ItemClick(object sender, ItemClickEventArgs e)
		{
			Desktop desktop = this.GetSelectedDesktop();
			if (desktop != null)
			{
				DesktopItem desktopItems = new DesktopItem
				{
					DesktopId = desktop.Id
				};
				this._formCreator.Show<DesktopItemForm, DesktopItem>(FormAction.Create, desktopItems);
			}
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x0000228D File Offset: 0x0000048D
		private void barButtonExit_ItemClick(object sender, ItemClickEventArgs e)
		{
			base.Close();
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x0001D21B File Offset: 0x0001B41B
		private Desktop GetSelectedDesktop()
		{
			return this.gridViewDesktops.GetFocusedRow() as Desktop;
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x0001D22D File Offset: 0x0001B42D
		private DesktopItem GetSelectedDesktopItem()
		{
			return this.gridViewDesktopItems.GetFocusedRow() as DesktopItem;
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x0001D240 File Offset: 0x0001B440
		private void gridViewDesktopItems_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			if (this._selectedDesktop != null && e.ListSourceRow < this._apiClient.DesktopItems.Count)
			{
				e.Visible = (this._apiClient.DesktopItems[e.ListSourceRow].DesktopId == this._selectedDesktop.Id);
			}
			else
			{
				e.Visible = false;
			}
			e.Handled = true;
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0001D2AE File Offset: 0x0001B4AE
		private void gridViewDesktops_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this._selectedDesktop = this.GetSelectedDesktop();
			this.gridDesktopItems.RefreshDataSource();
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x0001D2C7 File Offset: 0x0001B4C7
		private void gridViewDesktops_RowCountChanged(object sender, EventArgs e)
		{
			this.barButtonAddItem.Enabled = (this.gridViewDesktops.RowCount > 0);
		}

		// Token: 0x04000274 RID: 628
		private readonly ApiClient _apiClient;

		// Token: 0x04000275 RID: 629
		private Desktop _selectedDesktop;
	}
}
