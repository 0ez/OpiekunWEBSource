﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005A RID: 90
	public partial class NonModalBaseForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060004D1 RID: 1233 RVA: 0x000182CD File Offset: 0x000164CD
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x000182EC File Offset: 0x000164EC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.NonModalBaseForm));
			base.SuspendLayout();
			componentResourceManager.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Name = "NonModalBaseForm";
			base.ResumeLayout(false);
		}

		// Token: 0x0400021D RID: 541
		private global::System.ComponentModel.IContainer components;
	}
}
