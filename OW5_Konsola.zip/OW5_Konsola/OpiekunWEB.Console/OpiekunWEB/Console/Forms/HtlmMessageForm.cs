﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000052 RID: 82
	public partial class HtlmMessageForm : BaseForm
	{
		// Token: 0x06000489 RID: 1161 RVA: 0x000153B4 File Offset: 0x000135B4
		public HtlmMessageForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x000153C4 File Offset: 0x000135C4
		public HtlmMessageForm(MessageWndToShow messageWndToShow)
		{
			this.InitializeComponent();
			this._messageWndToShow = messageWndToShow;
			base.CanCloseByEsc = false;
			this.buttonOk.Enabled = false;
			if (this._messageWndToShow.Title != "")
			{
				this.Text = this._messageWndToShow.Title;
			}
			if (this._messageWndToShow.Maximize)
			{
				base.WindowState = FormWindowState.Maximized;
				return;
			}
			if (this._messageWndToShow.Width != 0U)
			{
				base.Width = (int)this._messageWndToShow.Width;
			}
			if (this._messageWndToShow.Height != 0U)
			{
				base.Height = (int)this._messageWndToShow.Height;
				base.CenterInParent();
			}
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x00015476 File Offset: 0x00013676
		protected override void AfterRestoreState()
		{
			base.AfterRestoreState();
			this.webBrowser.Navigate(this._messageWndToShow.Url);
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x00015494 File Offset: 0x00013694
		private void HtlmMessageForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (!this.buttonOk.Enabled)
			{
				e.Cancel = true;
			}
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x000154AC File Offset: 0x000136AC
		private void webBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
		{
			HtlmMessageForm.<webBrowser_DocumentCompleted>d__6 <webBrowser_DocumentCompleted>d__;
			<webBrowser_DocumentCompleted>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<webBrowser_DocumentCompleted>d__.<>4__this = this;
			<webBrowser_DocumentCompleted>d__.<>1__state = -1;
			<webBrowser_DocumentCompleted>d__.<>t__builder.Start<HtlmMessageForm.<webBrowser_DocumentCompleted>d__6>(ref <webBrowser_DocumentCompleted>d__);
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x000154E4 File Offset: 0x000136E4
		private void webBrowser_Navigating(object sender, WebBrowserNavigatingEventArgs e)
		{
			if ((this._docummentCompleted && e.TargetFrameName == "") || e.TargetFrameName == "_blank")
			{
				e.Cancel = true;
				Process.Start(e.Url.ToString());
			}
		}

		// Token: 0x040001D6 RID: 470
		private bool _docummentCompleted;

		// Token: 0x040001D7 RID: 471
		private MessageWndToShow _messageWndToShow;
	}
}
