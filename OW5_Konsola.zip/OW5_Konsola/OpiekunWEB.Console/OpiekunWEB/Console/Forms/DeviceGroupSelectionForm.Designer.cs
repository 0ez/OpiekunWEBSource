﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006D RID: 109
	public partial class DeviceGroupSelectionForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060005DA RID: 1498 RVA: 0x00027C09 File Offset: 0x00025E09
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x00027C28 File Offset: 0x00025E28
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DeviceGroupSelectionForm));
			this.labelGroupName = new global::DevExpress.XtraEditors.LabelControl();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.treeListLookUpGroups = new global::DevExpress.XtraEditors.TreeListLookUpEdit();
			this.treeListLookUpGroupsTreeList = new global::DevExpress.XtraTreeList.TreeList();
			this.treeListColumnDeviceGroupName = new global::DevExpress.XtraTreeList.Columns.TreeListColumn();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroups.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.labelGroupName, "labelGroupName");
			this.labelGroupName.Name = "labelGroupName";
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonOk.ImageOptions.Image");
			this.buttonOk.ImageOptions.ImageIndex = (int)resources.GetObject("buttonOk.ImageOptions.ImageIndex");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			resources.ApplyResources(this.treeListLookUpGroups, "treeListLookUpGroups");
			this.treeListLookUpGroups.Name = "treeListLookUpGroups";
			this.treeListLookUpGroups.Properties.AccessibleDescription = resources.GetString("treeListLookUpGroups.Properties.AccessibleDescription");
			this.treeListLookUpGroups.Properties.AccessibleName = resources.GetString("treeListLookUpGroups.Properties.AccessibleName");
			this.treeListLookUpGroups.Properties.AutoHeight = (bool)resources.GetObject("treeListLookUpGroups.Properties.AutoHeight");
			this.treeListLookUpGroups.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("treeListLookUpGroups.Properties.Buttons"))
			});
			this.treeListLookUpGroups.Properties.DisplayMember = "Name";
			this.treeListLookUpGroups.Properties.NullText = resources.GetString("treeListLookUpGroups.Properties.NullText");
			this.treeListLookUpGroups.Properties.NullValuePrompt = resources.GetString("treeListLookUpGroups.Properties.NullValuePrompt");
			this.treeListLookUpGroups.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("treeListLookUpGroups.Properties.NullValuePromptShowForEmptyValue");
			this.treeListLookUpGroups.Properties.TreeList = this.treeListLookUpGroupsTreeList;
			resources.ApplyResources(this.treeListLookUpGroupsTreeList, "treeListLookUpGroupsTreeList");
			this.treeListLookUpGroupsTreeList.Columns.AddRange(new global::DevExpress.XtraTreeList.Columns.TreeListColumn[]
			{
				this.treeListColumnDeviceGroupName
			});
			this.treeListLookUpGroupsTreeList.KeyFieldName = "Id";
			this.treeListLookUpGroupsTreeList.Name = "treeListLookUpGroupsTreeList";
			this.treeListLookUpGroupsTreeList.OptionsView.ShowColumns = false;
			this.treeListLookUpGroupsTreeList.OptionsView.ShowIndentAsRowStyle = true;
			this.treeListLookUpGroupsTreeList.ParentFieldName = "ParentId";
			resources.ApplyResources(this.treeListColumnDeviceGroupName, "treeListColumnDeviceGroupName");
			this.treeListColumnDeviceGroupName.FieldName = "Name";
			this.treeListColumnDeviceGroupName.ImageOptions.ImageIndex = (int)resources.GetObject("treeListColumnDeviceGroupName.ImageOptions.ImageIndex");
			this.treeListColumnDeviceGroupName.Name = "treeListColumnDeviceGroupName";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.treeListLookUpGroups);
			base.Controls.Add(this.buttonOk);
			base.Controls.Add(this.labelGroupName);
			base.Name = "DeviceGroupSelectionForm";
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroups.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000357 RID: 855
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000358 RID: 856
		private global::DevExpress.XtraEditors.LabelControl labelGroupName;

		// Token: 0x04000359 RID: 857
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x0400035A RID: 858
		private global::DevExpress.XtraEditors.TreeListLookUpEdit treeListLookUpGroups;

		// Token: 0x0400035B RID: 859
		private global::DevExpress.XtraTreeList.TreeList treeListLookUpGroupsTreeList;

		// Token: 0x0400035C RID: 860
		private global::DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumnDeviceGroupName;
	}
}
