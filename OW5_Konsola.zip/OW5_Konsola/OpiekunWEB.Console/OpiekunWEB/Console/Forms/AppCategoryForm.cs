﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200004E RID: 78
	public partial class AppCategoryForm : CRUDBaseForm
	{
		// Token: 0x06000462 RID: 1122 RVA: 0x00011A64 File Offset: 0x0000FC64
		public AppCategoryForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, IIconsProvider iconsProvider, ApiClient apiClient, AppCategory urlCategory) : base(formsSettings, formCreator, action, apiClient)
		{
			this._appCategory = urlCategory;
			this.InitializeComponent();
			this._rolesIncluded = new List<string>();
			this.imageComboBoxCategoryType.Properties.SmallImages = iconsProvider.AppCategoryTypeImages16x16;
			this.imageComboBoxCategoryType.Properties.Items.AddEnum<AppCategoryType>((AppCategoryType cat) => cat.GetDescription());
			if (action == FormAction.Update)
			{
				this.textEditCategoryName.Text = this._appCategory.Name;
				this.textEditCategoryDescription.Text = this._appCategory.Description;
				this._rolesIncluded.AddRange(this._appCategory.Roles.ToList<string>());
			}
			this.imageComboBoxCategoryType.EditValue = this._appCategory.CategoryType;
			this.gridCategoryState.DataSource = this._apiClient.Roles;
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x00011B5C File Offset: 0x0000FD5C
		public AppCategoryForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x00011B6C File Offset: 0x0000FD6C
		protected Task CreateAppCategory()
		{
			AppCategoryForm.<CreateAppCategory>d__4 <CreateAppCategory>d__;
			<CreateAppCategory>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CreateAppCategory>d__.<>4__this = this;
			<CreateAppCategory>d__.<>1__state = -1;
			<CreateAppCategory>d__.<>t__builder.Start<AppCategoryForm.<CreateAppCategory>d__4>(ref <CreateAppCategory>d__);
			return <CreateAppCategory>d__.<>t__builder.Task;
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00011BB0 File Offset: 0x0000FDB0
		protected AppCategoryType GetAppCategoryType()
		{
			return (this.imageComboBoxCategoryType.EditValue as AppCategoryType?).GetValueOrDefault();
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x00011BDC File Offset: 0x0000FDDC
		protected override bool IsDataUpdated()
		{
			List<string> list = this._appCategory.Roles.ToList<string>();
			list.Sort();
			this._rolesIncluded.Sort();
			bool isRolesEqual = list.SequenceEqual(this._rolesIncluded);
			return this.GetAppCategoryType() != this._appCategory.CategoryType || this.textEditCategoryName.Text != this._appCategory.Name || this.textEditCategoryDescription.Text != this._appCategory.Description || !isRolesEqual;
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00011C6C File Offset: 0x0000FE6C
		protected override Task<bool> OnActionCreate()
		{
			AppCategoryForm.<OnActionCreate>d__7 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<AppCategoryForm.<OnActionCreate>d__7>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00011CB0 File Offset: 0x0000FEB0
		protected override Task<bool> OnActionUpdate()
		{
			AppCategoryForm.<OnActionUpdate>d__8 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<AppCategoryForm.<OnActionUpdate>d__8>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x00011CF4 File Offset: 0x0000FEF4
		protected Task UpdateCategory()
		{
			AppCategoryForm.<UpdateCategory>d__9 <UpdateCategory>d__;
			<UpdateCategory>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UpdateCategory>d__.<>4__this = this;
			<UpdateCategory>d__.<>1__state = -1;
			<UpdateCategory>d__.<>t__builder.Start<AppCategoryForm.<UpdateCategory>d__9>(ref <UpdateCategory>d__);
			return <UpdateCategory>d__.<>t__builder.Task;
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00011D38 File Offset: 0x0000FF38
		private void gridViewCategoryState_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			if (e.Column.FieldName == "RoleState" && e.IsGetData && e.IsGetData)
			{
				Role role = e.Row as Role;
				if (role != null)
				{
					e.Value = (this._rolesIncluded.IndexOf(role.Id) >= 0);
				}
			}
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x00011DA0 File Offset: 0x0000FFA0
		private void imageComboBoxRoleState_EditValueChanging(object sender, ChangingEventArgs e)
		{
			Role role = this.gridViewCategoryState.GetFocusedRow() as Role;
			if (role != null)
			{
				bool value = ((bool?)e.NewValue).Value;
				int idx = this._rolesIncluded.IndexOf(role.Id);
				if (value)
				{
					if (idx == -1)
					{
						this._rolesIncluded.Add(role.Id);
						return;
					}
				}
				else if (idx >= 0)
				{
					this._rolesIncluded.RemoveAt(idx);
				}
			}
		}

		// Token: 0x04000187 RID: 391
		private AppCategory _appCategory;

		// Token: 0x04000188 RID: 392
		private List<string> _rolesIncluded;
	}
}
