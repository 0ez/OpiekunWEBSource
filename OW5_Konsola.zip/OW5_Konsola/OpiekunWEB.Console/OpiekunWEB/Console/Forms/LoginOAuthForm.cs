﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000053 RID: 83
	public partial class LoginOAuthForm : BaseForm
	{
		// Token: 0x06000491 RID: 1169 RVA: 0x00015700 File Offset: 0x00013900
		public LoginOAuthForm()
		{
			this.InitializeComponent();
			this.webBrowser.Url = new Uri("http://localhost:3000/auth/google");
		}
	}
}
