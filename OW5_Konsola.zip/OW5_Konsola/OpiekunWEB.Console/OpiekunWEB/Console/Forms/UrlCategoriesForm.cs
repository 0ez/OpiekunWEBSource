﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTab;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraTreeList.Nodes.Operations;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007E RID: 126
	public partial class UrlCategoriesForm : RibbonBaseForm
	{
		// Token: 0x060006A8 RID: 1704 RVA: 0x0003884C File Offset: 0x00036A4C
		public UrlCategoriesForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._contentFilters = new BindingList<UrlCategoriesForm.ContentFilterWithId>();
			this.treeContentFilters.DataSource = this._contentFilters;
			this.gridUserCategories.DataSource = apiClient.URLCategories;
			this.gridSystemCategories.DataSource = apiClient.URLSystemCategories;
			this.imageComboBoxUserCategoryState.Items.AddEnum<ControlState>((ControlState state) => state.GetDescription());
			foreach (object item in this.imageComboBoxUserCategoryState.Items)
			{
				this.imageComboBoxSystemCategoryState.Items.Add(item);
			}
			this.imageComboBoxSystemCategoryState.Items.AddEnum<ControlState>((ControlState state) => state.GetDescription());
			base.SetGridColumnForEditDeleteCommands(this.columnUserCategoryCommand);
			base.SetGridColumnForEditCommand(this.columnSystemCategoryCommand);
			base.SetTreeColumnForEditDeleteCommands(this.treeColumnContentFilterCommand);
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x00038988 File Offset: 0x00036B88
		protected override void OnGridCommandDeleteClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			UrlCategoriesForm.<OnGridCommandDeleteClick>d__3 <OnGridCommandDeleteClick>d__;
			<OnGridCommandDeleteClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnGridCommandDeleteClick>d__.<>4__this = this;
			<OnGridCommandDeleteClick>d__.<>1__state = -1;
			<OnGridCommandDeleteClick>d__.<>t__builder.Start<UrlCategoriesForm.<OnGridCommandDeleteClick>d__3>(ref <OnGridCommandDeleteClick>d__);
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x000389C0 File Offset: 0x00036BC0
		protected override void OnGridCommandEditClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			URLCategory category = (parent == this.gridUserCategories) ? this.GetSelectedUserCategory() : this.GetSelectedSystemCategory();
			if (category != null && this._formCreator.Show<UrlCategoryForm, URLCategory>(FormAction.Update, category))
			{
				if (parent == this.gridUserCategories)
				{
					this.gridViewUserCategories.RefreshRow(this.gridViewUserCategories.FocusedRowHandle);
					return;
				}
				this.gridViewSystemCategories.RefreshRow(this.gridViewSystemCategories.FocusedRowHandle);
			}
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x00038A30 File Offset: 0x00036C30
		protected override void OnTreeListCommandDeleteClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			UrlCategoriesForm.<OnTreeListCommandDeleteClick>d__5 <OnTreeListCommandDeleteClick>d__;
			<OnTreeListCommandDeleteClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnTreeListCommandDeleteClick>d__.<>4__this = this;
			<OnTreeListCommandDeleteClick>d__.<>1__state = -1;
			<OnTreeListCommandDeleteClick>d__.<>t__builder.Start<UrlCategoriesForm.<OnTreeListCommandDeleteClick>d__5>(ref <OnTreeListCommandDeleteClick>d__);
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x00038A68 File Offset: 0x00036C68
		protected override void OnTreeListCommandEditClick(object sender, Control parent, ButtonPressedEventArgs e)
		{
			UrlCategoriesForm.ContentFilterWithId item = this.GetFocusedUserCategoryContent();
			if (this._formCreator.Show<ContentFilterForm, ContentFilter>(FormAction.Update, item.ContentFilter))
			{
				this.ShowContentFiltersforSelectedUserCategory();
				this.SelectContentFilter(item.ContentFilter);
			}
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x00038AA4 File Offset: 0x00036CA4
		private void barButtonAddCategory_ItemClick(object sender, ItemClickEventArgs e)
		{
			URLCategory category = new URLCategory();
			if (this._formCreator.Show<UrlCategoryForm, URLCategory>(FormAction.Create, category))
			{
				this.SelectUserCategory(category.Id);
			}
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x00038AD2 File Offset: 0x00036CD2
		private void barButtonAddPhrase_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.CreateContentFilter(ContentFilterType.PhraseFilter);
		}

		// Token: 0x060006AF RID: 1711 RVA: 0x00038ADB File Offset: 0x00036CDB
		private void barButtonAddRegex_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.CreateContentFilter(ContentFilterType.UrlRegexFilter);
		}

		// Token: 0x060006B0 RID: 1712 RVA: 0x00038AE4 File Offset: 0x00036CE4
		private void barButtonAddUrl_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.CreateContentFilter(ContentFilterType.UrlFilter);
		}

		// Token: 0x060006B1 RID: 1713 RVA: 0x0000228D File Offset: 0x0000048D
		private void barButtonExit_ItemClick(object sender, ItemClickEventArgs e)
		{
			base.Close();
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x00038AED File Offset: 0x00036CED
		private void Control_Enter(object sender, EventArgs e)
		{
			this.SetSelectionInfo();
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x00038AF8 File Offset: 0x00036CF8
		private void CreateContentFilter(ContentFilterType filterType)
		{
			URLCategory category = this.GetSelectedUserCategory();
			if (category != null)
			{
				ContentFilter filter = new ContentFilter
				{
					FilterType = filterType,
					CategoriesId = 
					{
						category.Id
					}
				};
				if (this._formCreator.Show<ContentFilterForm, ContentFilter>(FormAction.Create, filter))
				{
					this.ShowContentFiltersforSelectedUserCategory();
					this.SelectContentFilter(filter);
				}
			}
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x00038B4C File Offset: 0x00036D4C
		private List<ContentFilter> GetFiltersForCategory(string categoryId)
		{
			List<ContentFilter> result = new List<ContentFilter>();
			foreach (ContentFilter filter in this._apiClient.ContentFilters)
			{
				if (filter.CategoriesId.Contains(categoryId))
				{
					result.Add(filter);
				}
			}
			return result;
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x00038BB4 File Offset: 0x00036DB4
		private UrlCategoriesForm.ContentFilterWithId GetFocusedUserCategoryContent()
		{
			UrlCategoriesForm.ContentFilterWithId result = null;
			if (this.treeContentFilters.FocusedNode != null)
			{
				result = (this.treeContentFilters.GetDataRecordByNode(this.treeContentFilters.FocusedNode) as UrlCategoriesForm.ContentFilterWithId);
			}
			return result;
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x00038BF0 File Offset: 0x00036DF0
		private URLCategory GetSelectedSystemCategory()
		{
			URLCategory result = null;
			if (this.IsSystemCategoriesTabSelected())
			{
				result = (this.gridViewSystemCategories.GetFocusedRow() as URLCategory);
			}
			return result;
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x00038C19 File Offset: 0x00036E19
		private URLCategory GetSelectedUserCategory()
		{
			return this.gridViewUserCategories.GetFocusedRow() as URLCategory;
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x00003A2C File Offset: 0x00001C2C
		private void gridUserCategories_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x00038C2C File Offset: 0x00036E2C
		private void gridViewSystemCategories_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			if (e.Column.FieldName == "SystemCategoryState" && e.IsGetData)
			{
				URLCategory category = e.Row as URLCategory;
				if (category != null)
				{
					e.Value = this._apiClient.GetURLCategoryControlState(category.Id);
				}
			}
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x00038AED File Offset: 0x00036CED
		private void gridViewSystemCategories_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this.SetSelectionInfo();
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x00038C84 File Offset: 0x00036E84
		private void gridViewUserCategories_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			if (e.Column.FieldName == "CategoryState")
			{
				URLCategory category = e.Row as URLCategory;
				if (category == null)
				{
					return;
				}
				if (e.IsGetData)
				{
					e.Value = this._apiClient.GetURLCategoryControlState(category.Id);
				}
			}
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x00038CDC File Offset: 0x00036EDC
		private void gridViewUserCategories_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this.ShowContentFiltersforSelectedUserCategory();
			this.SetSelectionInfo();
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x00038CEA File Offset: 0x00036EEA
		private void gridViewUserCategories_RowCountChanged(object sender, EventArgs e)
		{
			this.SetAddFiltersButtonState();
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x00038CF4 File Offset: 0x00036EF4
		private void imageComboSystemCategoryState_EditValueChanging(object sender, ChangingEventArgs e)
		{
			UrlCategoriesForm.<imageComboSystemCategoryState_EditValueChanging>d__24 <imageComboSystemCategoryState_EditValueChanging>d__;
			<imageComboSystemCategoryState_EditValueChanging>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<imageComboSystemCategoryState_EditValueChanging>d__.<>4__this = this;
			<imageComboSystemCategoryState_EditValueChanging>d__.e = e;
			<imageComboSystemCategoryState_EditValueChanging>d__.<>1__state = -1;
			<imageComboSystemCategoryState_EditValueChanging>d__.<>t__builder.Start<UrlCategoriesForm.<imageComboSystemCategoryState_EditValueChanging>d__24>(ref <imageComboSystemCategoryState_EditValueChanging>d__);
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x00038D34 File Offset: 0x00036F34
		private void imageComboUserCategoryState_EditValueChanging(object sender, ChangingEventArgs e)
		{
			UrlCategoriesForm.<imageComboUserCategoryState_EditValueChanging>d__25 <imageComboUserCategoryState_EditValueChanging>d__;
			<imageComboUserCategoryState_EditValueChanging>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<imageComboUserCategoryState_EditValueChanging>d__.<>4__this = this;
			<imageComboUserCategoryState_EditValueChanging>d__.e = e;
			<imageComboUserCategoryState_EditValueChanging>d__.<>1__state = -1;
			<imageComboUserCategoryState_EditValueChanging>d__.<>t__builder.Start<UrlCategoriesForm.<imageComboUserCategoryState_EditValueChanging>d__25>(ref <imageComboUserCategoryState_EditValueChanging>d__);
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x00038D73 File Offset: 0x00036F73
		private bool IsContentFilterTreeSelected()
		{
			return this.IsUserCategoriesTabSelected() && this.treeContentFilters.Focused;
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x00038D8A File Offset: 0x00036F8A
		private bool IsSystemCategoriesTabSelected()
		{
			return !this.IsUserCategoriesTabSelected();
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x00038D95 File Offset: 0x00036F95
		private bool IsUserCategoriesTabSelected()
		{
			return this.tabControlCategories.SelectedTabPage == this.tabPageUserCategories;
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x00038DAC File Offset: 0x00036FAC
		private void SelectContentFilter(ContentFilter filter)
		{
			UrlCategoriesForm.TreeListSelectContentFilter itrator = new UrlCategoriesForm.TreeListSelectContentFilter(this.treeContentFilters, filter);
			this.treeContentFilters.NodesIterator.DoLocalOperation(itrator, this.treeContentFilters.Nodes);
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x00038DE4 File Offset: 0x00036FE4
		private void SelectUserCategory(string categoryId)
		{
			int rowHandle = this.gridViewUserCategories.LocateByValue("Id", categoryId, Array.Empty<OperationCompleted>());
			if (rowHandle != -2147483648)
			{
				this.gridViewUserCategories.FocusedRowHandle = rowHandle;
			}
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x00038E1C File Offset: 0x0003701C
		private void SetAddFiltersButtonState()
		{
			bool enableButtons = this.tabControlCategories.SelectedTabPage == this.tabPageUserCategories && this.gridViewUserCategories.RowCount > 0;
			this.barButtonAddUrl.Enabled = enableButtons;
			this.barButtonAddPhrase.Enabled = enableButtons;
			this.barButtonAddRegex.Enabled = enableButtons;
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x00038E74 File Offset: 0x00037074
		private void SetSelectionInfo()
		{
			this.barStaticSelection.Caption = "";
			if (this.IsContentFilterTreeSelected())
			{
				UrlCategoriesForm.ContentFilterWithId item = this.GetFocusedUserCategoryContent();
				if (this.GetSelectedUserCategory() != null && item != null)
				{
					this.barStaticSelection.Caption = string.Format(Resources.UrlCategoriesForm_FilterSelectionInfo, item.Content, item.ContentFilter.FilterType.GetDescription());
				}
			}
			else
			{
				URLCategory category = this.IsUserCategoriesTabSelected() ? this.GetSelectedUserCategory() : this.GetSelectedSystemCategory();
				if (category != null)
				{
					this.barStaticSelection.Caption = string.Format(Resources.UrlCategoriesForm_CategorySelectionInfo, category.Name);
				}
			}
			this.ribbonStatusBar.Refresh();
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x00038F18 File Offset: 0x00037118
		private void ShowContentFiltersforSelectedUserCategory()
		{
			URLCategory category = this.GetSelectedUserCategory();
			if (category != null)
			{
				this._contentFilters.Clear();
				this._contentFilters.Add(new UrlCategoriesForm.ContentFilterWithId(ContentFilterType.UrlFilter.AsString(), null, new ContentFilter
				{
					FilterType = ContentFilterType.UrlFilter,
					Data = ContentFilterType.UrlFilter.GetDescription()
				}));
				this._contentFilters.Add(new UrlCategoriesForm.ContentFilterWithId(ContentFilterType.PhraseFilter.AsString(), null, new ContentFilter
				{
					FilterType = ContentFilterType.PhraseFilter,
					Data = ContentFilterType.PhraseFilter.GetDescription()
				}));
				this._contentFilters.Add(new UrlCategoriesForm.ContentFilterWithId(ContentFilterType.UrlRegexFilter.AsString(), null, new ContentFilter
				{
					FilterType = ContentFilterType.UrlRegexFilter,
					Data = ContentFilterType.UrlRegexFilter.GetDescription()
				}));
				int id = 999;
				foreach (ContentFilter filter in this.GetFiltersForCategory(category.Id))
				{
					this._contentFilters.Add(new UrlCategoriesForm.ContentFilterWithId(id.ToString(), filter.FilterType.AsString(), filter));
					id++;
				}
				this.treeContentFilters.ExpandAll();
			}
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x00039048 File Offset: 0x00037248
		private void tabControlCategories_SelectedPageChanged(object sender, TabPageChangedEventArgs e)
		{
			this.barButtonAddCategory.Enabled = (this.tabControlCategories.SelectedTabPage == this.tabPageUserCategories);
			this.SetAddFiltersButtonState();
			this.SetSelectionInfo();
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x00039074 File Offset: 0x00037274
		private void treeContentFilters_BeforeFocusNode(object sender, BeforeFocusNodeEventArgs args)
		{
			UrlCategoriesForm.ContentFilterWithId item = this.treeContentFilters.GetDataRecordByNode(args.Node) as UrlCategoriesForm.ContentFilterWithId;
			if (item != null && item.ParentId == null)
			{
				args.CanFocus = false;
			}
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x00038AED File Offset: 0x00036CED
		private void treeContentFilters_FocusedNodeChanged(object sender, FocusedNodeChangedEventArgs e)
		{
			this.SetSelectionInfo();
		}

		// Token: 0x0400048E RID: 1166
		private readonly ApiClient _apiClient;

		// Token: 0x0400048F RID: 1167
		private readonly BindingList<UrlCategoriesForm.ContentFilterWithId> _contentFilters;

		// Token: 0x02000172 RID: 370
		private class ContentFilterWithId
		{
			// Token: 0x06000B72 RID: 2930 RVA: 0x00060759 File Offset: 0x0005E959
			public ContentFilterWithId(string id, string patParentId, ContentFilter contentFilter)
			{
				this.Id = id;
				this.ParentId = patParentId;
				this.ContentFilter = contentFilter;
			}

			// Token: 0x170002FE RID: 766
			// (get) Token: 0x06000B73 RID: 2931 RVA: 0x00060776 File Offset: 0x0005E976
			public string Content
			{
				get
				{
					return this.ContentFilter.Data;
				}
			}

			// Token: 0x170002FF RID: 767
			// (get) Token: 0x06000B74 RID: 2932 RVA: 0x00060783 File Offset: 0x0005E983
			public ContentFilter ContentFilter { get; }

			// Token: 0x17000300 RID: 768
			// (get) Token: 0x06000B75 RID: 2933 RVA: 0x0006078B File Offset: 0x0005E98B
			public string Id { get; }

			// Token: 0x17000301 RID: 769
			// (get) Token: 0x06000B76 RID: 2934 RVA: 0x00060793 File Offset: 0x0005E993
			public string ParentId { get; }
		}

		// Token: 0x02000173 RID: 371
		private class TreeListSelectContentFilter : TreeListOperation
		{
			// Token: 0x06000B77 RID: 2935 RVA: 0x0006079B File Offset: 0x0005E99B
			public TreeListSelectContentFilter(TreeList treeList, ContentFilter contentFilterToSelect)
			{
				this._treeList = treeList;
				this._contentFilterToSelect = contentFilterToSelect;
			}

			// Token: 0x06000B78 RID: 2936 RVA: 0x000607B4 File Offset: 0x0005E9B4
			public override void Execute(TreeListNode node)
			{
				UrlCategoriesForm.ContentFilterWithId filter = node.TreeList.GetDataRecordByNode(node) as UrlCategoriesForm.ContentFilterWithId;
				if (filter != null && filter.ContentFilter.FilterType == this._contentFilterToSelect.FilterType && filter.ContentFilter.Data == this._contentFilterToSelect.Data)
				{
					this._treeList.SelectNode(node);
					this._treeList.FocusedNode = node;
				}
			}

			// Token: 0x04000A12 RID: 2578
			private readonly ContentFilter _contentFilterToSelect;

			// Token: 0x04000A13 RID: 2579
			private readonly TreeList _treeList;
		}
	}
}
