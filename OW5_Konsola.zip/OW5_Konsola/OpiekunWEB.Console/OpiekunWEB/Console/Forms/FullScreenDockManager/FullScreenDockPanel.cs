﻿using System;
using DevExpress.XtraBars.Docking;

namespace OpiekunWEB.Console.Forms.FullScreenDockManager
{
	// Token: 0x020000B0 RID: 176
	public class FullScreenDockPanel : DockPanel
	{
		// Token: 0x06000909 RID: 2313 RVA: 0x000521DA File Offset: 0x000503DA
		public FullScreenDockPanel() : this(false, DockingStyle.Float, null)
		{
		}

		// Token: 0x0600090A RID: 2314 RVA: 0x000521E5 File Offset: 0x000503E5
		public FullScreenDockPanel(bool createControlContainer, DockingStyle dock, DockManager dockManager) : base(createControlContainer, dock, dockManager)
		{
			base.DockLayout = new FullScreenDockLayout(dock, this);
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x0600090B RID: 2315 RVA: 0x000521FD File Offset: 0x000503FD
		// (set) Token: 0x0600090C RID: 2316 RVA: 0x00052205 File Offset: 0x00050405
		public bool IsFullScreen { get; set; }

		// Token: 0x0600090D RID: 2317 RVA: 0x0005220E File Offset: 0x0005040E
		public void SetFullScreen(bool fullScreenOn)
		{
			this.IsFullScreen = fullScreenOn;
			FullScreenDockLayout fullScreenDockLayout = base.DockLayout as FullScreenDockLayout;
			if (fullScreenDockLayout == null)
			{
				return;
			}
			fullScreenDockLayout.LayoutChanged();
		}
	}
}
