﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraBars.Docking;

namespace OpiekunWEB.Console.Forms.FullScreenDockManager
{
	// Token: 0x020000AF RID: 175
	public class FullScreenDockManager : DockManager
	{
		// Token: 0x06000903 RID: 2307 RVA: 0x0005212F File Offset: 0x0005032F
		public FullScreenDockManager()
		{
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x00052137 File Offset: 0x00050337
		public FullScreenDockManager(ContainerControl form) : base(form)
		{
		}

		// Token: 0x06000905 RID: 2309 RVA: 0x00052140 File Offset: 0x00050340
		public FullScreenDockManager(IContainer container) : base(container)
		{
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x06000906 RID: 2310 RVA: 0x0005214C File Offset: 0x0005034C
		// (remove) Token: 0x06000907 RID: 2311 RVA: 0x00052184 File Offset: 0x00050384
		public event FullScreenDockManager.CreateDockPanelEventHandler OnCreateDockPanel;

		// Token: 0x06000908 RID: 2312 RVA: 0x000521B9 File Offset: 0x000503B9
		protected override DockPanel CreateDockPanel(DockingStyle dock, bool createControlContainer)
		{
			if (this.OnCreateDockPanel != null)
			{
				return this.OnCreateDockPanel(this, dock, createControlContainer);
			}
			return new FullScreenDockPanel(createControlContainer, dock, this);
		}

		// Token: 0x020001CE RID: 462
		// (Invoke) Token: 0x06000C77 RID: 3191
		public delegate DockPanel CreateDockPanelEventHandler(object sender, DockingStyle dock, bool createControlContainer);
	}
}
