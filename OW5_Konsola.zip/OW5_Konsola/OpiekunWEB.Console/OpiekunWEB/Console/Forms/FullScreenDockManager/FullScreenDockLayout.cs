﻿using System;
using System.Drawing;
using DevExpress.XtraBars.Docking;
using DevExpress.XtraBars.Docking.Helpers;

namespace OpiekunWEB.Console.Forms.FullScreenDockManager
{
	// Token: 0x020000AE RID: 174
	public class FullScreenDockLayout : DockLayout
	{
		// Token: 0x060008FD RID: 2301 RVA: 0x000520AC File Offset: 0x000502AC
		public FullScreenDockLayout(DockingStyle dock, DockPanel panel) : base(dock, panel)
		{
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x000520B6 File Offset: 0x000502B6
		public FullScreenDockLayout(DockingStyle dock, Size size, DockPanel panel) : base(dock, size, panel)
		{
		}

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x060008FF RID: 2303 RVA: 0x000520C1 File Offset: 0x000502C1
		public new FullScreenDockManager DockManager
		{
			get
			{
				return base.DockManager as FullScreenDockManager;
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x06000900 RID: 2304 RVA: 0x000520CE File Offset: 0x000502CE
		protected override int CaptionHeight
		{
			get
			{
				if (!(base.Panel is FullScreenDockPanel))
				{
					return base.CaptionHeight;
				}
				if (!(base.Panel as FullScreenDockPanel).IsFullScreen)
				{
					return base.CaptionHeight;
				}
				return 0;
			}
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x06000901 RID: 2305 RVA: 0x000520FE File Offset: 0x000502FE
		protected override bool HasBorder
		{
			get
			{
				if (base.Panel is FullScreenDockPanel)
				{
					return !(base.Panel as FullScreenDockPanel).IsFullScreen;
				}
				return base.HasBorder;
			}
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x00052127 File Offset: 0x00050327
		public new void LayoutChanged()
		{
			base.LayoutChanged();
		}
	}
}
