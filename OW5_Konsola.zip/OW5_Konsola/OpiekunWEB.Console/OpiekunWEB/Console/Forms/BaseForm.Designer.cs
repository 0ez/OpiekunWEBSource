﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000058 RID: 88
	public partial class BaseForm : global::DevExpress.XtraEditors.XtraForm
	{
		// Token: 0x060004C1 RID: 1217 RVA: 0x00018076 File Offset: 0x00016276
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x00018098 File Offset: 0x00016298
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.BaseForm));
			base.SuspendLayout();
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("BaseForm.IconOptions.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "BaseForm";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.FormBase_FormClosing);
			base.Load += new global::System.EventHandler(this.FormBase_Load);
			base.ResumeLayout(false);
		}

		// Token: 0x04000219 RID: 537
		private global::System.ComponentModel.IContainer components;
	}
}
