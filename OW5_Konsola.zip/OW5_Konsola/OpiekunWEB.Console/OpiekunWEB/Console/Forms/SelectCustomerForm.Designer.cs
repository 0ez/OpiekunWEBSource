﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000078 RID: 120
	public partial class SelectCustomerForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000651 RID: 1617 RVA: 0x00032012 File Offset: 0x00030212
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00032034 File Offset: 0x00030234
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.SelectCustomerForm));
			this.gridCustomers = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewCustomers = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnCustomerName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnMaxDevices = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.gridColumnKeyDescription = new global::DevExpress.XtraGrid.Columns.GridColumn();
			((global::System.ComponentModel.ISupportInitialize)this.gridCustomers).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewCustomers).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.gridCustomers, "gridCustomers");
			this.gridCustomers.MainView = this.gridViewCustomers;
			this.gridCustomers.Name = "gridCustomers";
			this.gridCustomers.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewCustomers
			});
			this.gridViewCustomers.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnCustomerName,
				this.gridColumnKeyDescription,
				this.gridColumnMaxDevices
			});
			this.gridViewCustomers.GridControl = this.gridCustomers;
			this.gridViewCustomers.Name = "gridViewCustomers";
			this.gridViewCustomers.OptionsBehavior.Editable = false;
			this.gridViewCustomers.OptionsBehavior.ReadOnly = true;
			this.gridViewCustomers.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewCustomers.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewCustomers.OptionsView.ShowGroupPanel = false;
			this.gridViewCustomers.DoubleClick += new global::System.EventHandler(this.gridViewCustomers_DoubleClick);
			this.gridColumnCustomerName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnCustomerName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnCustomerName, "gridColumnCustomerName");
			this.gridColumnCustomerName.FieldName = "KeyName";
			this.gridColumnCustomerName.MinWidth = 25;
			this.gridColumnCustomerName.Name = "gridColumnCustomerName";
			this.gridColumnCustomerName.OptionsColumn.ReadOnly = true;
			this.gridColumnMaxDevices.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnMaxDevices.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnMaxDevices, "gridColumnMaxDevices");
			this.gridColumnMaxDevices.FieldName = "MaxDevices";
			this.gridColumnMaxDevices.MinWidth = 25;
			this.gridColumnMaxDevices.Name = "gridColumnMaxDevices";
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			this.gridColumnKeyDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnKeyDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnKeyDescription, "gridColumnKeyDescription");
			this.gridColumnKeyDescription.FieldName = "KeyDescription";
			this.gridColumnKeyDescription.MinWidth = 25;
			this.gridColumnKeyDescription.Name = "gridColumnKeyDescription";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.buttonOk);
			base.Controls.Add(this.gridCustomers);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("SelectCustomerForm.IconOptions.Icon");
			base.Name = "SelectCustomerForm";
			((global::System.ComponentModel.ISupportInitialize)this.gridCustomers).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewCustomers).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000401 RID: 1025
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000402 RID: 1026
		private global::DevExpress.XtraGrid.GridControl gridCustomers;

		// Token: 0x04000403 RID: 1027
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewCustomers;

		// Token: 0x04000404 RID: 1028
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnCustomerName;

		// Token: 0x04000405 RID: 1029
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x04000406 RID: 1030
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnMaxDevices;

		// Token: 0x04000407 RID: 1031
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnKeyDescription;
	}
}
