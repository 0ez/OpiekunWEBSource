﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000081 RID: 129
	public partial class LoginForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060006F0 RID: 1776 RVA: 0x0003C0BF File Offset: 0x0003A2BF
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x0003C0E0 File Offset: 0x0003A2E0
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.LoginForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.checkEditSavePassword = new global::DevExpress.XtraEditors.CheckEdit();
			this.checkEditSaveLogin = new global::DevExpress.XtraEditors.CheckEdit();
			this.textEditPassword = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditLogin = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlLogin = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlPassword = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlSaveEmail = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlSavePassword = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.hyperlinkLabelForgotenPassword = new global::DevExpress.XtraEditors.HyperlinkLabelControl();
			this.buttonLogin = new global::DevExpress.XtraEditors.SimpleButton();
			this.pictureBoxLogo = new global::System.Windows.Forms.PictureBox();
			this.behaviorManager1 = new global::DevExpress.Utils.Behaviors.BehaviorManager(this.components);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditSavePassword.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditSaveLogin.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditLogin.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlLogin).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPassword).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSaveEmail).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSavePassword).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.behaviorManager1).BeginInit();
			base.SuspendLayout();
			this.layoutControlMain.AllowCustomization = false;
			this.layoutControlMain.Controls.Add(this.checkEditSavePassword);
			this.layoutControlMain.Controls.Add(this.checkEditSaveLogin);
			this.layoutControlMain.Controls.Add(this.textEditPassword);
			this.layoutControlMain.Controls.Add(this.textEditLogin);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2145, 256, 609, 465));
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.checkEditSavePassword, "checkEditSavePassword");
			this.checkEditSavePassword.Name = "checkEditSavePassword";
			this.checkEditSavePassword.Properties.Caption = resources.GetString("checkEditSavePassword.Properties.Caption");
			this.checkEditSavePassword.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.checkEditSaveLogin, "checkEditSaveLogin");
			this.checkEditSaveLogin.Name = "checkEditSaveLogin";
			this.checkEditSaveLogin.Properties.Caption = resources.GetString("checkEditSaveLogin.Properties.Caption");
			this.checkEditSaveLogin.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditPassword, "textEditPassword");
			this.textEditPassword.Name = "textEditPassword";
			this.textEditPassword.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditPassword.Properties.Mask.BeepOnError");
			this.textEditPassword.Properties.Mask.EditMask = resources.GetString("textEditPassword.Properties.Mask.EditMask");
			this.textEditPassword.Properties.PasswordChar = '*';
			this.textEditPassword.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditLogin, "textEditLogin");
			this.textEditLogin.Name = "textEditLogin";
			this.textEditLogin.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditLogin.Properties.Mask.BeepOnError");
			this.textEditLogin.Properties.Mask.EditMask = resources.GetString("textEditLogin.Properties.Mask.EditMask");
			this.textEditLogin.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlLogin,
				this.layoutControlPassword,
				this.layoutControlSaveEmail,
				this.layoutControlSavePassword
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.Padding = new global::DevExpress.XtraLayout.Utils.Padding(12, 12, 12, 12);
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(252, 207);
			this.layoutControlGroupMain.TextVisible = false;
			this.layoutControlLogin.Control = this.textEditLogin;
			resources.ApplyResources(this.layoutControlLogin, "layoutControlLogin");
			this.layoutControlLogin.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlLogin.Name = "layoutControlLogin";
			this.layoutControlLogin.Size = new global::System.Drawing.Size(228, 45);
			this.layoutControlLogin.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlLogin.TextSize = new global::System.Drawing.Size(60, 16);
			this.layoutControlPassword.Control = this.textEditPassword;
			resources.ApplyResources(this.layoutControlPassword, "layoutControlPassword");
			this.layoutControlPassword.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlPassword.Name = "layoutControlPassword";
			this.layoutControlPassword.Size = new global::System.Drawing.Size(228, 45);
			this.layoutControlPassword.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlPassword.TextSize = new global::System.Drawing.Size(60, 16);
			this.layoutControlSaveEmail.Control = this.checkEditSaveLogin;
			this.layoutControlSaveEmail.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlSaveEmail.Name = "layoutControlSaveEmail";
			this.layoutControlSaveEmail.Size = new global::System.Drawing.Size(228, 24);
			this.layoutControlSaveEmail.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlSaveEmail.TextVisible = false;
			this.layoutControlSavePassword.Control = this.checkEditSavePassword;
			this.layoutControlSavePassword.Location = new global::System.Drawing.Point(0, 114);
			this.layoutControlSavePassword.Name = "layoutControlSavePassword";
			this.layoutControlSavePassword.Size = new global::System.Drawing.Size(228, 69);
			this.layoutControlSavePassword.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlSavePassword.TextVisible = false;
			resources.ApplyResources(this.hyperlinkLabelForgotenPassword, "hyperlinkLabelForgotenPassword");
			this.hyperlinkLabelForgotenPassword.Name = "hyperlinkLabelForgotenPassword";
			this.hyperlinkLabelForgotenPassword.Click += new global::System.EventHandler(this.hyperlinkLabelForgotenPassword_Click);
			this.buttonLogin.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			resources.ApplyResources(this.buttonLogin, "buttonLogin");
			this.buttonLogin.Name = "buttonLogin";
			this.buttonLogin.Click += new global::System.EventHandler(this.buttonLogin_Click);
			this.pictureBoxLogo.Image = global::OpiekunWEB.Console.Properties.Resources.opiekun_logo_120x125;
			resources.ApplyResources(this.pictureBoxLogo, "pictureBoxLogo");
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.TabStop = false;
			base.AcceptButton = this.buttonLogin;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.pictureBoxLogo);
			base.Controls.Add(this.buttonLogin);
			base.Controls.Add(this.layoutControlMain);
			base.Controls.Add(this.hyperlinkLabelForgotenPassword);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("LoginForm.IconOptions.Icon");
			base.Name = "LoginForm";
			base.Load += new global::System.EventHandler(this.FormLogin_Load);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.checkEditSavePassword.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditSaveLogin.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditLogin.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlLogin).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPassword).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSaveEmail).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSavePassword).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.behaviorManager1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040004D9 RID: 1241
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040004DA RID: 1242
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040004DB RID: 1243
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040004DC RID: 1244
		private global::DevExpress.XtraEditors.TextEdit textEditPassword;

		// Token: 0x040004DD RID: 1245
		private global::DevExpress.XtraEditors.TextEdit textEditLogin;

		// Token: 0x040004DE RID: 1246
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlLogin;

		// Token: 0x040004DF RID: 1247
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlPassword;

		// Token: 0x040004E0 RID: 1248
		private global::DevExpress.XtraEditors.SimpleButton buttonLogin;

		// Token: 0x040004E1 RID: 1249
		private global::System.Windows.Forms.PictureBox pictureBoxLogo;

		// Token: 0x040004E2 RID: 1250
		private global::DevExpress.XtraEditors.CheckEdit checkEditSaveLogin;

		// Token: 0x040004E3 RID: 1251
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSaveEmail;

		// Token: 0x040004E4 RID: 1252
		private global::DevExpress.XtraEditors.CheckEdit checkEditSavePassword;

		// Token: 0x040004E5 RID: 1253
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSavePassword;

		// Token: 0x040004E6 RID: 1254
		private global::DevExpress.XtraEditors.HyperlinkLabelControl hyperlinkLabelForgotenPassword;

		// Token: 0x040004E7 RID: 1255
		private global::DevExpress.Utils.Behaviors.BehaviorManager behaviorManager1;
	}
}
