﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000056 RID: 86
	public partial class AgentUpdateForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060004AB RID: 1195 RVA: 0x000176DF File Offset: 0x000158DF
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x00017700 File Offset: 0x00015900
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.AgentUpdateForm));
			this.comboBoxInstallerVersions = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.labelInstallerVersions = new global::DevExpress.XtraEditors.LabelControl();
			this.buttonInstall = new global::DevExpress.XtraEditors.SimpleButton();
			this.panelTop = new global::System.Windows.Forms.Panel();
			this.selectedDevicesControl = new global::OpiekunWEB.Console.Controls.SelectedDevicesControl();
			this.buttonDownload = new global::DevExpress.XtraEditors.SimpleButton();
			this.checkEditNoRestart = new global::DevExpress.XtraEditors.CheckEdit();
			this.labelControlLastVersion = new global::DevExpress.XtraEditors.LabelControl();
			this.labelDeviceGroup = new global::DevExpress.XtraEditors.LabelControl();
			this.treeListLookUpDeviceGroup = new global::DevExpress.XtraEditors.TreeListLookUpEdit();
			this.treeListLookUpGroupsTreeList = new global::DevExpress.XtraTreeList.TreeList();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxInstallerVersions.Properties).BeginInit();
			this.panelTop.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditNoRestart.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpDeviceGroup.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.comboBoxInstallerVersions, "comboBoxInstallerVersions");
			this.comboBoxInstallerVersions.Name = "comboBoxInstallerVersions";
			this.comboBoxInstallerVersions.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxInstallerVersions.Properties.Buttons"))
			});
			this.comboBoxInstallerVersions.Properties.NullValuePrompt = resources.GetString("comboBoxInstallerVersions.Properties.NullValuePrompt");
			this.comboBoxInstallerVersions.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxInstallerVersions.Properties.EditValueChanged += new global::System.EventHandler(this.comboBoxInstallerVersions_Properties_EditValueChanged);
			resources.ApplyResources(this.labelInstallerVersions, "labelInstallerVersions");
			this.labelInstallerVersions.Name = "labelInstallerVersions";
			resources.ApplyResources(this.buttonInstall, "buttonInstall");
			this.buttonInstall.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.settings_update_agents_16x16;
			this.buttonInstall.Name = "buttonInstall";
			this.buttonInstall.Click += new global::System.EventHandler(this.buttonInstall_Click);
			this.panelTop.Controls.Add(this.selectedDevicesControl);
			resources.ApplyResources(this.panelTop, "panelTop");
			this.panelTop.Name = "panelTop";
			resources.ApplyResources(this.selectedDevicesControl, "selectedDevicesControl");
			this.selectedDevicesControl.Name = "selectedDevicesControl";
			resources.ApplyResources(this.buttonDownload, "buttonDownload");
			this.buttonDownload.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonDownload.ImageOptions.Image");
			this.buttonDownload.ImageOptions.ImageToTextAlignment = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.buttonDownload.Name = "buttonDownload";
			this.buttonDownload.Click += new global::System.EventHandler(this.buttonDownload_Click);
			resources.ApplyResources(this.checkEditNoRestart, "checkEditNoRestart");
			this.checkEditNoRestart.Name = "checkEditNoRestart";
			this.checkEditNoRestart.Properties.Caption = resources.GetString("checkEditNoRestart.Properties.Caption");
			this.labelControlLastVersion.AllowHtmlString = true;
			resources.ApplyResources(this.labelControlLastVersion, "labelControlLastVersion");
			this.labelControlLastVersion.Appearance.Font = (global::System.Drawing.Font)resources.GetObject("labelControlLastVersion.Appearance.Font");
			this.labelControlLastVersion.Appearance.Options.UseFont = true;
			this.labelControlLastVersion.Name = "labelControlLastVersion";
			resources.ApplyResources(this.labelDeviceGroup, "labelDeviceGroup");
			this.labelDeviceGroup.Name = "labelDeviceGroup";
			resources.ApplyResources(this.treeListLookUpDeviceGroup, "treeListLookUpDeviceGroup");
			this.treeListLookUpDeviceGroup.Name = "treeListLookUpDeviceGroup";
			this.treeListLookUpDeviceGroup.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("treeListLookUpDeviceGroup.Properties.Buttons"))
			});
			this.treeListLookUpDeviceGroup.Properties.DisplayMember = "Name";
			this.treeListLookUpDeviceGroup.Properties.NullText = resources.GetString("treeListLookUpDeviceGroup.Properties.NullText");
			this.treeListLookUpDeviceGroup.Properties.TreeList = this.treeListLookUpGroupsTreeList;
			this.treeListLookUpDeviceGroup.EditValueChanged += new global::System.EventHandler(this.treeListLookUpDeviceGroup_EditValueChanged);
			this.treeListLookUpGroupsTreeList.HorzScrollStep = 5;
			this.treeListLookUpGroupsTreeList.KeyFieldName = "Id";
			resources.ApplyResources(this.treeListLookUpGroupsTreeList, "treeListLookUpGroupsTreeList");
			this.treeListLookUpGroupsTreeList.MinWidth = 31;
			this.treeListLookUpGroupsTreeList.Name = "treeListLookUpGroupsTreeList";
			this.treeListLookUpGroupsTreeList.OptionsView.ShowColumns = false;
			this.treeListLookUpGroupsTreeList.OptionsView.ShowIndentAsRowStyle = true;
			this.treeListLookUpGroupsTreeList.ParentFieldName = "ParentId";
			this.treeListLookUpGroupsTreeList.TreeLevelWidth = 27;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.treeListLookUpDeviceGroup);
			base.Controls.Add(this.labelDeviceGroup);
			base.Controls.Add(this.checkEditNoRestart);
			base.Controls.Add(this.buttonDownload);
			base.Controls.Add(this.panelTop);
			base.Controls.Add(this.comboBoxInstallerVersions);
			base.Controls.Add(this.labelInstallerVersions);
			base.Controls.Add(this.labelControlLastVersion);
			base.Controls.Add(this.buttonInstall);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("AgentUpdateForm.IconOptions.Icon");
			base.MaximizeBox = true;
			base.Name = "AgentUpdateForm";
			base.FormClosed += new global::System.Windows.Forms.FormClosedEventHandler(this.AgentUpdateForm_FormClosed);
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxInstallerVersions.Properties).EndInit();
			this.panelTop.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.checkEditNoRestart.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpDeviceGroup.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.treeListLookUpGroupsTreeList).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000206 RID: 518
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000207 RID: 519
		private global::DevExpress.XtraEditors.SimpleButton buttonInstall;

		// Token: 0x04000208 RID: 520
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxInstallerVersions;

		// Token: 0x04000209 RID: 521
		private global::DevExpress.XtraEditors.LabelControl labelInstallerVersions;

		// Token: 0x0400020A RID: 522
		private global::System.Windows.Forms.Panel panelTop;

		// Token: 0x0400020B RID: 523
		private global::OpiekunWEB.Console.Controls.SelectedDevicesControl selectedDevicesControl;

		// Token: 0x0400020C RID: 524
		private global::DevExpress.XtraEditors.SimpleButton buttonDownload;

		// Token: 0x0400020D RID: 525
		private global::DevExpress.XtraEditors.CheckEdit checkEditNoRestart;

		// Token: 0x0400020E RID: 526
		private global::DevExpress.XtraEditors.LabelControl labelControlLastVersion;

		// Token: 0x0400020F RID: 527
		private global::DevExpress.XtraEditors.LabelControl labelDeviceGroup;

		// Token: 0x04000210 RID: 528
		private global::DevExpress.XtraEditors.TreeListLookUpEdit treeListLookUpDeviceGroup;

		// Token: 0x04000211 RID: 529
		private global::DevExpress.XtraTreeList.TreeList treeListLookUpGroupsTreeList;
	}
}
