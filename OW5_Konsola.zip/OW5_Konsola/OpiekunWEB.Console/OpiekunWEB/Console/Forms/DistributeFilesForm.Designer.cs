﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006B RID: 107
	public partial class DistributeFilesForm : global::OpiekunWEB.Console.Forms.NonModalBaseForm
	{
		// Token: 0x060005C7 RID: 1479 RVA: 0x000250E3 File Offset: 0x000232E3
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005C8 RID: 1480 RVA: 0x00025104 File Offset: 0x00023304
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DistributeFilesForm));
			global::DevExpress.XtraGrid.GridLevelNode gridLevelNode = new global::DevExpress.XtraGrid.GridLevelNode();
			this.gridViewSendInfoLog = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnSendInfoLog = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridSendProgress = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewSendInfo = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnDeviceName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnSendProgress = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryItemSendProgressBar = new global::DevExpress.XtraEditors.Repository.RepositoryItemProgressBar();
			this.gridColumnSendBytesPerSec = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnSendSecRemain = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnSendStatus = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnUserName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.xtraTabControl = new global::DevExpress.XtraTab.XtraTabControl();
			this.xtraTabPageFileList = new global::DevExpress.XtraTab.XtraTabPage();
			this.layoutControlOptions = new global::DevExpress.XtraLayout.LayoutControl();
			this.comboBoxReceiveFilesLocalPathType = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.comboBoxReceiveFileOverride = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.textEditReceiveDestinationPath = new global::DevExpress.XtraEditors.ButtonEdit();
			this.comboBoxSendFileOverride = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.textEditSendDestinationPath = new global::DevExpress.XtraEditors.ButtonEdit();
			this.comboBoxSendDestinationDirMacro = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.panelControl1 = new global::DevExpress.XtraEditors.PanelControl();
			this.buttonRemoveFile = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonAddFile = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonAddFolder = new global::DevExpress.XtraEditors.SimpleButton();
			this.gridDevices = new global::DevExpress.XtraGrid.GridControl();
			this.cardViewDevices = new global::DevExpress.XtraGrid.Views.Card.CardView();
			this.gridColumnAgentName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridFileList = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewFileList = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnFileName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlGroupFilesTransfer = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlGridFileList = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItem3 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroupDevices = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlItem1 = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroupSendSettings = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlSendDestinationDirMacro = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlSendDestinationPath = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlSendFileOverride = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlGroupReceiveSettings = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlReceiveDestinationPath = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutItemReceiveFilesLocalPathType = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlReceiveFileOverride = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem2 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.panelBootomTab1 = new global::DevExpress.XtraEditors.PanelControl();
			this.buttonTransfer = new global::DevExpress.XtraEditors.SimpleButton();
			this.xtraTabPageSendProgress = new global::DevExpress.XtraTab.XtraTabPage();
			this.panelControlBottomTab2 = new global::DevExpress.XtraEditors.PanelControl();
			this.buttonCancel = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSendInfoLog).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridSendProgress).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSendInfo).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemSendProgressBar).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControl).BeginInit();
			this.xtraTabControl.SuspendLayout();
			this.xtraTabPageFileList.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlOptions).BeginInit();
			this.layoutControlOptions.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxReceiveFilesLocalPathType.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxReceiveFileOverride.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditReceiveDestinationPath.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxSendFileOverride.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditSendDestinationPath.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxSendDestinationDirMacro.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelControl1).BeginInit();
			this.panelControl1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.cardViewDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridFileList).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewFileList).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupFilesTransfer).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGridFileList).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem3).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupSendSettings).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendDestinationDirMacro).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendDestinationPath).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendFileOverride).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupReceiveSettings).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlReceiveDestinationPath).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutItemReceiveFilesLocalPathType).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlReceiveFileOverride).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelBootomTab1).BeginInit();
			this.panelBootomTab1.SuspendLayout();
			this.xtraTabPageSendProgress.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.panelControlBottomTab2).BeginInit();
			this.panelControlBottomTab2.SuspendLayout();
			base.SuspendLayout();
			this.gridViewSendInfoLog.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnSendInfoLog
			});
			this.gridViewSendInfoLog.GridControl = this.gridSendProgress;
			this.gridViewSendInfoLog.Name = "gridViewSendInfoLog";
			this.gridViewSendInfoLog.OptionsBehavior.Editable = false;
			this.gridViewSendInfoLog.OptionsBehavior.ReadOnly = true;
			this.gridViewSendInfoLog.OptionsView.ShowGroupPanel = false;
			this.gridColumnSendInfoLog.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnSendInfoLog.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnSendInfoLog, "gridColumnSendInfoLog");
			this.gridColumnSendInfoLog.FieldName = "Column";
			this.gridColumnSendInfoLog.Name = "gridColumnSendInfoLog";
			resources.ApplyResources(this.gridSendProgress, "gridSendProgress");
			gridLevelNode.LevelTemplate = this.gridViewSendInfoLog;
			gridLevelNode.RelationName = "Log";
			this.gridSendProgress.LevelTree.Nodes.AddRange(new global::DevExpress.XtraGrid.GridLevelNode[]
			{
				gridLevelNode
			});
			this.gridSendProgress.MainView = this.gridViewSendInfo;
			this.gridSendProgress.Name = "gridSendProgress";
			this.gridSendProgress.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryItemSendProgressBar
			});
			this.gridSendProgress.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewSendInfo,
				this.gridViewSendInfoLog
			});
			this.gridViewSendInfo.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnDeviceName,
				this.gridColumnSendProgress,
				this.gridColumnSendBytesPerSec,
				this.gridColumnSendSecRemain,
				this.gridColumnSendStatus,
				this.gridColumnUserName
			});
			this.gridViewSendInfo.GridControl = this.gridSendProgress;
			this.gridViewSendInfo.Name = "gridViewSendInfo";
			this.gridViewSendInfo.OptionsBehavior.Editable = false;
			this.gridViewSendInfo.OptionsBehavior.ReadOnly = true;
			this.gridViewSendInfo.OptionsDetail.ShowDetailTabs = false;
			this.gridViewSendInfo.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewSendInfo.OptionsView.ShowGroupPanel = false;
			this.gridViewSendInfo.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnDeviceName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewSendInfo.RowStyle += new global::DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.gridViewSendInfo_RowStyle);
			this.gridColumnDeviceName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDeviceName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnDeviceName, "gridColumnDeviceName");
			this.gridColumnDeviceName.FieldName = "DeviceItem.Name";
			this.gridColumnDeviceName.Name = "gridColumnDeviceName";
			this.gridColumnSendProgress.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnSendProgress.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnSendProgress, "gridColumnSendProgress");
			this.gridColumnSendProgress.ColumnEdit = this.repositoryItemSendProgressBar;
			this.gridColumnSendProgress.FieldName = "FilesProgress.Progress";
			this.gridColumnSendProgress.Name = "gridColumnSendProgress";
			this.repositoryItemSendProgressBar.Name = "repositoryItemSendProgressBar";
			this.repositoryItemSendProgressBar.ShowTitle = true;
			this.gridColumnSendBytesPerSec.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnSendBytesPerSec.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnSendBytesPerSec, "gridColumnSendBytesPerSec");
			this.gridColumnSendBytesPerSec.FieldName = "BytesPerSecAsString";
			this.gridColumnSendBytesPerSec.Name = "gridColumnSendBytesPerSec";
			this.gridColumnSendSecRemain.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnSendSecRemain.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnSendSecRemain, "gridColumnSendSecRemain");
			this.gridColumnSendSecRemain.FieldName = "SecRemainAsString";
			this.gridColumnSendSecRemain.Name = "gridColumnSendSecRemain";
			this.gridColumnSendStatus.AppearanceCell.Options.UseTextOptions = true;
			this.gridColumnSendStatus.AppearanceCell.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Near;
			this.gridColumnSendStatus.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnSendStatus.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnSendStatus, "gridColumnSendStatus");
			this.gridColumnSendStatus.FieldName = "StatusAsString";
			this.gridColumnSendStatus.Name = "gridColumnSendStatus";
			this.gridColumnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnUserName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnUserName, "gridColumnUserName");
			this.gridColumnUserName.FieldName = "UserName";
			this.gridColumnUserName.MinWidth = 25;
			this.gridColumnUserName.Name = "gridColumnUserName";
			resources.ApplyResources(this.xtraTabControl, "xtraTabControl");
			this.xtraTabControl.Name = "xtraTabControl";
			this.xtraTabControl.SelectedTabPage = this.xtraTabPageFileList;
			this.xtraTabControl.TabPages.AddRange(new global::DevExpress.XtraTab.XtraTabPage[]
			{
				this.xtraTabPageFileList,
				this.xtraTabPageSendProgress
			});
			this.xtraTabPageFileList.Controls.Add(this.layoutControlOptions);
			this.xtraTabPageFileList.Controls.Add(this.panelBootomTab1);
			this.xtraTabPageFileList.Name = "xtraTabPageFileList";
			resources.ApplyResources(this.xtraTabPageFileList, "xtraTabPageFileList");
			this.layoutControlOptions.Controls.Add(this.comboBoxReceiveFilesLocalPathType);
			this.layoutControlOptions.Controls.Add(this.comboBoxReceiveFileOverride);
			this.layoutControlOptions.Controls.Add(this.textEditReceiveDestinationPath);
			this.layoutControlOptions.Controls.Add(this.comboBoxSendFileOverride);
			this.layoutControlOptions.Controls.Add(this.textEditSendDestinationPath);
			this.layoutControlOptions.Controls.Add(this.comboBoxSendDestinationDirMacro);
			this.layoutControlOptions.Controls.Add(this.panelControl1);
			this.layoutControlOptions.Controls.Add(this.gridDevices);
			this.layoutControlOptions.Controls.Add(this.gridFileList);
			resources.ApplyResources(this.layoutControlOptions, "layoutControlOptions");
			this.layoutControlOptions.Name = "layoutControlOptions";
			this.layoutControlOptions.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2978, 260, 812, 500));
			this.layoutControlOptions.Root = this.Root;
			resources.ApplyResources(this.comboBoxReceiveFilesLocalPathType, "comboBoxReceiveFilesLocalPathType");
			this.comboBoxReceiveFilesLocalPathType.Name = "comboBoxReceiveFilesLocalPathType";
			this.comboBoxReceiveFilesLocalPathType.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxReceiveFilesLocalPathType.Properties.Buttons"))
			});
			this.comboBoxReceiveFilesLocalPathType.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxReceiveFilesLocalPathType.Properties.CustomItemDisplayText += new global::DevExpress.XtraEditors.CustomItemDisplayTextEventHandler(this.comboBoxReceiveFilesLocalPathType_Properties_CustomItemDisplayText);
			this.comboBoxReceiveFilesLocalPathType.Properties.CustomDisplayText += new global::DevExpress.XtraEditors.Controls.CustomDisplayTextEventHandler(this.comboBoxReceiveFilesLocalPathType_Properties_CustomDisplayText);
			this.comboBoxReceiveFilesLocalPathType.StyleController = this.layoutControlOptions;
			resources.ApplyResources(this.comboBoxReceiveFileOverride, "comboBoxReceiveFileOverride");
			this.comboBoxReceiveFileOverride.Name = "comboBoxReceiveFileOverride";
			this.comboBoxReceiveFileOverride.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxReceiveFileOverride.Properties.Buttons"))
			});
			this.comboBoxReceiveFileOverride.Properties.Items.AddRange(new object[]
			{
				resources.GetString("comboBoxReceiveFileOverride.Properties.Items"),
				resources.GetString("comboBoxReceiveFileOverride.Properties.Items1")
			});
			this.comboBoxReceiveFileOverride.StyleController = this.layoutControlOptions;
			resources.ApplyResources(this.textEditReceiveDestinationPath, "textEditReceiveDestinationPath");
			this.textEditReceiveDestinationPath.Name = "textEditReceiveDestinationPath";
			this.textEditReceiveDestinationPath.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.textEditReceiveDestinationPath.StyleController = this.layoutControlOptions;
			this.textEditReceiveDestinationPath.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.textEditReceiveDestinationPath_ButtonClick);
			this.textEditReceiveDestinationPath.EditValueChanged += new global::System.EventHandler(this.textEditReceiveDestinationPath_EditValueChanged);
			resources.ApplyResources(this.comboBoxSendFileOverride, "comboBoxSendFileOverride");
			this.comboBoxSendFileOverride.Name = "comboBoxSendFileOverride";
			this.comboBoxSendFileOverride.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxSendFileOverride.Properties.Buttons"))
			});
			this.comboBoxSendFileOverride.Properties.Items.AddRange(new object[]
			{
				resources.GetString("comboBoxSendFileOverride.Properties.Items"),
				resources.GetString("comboBoxSendFileOverride.Properties.Items1")
			});
			this.comboBoxSendFileOverride.Properties.NullValuePrompt = resources.GetString("comboBoxSendFileOverride.Properties.NullValuePrompt");
			this.comboBoxSendFileOverride.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxSendFileOverride.StyleController = this.layoutControlOptions;
			resources.ApplyResources(this.textEditSendDestinationPath, "textEditSendDestinationPath");
			this.textEditSendDestinationPath.Name = "textEditSendDestinationPath";
			this.textEditSendDestinationPath.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.textEditSendDestinationPath.Properties.Mask.EditMask = resources.GetString("textEditSendDestinationPath.Properties.Mask.EditMask");
			this.textEditSendDestinationPath.Properties.NullValuePrompt = resources.GetString("textEditSendDestinationPath.Properties.NullValuePrompt");
			this.textEditSendDestinationPath.StyleController = this.layoutControlOptions;
			this.textEditSendDestinationPath.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.textEditDestinationPath_ButtonClick);
			this.textEditSendDestinationPath.EditValueChanged += new global::System.EventHandler(this.textEditSendDestinationPath_EditValueChanged);
			resources.ApplyResources(this.comboBoxSendDestinationDirMacro, "comboBoxSendDestinationDirMacro");
			this.comboBoxSendDestinationDirMacro.Name = "comboBoxSendDestinationDirMacro";
			this.comboBoxSendDestinationDirMacro.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxSendDestinationDirMacro.Properties.Buttons"))
			});
			this.comboBoxSendDestinationDirMacro.Properties.NullValuePrompt = resources.GetString("comboBoxSendDestinationDirMacro.Properties.NullValuePrompt");
			this.comboBoxSendDestinationDirMacro.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxSendDestinationDirMacro.StyleController = this.layoutControlOptions;
			this.comboBoxSendDestinationDirMacro.TextChanged += new global::System.EventHandler(this.comboBoxDestinationDirMacro_TextChanged);
			this.panelControl1.Controls.Add(this.buttonRemoveFile);
			this.panelControl1.Controls.Add(this.buttonAddFile);
			this.panelControl1.Controls.Add(this.buttonAddFolder);
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.Name = "panelControl1";
			resources.ApplyResources(this.buttonRemoveFile, "buttonRemoveFile");
			this.buttonRemoveFile.Name = "buttonRemoveFile";
			this.buttonRemoveFile.Click += new global::System.EventHandler(this.buttonRemoveFile_Click);
			resources.ApplyResources(this.buttonAddFile, "buttonAddFile");
			this.buttonAddFile.Name = "buttonAddFile";
			this.buttonAddFile.Click += new global::System.EventHandler(this.buttonAddFile_Click);
			resources.ApplyResources(this.buttonAddFolder, "buttonAddFolder");
			this.buttonAddFolder.Name = "buttonAddFolder";
			this.buttonAddFolder.Click += new global::System.EventHandler(this.buttonAddFolder_Click);
			resources.ApplyResources(this.gridDevices, "gridDevices");
			this.gridDevices.MainView = this.cardViewDevices;
			this.gridDevices.Name = "gridDevices";
			this.gridDevices.ShowOnlyPredefinedDetails = true;
			this.gridDevices.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.cardViewDevices
			});
			this.gridDevices.DoubleClick += new global::System.EventHandler(this.gridDevices_DoubleClick);
			this.cardViewDevices.CardInterval = 4;
			this.cardViewDevices.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnAgentName
			});
			this.cardViewDevices.GridControl = this.gridDevices;
			this.cardViewDevices.Name = "cardViewDevices";
			this.cardViewDevices.OptionsBehavior.Editable = false;
			this.cardViewDevices.OptionsBehavior.ReadOnly = true;
			this.cardViewDevices.OptionsView.ShowCardCaption = false;
			this.cardViewDevices.OptionsView.ShowCardExpandButton = false;
			this.cardViewDevices.OptionsView.ShowFieldCaptions = false;
			this.cardViewDevices.OptionsView.ShowLines = false;
			this.cardViewDevices.OptionsView.ShowQuickCustomizeButton = false;
			this.cardViewDevices.VertScrollVisibility = global::DevExpress.XtraGrid.Views.Base.ScrollVisibility.Auto;
			this.cardViewDevices.CustomDrawCardFieldValue += new global::DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.cardViewDevices_CustomDrawCardFieldValue);
			this.cardViewDevices.CustomColumnDisplayText += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.cardViewDevices_CustomColumnDisplayText);
			this.gridColumnAgentName.FieldName = "gridColumnAgentName";
			this.gridColumnAgentName.MinWidth = 25;
			this.gridColumnAgentName.Name = "gridColumnAgentName";
			this.gridColumnAgentName.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			resources.ApplyResources(this.gridColumnAgentName, "gridColumnAgentName");
			resources.ApplyResources(this.gridFileList, "gridFileList");
			this.gridFileList.MainView = this.gridViewFileList;
			this.gridFileList.Name = "gridFileList";
			this.gridFileList.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewFileList
			});
			this.gridViewFileList.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnFileName
			});
			this.gridViewFileList.GridControl = this.gridFileList;
			this.gridViewFileList.Name = "gridViewFileList";
			this.gridViewFileList.OptionsBehavior.Editable = false;
			this.gridViewFileList.OptionsBehavior.ReadOnly = true;
			this.gridViewFileList.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewFileList.OptionsView.ShowColumnHeaders = false;
			this.gridViewFileList.OptionsView.ShowGroupPanel = false;
			this.gridViewFileList.CustomColumnDisplayText += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridViewFileList_CustomColumnDisplayText);
			resources.ApplyResources(this.gridColumnFileName, "gridColumnFileName");
			this.gridColumnFileName.FieldName = "Column";
			this.gridColumnFileName.Name = "gridColumnFileName";
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlGroupFilesTransfer,
				this.layoutControlGroupDevices,
				this.layoutControlGroupSendSettings,
				this.layoutControlGroupReceiveSettings
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(673, 544);
			this.Root.TextVisible = false;
			this.layoutControlGroupFilesTransfer.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlGridFileList,
				this.layoutControlItem3
			});
			this.layoutControlGroupFilesTransfer.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlGroupFilesTransfer.Name = "layoutControlGroupFilesTransfer";
			this.layoutControlGroupFilesTransfer.Size = new global::System.Drawing.Size(653, 179);
			resources.ApplyResources(this.layoutControlGroupFilesTransfer, "layoutControlGroupFilesTransfer");
			this.layoutControlGridFileList.Control = this.gridFileList;
			this.layoutControlGridFileList.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlGridFileList.Name = "layoutControlGridFileList";
			this.layoutControlGridFileList.Size = new global::System.Drawing.Size(492, 132);
			this.layoutControlGridFileList.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlGridFileList.TextVisible = false;
			this.layoutControlItem3.Control = this.panelControl1;
			this.layoutControlItem3.Location = new global::System.Drawing.Point(492, 0);
			this.layoutControlItem3.Name = "layoutControlItem3";
			this.layoutControlItem3.Size = new global::System.Drawing.Size(137, 132);
			this.layoutControlItem3.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem3.TextVisible = false;
			this.layoutControlGroupDevices.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlItem1
			});
			this.layoutControlGroupDevices.Location = new global::System.Drawing.Point(0, 453);
			this.layoutControlGroupDevices.Name = "layoutControlGroupDevices";
			this.layoutControlGroupDevices.Size = new global::System.Drawing.Size(653, 71);
			resources.ApplyResources(this.layoutControlGroupDevices, "layoutControlGroupDevices");
			this.layoutControlItem1.Control = this.gridDevices;
			this.layoutControlItem1.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlItem1.Name = "layoutControlItem1";
			this.layoutControlItem1.Size = new global::System.Drawing.Size(629, 24);
			this.layoutControlItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem1.TextVisible = false;
			this.layoutControlGroupSendSettings.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlSendDestinationDirMacro,
				this.layoutControlSendDestinationPath,
				this.layoutControlSendFileOverride,
				this.emptySpaceItem1
			});
			this.layoutControlGroupSendSettings.Location = new global::System.Drawing.Point(0, 179);
			this.layoutControlGroupSendSettings.Name = "layoutControlGroupSendSettings";
			this.layoutControlGroupSendSettings.Size = new global::System.Drawing.Size(653, 137);
			resources.ApplyResources(this.layoutControlGroupSendSettings, "layoutControlGroupSendSettings");
			this.layoutControlGroupSendSettings.Visibility = global::DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
			this.layoutControlSendDestinationDirMacro.Control = this.comboBoxSendDestinationDirMacro;
			this.layoutControlSendDestinationDirMacro.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlSendDestinationDirMacro.Name = "layoutControlSendDestinationDirMacro";
			this.layoutControlSendDestinationDirMacro.Size = new global::System.Drawing.Size(304, 45);
			resources.ApplyResources(this.layoutControlSendDestinationDirMacro, "layoutControlSendDestinationDirMacro");
			this.layoutControlSendDestinationDirMacro.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlSendDestinationDirMacro.TextSize = new global::System.Drawing.Size(125, 16);
			this.layoutControlSendDestinationPath.Control = this.textEditSendDestinationPath;
			this.layoutControlSendDestinationPath.Location = new global::System.Drawing.Point(304, 0);
			this.layoutControlSendDestinationPath.Name = "layoutControlSendDestinationPath";
			this.layoutControlSendDestinationPath.Size = new global::System.Drawing.Size(325, 45);
			resources.ApplyResources(this.layoutControlSendDestinationPath, "layoutControlSendDestinationPath");
			this.layoutControlSendDestinationPath.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlSendDestinationPath.TextSize = new global::System.Drawing.Size(125, 16);
			this.layoutControlSendFileOverride.Control = this.comboBoxSendFileOverride;
			this.layoutControlSendFileOverride.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlSendFileOverride.Name = "layoutControlSendFileOverride";
			this.layoutControlSendFileOverride.Size = new global::System.Drawing.Size(304, 45);
			resources.ApplyResources(this.layoutControlSendFileOverride, "layoutControlSendFileOverride");
			this.layoutControlSendFileOverride.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlSendFileOverride.TextSize = new global::System.Drawing.Size(125, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(304, 45);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(325, 45);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlGroupReceiveSettings.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlReceiveDestinationPath,
				this.layoutItemReceiveFilesLocalPathType,
				this.layoutControlReceiveFileOverride,
				this.emptySpaceItem2
			});
			this.layoutControlGroupReceiveSettings.Location = new global::System.Drawing.Point(0, 316);
			this.layoutControlGroupReceiveSettings.Name = "layoutControlGroupReceiveSettings";
			this.layoutControlGroupReceiveSettings.Size = new global::System.Drawing.Size(653, 137);
			resources.ApplyResources(this.layoutControlGroupReceiveSettings, "layoutControlGroupReceiveSettings");
			this.layoutControlGroupReceiveSettings.Visibility = global::DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
			this.layoutControlReceiveDestinationPath.Control = this.textEditReceiveDestinationPath;
			this.layoutControlReceiveDestinationPath.Location = new global::System.Drawing.Point(304, 0);
			this.layoutControlReceiveDestinationPath.Name = "layoutControlReceiveDestinationPath";
			this.layoutControlReceiveDestinationPath.Size = new global::System.Drawing.Size(325, 45);
			resources.ApplyResources(this.layoutControlReceiveDestinationPath, "layoutControlReceiveDestinationPath");
			this.layoutControlReceiveDestinationPath.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlReceiveDestinationPath.TextSize = new global::System.Drawing.Size(125, 16);
			this.layoutItemReceiveFilesLocalPathType.Control = this.comboBoxReceiveFilesLocalPathType;
			this.layoutItemReceiveFilesLocalPathType.Location = new global::System.Drawing.Point(0, 0);
			this.layoutItemReceiveFilesLocalPathType.Name = "layoutItemReceiveFilesLocalPathType";
			this.layoutItemReceiveFilesLocalPathType.Size = new global::System.Drawing.Size(304, 45);
			resources.ApplyResources(this.layoutItemReceiveFilesLocalPathType, "layoutItemReceiveFilesLocalPathType");
			this.layoutItemReceiveFilesLocalPathType.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutItemReceiveFilesLocalPathType.TextSize = new global::System.Drawing.Size(125, 16);
			this.layoutControlReceiveFileOverride.Control = this.comboBoxReceiveFileOverride;
			this.layoutControlReceiveFileOverride.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlReceiveFileOverride.Name = "layoutControlReceiveFileOverride";
			this.layoutControlReceiveFileOverride.Size = new global::System.Drawing.Size(304, 45);
			resources.ApplyResources(this.layoutControlReceiveFileOverride, "layoutControlReceiveFileOverride");
			this.layoutControlReceiveFileOverride.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlReceiveFileOverride.TextSize = new global::System.Drawing.Size(125, 16);
			this.emptySpaceItem2.AllowHotTrack = false;
			this.emptySpaceItem2.Location = new global::System.Drawing.Point(304, 45);
			this.emptySpaceItem2.Name = "emptySpaceItem2";
			this.emptySpaceItem2.Size = new global::System.Drawing.Size(325, 45);
			this.emptySpaceItem2.TextSize = new global::System.Drawing.Size(0, 0);
			this.panelBootomTab1.BorderStyle = global::DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelBootomTab1.Controls.Add(this.buttonTransfer);
			resources.ApplyResources(this.panelBootomTab1, "panelBootomTab1");
			this.panelBootomTab1.Name = "panelBootomTab1";
			resources.ApplyResources(this.buttonTransfer, "buttonTransfer");
			this.buttonTransfer.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.doublenext_32x32;
			this.buttonTransfer.Name = "buttonTransfer";
			this.buttonTransfer.Click += new global::System.EventHandler(this.buttonTransfer_Click);
			this.xtraTabPageSendProgress.Controls.Add(this.gridSendProgress);
			this.xtraTabPageSendProgress.Controls.Add(this.panelControlBottomTab2);
			this.xtraTabPageSendProgress.Name = "xtraTabPageSendProgress";
			resources.ApplyResources(this.xtraTabPageSendProgress, "xtraTabPageSendProgress");
			this.panelControlBottomTab2.BorderStyle = global::DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControlBottomTab2.Controls.Add(this.buttonCancel);
			resources.ApplyResources(this.panelControlBottomTab2, "panelControlBottomTab2");
			this.panelControlBottomTab2.Name = "panelControlBottomTab2";
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonCancel.ImageOptions.Image");
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Click += new global::System.EventHandler(this.buttonCancel_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.xtraTabControl);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("DistributeFilesForm.IconOptions.Icon");
			base.MaximizeBox = true;
			base.Name = "DistributeFilesForm";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.FormFileDistribute_FormClosing);
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSendInfoLog).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridSendProgress).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSendInfo).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemSendProgressBar).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControl).EndInit();
			this.xtraTabControl.ResumeLayout(false);
			this.xtraTabPageFileList.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlOptions).EndInit();
			this.layoutControlOptions.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxReceiveFilesLocalPathType.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxReceiveFileOverride.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditReceiveDestinationPath.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxSendFileOverride.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditSendDestinationPath.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxSendDestinationDirMacro.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelControl1).EndInit();
			this.panelControl1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.cardViewDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridFileList).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewFileList).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupFilesTransfer).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGridFileList).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem3).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupSendSettings).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendDestinationDirMacro).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendDestinationPath).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendFileOverride).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupReceiveSettings).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlReceiveDestinationPath).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutItemReceiveFilesLocalPathType).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlReceiveFileOverride).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelBootomTab1).EndInit();
			this.panelBootomTab1.ResumeLayout(false);
			this.xtraTabPageSendProgress.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.panelControlBottomTab2).EndInit();
			this.panelControlBottomTab2.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x04000311 RID: 785
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000312 RID: 786
		private global::DevExpress.XtraTab.XtraTabControl xtraTabControl;

		// Token: 0x04000313 RID: 787
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPageSendProgress;

		// Token: 0x04000314 RID: 788
		private global::DevExpress.XtraGrid.GridControl gridSendProgress;

		// Token: 0x04000315 RID: 789
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewSendInfo;

		// Token: 0x04000316 RID: 790
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDeviceName;

		// Token: 0x04000317 RID: 791
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnSendStatus;

		// Token: 0x04000318 RID: 792
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnSendProgress;

		// Token: 0x04000319 RID: 793
		private global::DevExpress.XtraEditors.Repository.RepositoryItemProgressBar repositoryItemSendProgressBar;

		// Token: 0x0400031A RID: 794
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnSendBytesPerSec;

		// Token: 0x0400031B RID: 795
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnSendSecRemain;

		// Token: 0x0400031C RID: 796
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewSendInfoLog;

		// Token: 0x0400031D RID: 797
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnSendInfoLog;

		// Token: 0x0400031E RID: 798
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPageFileList;

		// Token: 0x0400031F RID: 799
		private global::DevExpress.XtraLayout.LayoutControl layoutControlOptions;

		// Token: 0x04000320 RID: 800
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x04000321 RID: 801
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxSendFileOverride;

		// Token: 0x04000322 RID: 802
		private global::DevExpress.XtraEditors.ButtonEdit textEditSendDestinationPath;

		// Token: 0x04000323 RID: 803
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxSendDestinationDirMacro;

		// Token: 0x04000324 RID: 804
		private global::DevExpress.XtraEditors.PanelControl panelControl1;

		// Token: 0x04000325 RID: 805
		private global::DevExpress.XtraEditors.SimpleButton buttonRemoveFile;

		// Token: 0x04000326 RID: 806
		private global::DevExpress.XtraEditors.SimpleButton buttonAddFile;

		// Token: 0x04000327 RID: 807
		private global::DevExpress.XtraEditors.SimpleButton buttonAddFolder;

		// Token: 0x04000328 RID: 808
		private global::DevExpress.XtraGrid.GridControl gridDevices;

		// Token: 0x04000329 RID: 809
		private global::DevExpress.XtraGrid.Views.Card.CardView cardViewDevices;

		// Token: 0x0400032A RID: 810
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnAgentName;

		// Token: 0x0400032B RID: 811
		private global::DevExpress.XtraGrid.GridControl gridFileList;

		// Token: 0x0400032C RID: 812
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewFileList;

		// Token: 0x0400032D RID: 813
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnFileName;

		// Token: 0x0400032E RID: 814
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupFilesTransfer;

		// Token: 0x0400032F RID: 815
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlGridFileList;

		// Token: 0x04000330 RID: 816
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;

		// Token: 0x04000331 RID: 817
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupDevices;

		// Token: 0x04000332 RID: 818
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;

		// Token: 0x04000333 RID: 819
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupSendSettings;

		// Token: 0x04000334 RID: 820
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSendDestinationDirMacro;

		// Token: 0x04000335 RID: 821
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSendDestinationPath;

		// Token: 0x04000336 RID: 822
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSendFileOverride;

		// Token: 0x04000337 RID: 823
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x04000338 RID: 824
		private global::DevExpress.XtraEditors.PanelControl panelBootomTab1;

		// Token: 0x04000339 RID: 825
		private global::DevExpress.XtraEditors.SimpleButton buttonTransfer;

		// Token: 0x0400033A RID: 826
		private global::DevExpress.XtraEditors.PanelControl panelControlBottomTab2;

		// Token: 0x0400033B RID: 827
		private global::DevExpress.XtraEditors.SimpleButton buttonCancel;

		// Token: 0x0400033C RID: 828
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnUserName;

		// Token: 0x0400033D RID: 829
		private global::DevExpress.XtraEditors.ButtonEdit textEditReceiveDestinationPath;

		// Token: 0x0400033E RID: 830
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupReceiveSettings;

		// Token: 0x0400033F RID: 831
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlReceiveDestinationPath;

		// Token: 0x04000340 RID: 832
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxReceiveFileOverride;

		// Token: 0x04000341 RID: 833
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlReceiveFileOverride;

		// Token: 0x04000342 RID: 834
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxReceiveFilesLocalPathType;

		// Token: 0x04000343 RID: 835
		private global::DevExpress.XtraLayout.LayoutControlItem layoutItemReceiveFilesLocalPathType;

		// Token: 0x04000344 RID: 836
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
	}
}
