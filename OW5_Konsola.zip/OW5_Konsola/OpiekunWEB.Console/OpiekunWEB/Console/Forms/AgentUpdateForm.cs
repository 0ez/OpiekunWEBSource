﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Nodes;
using Google.Protobuf;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Controls;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000056 RID: 86
	public partial class AgentUpdateForm : BaseForm
	{
		// Token: 0x0600049F RID: 1183 RVA: 0x0001706F File Offset: 0x0001526F
		public AgentUpdateForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x00017080 File Offset: 0x00015280
		public AgentUpdateForm(FormsSettings formsSettings, IFormCreator formCreator, DevicesTree devicesTree, ApiClient apiClient, IIconsProvider iconsProvider) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._devicesTree = devicesTree;
			this._apiClient = apiClient;
			this._agentExpectedVersion = new Dictionary<string, string>();
			this.selectedDevicesControl.SetIconsProvider(iconsProvider);
			this.treeListLookUpDeviceGroup.Properties.DataSource = this._apiClient.DevicesGroups;
			TreeListNode treeItem = this.treeListLookUpGroupsTreeList.FindNodeByKeyID(devicesTree.RootGroupId);
			this.treeListLookUpDeviceGroup.EditValue = this.treeListLookUpGroupsTreeList.GetDataRecordByNode(treeItem);
			this.selectedDevicesControl.columnStatusImage.VisibleIndex = 1;
			this.selectedDevicesControl.columnStatusImage.Visible = true;
			this.selectedDevicesControl.columnStatusImage.OptionsColumn.FixedWidth = true;
			this.selectedDevicesControl.columnStatusImage.Width = 64;
			this.selectedDevicesControl.columnMessage.Visible = true;
			this.selectedDevicesControl.columnMessage.MinWidth = 200;
			this.selectedDevicesControl.columnAgentVersion.Visible = true;
			this.selectedDevicesControl.columnAgentVersion.MinWidth = 80;
			this._observer = this._apiClient.EventsStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<EventMessage>(this.OnApiEvent));
			this._objectsToSaveState.Add(this.checkEditNoRestart);
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x000171D8 File Offset: 0x000153D8
		protected override void AfterRestoreState()
		{
			AgentUpdateForm.<AfterRestoreState>d__7 <AfterRestoreState>d__;
			<AfterRestoreState>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AfterRestoreState>d__.<>4__this = this;
			<AfterRestoreState>d__.<>1__state = -1;
			<AfterRestoreState>d__.<>t__builder.Start<AgentUpdateForm.<AfterRestoreState>d__7>(ref <AfterRestoreState>d__);
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x0001720F File Offset: 0x0001540F
		private void AgentUpdateForm_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (this._observer != null)
			{
				this._observer.Dispose();
				this._observer = null;
			}
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x0001722C File Offset: 0x0001542C
		private void buttonDownload_Click(object sender, EventArgs e)
		{
			InstallerFileInfo installerVersion = this.GetSelectedInstallerVersion();
			if (installerVersion != null)
			{
				try
				{
					using (XtraFolderBrowserDialog dlg = new XtraFolderBrowserDialog())
					{
						dlg.Title = Resources.AppUpdateForm_FolderBrowserTitle;
						if (!dlg.ShowDialog().Equals(DialogResult.Cancel))
						{
							Uri url = new Uri(installerVersion.Url);
							string fileName = Path.GetFileName(url.LocalPath);
							string localFilePath = Path.Combine(dlg.SelectedPath, fileName);
							using (HttpDownloadForm httpDownloadForm = new HttpDownloadForm(this._formCreator, url, localFilePath))
							{
								if (httpDownloadForm.ShowDialog() == DialogResult.OK)
								{
									this._formCreator.ShowInfo(Resources.AppUpdateForm_DownloadSucceeded);
								}
								else
								{
									File.Delete(localFilePath);
								}
							}
						}
					}
				}
				catch (Exception ex)
				{
					string msg = ex.Message;
					if (ex.InnerException != null)
					{
						msg = ex.InnerException.Message;
					}
					this._formCreator.ShowError(msg);
				}
			}
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00017348 File Offset: 0x00015548
		private void buttonInstall_Click(object sender, EventArgs e)
		{
			AgentUpdateForm.<buttonInstall_Click>d__10 <buttonInstall_Click>d__;
			<buttonInstall_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonInstall_Click>d__.<>4__this = this;
			<buttonInstall_Click>d__.<>1__state = -1;
			<buttonInstall_Click>d__.<>t__builder.Start<AgentUpdateForm.<buttonInstall_Click>d__10>(ref <buttonInstall_Click>d__);
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0001737F File Offset: 0x0001557F
		private void comboBoxInstallerVersions_Properties_EditValueChanged(object sender, EventArgs e)
		{
			this.SelectDevicesBellowVersion(this.GetSelectedInstallerVersion());
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x00017390 File Offset: 0x00015590
		private Task FillAgentInstallerVersions()
		{
			AgentUpdateForm.<FillAgentInstallerVersions>d__12 <FillAgentInstallerVersions>d__;
			<FillAgentInstallerVersions>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<FillAgentInstallerVersions>d__.<>4__this = this;
			<FillAgentInstallerVersions>d__.<>1__state = -1;
			<FillAgentInstallerVersions>d__.<>t__builder.Start<AgentUpdateForm.<FillAgentInstallerVersions>d__12>(ref <FillAgentInstallerVersions>d__);
			return <FillAgentInstallerVersions>d__.<>t__builder.Task;
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x000173D4 File Offset: 0x000155D4
		private InstallerFileInfo GetSelectedInstallerVersion()
		{
			string s = this.comboBoxInstallerVersions.EditValue as string;
			if (string.IsNullOrEmpty(s))
			{
				return null;
			}
			if (s.IndexOf(' ') > -1)
			{
				s = s.Substring(0, s.IndexOf(' '));
			}
			return this._appInstallers.AgentFiles.FirstOrDefault((InstallerFileInfo x) => x.Version == s);
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x00017458 File Offset: 0x00015658
		private void OnApiEvent(EventMessage eventMessage)
		{
			if (eventMessage.Topic == "UpdateAgentProgress")
			{
				UpdateAgentProgress msg = new UpdateAgentProgress();
				msg.MergeFrom(eventMessage.Payload);
				string description = msg.Status.GetDescription();
				if (msg.Status == UpdateAgentStatus.InstallerProgress)
				{
					description = Resources.AgentUpdateForm_UpdateProgress + string.Format(" {0}%", msg.Percent);
				}
				string deviceId = ApiUtils.DeviceIdFromAgentId(eventMessage.PublisherId);
				if (description != string.Empty)
				{
					this.selectedDevicesControl.SetMessageForDevice(deviceId, description);
				}
				this.selectedDevicesControl.SetObjectForDevice(deviceId, msg.Status);
				switch (msg.Status)
				{
				case UpdateAgentStatus.DownloadBegin:
					this.selectedDevicesControl.SetStatusImageForDevice(deviceId, Resources.progress_animated);
					return;
				case UpdateAgentStatus.DownloadError:
				case UpdateAgentStatus.InstallerRunError:
				case UpdateAgentStatus.InstallerError:
					this.selectedDevicesControl.SetStatusImageForDevice(deviceId, Resources.cancel_16x161);
					return;
				case UpdateAgentStatus.DownloadSuccess:
				case UpdateAgentStatus.InstallerRunning:
				case UpdateAgentStatus.InstallerProgress:
					break;
				case UpdateAgentStatus.InstallerSucess:
					this.selectedDevicesControl.SetStatusImageForDevice(deviceId, Resources.iconsetsymbols3_16x16);
					return;
				default:
					return;
				}
			}
			else if (eventMessage.Topic == "DeviceConnected")
			{
				string deviceId2 = ApiUtils.DeviceIdFromAgentId(eventMessage.PublisherId);
				object obj = this.selectedDevicesControl.GetDeviceObject(deviceId2);
				if (obj == null)
				{
					return;
				}
				string expected;
				if ((UpdateAgentStatus)obj == UpdateAgentStatus.InstallerRunning && this._agentExpectedVersion.TryGetValue(deviceId2, out expected))
				{
					DeviceConnected deviceConnected = new DeviceConnected();
					deviceConnected.MergeFrom(eventMessage.Payload);
					if (deviceConnected.AppVersion == expected)
					{
						this.selectedDevicesControl.SetMessageForDevice(deviceId2, UpdateAgentStatus.InstallerSucess.GetDescription());
						this.selectedDevicesControl.SetStatusImageForDevice(deviceId2, Resources.iconsetsymbols3_16x16);
					}
				}
			}
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x000175FC File Offset: 0x000157FC
		private void SelectDevicesBellowVersion(InstallerFileInfo fileInfo)
		{
			if (fileInfo == null)
			{
				this.selectedDevicesControl.ClearDevicesSelected();
				return;
			}
			List<DeviceItem> devicesToSelect = (from x in this.selectedDevicesControl.Devices.OfType<DeviceItem>()
			where SsStringUtils.IsAppVersionNeverThat(x.AppVersion, fileInfo.Version)
			select x).ToList<DeviceItem>();
			this.selectedDevicesControl.SetDevicesSelected(devicesToSelect);
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x00017660 File Offset: 0x00015860
		private void treeListLookUpDeviceGroup_EditValueChanged(object sender, EventArgs e)
		{
			DevicesGroup group = this.treeListLookUpDeviceGroup.GetSelectedDataRow() as DevicesGroup;
			if (group != null)
			{
				if (group.Id == this._devicesTree.RootGroupId)
				{
					this.selectedDevicesControl.SetDevices(this._devicesTree.GetDevices(), true, true, true, false, true);
				}
				else
				{
					this.selectedDevicesControl.SetDevices(this._devicesTree.GetDevicesForGroupAndSubgroups(group.Id), true, true, true, false, true);
				}
				this.comboBoxInstallerVersions_Properties_EditValueChanged(this, null);
			}
		}

		// Token: 0x04000201 RID: 513
		protected readonly DevicesTree _devicesTree;

		// Token: 0x04000202 RID: 514
		protected ApiClient _apiClient;

		// Token: 0x04000203 RID: 515
		private readonly Dictionary<string, string> _agentExpectedVersion;

		// Token: 0x04000204 RID: 516
		private AppInstallersInfo _appInstallers;

		// Token: 0x04000205 RID: 517
		private IDisposable _observer;
	}
}
