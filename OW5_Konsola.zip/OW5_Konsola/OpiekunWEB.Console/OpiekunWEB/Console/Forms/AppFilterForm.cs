﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200004F RID: 79
	public partial class AppFilterForm : CRUDBaseForm
	{
		// Token: 0x0600046E RID: 1134 RVA: 0x00012ACD File Offset: 0x00010CCD
		public AppFilterForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x00012ADC File Offset: 0x00010CDC
		public AppFilterForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, AppFilter appFilter) : base(formsSettings, formCreator, action, apiClient)
		{
			this.InitializeComponent();
			this._appFilter = appFilter;
			this._macroList = Macros.GetDirMacrosAsStringKeyValueList(true);
			this.comboBoxMacro.Properties.Items.AddRange(this._macroList);
			if (action != FormAction.Update)
			{
				this.comboBoxMacro.SelectedItem = this._macroList.Find((StringKeyAndValue x) => x.Key == "{?}");
				return;
			}
			this.textEditDescription.Text = appFilter.Description;
			AppFilterType filterType = this._appFilter.FilterType;
			if (filterType != AppFilterType.PathFilter)
			{
				return;
			}
			AppPathFilter pathFilter = appFilter.GetAppPathFilter();
			System.ValueTuple<StringKeyAndValue, string> valueTuple = Macros.SplitFileNameToMacroAndFileName(this._macroList, pathFilter.Path);
			StringKeyAndValue macro = valueTuple.Item1;
			string fileName = valueTuple.Item2;
			this.comboBoxMacro.SelectedItem = macro;
			this.textEditFilePath.Text = fileName;
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x00012BC7 File Offset: 0x00010DC7
		protected string GetFileName()
		{
			StringKeyAndValue selectedMacro = this.GetSelectedMacro();
			return Macros.MacroAndFileNameToString((selectedMacro != null) ? selectedMacro.Key : null, this.textEditFilePath.Text);
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x00012BEB File Offset: 0x00010DEB
		protected override bool IsDataUpdated()
		{
			return this.GetCurrentAppFilter().ToString() != this._appFilter.ToString();
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x00012C08 File Offset: 0x00010E08
		protected override bool IsDataValid()
		{
			if (this.textEditFilePath.Text == "*" || this.textEditFilePath.Text == "**")
			{
				this.textEditFilePath.Text = "\\" + this.textEditFilePath.Text;
			}
			string pathToCheck = this.textEditFilePath.Text;
			string endWildcards = string.Empty;
			if (pathToCheck.EndsWith("\\**"))
			{
				endWildcards = "\\**";
			}
			else if (pathToCheck.EndsWith("\\*"))
			{
				endWildcards = "\\*";
			}
			if (endWildcards != string.Empty)
			{
				pathToCheck = pathToCheck.Substring(0, pathToCheck.Length - endWildcards.Length);
			}
			bool isPathValid;
			if (endWildcards != string.Empty && pathToCheck == string.Empty)
			{
				StringKeyAndValue selectedMacro = this.GetSelectedMacro();
				isPathValid = !Macros.IsAnyDirectoryMacro((selectedMacro != null) ? selectedMacro.Key : null);
			}
			else
			{
				StringKeyAndValue selectedMacro2 = this.GetSelectedMacro();
				string modifiedPath;
				isPathValid = Macros.ValidateMacroAndPath((selectedMacro2 != null) ? selectedMacro2.Key : null, pathToCheck, out modifiedPath, FileOrFolder.File);
				if (endWildcards != string.Empty)
				{
					modifiedPath += endWildcards;
					this.textEditFilePath.Text = modifiedPath;
				}
			}
			if (!isPathValid)
			{
				this.textEditFilePath.Focus();
				this.textEditFilePath.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
			}
			return isPathValid;
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x00012D5C File Offset: 0x00010F5C
		protected override Task<bool> OnActionCreate()
		{
			AppFilterForm.<OnActionCreate>d__7 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<AppFilterForm.<OnActionCreate>d__7>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x00012DA0 File Offset: 0x00010FA0
		protected override Task<bool> OnActionUpdate()
		{
			AppFilterForm.<OnActionUpdate>d__8 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<AppFilterForm.<OnActionUpdate>d__8>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x00012DE3 File Offset: 0x00010FE3
		private AppFilter GetCurrentAppFilter()
		{
			return new AppFilter
			{
				FilterType = this._appFilter.FilterType,
				Data = this.GetFilterData(),
				Description = this.textEditDescription.Text
			};
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x00012E18 File Offset: 0x00011018
		private string GetFilterData()
		{
			string result = string.Empty;
			AppFilterType filterType = this._appFilter.FilterType;
			if (filterType != AppFilterType.PathFilter)
			{
				if (filterType != AppFilterType.HashFilter)
				{
				}
			}
			else
			{
				result = new AppPathFilter
				{
					Path = this.GetFileName()
				}.ToString();
			}
			return result;
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x00012E58 File Offset: 0x00011058
		private StringKeyAndValue GetSelectedMacro()
		{
			return this.comboBoxMacro.SelectedItem as StringKeyAndValue;
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x00012E6C File Offset: 0x0001106C
		private void textEditFilePath_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			using (XtraOpenFileDialog dlg = new XtraOpenFileDialog())
			{
				if (dlg.ShowDialog() == DialogResult.OK)
				{
					this.textEditFilePath.Text = dlg.FileName;
				}
			}
		}

		// Token: 0x0400019C RID: 412
		private readonly AppFilter _appFilter;

		// Token: 0x0400019D RID: 413
		private readonly List<StringKeyAndValue> _macroList;
	}
}
