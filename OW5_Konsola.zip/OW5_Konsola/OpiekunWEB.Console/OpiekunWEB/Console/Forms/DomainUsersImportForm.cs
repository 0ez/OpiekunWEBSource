﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000065 RID: 101
	public partial class DomainUsersImportForm : BaseForm
	{
		// Token: 0x06000547 RID: 1351 RVA: 0x0001F24C File Offset: 0x0001D44C
		public DomainUsersImportForm(IFormCreator formCreator, ApiClient apiClient, string roleId) : base(null, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._userList = new BindingList<DomainUsersImportForm.DomainUserInfo>();
			this.gridUsers.DataSource = this._userList;
			this._rolesList = (from x in apiClient.Roles
			where x.RoleType == RoleType.WindowsUsers
			select x).ToList<Role>();
			this.lookUpRoles.Properties.DataSource = this._rolesList;
			if (this._rolesList.Find((Role x) => x.Id == roleId) != null)
			{
				this.lookUpRoles.EditValue = roleId;
			}
			try
			{
				this.textEditDomainName.Text = Domain.GetComputerDomain().Name;
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x0001F338 File Offset: 0x0001D538
		protected override void AfterRestoreState()
		{
			DomainUsersImportForm.<AfterRestoreState>d__5 <AfterRestoreState>d__;
			<AfterRestoreState>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AfterRestoreState>d__.<>4__this = this;
			<AfterRestoreState>d__.<>1__state = -1;
			<AfterRestoreState>d__.<>t__builder.Start<DomainUsersImportForm.<AfterRestoreState>d__5>(ref <AfterRestoreState>d__);
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x0001F370 File Offset: 0x0001D570
		private void buttonOk_Click(object sender, EventArgs e)
		{
			DomainUsersImportForm.<buttonOk_Click>d__6 <buttonOk_Click>d__;
			<buttonOk_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonOk_Click>d__.<>4__this = this;
			<buttonOk_Click>d__.<>1__state = -1;
			<buttonOk_Click>d__.<>t__builder.Start<DomainUsersImportForm.<buttonOk_Click>d__6>(ref <buttonOk_Click>d__);
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x0001F3A8 File Offset: 0x0001D5A8
		private void comboBoxGroupNames_SelectedValueChanged(object sender, EventArgs e)
		{
			List<DomainUsersImportForm.DomainUserInfo> userList = new List<DomainUsersImportForm.DomainUserInfo>();
			if (this.comboBoxGroupNames.SelectedIndex == 0)
			{
				using (Dictionary<string, List<DomainUsersImportForm.DomainUserInfo>>.Enumerator enumerator = this._groupsAndUsers.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						KeyValuePair<string, List<DomainUsersImportForm.DomainUserInfo>> groupsAndUser = enumerator.Current;
						userList.AddRange(groupsAndUser.Value);
					}
					goto IL_95;
				}
			}
			string groupName = this.comboBoxGroupNames.Properties.Items[this.comboBoxGroupNames.SelectedIndex] as string;
			if (this._groupsAndUsers.ContainsKey(groupName))
			{
				userList.AddRange(this._groupsAndUsers[groupName]);
			}
			IL_95:
			this._userList.Clear();
			using (List<DomainUsersImportForm.DomainUserInfo>.Enumerator enumerator2 = userList.GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					DomainUsersImportForm.DomainUserInfo user = enumerator2.Current;
					if (!this._userList.Any((DomainUsersImportForm.DomainUserInfo x) => x.Login == user.Login))
					{
						this._userList.Add(user);
					}
				}
			}
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x0001F4D8 File Offset: 0x0001D6D8
		private Dictionary<string, List<DomainUsersImportForm.DomainUserInfo>> CreateGroupsAndUsers()
		{
			Dictionary<string, List<DomainUsersImportForm.DomainUserInfo>> result = new Dictionary<string, List<DomainUsersImportForm.DomainUserInfo>>();
			try
			{
				using (PrincipalContext context = new PrincipalContext(ContextType.Domain, this.textEditDomainName.Text))
				{
					using (PrincipalSearcher searcher = new PrincipalSearcher(new UserPrincipal(context)
					{
						Enabled = new bool?(true)
					}))
					{
						foreach (Principal user in searcher.FindAll())
						{
							try
							{
								DirectoryEntry de = user.GetUnderlyingObject() as DirectoryEntry;
								string name = string.Empty;
								string displayName = string.Empty;
								string login = string.Empty;
								if (de.Properties["givenName"].Value != null)
								{
									name = de.Properties["givenName"].Value.ToString();
								}
								if (de.Properties["sn"].Value != null)
								{
									if (!string.IsNullOrEmpty(name))
									{
										name += " ";
									}
									name += de.Properties["sn"].Value.ToString();
								}
								login = de.Properties["samAccountName"].Value.ToString();
								if (de.Properties["displayName"].Value != null)
								{
									displayName = de.Properties["displayName"].Value.ToString();
								}
								UserPrincipal userPrincipal = user as UserPrincipal;
								foreach (Principal p in ((userPrincipal != null) ? userPrincipal.GetGroups() : null))
								{
									List<DomainUsersImportForm.DomainUserInfo> userList;
									if (result.ContainsKey(p.Name))
									{
										userList = result[p.Name];
									}
									else
									{
										userList = new List<DomainUsersImportForm.DomainUserInfo>();
										result[p.Name] = userList;
									}
									userList.Add(new DomainUsersImportForm.DomainUserInfo(login, name, displayName));
								}
							}
							catch (Exception)
							{
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				this._formCreator.ShowErrorF(Resources.DomainUsersImportForm_ErrorReadingDomainData, new object[]
				{
					ex.Message
				});
			}
			return result;
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x0001F7A0 File Offset: 0x0001D9A0
		private Task CreateGroupsListAsTask()
		{
			return Task.Factory.StartNew(delegate()
			{
				this._groupsAndUsers = this.CreateGroupsAndUsers();
				List<string> groupsList = new List<string>();
				groupsList = this._groupsAndUsers.Keys.ToList<string>();
				groupsList.Sort();
				this.comboBoxGroupNames.InvokeIfRequired(delegate
				{
					this.comboBoxGroupNames.Properties.Items.Clear();
					this.comboBoxGroupNames.Properties.Items.AddRange(groupsList);
					this.comboBoxGroupNames.Properties.Items.Insert(0, Resources.DomainUsersImportForm_AllGroups);
					this.comboBoxGroupNames.SelectedIndex = 0;
				});
			});
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x0001F7B8 File Offset: 0x0001D9B8
		private string GetNetbiosDomainName(string dnsDomainName)
		{
			string netbiosDomainName = dnsDomainName;
			try
			{
				DirectoryEntry rootDse = new DirectoryEntry(string.Format("LDAP://{0}/RootDSE", dnsDomainName));
				string configurationNamingContext = rootDse.Properties["configurationNamingContext"][0].ToString();
				DirectorySearcher directorySearcher = new DirectorySearcher(new DirectoryEntry("LDAP://cn=Partitions," + configurationNamingContext));
				directorySearcher.SearchScope = SearchScope.OneLevel;
				directorySearcher.Filter = string.Format("(&(objectcategory=Crossref)(dnsRoot={0})(netBIOSName=*))", dnsDomainName);
				SearchResult result = directorySearcher.FindOne();
				if (result != null)
				{
					netbiosDomainName = result.Properties["netbiosname"][0].ToString();
				}
				rootDse.Dispose();
				if (directorySearcher != null)
				{
					directorySearcher.Dispose();
				}
			}
			catch (Exception ex)
			{
				this._formCreator.ShowErrorF(Resources.DomainUsersImportForm_ErrorReadingDomainData, new object[]
				{
					ex.Message
				});
				return string.Empty;
			}
			return netbiosDomainName;
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x0001F89C File Offset: 0x0001DA9C
		private Task ImportUsers()
		{
			DomainUsersImportForm.<ImportUsers>d__11 <ImportUsers>d__;
			<ImportUsers>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ImportUsers>d__.<>4__this = this;
			<ImportUsers>d__.<>1__state = -1;
			<ImportUsers>d__.<>t__builder.Start<DomainUsersImportForm.<ImportUsers>d__11>(ref <ImportUsers>d__);
			return <ImportUsers>d__.<>t__builder.Task;
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x0001F8E0 File Offset: 0x0001DAE0
		private void textEditDomainName_KeyUp(object sender, KeyEventArgs e)
		{
			DomainUsersImportForm.<textEditDomainName_KeyUp>d__12 <textEditDomainName_KeyUp>d__;
			<textEditDomainName_KeyUp>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<textEditDomainName_KeyUp>d__.<>4__this = this;
			<textEditDomainName_KeyUp>d__.e = e;
			<textEditDomainName_KeyUp>d__.<>1__state = -1;
			<textEditDomainName_KeyUp>d__.<>t__builder.Start<DomainUsersImportForm.<textEditDomainName_KeyUp>d__12>(ref <textEditDomainName_KeyUp>d__);
		}

		// Token: 0x040002A2 RID: 674
		private readonly ApiClient _apiClient;

		// Token: 0x040002A3 RID: 675
		private readonly List<Role> _rolesList;

		// Token: 0x040002A4 RID: 676
		private readonly BindingList<DomainUsersImportForm.DomainUserInfo> _userList;

		// Token: 0x040002A5 RID: 677
		private Dictionary<string, List<DomainUsersImportForm.DomainUserInfo>> _groupsAndUsers;

		// Token: 0x02000130 RID: 304
		private class DomainUserInfo
		{
			// Token: 0x06000ABD RID: 2749 RVA: 0x0005C936 File Offset: 0x0005AB36
			public DomainUserInfo(string login, string userName, string displayName)
			{
				this.Login = login;
				this.UserName = userName;
				this.DisplayName = displayName;
			}

			// Token: 0x170002E5 RID: 741
			// (get) Token: 0x06000ABE RID: 2750 RVA: 0x0005C953 File Offset: 0x0005AB53
			public string DisplayName { get; }

			// Token: 0x170002E6 RID: 742
			// (get) Token: 0x06000ABF RID: 2751 RVA: 0x0005C95B File Offset: 0x0005AB5B
			public string Login { get; }

			// Token: 0x170002E7 RID: 743
			// (get) Token: 0x06000AC0 RID: 2752 RVA: 0x0005C963 File Offset: 0x0005AB63
			public string UserName { get; }
		}
	}
}
