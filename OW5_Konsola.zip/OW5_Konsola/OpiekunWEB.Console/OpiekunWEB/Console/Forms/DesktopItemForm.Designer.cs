﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000060 RID: 96
	public partial class DesktopItemForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x0600051E RID: 1310 RVA: 0x0001BC44 File Offset: 0x00019E44
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x0001BC64 File Offset: 0x00019E64
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DesktopItemForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.textEditParams = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditName = new global::DevExpress.XtraEditors.TextEdit();
			this.comboBoxMacro = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.textEditFilePath = new global::DevExpress.XtraEditors.ButtonEdit();
			this.imageComboBoxIcon = new global::DevExpress.XtraEditors.ImageComboBoxEdit();
			this.imageCollectionIcon = new global::DevExpress.Utils.ImageCollection(this.components);
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControMacro = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlFilePath = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlParams = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlIcon = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditParams.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxMacro.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditFilePath.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxIcon.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionIcon).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControMacro).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlFilePath).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlParams).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIcon).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.layoutControlMain.Controls.Add(this.textEditParams);
			this.layoutControlMain.Controls.Add(this.textEditName);
			this.layoutControlMain.Controls.Add(this.comboBoxMacro);
			this.layoutControlMain.Controls.Add(this.textEditFilePath);
			this.layoutControlMain.Controls.Add(this.imageComboBoxIcon);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2948, 297, 812, 500));
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.textEditParams, "textEditParams");
			this.textEditParams.Name = "textEditParams";
			this.textEditParams.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditName, "textEditName");
			this.textEditName.Name = "textEditName";
			this.textEditName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditName.Properties.Mask.BeepOnError");
			this.textEditName.Properties.Mask.EditMask = resources.GetString("textEditName.Properties.Mask.EditMask");
			this.textEditName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditName.Properties.Mask.IgnoreMaskBlank");
			this.textEditName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditName.Properties.Mask.MaskType");
			this.textEditName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditName.Properties.Mask.ShowPlaceHolders");
			this.textEditName.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxMacro, "comboBoxMacro");
			this.comboBoxMacro.Name = "comboBoxMacro";
			this.comboBoxMacro.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxMacro.Properties.Buttons"))
			});
			this.comboBoxMacro.Properties.DropDownRows = 9;
			this.comboBoxMacro.Properties.NullValuePrompt = resources.GetString("comboBoxMacro.Properties.NullValuePrompt");
			this.comboBoxMacro.Properties.ShowToolTipForTrimmedText = global::DevExpress.Utils.DefaultBoolean.False;
			this.comboBoxMacro.Properties.Sorted = true;
			this.comboBoxMacro.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxMacro.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditFilePath, "textEditFilePath");
			this.textEditFilePath.Name = "textEditFilePath";
			this.textEditFilePath.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.textEditFilePath.Properties.Mask.EditMask = resources.GetString("textEditFilePath.Properties.Mask.EditMask");
			this.textEditFilePath.Properties.NullValuePrompt = resources.GetString("textEditFilePath.Properties.NullValuePrompt");
			this.textEditFilePath.StyleController = this.layoutControlMain;
			this.textEditFilePath.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.textEditFilePath_ButtonClick);
			resources.ApplyResources(this.imageComboBoxIcon, "imageComboBoxIcon");
			this.imageComboBoxIcon.Name = "imageComboBoxIcon";
			this.imageComboBoxIcon.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxIcon.Properties.Buttons")),
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.imageComboBoxIcon.Properties.DropDownRows = 1;
			this.imageComboBoxIcon.Properties.GlyphAlignment = (global::DevExpress.Utils.HorzAlignment)resources.GetObject("imageComboBoxIcon.Properties.GlyphAlignment");
			this.imageComboBoxIcon.Properties.ShowDropDown = global::DevExpress.XtraEditors.Controls.ShowDropDown.Never;
			this.imageComboBoxIcon.Properties.SmallImages = this.imageCollectionIcon;
			this.imageComboBoxIcon.StyleController = this.layoutControlMain;
			this.imageComboBoxIcon.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.imageComboBoxIconNo_ButtonClick);
			resources.ApplyResources(this.imageCollectionIcon, "imageCollectionIcon");
			this.imageCollectionIcon.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imageCollectionIcon.ImageStream");
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlName,
				this.layoutControMacro,
				this.layoutControlFilePath,
				this.layoutControlParams,
				this.layoutControlIcon,
				this.emptySpaceItem1
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(507, 232);
			this.Root.TextVisible = false;
			this.layoutControlName.Control = this.textEditName;
			this.layoutControlName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlName.Name = "layoutControlName";
			this.layoutControlName.Size = new global::System.Drawing.Size(487, 45);
			resources.ApplyResources(this.layoutControlName, "layoutControlName");
			this.layoutControlName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlName.TextSize = new global::System.Drawing.Size(58, 16);
			this.layoutControMacro.Control = this.comboBoxMacro;
			resources.ApplyResources(this.layoutControMacro, "layoutControMacro");
			this.layoutControMacro.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControMacro.MinSize = new global::System.Drawing.Size(112, 46);
			this.layoutControMacro.Name = "layoutControMacro";
			this.layoutControMacro.Size = new global::System.Drawing.Size(182, 46);
			this.layoutControMacro.SizeConstraintsType = global::DevExpress.XtraLayout.SizeConstraintsType.Custom;
			this.layoutControMacro.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControMacro.TextSize = new global::System.Drawing.Size(58, 16);
			this.layoutControlFilePath.Control = this.textEditFilePath;
			resources.ApplyResources(this.layoutControlFilePath, "layoutControlFilePath");
			this.layoutControlFilePath.Location = new global::System.Drawing.Point(182, 45);
			this.layoutControlFilePath.Name = "layoutControlFilePath";
			this.layoutControlFilePath.Size = new global::System.Drawing.Size(305, 46);
			this.layoutControlFilePath.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlFilePath.TextSize = new global::System.Drawing.Size(58, 16);
			this.layoutControlParams.Control = this.textEditParams;
			this.layoutControlParams.Location = new global::System.Drawing.Point(0, 91);
			this.layoutControlParams.Name = "layoutControlParams";
			this.layoutControlParams.Size = new global::System.Drawing.Size(487, 45);
			resources.ApplyResources(this.layoutControlParams, "layoutControlParams");
			this.layoutControlParams.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlParams.TextSize = new global::System.Drawing.Size(58, 16);
			this.layoutControlIcon.Control = this.imageComboBoxIcon;
			resources.ApplyResources(this.layoutControlIcon, "layoutControlIcon");
			this.layoutControlIcon.Location = new global::System.Drawing.Point(0, 136);
			this.layoutControlIcon.MaxSize = new global::System.Drawing.Size(0, 45);
			this.layoutControlIcon.MinSize = new global::System.Drawing.Size(66, 45);
			this.layoutControlIcon.Name = "layoutControlIcon";
			this.layoutControlIcon.Size = new global::System.Drawing.Size(98, 76);
			this.layoutControlIcon.SizeConstraintsType = global::DevExpress.XtraLayout.SizeConstraintsType.Custom;
			this.layoutControlIcon.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlIcon.TextSize = new global::System.Drawing.Size(58, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(98, 136);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(389, 76);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("DesktopItemForm.IconOptions.Icon");
			base.Name = "DesktopItemForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditParams.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxMacro.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditFilePath.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxIcon.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionIcon).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControMacro).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlFilePath).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlParams).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIcon).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x0400025A RID: 602
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400025B RID: 603
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x0400025C RID: 604
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x0400025D RID: 605
		private global::DevExpress.XtraEditors.TextEdit textEditName;

		// Token: 0x0400025E RID: 606
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlName;

		// Token: 0x0400025F RID: 607
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxMacro;

		// Token: 0x04000260 RID: 608
		private global::DevExpress.XtraEditors.ButtonEdit textEditFilePath;

		// Token: 0x04000261 RID: 609
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControMacro;

		// Token: 0x04000262 RID: 610
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlFilePath;

		// Token: 0x04000263 RID: 611
		private global::DevExpress.XtraEditors.TextEdit textEditParams;

		// Token: 0x04000264 RID: 612
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlParams;

		// Token: 0x04000265 RID: 613
		private global::DevExpress.XtraEditors.ImageComboBoxEdit imageComboBoxIcon;

		// Token: 0x04000266 RID: 614
		private global::DevExpress.Utils.ImageCollection imageCollectionIcon;

		// Token: 0x04000267 RID: 615
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlIcon;

		// Token: 0x04000268 RID: 616
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
	}
}
