﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils.MVVM;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraSplashScreen;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000067 RID: 103
	public partial class FileManagerForm : NonModalBaseForm
	{
		// Token: 0x0600055E RID: 1374 RVA: 0x00021428 File Offset: 0x0001F628
		public FileManagerForm(FormsSettings formsSettings, FormCreator formCreator, AgentClient agentClient) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			this.labelLocalDevice.Text = Environment.MachineName + " " + this.labelLocalDevice.Text;
			Control control = this.labelRemoteDevice;
			string[] array = new string[5];
			array[0] = ((agentClient != null) ? agentClient.DeviceName : null);
			array[1] = " (";
			int num = 2;
			string text;
			if (agentClient == null)
			{
				text = null;
			}
			else
			{
				WindowsUserInfo windowsUser = agentClient.WindowsUser;
				text = ((windowsUser != null) ? windowsUser.UserName : null);
			}
			array[num] = text;
			array[3] = ") ";
			array[4] = this.labelRemoteDevice.Text;
			control.Text = string.Concat(array);
			this._objectsToSaveState.Add(this);
			this._objectsToSaveState.Add(this.splitContainerGrids);
			this._viewModel = this.mvvmContext.GetViewModel<FileManagerViewModel>();
			this._viewModel.AgentClient = agentClient;
			this._viewModel.AfterLocalDirChanged += this.OnAfterLocalDirChanged;
			this._viewModel.AfterLogChanged += this.OnAfterLogChanged;
			this._viewModel.AfterRemoteDirChanged += this.OnAfterRemoteDirChanged;
			this._viewModel.AfterTask += this.OnAfterTask;
			this._viewModel.BeforeTask += this.OnBeforeTask;
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x00021574 File Offset: 0x0001F774
		protected override void AfterRestoreState()
		{
			FileManagerForm.<AfterRestoreState>d__8 <AfterRestoreState>d__;
			<AfterRestoreState>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AfterRestoreState>d__.<>4__this = this;
			<AfterRestoreState>d__.<>1__state = -1;
			<AfterRestoreState>d__.<>t__builder.Start<FileManagerForm.<AfterRestoreState>d__8>(ref <AfterRestoreState>d__);
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x000215AC File Offset: 0x0001F7AC
		private void buttonLocalDeviceCreateDir_Click(object sender, EventArgs e)
		{
			string dir = this.CreateDirNameQuestion();
			if (!string.IsNullOrEmpty(dir))
			{
				this._viewModel.CreateLocalDir(dir);
			}
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x000215D4 File Offset: 0x0001F7D4
		private void buttonLocalDeviceDeleteDir_Click(object sender, EventArgs e)
		{
			if (!this.IsLocalDirOrFileSelected())
			{
				this._formCreator.ShowInfo(Resources.FileManagerForm_MustSelectFileOrFolder);
				return;
			}
			if (this.DeleteFilesQuestion(this.gridViewLocalFiles))
			{
				this._viewModel.DeleteLocalFiles(this.GetSelectedFileNamesFromGridView(this.gridViewLocalFiles));
			}
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x00021614 File Offset: 0x0001F814
		private void buttonLocalDeviceDirUp_Click(object sender, EventArgs e)
		{
			this._viewModel.ChangeLocalDirToParent();
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x00021621 File Offset: 0x0001F821
		private void buttonLocalDeviceRefresh_Click(object sender, EventArgs e)
		{
			this._viewModel.RefreshLocalDir();
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x0002162E File Offset: 0x0001F82E
		private void buttonReadFromRemote_Click(object sender, EventArgs e)
		{
			this.ShowFilesTransferForm(true);
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x00021638 File Offset: 0x0001F838
		private void buttonRemoteDeviceCreateDir_Click(object sender, EventArgs e)
		{
			FileManagerForm.<buttonRemoteDeviceCreateDir_Click>d__14 <buttonRemoteDeviceCreateDir_Click>d__;
			<buttonRemoteDeviceCreateDir_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonRemoteDeviceCreateDir_Click>d__.<>4__this = this;
			<buttonRemoteDeviceCreateDir_Click>d__.<>1__state = -1;
			<buttonRemoteDeviceCreateDir_Click>d__.<>t__builder.Start<FileManagerForm.<buttonRemoteDeviceCreateDir_Click>d__14>(ref <buttonRemoteDeviceCreateDir_Click>d__);
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x00021670 File Offset: 0x0001F870
		private void buttonRemoteDeviceDeleteDir_Click(object sender, EventArgs e)
		{
			FileManagerForm.<buttonRemoteDeviceDeleteDir_Click>d__15 <buttonRemoteDeviceDeleteDir_Click>d__;
			<buttonRemoteDeviceDeleteDir_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonRemoteDeviceDeleteDir_Click>d__.<>4__this = this;
			<buttonRemoteDeviceDeleteDir_Click>d__.<>1__state = -1;
			<buttonRemoteDeviceDeleteDir_Click>d__.<>t__builder.Start<FileManagerForm.<buttonRemoteDeviceDeleteDir_Click>d__15>(ref <buttonRemoteDeviceDeleteDir_Click>d__);
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x000216A8 File Offset: 0x0001F8A8
		private void buttonRemoteDeviceDirUp_Click(object sender, EventArgs e)
		{
			FileManagerForm.<buttonRemoteDeviceDirUp_Click>d__16 <buttonRemoteDeviceDirUp_Click>d__;
			<buttonRemoteDeviceDirUp_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonRemoteDeviceDirUp_Click>d__.<>4__this = this;
			<buttonRemoteDeviceDirUp_Click>d__.<>1__state = -1;
			<buttonRemoteDeviceDirUp_Click>d__.<>t__builder.Start<FileManagerForm.<buttonRemoteDeviceDirUp_Click>d__16>(ref <buttonRemoteDeviceDirUp_Click>d__);
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x000216E0 File Offset: 0x0001F8E0
		private void buttonRemoteDeviceRefresh_Click(object sender, EventArgs e)
		{
			FileManagerForm.<buttonRemoteDeviceRefresh_Click>d__17 <buttonRemoteDeviceRefresh_Click>d__;
			<buttonRemoteDeviceRefresh_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonRemoteDeviceRefresh_Click>d__.<>4__this = this;
			<buttonRemoteDeviceRefresh_Click>d__.<>1__state = -1;
			<buttonRemoteDeviceRefresh_Click>d__.<>t__builder.Start<FileManagerForm.<buttonRemoteDeviceRefresh_Click>d__17>(ref <buttonRemoteDeviceRefresh_Click>d__);
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x00021717 File Offset: 0x0001F917
		private void buttonSendToRemote_Click(object sender, EventArgs e)
		{
			this.ShowFilesTransferForm(false);
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x00021720 File Offset: 0x0001F920
		private void comboBoxLocalDeviceDir_CloseUp(object sender, CloseUpEventArgs e)
		{
			this._viewModel.LocalDir = (string)e.Value;
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x00021738 File Offset: 0x0001F938
		private void comboBoxLocalDeviceDir_Validating(object sender, CancelEventArgs e)
		{
			this._viewModel.ChangeLocalDir(this.comboBoxLocalDeviceDir.Text);
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x00021750 File Offset: 0x0001F950
		private void comboBoxRemoteDeviceDir_CloseUp(object sender, CloseUpEventArgs e)
		{
			FileManagerForm.<comboBoxRemoteDeviceDir_CloseUp>d__21 <comboBoxRemoteDeviceDir_CloseUp>d__;
			<comboBoxRemoteDeviceDir_CloseUp>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<comboBoxRemoteDeviceDir_CloseUp>d__.<>4__this = this;
			<comboBoxRemoteDeviceDir_CloseUp>d__.<>1__state = -1;
			<comboBoxRemoteDeviceDir_CloseUp>d__.<>t__builder.Start<FileManagerForm.<comboBoxRemoteDeviceDir_CloseUp>d__21>(ref <comboBoxRemoteDeviceDir_CloseUp>d__);
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x00021788 File Offset: 0x0001F988
		private void comboBoxRemoteDeviceDir_Validating(object sender, CancelEventArgs e)
		{
			FileManagerForm.<comboBoxRemoteDeviceDir_Validating>d__22 <comboBoxRemoteDeviceDir_Validating>d__;
			<comboBoxRemoteDeviceDir_Validating>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<comboBoxRemoteDeviceDir_Validating>d__.<>4__this = this;
			<comboBoxRemoteDeviceDir_Validating>d__.<>1__state = -1;
			<comboBoxRemoteDeviceDir_Validating>d__.<>t__builder.Start<FileManagerForm.<comboBoxRemoteDeviceDir_Validating>d__22>(ref <comboBoxRemoteDeviceDir_Validating>d__);
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x000217C0 File Offset: 0x0001F9C0
		private string CreateDirNameQuestion()
		{
			TextValueEditFormParams @params = new TextValueEditFormParams(Resources.FileManagerForm_CreateFolder, Resources.FileManagerForm_FolderName, string.Empty);
			if (this._formCreator.Show<TextValueEditForm, TextValueEditFormParams>(FormAction.Create, @params, out @params))
			{
				return @params.Value;
			}
			return null;
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x000217FC File Offset: 0x0001F9FC
		private bool DeleteFilesQuestion(GridView gridView)
		{
			List<string> files = this.GetSelectedFileNamesFromGridView(gridView);
			if (files.Count == 1)
			{
				return this._formCreator.ShowYesNoQuestionF(Resources.FileManagerForm_DoYouWantToDeleteFile, new object[]
				{
					this._viewModel.DirWithMacroToDirDescription(files[0])
				});
			}
			return this._formCreator.ShowYesNoQuestion(Resources.FileManagerForm_DoYouWantToDeleteSelectedFiles);
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x00021858 File Offset: 0x0001FA58
		private FileManagerForm.GridItemClickedInfo GetClickedGridItemInfo(GridControl grid, GridView gridView, string currentPath)
		{
			Owpb.FileInfo item = this.GetElementClickedInGrid(grid, gridView);
			if (item == null)
			{
				return null;
			}
			FileManagerForm.GridItemClickedInfo result = new FileManagerForm.GridItemClickedInfo
			{
				FileInfo = item,
				ItemType = FileManagerForm.GridItemType.Directory
			};
			if (item.Name == "..")
			{
				result.NewDirectory = Path.GetDirectoryName(currentPath);
			}
			else if (currentPath == null)
			{
				result.NewDirectory = item.Name;
			}
			else if (this.IsDirectoryAttrib(item))
			{
				result.NewDirectory = Path.Combine(currentPath, item.Name);
			}
			else
			{
				result.ItemType = FileManagerForm.GridItemType.File;
			}
			return result;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x000218E0 File Offset: 0x0001FAE0
		private Owpb.FileInfo GetElementClickedInGrid(GridControl grid, GridView gridView)
		{
			Point pt = grid.PointToClient(Control.MousePosition);
			if (gridView.CalcHitInfo(pt).InRow)
			{
				return gridView.GetFocusedRow() as Owpb.FileInfo;
			}
			return null;
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x00021914 File Offset: 0x0001FB14
		private List<string> GetSelectedFileNamesFromGridView(GridView gridView)
		{
			List<string> result = new List<string>();
			foreach (int selectedRow in gridView.GetSelectedRows())
			{
				Owpb.FileInfo fileInfo = gridView.GetRow(selectedRow) as Owpb.FileInfo;
				if (fileInfo != null && !this.IsParentDirName(fileInfo.Name))
				{
					string gridDir = (gridView == this.gridViewLocalFiles) ? this._viewModel.LocalDirResolved : this._viewModel.RemoteDirResolved;
					if (this.IsDirectoryAttrib(fileInfo))
					{
						result.Add(Path.Combine(gridDir, fileInfo.Name + "\\*"));
					}
					else
					{
						result.Add(Path.Combine(gridDir, fileInfo.Name));
					}
				}
			}
			return result;
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x000219CC File Offset: 0x0001FBCC
		private void gridLocalFiles_DoubleClick(object sender, EventArgs e)
		{
			FileManagerForm.GridItemClickedInfo itemInfo = this.GetClickedGridItemInfo(this.gridLocalFiles, this.gridViewLocalFiles, this._viewModel.LocalDir);
			FileManagerForm.GridItemType? gridItemType = (itemInfo != null) ? new FileManagerForm.GridItemType?(itemInfo.ItemType) : null;
			if (gridItemType != null)
			{
				FileManagerForm.GridItemType valueOrDefault = gridItemType.GetValueOrDefault();
				if (valueOrDefault == FileManagerForm.GridItemType.Directory)
				{
					this._viewModel.LocalDir = itemInfo.NewDirectory;
					return;
				}
				if (valueOrDefault != FileManagerForm.GridItemType.File)
				{
					return;
				}
				this.buttonSendToRemote.PerformClick();
			}
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x00021A48 File Offset: 0x0001FC48
		private void gridRemoteFiles_DoubleClick(object sender, EventArgs e)
		{
			FileManagerForm.<gridRemoteFiles_DoubleClick>d__29 <gridRemoteFiles_DoubleClick>d__;
			<gridRemoteFiles_DoubleClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<gridRemoteFiles_DoubleClick>d__.<>4__this = this;
			<gridRemoteFiles_DoubleClick>d__.<>1__state = -1;
			<gridRemoteFiles_DoubleClick>d__.<>t__builder.Start<FileManagerForm.<gridRemoteFiles_DoubleClick>d__29>(ref <gridRemoteFiles_DoubleClick>d__);
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x00021A80 File Offset: 0x0001FC80
		private void gridView_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			if (e.Column != this.gridColumnRemoteSize && e.Column != this.gridColumnLocalSize)
			{
				if (e.Column == this.gridColumnRemoteDate || e.Column == this.gridColumnLocalDate)
				{
					long i = Convert.ToInt64(e.Value);
					e.DisplayText = ((i == 0L) ? string.Empty : DateTimeOffset.FromUnixTimeSeconds(i).DateTime.ToLocalTime().ToString("yyyy.MM.dd HH:mm:ss"));
				}
				return;
			}
			GridView gridView = sender as GridView;
			object attributesField = (gridView != null) ? gridView.GetListSourceRowCellValue(e.ListSourceRowIndex, "Attributes") : null;
			if (attributesField == null)
			{
				return;
			}
			long fileSize = Convert.ToInt64(e.Value);
			uint attrib = ((uint?)attributesField).Value;
			if (this.IsDirectoryAttrib(attrib))
			{
				e.DisplayText = Resources.FileManagerForm_DriveTypeDirectory;
				return;
			}
			if (this.IsDriveAttrib(attrib))
			{
				long num = fileSize - 2L;
				if (num <= 4L)
				{
					switch ((uint)num)
					{
					case 0U:
						e.DisplayText = Resources.FileManagerForm_DriveTypeRemovable;
						return;
					case 1U:
						e.DisplayText = Resources.FileManagerForm_DriveTypeFixed;
						return;
					case 2U:
						e.DisplayText = Resources.FileManagerForm_DriveTypeRemote;
						return;
					case 3U:
						e.DisplayText = Resources.FileManagerForm_DriveTypeCDROM;
						return;
					case 4U:
						e.DisplayText = Resources.FileManagerForm_DriveTypeRamdisk;
						return;
					}
				}
				e.DisplayText = Resources.FileManagerForm_DriveTypeUnknown;
				return;
			}
			e.DisplayText = LangStringUtils.StringRepresentingFileSize(fileSize);
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x00021BE8 File Offset: 0x0001FDE8
		private void gridView_CustomColumnSort(object sender, CustomColumnSortEventArgs e)
		{
			GridView gridView = sender as GridView;
			string fileName = gridView.GetListSourceRowCellValue(e.ListSourceRowIndex1, "Name") as string;
			string fileName2 = gridView.GetListSourceRowCellValue(e.ListSourceRowIndex2, "Name") as string;
			e.Handled = true;
			if (this.IsParentDirName(fileName) && this.IsParentDirName(fileName2))
			{
				e.Result = 0;
				return;
			}
			if (this.IsParentDirName(fileName))
			{
				e.Result = ((e.SortOrder == ColumnSortOrder.Ascending) ? -1 : 1);
				return;
			}
			if (this.IsParentDirName(fileName2))
			{
				e.Result = ((e.SortOrder == ColumnSortOrder.Ascending) ? 1 : -1);
				return;
			}
			if (e.Column.FieldName == "Name")
			{
				int drivesName = 0;
				if (this.IsDriveName(fileName))
				{
					drivesName++;
				}
				if (this.IsDriveName(fileName2))
				{
					drivesName++;
				}
				if (drivesName == 1)
				{
					e.Result = 1;
					return;
				}
				e.Result = string.Compare(fileName, fileName2, true);
				return;
			}
			else
			{
				if (!(e.Column.FieldName == "FileSize"))
				{
					if (e.Column.FieldName == "LastWriteTime")
					{
						e.Result = Comparer.Default.Compare(e.Value1, e.Value2);
					}
					return;
				}
				uint? attr = gridView.GetListSourceRowCellValue(e.ListSourceRowIndex1, "Attributes") as uint?;
				uint? attr2 = gridView.GetListSourceRowCellValue(e.ListSourceRowIndex2, "Attributes") as uint?;
				if (this.IsDirectoryAttrib(attr.Value) && this.IsDirectoryAttrib(attr2.Value))
				{
					e.Result = string.Compare(fileName, fileName2, true);
					return;
				}
				if (this.IsDirectoryAttrib(attr.Value))
				{
					e.Result = ((e.SortOrder == ColumnSortOrder.Ascending) ? -1 : 1);
					return;
				}
				if (this.IsDirectoryAttrib(attr2.Value))
				{
					e.Result = ((e.SortOrder == ColumnSortOrder.Ascending) ? 1 : -1);
					return;
				}
				ulong size = (ulong)e.Value1;
				ulong size2 = (ulong)e.Value2;
				e.Result = size.CompareTo(size2);
				return;
			}
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x00021DF7 File Offset: 0x0001FFF7
		private bool IsDirectoryAttrib(uint attrib)
		{
			return (attrib & 16U) == 16U;
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x00021E01 File Offset: 0x00020001
		private bool IsDirectoryAttrib(Owpb.FileInfo fileInfo)
		{
			return this.IsDirectoryAttrib(fileInfo.Attributes);
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x00021E0F File Offset: 0x0002000F
		private bool IsDriveAttrib(uint attrib)
		{
			return (attrib & 32768U) == 32768U;
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x00021E1F File Offset: 0x0002001F
		private bool IsDriveName(string fileName)
		{
			return fileName.Length == 3 && fileName[1] == ':' && fileName[2] == '\\';
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x00021E42 File Offset: 0x00020042
		private bool IsLocalDirOrFileSelected()
		{
			return !string.IsNullOrEmpty(this._viewModel.LocalDir) && this.gridViewLocalFiles.SelectedRowsCount != 0 && !this.IsSelectedOnlyParentFolder(this.gridViewLocalFiles);
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00021E74 File Offset: 0x00020074
		private bool IsParentDirName(string dir)
		{
			return dir == "..";
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x00021E81 File Offset: 0x00020081
		private bool IsRemoteDirOrFileSelected()
		{
			return !string.IsNullOrEmpty(this._viewModel.RemoteDir) && this.gridViewRemoteFiles.SelectedRowsCount != 0 && !this.IsSelectedOnlyParentFolder(this.gridViewRemoteFiles);
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x00021EB4 File Offset: 0x000200B4
		private bool IsSelectedOnlyParentFolder(GridView gridView)
		{
			if (gridView.SelectedRowsCount == 1)
			{
				int[] selectedRows = gridView.GetSelectedRows();
				return (gridView.GetRow(selectedRows[0]) as Owpb.FileInfo).Name == "..";
			}
			return false;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00021EF0 File Offset: 0x000200F0
		private void OnAfterLocalDirChanged(object sender, string dir)
		{
			this.comboBoxLocalDeviceDir.Text = dir;
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x00021EFE File Offset: 0x000200FE
		private void OnAfterLogChanged(object sender, EventArgs eventArgs)
		{
			this.listBoxTransferLog.MakeItemVisible(this.listBoxTransferLog.ItemCount - 1);
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x00021F18 File Offset: 0x00020118
		private void OnAfterRemoteDirChanged(object sender, string dir)
		{
			this.comboBoxRemoteDeviceDir.Text = dir;
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x00021F26 File Offset: 0x00020126
		private void OnAfterTask(object sender, EventArgs eventArgs)
		{
			SplashScreenManager.CloseOverlayForm(this._splashHandle);
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x00021F33 File Offset: 0x00020133
		private void OnBeforeTask(object sender, EventArgs eventArgs)
		{
			this._splashHandle = SplashScreenManager.ShowOverlayForm(this);
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x00021F44 File Offset: 0x00020144
		private void ShowFilesTransferForm(bool readFromRemote)
		{
			FileManagerForm.<ShowFilesTransferForm>d__45 <ShowFilesTransferForm>d__;
			<ShowFilesTransferForm>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ShowFilesTransferForm>d__.<>4__this = this;
			<ShowFilesTransferForm>d__.readFromRemote = readFromRemote;
			<ShowFilesTransferForm>d__.<>1__state = -1;
			<ShowFilesTransferForm>d__.<>t__builder.Start<FileManagerForm.<ShowFilesTransferForm>d__45>(ref <ShowFilesTransferForm>d__);
		}

		// Token: 0x040002C3 RID: 707
		private const string FIELD_FILE_ATTRIBUTES = "Attributes";

		// Token: 0x040002C4 RID: 708
		private const string FIELD_FILE_LAST_WRITE_TIME = "LastWriteTime";

		// Token: 0x040002C5 RID: 709
		private const string FIELD_FILE_NAME = "Name";

		// Token: 0x040002C6 RID: 710
		private const string FIELD_FILE_SIZE = "FileSize";

		// Token: 0x040002C7 RID: 711
		private readonly FileManagerViewModel _viewModel;

		// Token: 0x040002C8 RID: 712
		private IOverlaySplashScreenHandle _splashHandle;

		// Token: 0x0200013C RID: 316
		private enum GridItemType
		{
			// Token: 0x04000930 RID: 2352
			Directory,
			// Token: 0x04000931 RID: 2353
			File
		}

		// Token: 0x0200013D RID: 317
		private class GridItemClickedInfo
		{
			// Token: 0x170002E8 RID: 744
			// (get) Token: 0x06000AD9 RID: 2777 RVA: 0x0005D356 File Offset: 0x0005B556
			// (set) Token: 0x06000ADA RID: 2778 RVA: 0x0005D35E File Offset: 0x0005B55E
			public Owpb.FileInfo FileInfo { get; set; }

			// Token: 0x170002E9 RID: 745
			// (get) Token: 0x06000ADB RID: 2779 RVA: 0x0005D367 File Offset: 0x0005B567
			// (set) Token: 0x06000ADC RID: 2780 RVA: 0x0005D36F File Offset: 0x0005B56F
			public FileManagerForm.GridItemType ItemType { get; set; }

			// Token: 0x170002EA RID: 746
			// (get) Token: 0x06000ADD RID: 2781 RVA: 0x0005D378 File Offset: 0x0005B578
			// (set) Token: 0x06000ADE RID: 2782 RVA: 0x0005D380 File Offset: 0x0005B580
			public string NewDirectory { get; set; }
		}
	}
}
