﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Card;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using DevExpress.XtraTab;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006B RID: 107
	public partial class DistributeFilesForm : NonModalBaseForm
	{
		// Token: 0x060005A2 RID: 1442 RVA: 0x000243EC File Offset: 0x000225EC
		public DistributeFilesForm(FormsSettings formsSettings, FormCreator formCreator, DistributeFilesFormParams @params) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			this._targetList = new List<DeviceTreeItemBase>();
			this._targetList.AddRange(@params.AgentItems);
			this._fileList = new List<string>();
			this._devicesTransferFilesInfo = new BindingList<DistributeFilesForm.DeviceTransferInfo>();
			this._cts = new CancellationTokenSource();
			this._macroList = Macros.GetDirMacrosAsStringKeyValueList(true);
			this._params = @params;
			if (this._params.Direction == AgentFileTransferDirection.Receive)
			{
				this.layoutControlGroupReceiveSettings.Visibility = LayoutVisibility.Always;
				this.buttonTransfer.ImageOptions.Image = Resources.doubleprev_32x32;
				this.Text = Resources.DistributeFilesForm_CollectingFilesTitle;
				this.layoutControlGroupFilesTransfer.Text = Resources.DistributeFilesForm_GroupFilesToTrasferText;
				this.buttonTransfer.Text = Resources.DistributeFilesForm_CollectButtonText;
			}
			else
			{
				this.layoutControlGroupSendSettings.Visibility = LayoutVisibility.Always;
			}
			this.gridFileList.DataSource = this._fileList;
			this.gridDevices.DataSource = this._targetList;
			this.comboBoxSendFileOverride.SelectedIndex = 0;
			this.comboBoxReceiveFileOverride.SelectedIndex = 0;
			this.comboBoxSendDestinationDirMacro.Properties.Items.AddRange(this._macroList);
			foreach (object item in Enum.GetValues(typeof(DistributeFilesForm.ReceiveFilesLocalPathType)))
			{
				this.comboBoxReceiveFilesLocalPathType.Properties.Items.Add(item);
			}
			this.comboBoxReceiveFilesLocalPathType.EditValue = DistributeFilesForm.ReceiveFilesLocalPathType.OneDirectoryForAll;
			this.xtraTabControl.ShowTabHeader = DefaultBoolean.False;
			this.xtraTabControl.SelectedTabPageIndex = 0;
			this._objectsToSaveState.Add(this.comboBoxSendDestinationDirMacro);
			this._objectsToSaveState.Add(this.comboBoxSendFileOverride);
			this._objectsToSaveState.Add(this.textEditSendDestinationPath);
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x000245D0 File Offset: 0x000227D0
		protected override void Finalize()
		{
			try
			{
				CancellationTokenSource cts = this._cts;
				if (cts != null)
				{
					cts.Dispose();
				}
			}
			finally
			{
				base.Finalize();
			}
		}

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x060005A4 RID: 1444 RVA: 0x00024608 File Offset: 0x00022808
		// (set) Token: 0x060005A5 RID: 1445 RVA: 0x00024610 File Offset: 0x00022810
		public object AgentClient { get; private set; }

		// Token: 0x060005A6 RID: 1446 RVA: 0x0002461C File Offset: 0x0002281C
		private void buttonAddFile_Click(object sender, EventArgs e)
		{
			if (this.IsSendDirection())
			{
				using (XtraOpenFileDialog dlg = new XtraOpenFileDialog())
				{
					dlg.Multiselect = true;
					if (dlg.ShowDialog() == DialogResult.OK)
					{
						this._fileList.AddRange(dlg.FileNames);
					}
					goto IL_6D;
				}
			}
			SelectRemoteFileFormParams @params = new SelectRemoteFileFormParams
			{
				SelectionMode = FileOrFolder.File
			};
			if (this._formCreator.Show<SelectRemoteFileForm, SelectRemoteFileFormParams>(@params))
			{
				this._fileList.Add(@params.FileName);
			}
			this.CheckIsUserDependDirForFilesToReceive();
			IL_6D:
			this.gridViewFileList.RefreshData();
			this.SetTransferButtonState();
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x000246B8 File Offset: 0x000228B8
		private void buttonAddFolder_Click(object sender, EventArgs e)
		{
			if (this.IsSendDirection())
			{
				using (XtraFolderBrowserDialog dlg = new XtraFolderBrowserDialog())
				{
					if (dlg.ShowDialog() == DialogResult.OK)
					{
						this._fileList.Add(Path.Combine(dlg.SelectedPath, "*"));
					}
					goto IL_70;
				}
			}
			SelectRemoteFileFormParams @params = new SelectRemoteFileFormParams
			{
				SelectionMode = FileOrFolder.Folder
			};
			if (this._formCreator.Show<SelectRemoteFileForm, SelectRemoteFileFormParams>(@params))
			{
				this._fileList.Add(@params.FileName);
			}
			this.CheckIsUserDependDirForFilesToReceive();
			IL_70:
			this.gridViewFileList.RefreshData();
			this.SetTransferButtonState();
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x00024758 File Offset: 0x00022958
		private void buttonCancel_Click(object sender, EventArgs e)
		{
			if (this._transferInProgress)
			{
				if (this._formCreator.ShowYesNoQuestion(Resources.DistributeFilesForm_CancelTransfer))
				{
					this._canceled = true;
					this._cts.Cancel(true);
					return;
				}
			}
			else
			{
				base.Close();
			}
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x00024790 File Offset: 0x00022990
		private void buttonRemoveFile_Click(object sender, EventArgs e)
		{
			string item = this.gridViewFileList.GetFocusedRow() as string;
			if (item != null)
			{
				this._fileList.Remove(item);
				this.gridViewFileList.RefreshData();
				this.SetTransferButtonState();
			}
			if (!this.IsSendDirection())
			{
				this.CheckIsUserDependDirForFilesToReceive();
			}
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x000247E0 File Offset: 0x000229E0
		private void buttonTransfer_Click(object sender, EventArgs e)
		{
			if (this.IsSendDirection())
			{
				if (!this.ValidateSendDestinationPath())
				{
					this.textEditSendDestinationPath.Focus();
					this.textEditSendDestinationPath.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
					return;
				}
			}
			else if (!this.ValidateReceiveDestinationPath())
			{
				this.textEditReceiveDestinationPath.Focus();
				this.textEditReceiveDestinationPath.ErrorText = Localizer.Active.GetLocalizedString(StringId.InvalidValueText);
				return;
			}
			this.xtraTabControl.SelectedTabPageIndex = 1;
			this.gridSendProgress.DataSource = this._devicesTransferFilesInfo;
			this.StartTransfer();
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x00024870 File Offset: 0x00022A70
		private void cardViewDevices_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			CardView cardView = sender as CardView;
			DeviceTreeItemBase item = ((cardView != null) ? cardView.GetRow(e.ListSourceRowIndex) : null) as DeviceTreeItemBase;
			if (item != null)
			{
				e.DisplayText = item.Name;
				AgentItem agentItem = item as AgentItem;
				if (agentItem != null)
				{
					e.DisplayText = agentItem.DeviceItem.Name;
					if (item.HasWindowsUser)
					{
						e.DisplayText = e.DisplayText + " (" + ((agentItem != null) ? agentItem.UserName : null) + ")";
						return;
					}
					e.DisplayText = e.DisplayText + " (" + Resources.WindowsUserNotLogged + ")";
				}
			}
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00024918 File Offset: 0x00022B18
		private void cardViewDevices_CustomDrawCardFieldValue(object sender, RowCellCustomDrawEventArgs e)
		{
			DeviceTreeItemBase item = (sender as CardView).GetRow(e.RowHandle) as DeviceTreeItemBase;
			if (item != null && (!item.IsConnected || (this._isUserDependDir && !item.HasWindowsUser)))
			{
				e.Appearance.ForeColor = Color.Red;
				e.Appearance.Font = e.Cache.GetFont(e.Appearance.Font, FontStyle.Bold);
				e.Appearance.DrawString(e.Cache, e.DisplayText, e.Bounds);
				e.Handled = true;
			}
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x000249B0 File Offset: 0x00022BB0
		private void CheckIsUserDependDirForFilesToReceive()
		{
			this._isUserDependDir = false;
			foreach (string fileName in this._fileList)
			{
				string macro = Macros.GetDirMacroFromFileName(fileName);
				if (!string.IsNullOrEmpty(macro) && Macros.IsUserDependMacro(macro))
				{
					this._isUserDependDir = true;
					break;
				}
			}
			this.gridDevices.RefreshDataSource();
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x00024A2C File Offset: 0x00022C2C
		private void comboBoxDestinationDirMacro_TextChanged(object sender, EventArgs e)
		{
			this.SetTransferButtonState();
			StringKeyAndValue macro = (StringKeyAndValue)this.comboBoxSendDestinationDirMacro.SelectedItem;
			this._isUserDependDir = Macros.IsUserDependMacro(macro.Key);
			this.textEditSendDestinationPath.Properties.Buttons[0].Enabled = Macros.IsAnyDirectoryMacro(this.GetSelectedMacro());
			this.gridDevices.RefreshDataSource();
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x00024A92 File Offset: 0x00022C92
		private void comboBoxReceiveFilesLocalPathType_Properties_CustomDisplayText(object sender, CustomDisplayTextEventArgs e)
		{
			if (e.Value != null)
			{
				e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<DistributeFilesForm.ReceiveFilesLocalPathType>((DistributeFilesForm.ReceiveFilesLocalPathType)e.Value, Resources.ResourceManager, null);
			}
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x00024AB8 File Offset: 0x00022CB8
		private void comboBoxReceiveFilesLocalPathType_Properties_CustomItemDisplayText(object sender, CustomItemDisplayTextEventArgs e)
		{
			e.DisplayText = SsStringUtils.GetEnumDescriptionFromResource<DistributeFilesForm.ReceiveFilesLocalPathType>((DistributeFilesForm.ReceiveFilesLocalPathType)e.Value, Resources.ResourceManager, null);
		}

		// Token: 0x060005B1 RID: 1457 RVA: 0x00024AD6 File Offset: 0x00022CD6
		private void FormFileDistribute_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (this._transferInProgress)
			{
				this._formCreator.ShowInfo(Resources.DistributeFilesForm_FormClosing);
				e.Cancel = true;
			}
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x00024AF8 File Offset: 0x00022CF8
		private string GetDestinationDir(DeviceItem deviceItem, AgentClient agentClient)
		{
			if (this.IsSendDirection())
			{
				StringKeyAndValue macro = this.GetSelectedMacro();
				if (Macros.IsAnyDirectoryMacro(macro))
				{
					return this.textEditSendDestinationPath.Text;
				}
				return macro.Key + this.textEditSendDestinationPath.Text;
			}
			else
			{
				switch ((DistributeFilesForm.ReceiveFilesLocalPathType)this.comboBoxReceiveFilesLocalPathType.EditValue)
				{
				case DistributeFilesForm.ReceiveFilesLocalPathType.OneDirectoryForAll:
					return this.textEditReceiveDestinationPath.Text;
				case DistributeFilesForm.ReceiveFilesLocalPathType.DirectoryPerDeviceName:
					return Path.Combine(this.textEditReceiveDestinationPath.Text, deviceItem.Name);
				case DistributeFilesForm.ReceiveFilesLocalPathType.DirectoryPerUserLogin:
					return Path.Combine(this.textEditReceiveDestinationPath.Text, (agentClient != null) ? agentClient.WindowsUser.UserName : null);
				case DistributeFilesForm.ReceiveFilesLocalPathType.DirectoryPerUserFullName:
					return Path.Combine(this.textEditReceiveDestinationPath.Text, (agentClient != null) ? agentClient.WindowsUser.FullName : null);
				default:
					return this.textEditReceiveDestinationPath.Text;
				}
			}
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x00024BDC File Offset: 0x00022DDC
		private DistributeFilesForm.DeviceTransferInfo GetDeviceTransferInfo(string agentId)
		{
			return this._devicesTransferFilesInfo.FirstOrDefault(delegate(DistributeFilesForm.DeviceTransferInfo x)
			{
				AgentClient agentClient = x.AgentClient;
				return ((agentClient != null) ? agentClient.AgentId : null) == agentId;
			});
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x00024C0D File Offset: 0x00022E0D
		private StringKeyAndValue GetSelectedMacro()
		{
			return (StringKeyAndValue)this.comboBoxSendDestinationDirMacro.SelectedItem;
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x00024C20 File Offset: 0x00022E20
		private void gridDevices_DoubleClick(object sender, EventArgs e)
		{
			DevicesSelectionFormParams @params = new DevicesSelectionFormParams(this._targetList, DeviceTreeItemsType.Agent | DeviceTreeItemsType.DeviceGroup | DeviceTreeItemsType.Device, DeviceTreeItemsType.Agent | DeviceTreeItemsType.Device, DeviceTreeItemsType.Agent | DeviceTreeItemsType.Device, true);
			if (this._formCreator.Show<DevicesSelectionForm, DevicesSelectionFormParams>(FormAction.Unknown, @params, out @params))
			{
				this._targetList = new List<DeviceTreeItemBase>();
				this._targetList.AddRange(@params.SelectedItems.OfType<AgentItem>().ToList<AgentItem>());
				this._targetList.AddRange(@params.SelectedItems.OfType<DeviceItem>().ToList<DeviceItem>());
				this.gridDevices.DataSource = this._targetList;
				this.SetTransferButtonState();
			}
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x00024CA8 File Offset: 0x00022EA8
		private void gridView1_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			GridView gridView = sender as GridView;
			AgentItem agentItem = ((gridView != null) ? gridView.GetRow(e.ListSourceRowIndex) : null) as AgentItem;
			if (agentItem != null)
			{
				e.DisplayText = agentItem.DeviceItem.Name;
			}
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x00024CE8 File Offset: 0x00022EE8
		private void gridViewFileList_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
		{
			System.ValueTuple<StringKeyAndValue, string> valueTuple = Macros.SplitFileNameToMacroAndFileName(this._macroList, e.DisplayText);
			StringKeyAndValue macro = valueTuple.Item1;
			string fileName = valueTuple.Item2;
			if (macro.Key != "{?}")
			{
				e.DisplayText = macro.Value + fileName;
			}
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x00024D38 File Offset: 0x00022F38
		private void gridViewSendInfo_RowStyle(object sender, RowStyleEventArgs e)
		{
			GridView gridView = sender as GridView;
			DistributeFilesForm.DeviceTransferInfo deviceTransferInfo = ((gridView != null) ? gridView.GetRow(e.RowHandle) : null) as DistributeFilesForm.DeviceTransferInfo;
			if (deviceTransferInfo != null && (deviceTransferInfo.Status == DistributeFilesForm.DistributeFileStatusInfo.Error || deviceTransferInfo.Status == DistributeFilesForm.DistributeFileStatusInfo.Canceled))
			{
				e.Appearance.ForeColor = Color.Red;
				e.HighPriority = true;
			}
		}

		// Token: 0x060005B9 RID: 1465 RVA: 0x00024D8F File Offset: 0x00022F8F
		private bool IsSendDirection()
		{
			return this._params.Direction == AgentFileTransferDirection.Send;
		}

		// Token: 0x060005BA RID: 1466 RVA: 0x00024D9F File Offset: 0x00022F9F
		private void OnFileOverride(object sender, AgentFileTransferOverrideArgs args)
		{
			if (this.IsSendDirection() ? (this.comboBoxSendFileOverride.SelectedIndex == 0) : (this.comboBoxReceiveFileOverride.SelectedIndex == 0))
			{
				args.Action = FileOverrideAction.Override;
				return;
			}
			args.Action = FileOverrideAction.Skip;
		}

		// Token: 0x060005BB RID: 1467 RVA: 0x00024DD8 File Offset: 0x00022FD8
		private void OnFilesBunchTransferProgres(object sender, AgentFilesBunchTransferProgressArgs args)
		{
			DistributeFilesForm.DeviceTransferInfo deviceTransferInfo = this.GetDeviceTransferInfo(args.AgentId);
			if (deviceTransferInfo != null)
			{
				deviceTransferInfo.FilesProgress = args;
				this.RefreshSendProgressGrid(false);
			}
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x00024E04 File Offset: 0x00023004
		private void OnFileTransferEnd(object sender, AgentFileTransferEndArgs args)
		{
			DistributeFilesForm.DeviceTransferInfo deviceTransferInfo = this.GetDeviceTransferInfo(args.AgentId);
			DistributeFilesForm.DistributeFileStatusInfo succesStatus = this.IsSendDirection() ? DistributeFilesForm.DistributeFileStatusInfo.SendSuccess : DistributeFilesForm.DistributeFileStatusInfo.ReceiveSuccess;
			if (deviceTransferInfo != null)
			{
				switch (args.Result)
				{
				case AgentFileTransferResult.Skipped:
					deviceTransferInfo.AddToLog(Resources.DistributeFilesForm_FileSkiped);
					deviceTransferInfo.Status = DistributeFilesForm.DistributeFileStatusInfo.Skipped;
					break;
				case AgentFileTransferResult.AlreadyExist:
					deviceTransferInfo.AddToLog(Resources.DistributeFilesForm_FileAlreadyExists);
					deviceTransferInfo.Status = succesStatus;
					break;
				case AgentFileTransferResult.Canceled:
					deviceTransferInfo.Status = DistributeFilesForm.DistributeFileStatusInfo.Error;
					break;
				default:
					deviceTransferInfo.Status = succesStatus;
					break;
				}
				this.RefreshSendProgressGrid(true);
			}
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x00024E8C File Offset: 0x0002308C
		private void OnFileTransferStart(object sender, AgentFileTransferArgs args)
		{
			DistributeFilesForm.DeviceTransferInfo deviceTransferInfo = this.GetDeviceTransferInfo(args.AgentId);
			if (deviceTransferInfo != null)
			{
				if (this.IsSendDirection())
				{
					deviceTransferInfo.AddToLog(string.Format(Resources.DistributeFilesForm_StartSendingFile, args.FileName));
					deviceTransferInfo.Status = DistributeFilesForm.DistributeFileStatusInfo.Sending;
				}
				else
				{
					deviceTransferInfo.AddToLog(string.Format(Resources.DistributeFilesForm_StartReceivingFile, args.FileName));
					deviceTransferInfo.Status = DistributeFilesForm.DistributeFileStatusInfo.Receiving;
				}
				this.RefreshSendProgressGrid(true);
			}
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x00024EF4 File Offset: 0x000230F4
		private void RefreshSendProgressGrid(bool forceRefresh)
		{
			if (SystemHelpers.GetTickCount() - this._lastSendInfoGridRefreshTick > 350U || forceRefresh)
			{
				this.gridSendProgress.BeginInvoke(new MethodInvoker(delegate()
				{
					this.gridViewSendInfo.RefreshData();
				}));
				this._lastSendInfoGridRefreshTick = SystemHelpers.GetTickCount();
			}
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x00024F30 File Offset: 0x00023130
		private void SetTransferButtonState()
		{
			this.buttonTransfer.Enabled = (this._fileList.Count > 0 && this._targetList.Count > 0);
			if (this.IsSendDirection())
			{
				if (this.comboBoxSendDestinationDirMacro.Text.Length == 0)
				{
					this.buttonTransfer.Enabled = false;
					return;
				}
			}
			else if (this.textEditReceiveDestinationPath.Text.Length == 0)
			{
				this.buttonTransfer.Enabled = false;
			}
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x00024FAC File Offset: 0x000231AC
		private void StartTransfer()
		{
			DistributeFilesForm.<StartTransfer>d__44 <StartTransfer>d__;
			<StartTransfer>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<StartTransfer>d__.<>4__this = this;
			<StartTransfer>d__.<>1__state = -1;
			<StartTransfer>d__.<>t__builder.Start<DistributeFilesForm.<StartTransfer>d__44>(ref <StartTransfer>d__);
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x00024FE4 File Offset: 0x000231E4
		private void textEditDestinationPath_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			using (XtraFolderBrowserDialog dlg = new XtraFolderBrowserDialog())
			{
				if (dlg.ShowDialog() == DialogResult.OK)
				{
					this.textEditSendDestinationPath.Text = dlg.SelectedPath;
				}
			}
		}

		// Token: 0x060005C2 RID: 1474 RVA: 0x00025030 File Offset: 0x00023230
		private void textEditReceiveDestinationPath_ButtonClick(object sender, ButtonPressedEventArgs e)
		{
			using (XtraFolderBrowserDialog dlg = new XtraFolderBrowserDialog())
			{
				if (dlg.ShowDialog() == DialogResult.OK)
				{
					this.textEditReceiveDestinationPath.Text = dlg.SelectedPath;
				}
			}
		}

		// Token: 0x060005C3 RID: 1475 RVA: 0x0002507C File Offset: 0x0002327C
		private void textEditReceiveDestinationPath_EditValueChanged(object sender, EventArgs e)
		{
			this.SetTransferButtonState();
		}

		// Token: 0x060005C4 RID: 1476 RVA: 0x0002507C File Offset: 0x0002327C
		private void textEditSendDestinationPath_EditValueChanged(object sender, EventArgs e)
		{
			this.SetTransferButtonState();
		}

		// Token: 0x060005C5 RID: 1477 RVA: 0x00025084 File Offset: 0x00023284
		private bool ValidateReceiveDestinationPath()
		{
			return this.textEditReceiveDestinationPath.Text.Length > 0 && Directory.Exists(this.textEditReceiveDestinationPath.Text);
		}

		// Token: 0x060005C6 RID: 1478 RVA: 0x000250AC File Offset: 0x000232AC
		private bool ValidateSendDestinationPath()
		{
			string modifiedPath;
			bool result = Macros.ValidateMacroAndPath(this.GetSelectedMacro().Key, this.textEditSendDestinationPath.Text, out modifiedPath, FileOrFolder.Folder);
			this.textEditSendDestinationPath.Text = modifiedPath;
			return result;
		}

		// Token: 0x04000306 RID: 774
		private readonly CancellationTokenSource _cts;

		// Token: 0x04000307 RID: 775
		private readonly BindingList<DistributeFilesForm.DeviceTransferInfo> _devicesTransferFilesInfo;

		// Token: 0x04000308 RID: 776
		private readonly List<string> _fileList;

		// Token: 0x04000309 RID: 777
		private readonly List<StringKeyAndValue> _macroList;

		// Token: 0x0400030A RID: 778
		private readonly DistributeFilesFormParams _params;

		// Token: 0x0400030B RID: 779
		private bool _canceled;

		// Token: 0x0400030C RID: 780
		private bool _isUserDependDir;

		// Token: 0x0400030D RID: 781
		private uint _lastSendInfoGridRefreshTick;

		// Token: 0x0400030E RID: 782
		private List<DeviceTreeItemBase> _targetList;

		// Token: 0x0400030F RID: 783
		private bool _transferInProgress;

		// Token: 0x0200014C RID: 332
		private enum DistributeFileStatusInfo
		{
			// Token: 0x04000972 RID: 2418
			Waiting,
			// Token: 0x04000973 RID: 2419
			Sending,
			// Token: 0x04000974 RID: 2420
			Receiving,
			// Token: 0x04000975 RID: 2421
			Skipped,
			// Token: 0x04000976 RID: 2422
			SendSuccess,
			// Token: 0x04000977 RID: 2423
			ReceiveSuccess,
			// Token: 0x04000978 RID: 2424
			Canceled,
			// Token: 0x04000979 RID: 2425
			Error
		}

		// Token: 0x0200014D RID: 333
		private enum ReceiveFilesLocalPathType
		{
			// Token: 0x0400097B RID: 2427
			OneDirectoryForAll,
			// Token: 0x0400097C RID: 2428
			DirectoryPerDeviceName,
			// Token: 0x0400097D RID: 2429
			DirectoryPerUserLogin,
			// Token: 0x0400097E RID: 2430
			DirectoryPerUserFullName
		}

		// Token: 0x0200014E RID: 334
		private class DeviceTransferInfo
		{
			// Token: 0x06000AFE RID: 2814 RVA: 0x0005E36C File Offset: 0x0005C56C
			public DeviceTransferInfo(AgentFileTransferDirection direction, DeviceItem deviceItem, AgentClient agentClient, List<string> filesList, string destinationDir, CancellationToken cancellationToken)
			{
				this.DeviceItem = deviceItem;
				this.AgentClient = agentClient;
				if (direction == AgentFileTransferDirection.Send)
				{
					this.FilesReaderOrWritter = new AgentMultipleFilesWritter(agentClient, FileToTransfer.CreateListForFilesWritter(filesList, destinationDir), 30720, cancellationToken);
				}
				else
				{
					this.FilesReaderOrWritter = new AgentMultipleFilesReader(agentClient, FileToTransfer.CreateListForFilesReader(filesList, destinationDir), 30720, cancellationToken);
				}
				this.Log = new List<string>();
				this.Status = DistributeFilesForm.DistributeFileStatusInfo.Waiting;
			}

			// Token: 0x170002EB RID: 747
			// (get) Token: 0x06000AFF RID: 2815 RVA: 0x0005E3DC File Offset: 0x0005C5DC
			public AgentClient AgentClient { get; }

			// Token: 0x170002EC RID: 748
			// (get) Token: 0x06000B00 RID: 2816 RVA: 0x0005E3E4 File Offset: 0x0005C5E4
			public string BytesPerSecAsString
			{
				get
				{
					if (this.FilesProgress == null)
					{
						return "";
					}
					return LangStringUtils.StringRepresentingFileSize(this.FilesProgress.BytesPerSec);
				}
			}

			// Token: 0x170002ED RID: 749
			// (get) Token: 0x06000B01 RID: 2817 RVA: 0x0005E404 File Offset: 0x0005C604
			public DeviceItem DeviceItem { get; }

			// Token: 0x170002EE RID: 750
			// (get) Token: 0x06000B02 RID: 2818 RVA: 0x0005E40C File Offset: 0x0005C60C
			// (set) Token: 0x06000B03 RID: 2819 RVA: 0x0005E414 File Offset: 0x0005C614
			public string ErrorText { get; set; }

			// Token: 0x170002EF RID: 751
			// (get) Token: 0x06000B04 RID: 2820 RVA: 0x0005E41D File Offset: 0x0005C61D
			// (set) Token: 0x06000B05 RID: 2821 RVA: 0x0005E425 File Offset: 0x0005C625
			public AgentFilesBunchTransferProgressArgs FilesProgress { get; set; }

			// Token: 0x170002F0 RID: 752
			// (get) Token: 0x06000B06 RID: 2822 RVA: 0x0005E42E File Offset: 0x0005C62E
			public AgentMultipleFilesBase FilesReaderOrWritter { get; }

			// Token: 0x170002F1 RID: 753
			// (get) Token: 0x06000B07 RID: 2823 RVA: 0x0005E436 File Offset: 0x0005C636
			public List<string> Log { get; }

			// Token: 0x170002F2 RID: 754
			// (get) Token: 0x06000B08 RID: 2824 RVA: 0x0005E43E File Offset: 0x0005C63E
			public string SecRemainAsString
			{
				get
				{
					if (this.FilesProgress == null)
					{
						return "";
					}
					return LangStringUtils.StringRepresentingRemainSec(this.FilesProgress.SecRemain);
				}
			}

			// Token: 0x170002F3 RID: 755
			// (get) Token: 0x06000B09 RID: 2825 RVA: 0x0005E45E File Offset: 0x0005C65E
			// (set) Token: 0x06000B0A RID: 2826 RVA: 0x0005E466 File Offset: 0x0005C666
			public DistributeFilesForm.DistributeFileStatusInfo Status { get; set; }

			// Token: 0x170002F4 RID: 756
			// (get) Token: 0x06000B0B RID: 2827 RVA: 0x0005E46F File Offset: 0x0005C66F
			public string StatusAsString
			{
				get
				{
					if (this.Status != DistributeFilesForm.DistributeFileStatusInfo.Error)
					{
						return SsStringUtils.GetEnumDescriptionFromResource<DistributeFilesForm.DistributeFileStatusInfo>(this.Status, Resources.ResourceManager, null);
					}
					return this.ErrorText;
				}
			}

			// Token: 0x170002F5 RID: 757
			// (get) Token: 0x06000B0C RID: 2828 RVA: 0x0005E492 File Offset: 0x0005C692
			public string UserName
			{
				get
				{
					AgentClient agentClient = this.AgentClient;
					if (agentClient == null)
					{
						return null;
					}
					WindowsUserInfo windowsUser = agentClient.WindowsUser;
					if (windowsUser == null)
					{
						return null;
					}
					return windowsUser.UserName;
				}
			}

			// Token: 0x06000B0D RID: 2829 RVA: 0x0005E4B0 File Offset: 0x0005C6B0
			public void AddToLog(string msg)
			{
				this.Log.Add(DateTime.Now.ToString() + "\t" + msg);
			}

			// Token: 0x06000B0E RID: 2830 RVA: 0x0005E4E0 File Offset: 0x0005C6E0
			public void SetError(string errorText)
			{
				this.Status = DistributeFilesForm.DistributeFileStatusInfo.Error;
				this.ErrorText = errorText;
				this.AddToLog(string.Format(Resources.DistributeFilesForm_TransferError, errorText));
			}
		}
	}
}
