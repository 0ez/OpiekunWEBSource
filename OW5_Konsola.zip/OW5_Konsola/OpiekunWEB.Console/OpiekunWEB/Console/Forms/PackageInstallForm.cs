﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using chocolatey.infrastructure.app.domain;
using DevExpress.Data;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraWizard;
using OpiekunWEB.Console.Choco;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007A RID: 122
	public partial class PackageInstallForm : NonModalBaseForm
	{
		// Token: 0x06000676 RID: 1654 RVA: 0x00033A67 File Offset: 0x00031C67
		public PackageInstallForm(IChocolateyService chocoService)
		{
			this.InitializeComponent();
			this._chocoService = chocoService;
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x00033A7C File Offset: 0x00031C7C
		public PackageInstallForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x00033A8A File Offset: 0x00031C8A
		private void simpleButton1_Click(object sender, EventArgs e)
		{
			this.gridViewPackages.RefreshData();
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00033A98 File Offset: 0x00031C98
		private void virtualServerModeSource_MoreRows(object sender, VirtualServerModeRowsEventArgs e)
		{
			e.RowsTask = Task.Factory.StartNew<VirtualServerModeRowsTaskResult>(delegate()
			{
				PackageSearchOptions options = new PackageSearchOptions(100, this._chocoSearchInfo.CurrentPage, "DownloadCount", false, false, false, "https://chocolatey.org/api/v2/");
				PackageResults chocoSearchResult = this._chocoService.Search("chrome", options).Result;
				this._chocoSearchInfo.CurrentPage = this._chocoSearchInfo.CurrentPage + 1;
				if (this._chocoSearchInfo.FirstSearch)
				{
					this._chocoSearchInfo.FirstSearch = false;
					this._chocoSearchInfo.TotalCount = chocoSearchResult.TotalCount;
				}
				e.UserData = this._chocoSearchInfo;
				return new VirtualServerModeRowsTaskResult(chocoSearchResult.Packages, this._chocoSearchInfo.CurrentPage * 100 < this._chocoSearchInfo.TotalCount, null);
			}, e.CancellationToken);
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x00033AE5 File Offset: 0x00031CE5
		private void virtualServerModeSource_ConfigurationChanged(object sender, VirtualServerModeRowsEventArgs e)
		{
			this._chocoSearchInfo = new PackageInstallForm.ChocoSearchInfo();
		}

		// Token: 0x04000429 RID: 1065
		private IChocolateyService _chocoService;

		// Token: 0x0400042A RID: 1066
		private const int ChocoSearchPageSize = 100;

		// Token: 0x0400042B RID: 1067
		private PackageInstallForm.ChocoSearchInfo _chocoSearchInfo;

		// Token: 0x02000163 RID: 355
		private class ChocoSearchInfo
		{
			// Token: 0x170002F6 RID: 758
			// (get) Token: 0x06000B48 RID: 2888 RVA: 0x0005F86E File Offset: 0x0005DA6E
			// (set) Token: 0x06000B49 RID: 2889 RVA: 0x0005F876 File Offset: 0x0005DA76
			public bool FirstSearch { get; set; }

			// Token: 0x170002F7 RID: 759
			// (get) Token: 0x06000B4A RID: 2890 RVA: 0x0005F87F File Offset: 0x0005DA7F
			// (set) Token: 0x06000B4B RID: 2891 RVA: 0x0005F887 File Offset: 0x0005DA87
			public int TotalCount { get; set; }

			// Token: 0x170002F8 RID: 760
			// (get) Token: 0x06000B4C RID: 2892 RVA: 0x0005F890 File Offset: 0x0005DA90
			// (set) Token: 0x06000B4D RID: 2893 RVA: 0x0005F898 File Offset: 0x0005DA98
			public int CurrentPage { get; set; }

			// Token: 0x06000B4E RID: 2894 RVA: 0x0005F8A1 File Offset: 0x0005DAA1
			public ChocoSearchInfo()
			{
				this.FirstSearch = true;
			}
		}
	}
}
