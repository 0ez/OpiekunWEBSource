﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000083 RID: 131
	public partial class ContentFilterForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x060006FE RID: 1790 RVA: 0x0003D8FC File Offset: 0x0003BAFC
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x0003D91C File Offset: 0x0003BB1C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ContentFilterForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.gridUserCategories = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewUserCategories = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnCategoryName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnState = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryItemImageComboBoxCategoryState = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.labelHelp = new global::DevExpress.XtraEditors.LabelControl();
			this.textEditUrl = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlItemUrl = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlItemHelp = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemGridUserCategories = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridUserCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUserCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxCategoryState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUrl.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemUrl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemHelp).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemGridUserCategories).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.layoutControlMain.Controls.Add(this.gridUserCategories);
			this.layoutControlMain.Controls.Add(this.labelHelp);
			this.layoutControlMain.Controls.Add(this.textEditUrl);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.gridUserCategories, "gridUserCategories");
			this.gridUserCategories.MainView = this.gridViewUserCategories;
			this.gridUserCategories.Name = "gridUserCategories";
			this.gridUserCategories.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryItemImageComboBoxCategoryState
			});
			this.gridUserCategories.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewUserCategories
			});
			this.gridViewUserCategories.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnCategoryName,
				this.gridColumnState
			});
			this.gridViewUserCategories.GridControl = this.gridUserCategories;
			this.gridViewUserCategories.Name = "gridViewUserCategories";
			this.gridViewUserCategories.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewUserCategories.OptionsView.ShowGroupPanel = false;
			this.gridViewUserCategories.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnCategoryName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewUserCategories.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewCategories_CustomUnboundColumnData);
			this.gridColumnCategoryName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnCategoryName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnCategoryName, "gridColumnCategoryName");
			this.gridColumnCategoryName.FieldName = "Name";
			this.gridColumnCategoryName.Name = "gridColumnCategoryName";
			this.gridColumnCategoryName.OptionsColumn.AllowEdit = false;
			this.gridColumnState.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnState.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnState, "gridColumnState");
			this.gridColumnState.ColumnEdit = this.repositoryItemImageComboBoxCategoryState;
			this.gridColumnState.FieldName = "CategoryState";
			this.gridColumnState.Name = "gridColumnState";
			this.gridColumnState.UnboundType = global::DevExpress.Data.UnboundColumnType.Boolean;
			resources.ApplyResources(this.repositoryItemImageComboBoxCategoryState, "repositoryItemImageComboBoxCategoryState");
			this.repositoryItemImageComboBoxCategoryState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("repositoryItemImageComboBoxCategoryState.Buttons"))
			});
			this.repositoryItemImageComboBoxCategoryState.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxCategoryState.Items"), resources.GetObject("repositoryItemImageComboBoxCategoryState.Items1"), (int)resources.GetObject("repositoryItemImageComboBoxCategoryState.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("repositoryItemImageComboBoxCategoryState.Items3"), resources.GetObject("repositoryItemImageComboBoxCategoryState.Items4"), (int)resources.GetObject("repositoryItemImageComboBoxCategoryState.Items5"))
			});
			this.repositoryItemImageComboBoxCategoryState.Name = "repositoryItemImageComboBoxCategoryState";
			resources.ApplyResources(this.labelHelp, "labelHelp");
			this.labelHelp.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftTop;
			this.labelHelp.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.question_32x32;
			this.labelHelp.Name = "labelHelp";
			this.labelHelp.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditUrl, "textEditUrl");
			this.textEditUrl.Name = "textEditUrl";
			this.textEditUrl.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditUrl.Properties.Mask.BeepOnError");
			this.textEditUrl.Properties.Mask.EditMask = resources.GetString("textEditUrl.Properties.Mask.EditMask");
			this.textEditUrl.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditUrl.Properties.Mask.IgnoreMaskBlank");
			this.textEditUrl.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditUrl.Properties.Mask.MaskType");
			this.textEditUrl.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditUrl.Properties.Mask.ShowPlaceHolders");
			this.textEditUrl.Properties.NullValuePrompt = resources.GetString("textEditUrl.Properties.NullValuePrompt");
			this.textEditUrl.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlItemUrl,
				this.emptySpaceItem1,
				this.layoutControlItemHelp,
				this.layoutControlItemGridUserCategories
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(417, 349);
			this.layoutControlGroupMain.TextVisible = false;
			this.layoutControlItemUrl.Control = this.textEditUrl;
			this.layoutControlItemUrl.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlItemUrl.Name = "layoutControlItemUrl";
			this.layoutControlItemUrl.Size = new global::System.Drawing.Size(397, 45);
			resources.ApplyResources(this.layoutControlItemUrl, "layoutControlItemUrl");
			this.layoutControlItemUrl.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemUrl.TextSize = new global::System.Drawing.Size(151, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 279);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(397, 10);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemHelp.Control = this.labelHelp;
			this.layoutControlItemHelp.Location = new global::System.Drawing.Point(0, 289);
			this.layoutControlItemHelp.Name = "layoutControlItemHelp";
			this.layoutControlItemHelp.Size = new global::System.Drawing.Size(397, 40);
			this.layoutControlItemHelp.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemHelp.TextVisible = false;
			this.layoutControlItemGridUserCategories.Control = this.gridUserCategories;
			this.layoutControlItemGridUserCategories.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlItemGridUserCategories.Name = "layoutControlItemGridUserCategories";
			this.layoutControlItemGridUserCategories.Size = new global::System.Drawing.Size(397, 234);
			resources.ApplyResources(this.layoutControlItemGridUserCategories, "layoutControlItemGridUserCategories");
			this.layoutControlItemGridUserCategories.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemGridUserCategories.TextSize = new global::System.Drawing.Size(151, 16);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.Name = "ContentFilterForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridUserCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUserCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemImageComboBoxCategoryState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUrl.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemUrl).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemHelp).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemGridUserCategories).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040004F4 RID: 1268
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040004F5 RID: 1269
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040004F6 RID: 1270
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040004F7 RID: 1271
		private global::DevExpress.XtraEditors.LabelControl labelHelp;

		// Token: 0x040004F8 RID: 1272
		private global::DevExpress.XtraEditors.TextEdit textEditUrl;

		// Token: 0x040004F9 RID: 1273
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemUrl;

		// Token: 0x040004FA RID: 1274
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040004FB RID: 1275
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemHelp;

		// Token: 0x040004FC RID: 1276
		private global::DevExpress.XtraGrid.GridControl gridUserCategories;

		// Token: 0x040004FD RID: 1277
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewUserCategories;

		// Token: 0x040004FE RID: 1278
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemGridUserCategories;

		// Token: 0x040004FF RID: 1279
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnCategoryName;

		// Token: 0x04000500 RID: 1280
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnState;

		// Token: 0x04000501 RID: 1281
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemImageComboBoxCategoryState;
	}
}
