﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000067 RID: 103
	public partial class FileManagerForm : global::OpiekunWEB.Console.Forms.NonModalBaseForm
	{
		// Token: 0x06000585 RID: 1413 RVA: 0x00021F83 File Offset: 0x00020183
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x00021FA4 File Offset: 0x000201A4
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.FileManagerForm));
			this.splitContainerVeritical = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.splitContainerGrids = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.gridLocalFiles = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewLocalFiles = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnLocalFileName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnLocalSize = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnLocalFileType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnLocalDate = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.panelLocalDeviceControls = new global::DevExpress.XtraEditors.PanelControl();
			this.buttonLocalDeviceRefresh = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonLocalDeviceDeleteDir = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonLocalDeviceDirUp = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonLocalDeviceCreateDir = new global::DevExpress.XtraEditors.SimpleButton();
			this.labelLocalDevice = new global::DevExpress.XtraEditors.LabelControl();
			this.buttonSendToRemote = new global::DevExpress.XtraEditors.SimpleButton();
			this.comboBoxLocalDeviceDir = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.gridRemoteFiles = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewRemoteFiles = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnRemoteFileName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRemoteSize = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRemoteFileType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRemoteDate = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.panelRemoteDeviceControls = new global::DevExpress.XtraEditors.PanelControl();
			this.buttonRemoteDeviceRefresh = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonRemoteDeviceDeleteDir = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonRemoteDeviceDirUp = new global::DevExpress.XtraEditors.SimpleButton();
			this.buttonRemoteDeviceCreateDir = new global::DevExpress.XtraEditors.SimpleButton();
			this.labelRemoteDevice = new global::DevExpress.XtraEditors.LabelControl();
			this.buttonReadFromRemote = new global::DevExpress.XtraEditors.SimpleButton();
			this.comboBoxRemoteDeviceDir = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.panBottom = new global::DevExpress.XtraEditors.PanelControl();
			this.listBoxTransferLog = new global::DevExpress.XtraEditors.ListBoxControl();
			this.mvvmContext = new global::DevExpress.Utils.MVVM.MVVMContext(this.components);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerVeritical).BeginInit();
			this.splitContainerVeritical.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerGrids).BeginInit();
			this.splitContainerGrids.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridLocalFiles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewLocalFiles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelLocalDeviceControls).BeginInit();
			this.panelLocalDeviceControls.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxLocalDeviceDir.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridRemoteFiles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewRemoteFiles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelRemoteDeviceControls).BeginInit();
			this.panelRemoteDeviceControls.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxRemoteDeviceDir.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.panBottom).BeginInit();
			this.panBottom.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.listBoxTransferLog).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.mvvmContext).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.splitContainerVeritical, "splitContainerVeritical");
			this.splitContainerVeritical.FixedPanel = global::DevExpress.XtraEditors.SplitFixedPanel.Panel2;
			this.splitContainerVeritical.Horizontal = false;
			this.splitContainerVeritical.Name = "splitContainerVeritical";
			this.splitContainerVeritical.Panel1.Controls.Add(this.splitContainerGrids);
			this.splitContainerVeritical.Panel2.Controls.Add(this.panBottom);
			this.splitContainerVeritical.SplitterPosition = 166;
			resources.ApplyResources(this.splitContainerGrids, "splitContainerGrids");
			this.splitContainerGrids.FixedPanel = global::DevExpress.XtraEditors.SplitFixedPanel.None;
			this.splitContainerGrids.Name = "splitContainerGrids";
			this.splitContainerGrids.Panel1.Controls.Add(this.gridLocalFiles);
			this.splitContainerGrids.Panel1.Controls.Add(this.panelLocalDeviceControls);
			this.splitContainerGrids.Panel2.Controls.Add(this.gridRemoteFiles);
			this.splitContainerGrids.Panel2.Controls.Add(this.panelRemoteDeviceControls);
			this.splitContainerGrids.SplitterPosition = 388;
			resources.ApplyResources(this.gridLocalFiles, "gridLocalFiles");
			this.gridLocalFiles.MainView = this.gridViewLocalFiles;
			this.gridLocalFiles.Name = "gridLocalFiles";
			this.gridLocalFiles.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewLocalFiles
			});
			this.gridLocalFiles.DoubleClick += new global::System.EventHandler(this.gridLocalFiles_DoubleClick);
			this.gridViewLocalFiles.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnLocalFileName,
				this.gridColumnLocalSize,
				this.gridColumnLocalFileType,
				this.gridColumnLocalDate
			});
			this.gridViewLocalFiles.GridControl = this.gridLocalFiles;
			this.gridViewLocalFiles.Name = "gridViewLocalFiles";
			this.gridViewLocalFiles.OptionsBehavior.Editable = false;
			this.gridViewLocalFiles.OptionsBehavior.ReadOnly = true;
			this.gridViewLocalFiles.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewLocalFiles.OptionsSelection.MultiSelect = true;
			this.gridViewLocalFiles.OptionsView.ShowGroupPanel = false;
			this.gridViewLocalFiles.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnLocalFileName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewLocalFiles.CustomColumnSort += new global::DevExpress.XtraGrid.Views.Base.CustomColumnSortEventHandler(this.gridView_CustomColumnSort);
			this.gridViewLocalFiles.CustomColumnDisplayText += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridView_CustomColumnDisplayText);
			resources.ApplyResources(this.gridColumnLocalFileName, "gridColumnLocalFileName");
			this.gridColumnLocalFileName.FieldName = "Name";
			this.gridColumnLocalFileName.Name = "gridColumnLocalFileName";
			this.gridColumnLocalFileName.SortMode = global::DevExpress.XtraGrid.ColumnSortMode.Custom;
			resources.ApplyResources(this.gridColumnLocalSize, "gridColumnLocalSize");
			this.gridColumnLocalSize.FieldName = "FileSize";
			this.gridColumnLocalSize.Name = "gridColumnLocalSize";
			this.gridColumnLocalSize.SortMode = global::DevExpress.XtraGrid.ColumnSortMode.Custom;
			resources.ApplyResources(this.gridColumnLocalFileType, "gridColumnLocalFileType");
			this.gridColumnLocalFileType.FieldName = "Attributes";
			this.gridColumnLocalFileType.Name = "gridColumnLocalFileType";
			resources.ApplyResources(this.gridColumnLocalDate, "gridColumnLocalDate");
			this.gridColumnLocalDate.FieldName = "LastWriteTime";
			this.gridColumnLocalDate.Name = "gridColumnLocalDate";
			this.gridColumnLocalDate.SortMode = global::DevExpress.XtraGrid.ColumnSortMode.Custom;
			this.gridColumnLocalDate.UnboundType = global::DevExpress.Data.UnboundColumnType.DateTime;
			this.panelLocalDeviceControls.Controls.Add(this.buttonLocalDeviceRefresh);
			this.panelLocalDeviceControls.Controls.Add(this.buttonLocalDeviceDeleteDir);
			this.panelLocalDeviceControls.Controls.Add(this.buttonLocalDeviceDirUp);
			this.panelLocalDeviceControls.Controls.Add(this.buttonLocalDeviceCreateDir);
			this.panelLocalDeviceControls.Controls.Add(this.labelLocalDevice);
			this.panelLocalDeviceControls.Controls.Add(this.buttonSendToRemote);
			this.panelLocalDeviceControls.Controls.Add(this.comboBoxLocalDeviceDir);
			resources.ApplyResources(this.panelLocalDeviceControls, "panelLocalDeviceControls");
			this.panelLocalDeviceControls.Name = "panelLocalDeviceControls";
			this.buttonLocalDeviceRefresh.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonLocalDeviceRefresh.ImageOptions.Image");
			resources.ApplyResources(this.buttonLocalDeviceRefresh, "buttonLocalDeviceRefresh");
			this.buttonLocalDeviceRefresh.Name = "buttonLocalDeviceRefresh";
			this.buttonLocalDeviceRefresh.Click += new global::System.EventHandler(this.buttonLocalDeviceRefresh_Click);
			this.buttonLocalDeviceDeleteDir.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonLocalDeviceDeleteDir.ImageOptions.Image");
			resources.ApplyResources(this.buttonLocalDeviceDeleteDir, "buttonLocalDeviceDeleteDir");
			this.buttonLocalDeviceDeleteDir.Name = "buttonLocalDeviceDeleteDir";
			this.buttonLocalDeviceDeleteDir.Click += new global::System.EventHandler(this.buttonLocalDeviceDeleteDir_Click);
			this.buttonLocalDeviceDirUp.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonLocalDeviceDirUp.ImageOptions.Image");
			resources.ApplyResources(this.buttonLocalDeviceDirUp, "buttonLocalDeviceDirUp");
			this.buttonLocalDeviceDirUp.Name = "buttonLocalDeviceDirUp";
			this.buttonLocalDeviceDirUp.Click += new global::System.EventHandler(this.buttonLocalDeviceDirUp_Click);
			this.buttonLocalDeviceCreateDir.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonLocalDeviceCreateDir.ImageOptions.Image");
			resources.ApplyResources(this.buttonLocalDeviceCreateDir, "buttonLocalDeviceCreateDir");
			this.buttonLocalDeviceCreateDir.Name = "buttonLocalDeviceCreateDir";
			this.buttonLocalDeviceCreateDir.Click += new global::System.EventHandler(this.buttonLocalDeviceCreateDir_Click);
			resources.ApplyResources(this.labelLocalDevice, "labelLocalDevice");
			this.labelLocalDevice.Name = "labelLocalDevice";
			resources.ApplyResources(this.buttonSendToRemote, "buttonSendToRemote");
			this.buttonSendToRemote.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSendToRemote.ImageOptions.Image");
			this.buttonSendToRemote.ImageOptions.Location = global::DevExpress.XtraEditors.ImageLocation.MiddleRight;
			this.buttonSendToRemote.Name = "buttonSendToRemote";
			this.buttonSendToRemote.Click += new global::System.EventHandler(this.buttonSendToRemote_Click);
			resources.ApplyResources(this.comboBoxLocalDeviceDir, "comboBoxLocalDeviceDir");
			this.comboBoxLocalDeviceDir.CausesValidation = false;
			this.comboBoxLocalDeviceDir.Name = "comboBoxLocalDeviceDir";
			this.comboBoxLocalDeviceDir.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxLocalDeviceDir.Properties.Buttons"))
			});
			this.comboBoxLocalDeviceDir.Properties.EditValueChangedFiringMode = global::DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
			this.comboBoxLocalDeviceDir.Properties.NullValuePrompt = resources.GetString("comboBoxLocalDeviceDir.Properties.NullValuePrompt");
			this.comboBoxLocalDeviceDir.Properties.ValidateOnEnterKey = true;
			this.comboBoxLocalDeviceDir.CloseUp += new global::DevExpress.XtraEditors.Controls.CloseUpEventHandler(this.comboBoxLocalDeviceDir_CloseUp);
			this.comboBoxLocalDeviceDir.Validating += new global::System.ComponentModel.CancelEventHandler(this.comboBoxLocalDeviceDir_Validating);
			resources.ApplyResources(this.gridRemoteFiles, "gridRemoteFiles");
			this.gridRemoteFiles.MainView = this.gridViewRemoteFiles;
			this.gridRemoteFiles.Name = "gridRemoteFiles";
			this.gridRemoteFiles.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewRemoteFiles
			});
			this.gridRemoteFiles.DoubleClick += new global::System.EventHandler(this.gridRemoteFiles_DoubleClick);
			this.gridViewRemoteFiles.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnRemoteFileName,
				this.gridColumnRemoteSize,
				this.gridColumnRemoteFileType,
				this.gridColumnRemoteDate
			});
			this.gridViewRemoteFiles.GridControl = this.gridRemoteFiles;
			this.gridViewRemoteFiles.Name = "gridViewRemoteFiles";
			this.gridViewRemoteFiles.OptionsBehavior.Editable = false;
			this.gridViewRemoteFiles.OptionsBehavior.ReadOnly = true;
			this.gridViewRemoteFiles.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewRemoteFiles.OptionsSelection.MultiSelect = true;
			this.gridViewRemoteFiles.OptionsView.ShowGroupPanel = false;
			this.gridViewRemoteFiles.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumnRemoteFileName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewRemoteFiles.CustomColumnSort += new global::DevExpress.XtraGrid.Views.Base.CustomColumnSortEventHandler(this.gridView_CustomColumnSort);
			this.gridViewRemoteFiles.CustomColumnDisplayText += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridView_CustomColumnDisplayText);
			resources.ApplyResources(this.gridColumnRemoteFileName, "gridColumnRemoteFileName");
			this.gridColumnRemoteFileName.FieldName = "Name";
			this.gridColumnRemoteFileName.Name = "gridColumnRemoteFileName";
			this.gridColumnRemoteFileName.SortMode = global::DevExpress.XtraGrid.ColumnSortMode.Custom;
			resources.ApplyResources(this.gridColumnRemoteSize, "gridColumnRemoteSize");
			this.gridColumnRemoteSize.FieldName = "FileSize";
			this.gridColumnRemoteSize.Name = "gridColumnRemoteSize";
			this.gridColumnRemoteSize.SortMode = global::DevExpress.XtraGrid.ColumnSortMode.Custom;
			resources.ApplyResources(this.gridColumnRemoteFileType, "gridColumnRemoteFileType");
			this.gridColumnRemoteFileType.FieldName = "Attrib";
			this.gridColumnRemoteFileType.Name = "gridColumnRemoteFileType";
			resources.ApplyResources(this.gridColumnRemoteDate, "gridColumnRemoteDate");
			this.gridColumnRemoteDate.FieldName = "LastWriteTime";
			this.gridColumnRemoteDate.Name = "gridColumnRemoteDate";
			this.gridColumnRemoteDate.SortMode = global::DevExpress.XtraGrid.ColumnSortMode.Custom;
			this.gridColumnRemoteDate.UnboundType = global::DevExpress.Data.UnboundColumnType.DateTime;
			this.panelRemoteDeviceControls.Controls.Add(this.buttonRemoteDeviceRefresh);
			this.panelRemoteDeviceControls.Controls.Add(this.buttonRemoteDeviceDeleteDir);
			this.panelRemoteDeviceControls.Controls.Add(this.buttonRemoteDeviceDirUp);
			this.panelRemoteDeviceControls.Controls.Add(this.buttonRemoteDeviceCreateDir);
			this.panelRemoteDeviceControls.Controls.Add(this.labelRemoteDevice);
			this.panelRemoteDeviceControls.Controls.Add(this.buttonReadFromRemote);
			this.panelRemoteDeviceControls.Controls.Add(this.comboBoxRemoteDeviceDir);
			resources.ApplyResources(this.panelRemoteDeviceControls, "panelRemoteDeviceControls");
			this.panelRemoteDeviceControls.Name = "panelRemoteDeviceControls";
			resources.ApplyResources(this.buttonRemoteDeviceRefresh, "buttonRemoteDeviceRefresh");
			this.buttonRemoteDeviceRefresh.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonRemoteDeviceRefresh.ImageOptions.Image");
			this.buttonRemoteDeviceRefresh.Name = "buttonRemoteDeviceRefresh";
			this.buttonRemoteDeviceRefresh.Click += new global::System.EventHandler(this.buttonRemoteDeviceRefresh_Click);
			resources.ApplyResources(this.buttonRemoteDeviceDeleteDir, "buttonRemoteDeviceDeleteDir");
			this.buttonRemoteDeviceDeleteDir.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonRemoteDeviceDeleteDir.ImageOptions.Image");
			this.buttonRemoteDeviceDeleteDir.Name = "buttonRemoteDeviceDeleteDir";
			this.buttonRemoteDeviceDeleteDir.Click += new global::System.EventHandler(this.buttonRemoteDeviceDeleteDir_Click);
			resources.ApplyResources(this.buttonRemoteDeviceDirUp, "buttonRemoteDeviceDirUp");
			this.buttonRemoteDeviceDirUp.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonRemoteDeviceDirUp.ImageOptions.Image");
			this.buttonRemoteDeviceDirUp.Name = "buttonRemoteDeviceDirUp";
			this.buttonRemoteDeviceDirUp.Click += new global::System.EventHandler(this.buttonRemoteDeviceDirUp_Click);
			resources.ApplyResources(this.buttonRemoteDeviceCreateDir, "buttonRemoteDeviceCreateDir");
			this.buttonRemoteDeviceCreateDir.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonRemoteDeviceCreateDir.ImageOptions.Image");
			this.buttonRemoteDeviceCreateDir.Name = "buttonRemoteDeviceCreateDir";
			this.buttonRemoteDeviceCreateDir.Click += new global::System.EventHandler(this.buttonRemoteDeviceCreateDir_Click);
			resources.ApplyResources(this.labelRemoteDevice, "labelRemoteDevice");
			this.labelRemoteDevice.Name = "labelRemoteDevice";
			this.buttonReadFromRemote.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonReadFromRemote.ImageOptions.Image");
			resources.ApplyResources(this.buttonReadFromRemote, "buttonReadFromRemote");
			this.buttonReadFromRemote.Name = "buttonReadFromRemote";
			this.buttonReadFromRemote.Click += new global::System.EventHandler(this.buttonReadFromRemote_Click);
			resources.ApplyResources(this.comboBoxRemoteDeviceDir, "comboBoxRemoteDeviceDir");
			this.comboBoxRemoteDeviceDir.CausesValidation = false;
			this.comboBoxRemoteDeviceDir.Name = "comboBoxRemoteDeviceDir";
			this.comboBoxRemoteDeviceDir.Properties.AutoComplete = false;
			this.comboBoxRemoteDeviceDir.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxRemoteDeviceDir.Properties.Buttons"))
			});
			this.comboBoxRemoteDeviceDir.Properties.EditValueChangedFiringMode = global::DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
			this.comboBoxRemoteDeviceDir.Properties.NullValuePrompt = resources.GetString("comboBoxRemoteDeviceDir.Properties.NullValuePrompt");
			this.comboBoxRemoteDeviceDir.Properties.ValidateOnEnterKey = true;
			this.comboBoxRemoteDeviceDir.CloseUp += new global::DevExpress.XtraEditors.Controls.CloseUpEventHandler(this.comboBoxRemoteDeviceDir_CloseUp);
			this.comboBoxRemoteDeviceDir.Validating += new global::System.ComponentModel.CancelEventHandler(this.comboBoxRemoteDeviceDir_Validating);
			this.panBottom.Controls.Add(this.listBoxTransferLog);
			resources.ApplyResources(this.panBottom, "panBottom");
			this.panBottom.Name = "panBottom";
			resources.ApplyResources(this.listBoxTransferLog, "listBoxTransferLog");
			this.listBoxTransferLog.HorizontalScrollbar = true;
			this.listBoxTransferLog.Items.AddRange(new object[]
			{
				resources.GetString("listBoxTransferLog.Items")
			});
			this.listBoxTransferLog.Name = "listBoxTransferLog";
			this.mvvmContext.BindingExpressions.AddRange(new global::DevExpress.Utils.MVVM.BindingExpression[]
			{
				global::DevExpress.Utils.MVVM.BindingExpression.CreatePropertyBinding(typeof(global::OpiekunWEB.Console.Forms.FileManagerViewModel), "LocalFiles", this.gridLocalFiles, "DataSource"),
				global::DevExpress.Utils.MVVM.BindingExpression.CreatePropertyBinding(typeof(global::OpiekunWEB.Console.Forms.FileManagerViewModel), "Log", this.listBoxTransferLog, "DataSource"),
				global::DevExpress.Utils.MVVM.BindingExpression.CreatePropertyBinding(typeof(global::OpiekunWEB.Console.Forms.FileManagerViewModel), "RemoteFiles", this.gridRemoteFiles, "DataSource")
			});
			this.mvvmContext.ContainerControl = this;
			this.mvvmContext.ViewModelType = typeof(global::OpiekunWEB.Console.Forms.FileManagerViewModel);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.splitContainerVeritical);
			this.DoubleBuffered = true;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("FileManagerForm.IconOptions.Icon");
			base.MaximizeBox = true;
			base.Name = "FileManagerForm";
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerVeritical).EndInit();
			this.splitContainerVeritical.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainerGrids).EndInit();
			this.splitContainerGrids.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridLocalFiles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewLocalFiles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelLocalDeviceControls).EndInit();
			this.panelLocalDeviceControls.ResumeLayout(false);
			this.panelLocalDeviceControls.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxLocalDeviceDir.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridRemoteFiles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewRemoteFiles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelRemoteDeviceControls).EndInit();
			this.panelRemoteDeviceControls.ResumeLayout(false);
			this.panelRemoteDeviceControls.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxRemoteDeviceDir.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.panBottom).EndInit();
			this.panBottom.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.listBoxTransferLog).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.mvvmContext).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040002C9 RID: 713
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002CA RID: 714
		private global::DevExpress.XtraEditors.SplitContainerControl splitContainerVeritical;

		// Token: 0x040002CB RID: 715
		private global::DevExpress.XtraEditors.SplitContainerControl splitContainerGrids;

		// Token: 0x040002CC RID: 716
		private global::DevExpress.XtraGrid.GridControl gridLocalFiles;

		// Token: 0x040002CD RID: 717
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewLocalFiles;

		// Token: 0x040002CE RID: 718
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnLocalFileName;

		// Token: 0x040002CF RID: 719
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnLocalSize;

		// Token: 0x040002D0 RID: 720
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnLocalFileType;

		// Token: 0x040002D1 RID: 721
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnLocalDate;

		// Token: 0x040002D2 RID: 722
		private global::DevExpress.XtraEditors.PanelControl panelLocalDeviceControls;

		// Token: 0x040002D3 RID: 723
		private global::DevExpress.XtraEditors.SimpleButton buttonLocalDeviceRefresh;

		// Token: 0x040002D4 RID: 724
		private global::DevExpress.XtraEditors.SimpleButton buttonLocalDeviceDeleteDir;

		// Token: 0x040002D5 RID: 725
		private global::DevExpress.XtraEditors.SimpleButton buttonLocalDeviceDirUp;

		// Token: 0x040002D6 RID: 726
		private global::DevExpress.XtraEditors.SimpleButton buttonLocalDeviceCreateDir;

		// Token: 0x040002D7 RID: 727
		private global::DevExpress.XtraEditors.LabelControl labelLocalDevice;

		// Token: 0x040002D8 RID: 728
		private global::DevExpress.XtraEditors.SimpleButton buttonSendToRemote;

		// Token: 0x040002D9 RID: 729
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxLocalDeviceDir;

		// Token: 0x040002DA RID: 730
		private global::DevExpress.XtraGrid.GridControl gridRemoteFiles;

		// Token: 0x040002DB RID: 731
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewRemoteFiles;

		// Token: 0x040002DC RID: 732
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRemoteFileName;

		// Token: 0x040002DD RID: 733
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRemoteSize;

		// Token: 0x040002DE RID: 734
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRemoteFileType;

		// Token: 0x040002DF RID: 735
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRemoteDate;

		// Token: 0x040002E0 RID: 736
		private global::DevExpress.XtraEditors.PanelControl panelRemoteDeviceControls;

		// Token: 0x040002E1 RID: 737
		private global::DevExpress.XtraEditors.SimpleButton buttonRemoteDeviceRefresh;

		// Token: 0x040002E2 RID: 738
		private global::DevExpress.XtraEditors.SimpleButton buttonRemoteDeviceDeleteDir;

		// Token: 0x040002E3 RID: 739
		private global::DevExpress.XtraEditors.SimpleButton buttonRemoteDeviceDirUp;

		// Token: 0x040002E4 RID: 740
		private global::DevExpress.XtraEditors.SimpleButton buttonRemoteDeviceCreateDir;

		// Token: 0x040002E5 RID: 741
		private global::DevExpress.XtraEditors.LabelControl labelRemoteDevice;

		// Token: 0x040002E6 RID: 742
		private global::DevExpress.XtraEditors.SimpleButton buttonReadFromRemote;

		// Token: 0x040002E7 RID: 743
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxRemoteDeviceDir;

		// Token: 0x040002E8 RID: 744
		private global::DevExpress.XtraEditors.PanelControl panBottom;

		// Token: 0x040002E9 RID: 745
		private global::DevExpress.XtraEditors.ListBoxControl listBoxTransferLog;

		// Token: 0x040002EA RID: 746
		private global::DevExpress.Utils.MVVM.MVVMContext mvvmContext;
	}
}
