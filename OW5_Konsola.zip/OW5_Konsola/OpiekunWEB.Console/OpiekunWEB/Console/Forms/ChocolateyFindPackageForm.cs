﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using chocolatey.infrastructure.app.domain;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraLayout;
using OpiekunWEB.Console.Choco;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000050 RID: 80
	public partial class ChocolateyFindPackageForm : BaseForm
	{
		// Token: 0x0600047B RID: 1147 RVA: 0x000136A0 File Offset: 0x000118A0
		public ChocolateyFindPackageForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x000136AE File Offset: 0x000118AE
		public ChocolateyFindPackageForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, IChocolateyService chocolateyService) : base(formsSettings, formCreator, action)
		{
			this._chocolateyService = chocolateyService;
			this._packagesInformation = new BindingList<ChocolateyPackageInformation>();
			this.InitializeComponent();
			this.gridControlPackages.DataSource = this._packagesInformation;
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x000136E4 File Offset: 0x000118E4
		private Task Search()
		{
			ChocolateyFindPackageForm.<Search>d__4 <Search>d__;
			<Search>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Search>d__.<>4__this = this;
			<Search>d__.<>1__state = -1;
			<Search>d__.<>t__builder.Start<ChocolateyFindPackageForm.<Search>d__4>(ref <Search>d__);
			return <Search>d__.<>t__builder.Task;
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x00013728 File Offset: 0x00011928
		private void simpleButtonSearch_Click(object sender, EventArgs e)
		{
			ChocolateyFindPackageForm.<simpleButtonSearch_Click>d__5 <simpleButtonSearch_Click>d__;
			<simpleButtonSearch_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<simpleButtonSearch_Click>d__.<>4__this = this;
			<simpleButtonSearch_Click>d__.<>1__state = -1;
			<simpleButtonSearch_Click>d__.<>t__builder.Start<ChocolateyFindPackageForm.<simpleButtonSearch_Click>d__5>(ref <simpleButtonSearch_Click>d__);
		}

		// Token: 0x040001AA RID: 426
		private IChocolateyService _chocolateyService;

		// Token: 0x040001AB RID: 427
		private BindingList<ChocolateyPackageInformation> _packagesInformation;
	}
}
