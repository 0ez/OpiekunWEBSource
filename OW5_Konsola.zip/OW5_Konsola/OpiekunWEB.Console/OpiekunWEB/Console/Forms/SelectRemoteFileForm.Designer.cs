﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000074 RID: 116
	public partial class SelectRemoteFileForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600061D RID: 1565 RVA: 0x0002D944 File Offset: 0x0002BB44
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x0002D964 File Offset: 0x0002BB64
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.SelectRemoteFileForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.comboBoxSendDestinationDirMacro = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.textEditDestinationPath = new global::DevExpress.XtraEditors.ButtonEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlSendDestinationDirMacro = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlDestinationPath = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxSendDestinationDirMacro.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDestinationPath.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendDestinationDirMacro).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDestinationPath).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Controls.Add(this.comboBoxSendDestinationDirMacro);
			this.layoutControlMain.Controls.Add(this.textEditDestinationPath);
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.comboBoxSendDestinationDirMacro, "comboBoxSendDestinationDirMacro");
			this.comboBoxSendDestinationDirMacro.Name = "comboBoxSendDestinationDirMacro";
			this.comboBoxSendDestinationDirMacro.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxSendDestinationDirMacro.Properties.Buttons"))
			});
			this.comboBoxSendDestinationDirMacro.Properties.NullValuePrompt = resources.GetString("comboBoxSendDestinationDirMacro.Properties.NullValuePrompt");
			this.comboBoxSendDestinationDirMacro.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxSendDestinationDirMacro.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditDestinationPath, "textEditDestinationPath");
			this.textEditDestinationPath.Name = "textEditDestinationPath";
			this.textEditDestinationPath.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton()
			});
			this.textEditDestinationPath.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditDestinationPath.Properties.Mask.BeepOnError");
			this.textEditDestinationPath.Properties.Mask.EditMask = resources.GetString("textEditDestinationPath.Properties.Mask.EditMask");
			this.textEditDestinationPath.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditDestinationPath.Properties.Mask.ShowPlaceHolders");
			this.textEditDestinationPath.Properties.NullValuePrompt = resources.GetString("textEditDestinationPath.Properties.NullValuePrompt");
			this.textEditDestinationPath.StyleController = this.layoutControlMain;
			this.textEditDestinationPath.ButtonClick += new global::DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.textEditDestinationPath_ButtonClick);
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlSendDestinationDirMacro,
				this.layoutControlDestinationPath
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(376, 168);
			this.Root.TextVisible = false;
			resources.ApplyResources(this.layoutControlSendDestinationDirMacro, "layoutControlSendDestinationDirMacro");
			this.layoutControlSendDestinationDirMacro.Control = this.comboBoxSendDestinationDirMacro;
			this.layoutControlSendDestinationDirMacro.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlSendDestinationDirMacro.Name = "layoutControlSendDestinationDirMacro";
			this.layoutControlSendDestinationDirMacro.Size = new global::System.Drawing.Size(356, 45);
			this.layoutControlSendDestinationDirMacro.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlSendDestinationDirMacro.TextSize = new global::System.Drawing.Size(125, 16);
			resources.ApplyResources(this.layoutControlDestinationPath, "layoutControlDestinationPath");
			this.layoutControlDestinationPath.Control = this.textEditDestinationPath;
			this.layoutControlDestinationPath.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlDestinationPath.Name = "layoutControlDestinationPath";
			this.layoutControlDestinationPath.Size = new global::System.Drawing.Size(356, 103);
			this.layoutControlDestinationPath.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDestinationPath.TextSize = new global::System.Drawing.Size(125, 16);
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.buttonOk);
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("SelectRemoteFileForm.IconOptions.Icon");
			base.Name = "SelectRemoteFileForm";
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxSendDestinationDirMacro.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDestinationPath.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSendDestinationDirMacro).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDestinationPath).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040003B4 RID: 948
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040003B5 RID: 949
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040003B6 RID: 950
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x040003B7 RID: 951
		protected global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x040003B8 RID: 952
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxSendDestinationDirMacro;

		// Token: 0x040003B9 RID: 953
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSendDestinationDirMacro;

		// Token: 0x040003BA RID: 954
		private global::DevExpress.XtraEditors.ButtonEdit textEditDestinationPath;

		// Token: 0x040003BB RID: 955
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDestinationPath;
	}
}
