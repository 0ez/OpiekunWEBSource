﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005E RID: 94
	public partial class CreateAppTokenForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600050B RID: 1291 RVA: 0x00019E8B File Offset: 0x0001808B
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x00019EAC File Offset: 0x000180AC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.CreateAppTokenForm));
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.labelInfo = new global::DevExpress.XtraEditors.LabelControl();
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.buttonCreateToken = new global::DevExpress.XtraEditors.SimpleButton();
			this.textEditToken = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditPassword = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlItemPassword = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemToken = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemCreateToken = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.pictureBoxLogo = new global::System.Windows.Forms.PictureBox();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditToken.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemPassword).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemToken).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemCreateToken).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.DialogResult = global::System.Windows.Forms.DialogResult.OK;
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.buttonOk.ImageOptions.ImageIndex = (int)resources.GetObject("buttonOk.ImageOptions.ImageIndex");
			this.buttonOk.Name = "buttonOk";
			resources.ApplyResources(this.labelInfo, "labelInfo");
			this.labelInfo.Appearance.FontSizeDelta = (int)resources.GetObject("labelInfo.Appearance.FontSizeDelta");
			this.labelInfo.Appearance.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("labelInfo.Appearance.FontStyleDelta");
			this.labelInfo.Appearance.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("labelInfo.Appearance.GradientMode");
			this.labelInfo.Appearance.Image = (global::System.Drawing.Image)resources.GetObject("labelInfo.Appearance.Image");
			this.labelInfo.Appearance.ImageAlign = global::System.Drawing.ContentAlignment.TopLeft;
			this.labelInfo.Appearance.ImageIndex = 0;
			this.labelInfo.Appearance.Options.UseImage = true;
			this.labelInfo.Appearance.Options.UseImageAlign = true;
			this.labelInfo.Appearance.Options.UseImageIndex = true;
			this.labelInfo.Appearance.Options.UseTextOptions = true;
			this.labelInfo.Appearance.TextOptions.WordWrap = global::DevExpress.Utils.WordWrap.Wrap;
			this.labelInfo.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftTop;
			this.labelInfo.Name = "labelInfo";
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.AllowCustomization = false;
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutItem.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.Image");
			this.layoutControlMain.Controls.Add(this.buttonCreateToken);
			this.layoutControlMain.Controls.Add(this.textEditToken);
			this.layoutControlMain.Controls.Add(this.textEditPassword);
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2145, 256, 609, 465));
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.Image");
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.buttonCreateToken, "buttonCreateToken");
			this.buttonCreateToken.ImageOptions.ImageIndex = (int)resources.GetObject("buttonCreateToken.ImageOptions.ImageIndex");
			this.buttonCreateToken.Name = "buttonCreateToken";
			this.buttonCreateToken.StyleController = this.layoutControlMain;
			this.buttonCreateToken.Click += new global::System.EventHandler(this.buttonCreateToken_Click);
			resources.ApplyResources(this.textEditToken, "textEditToken");
			this.textEditToken.Name = "textEditToken";
			this.textEditToken.Properties.AccessibleDescription = resources.GetString("textEditToken.Properties.AccessibleDescription");
			this.textEditToken.Properties.AccessibleName = resources.GetString("textEditToken.Properties.AccessibleName");
			this.textEditToken.Properties.AutoHeight = (bool)resources.GetObject("textEditToken.Properties.AutoHeight");
			this.textEditToken.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("textEditToken.Properties.Mask.AutoComplete");
			this.textEditToken.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditToken.Properties.Mask.BeepOnError");
			this.textEditToken.Properties.Mask.EditMask = resources.GetString("textEditToken.Properties.Mask.EditMask");
			this.textEditToken.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditToken.Properties.Mask.IgnoreMaskBlank");
			this.textEditToken.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditToken.Properties.Mask.MaskType");
			this.textEditToken.Properties.Mask.PlaceHolder = (char)resources.GetObject("textEditToken.Properties.Mask.PlaceHolder");
			this.textEditToken.Properties.Mask.SaveLiteral = (bool)resources.GetObject("textEditToken.Properties.Mask.SaveLiteral");
			this.textEditToken.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditToken.Properties.Mask.ShowPlaceHolders");
			this.textEditToken.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("textEditToken.Properties.Mask.UseMaskAsDisplayFormat");
			this.textEditToken.Properties.NullValuePrompt = resources.GetString("textEditToken.Properties.NullValuePrompt");
			this.textEditToken.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("textEditToken.Properties.NullValuePromptShowForEmptyValue");
			this.textEditToken.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditPassword, "textEditPassword");
			this.textEditPassword.Name = "textEditPassword";
			this.textEditPassword.Properties.AccessibleDescription = resources.GetString("textEditPassword.Properties.AccessibleDescription");
			this.textEditPassword.Properties.AccessibleName = resources.GetString("textEditPassword.Properties.AccessibleName");
			this.textEditPassword.Properties.AutoHeight = (bool)resources.GetObject("textEditPassword.Properties.AutoHeight");
			this.textEditPassword.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("textEditPassword.Properties.Mask.AutoComplete");
			this.textEditPassword.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditPassword.Properties.Mask.BeepOnError");
			this.textEditPassword.Properties.Mask.EditMask = resources.GetString("textEditPassword.Properties.Mask.EditMask");
			this.textEditPassword.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditPassword.Properties.Mask.IgnoreMaskBlank");
			this.textEditPassword.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditPassword.Properties.Mask.MaskType");
			this.textEditPassword.Properties.Mask.PlaceHolder = (char)resources.GetObject("textEditPassword.Properties.Mask.PlaceHolder");
			this.textEditPassword.Properties.Mask.SaveLiteral = (bool)resources.GetObject("textEditPassword.Properties.Mask.SaveLiteral");
			this.textEditPassword.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditPassword.Properties.Mask.ShowPlaceHolders");
			this.textEditPassword.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("textEditPassword.Properties.Mask.UseMaskAsDisplayFormat");
			this.textEditPassword.Properties.NullValuePrompt = resources.GetString("textEditPassword.Properties.NullValuePrompt");
			this.textEditPassword.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("textEditPassword.Properties.NullValuePromptShowForEmptyValue");
			this.textEditPassword.Properties.UseSystemPasswordChar = true;
			this.textEditPassword.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.BackgroundImageOptions.ImageIndex");
			this.layoutControlGroupMain.CaptionImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.CaptionImageOptions.ImageIndex");
			this.layoutControlGroupMain.ContentImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.ContentImageOptions.ImageIndex");
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlItemPassword,
				this.layoutControlItemToken,
				this.layoutControlItemCreateToken
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.Padding = new global::DevExpress.XtraLayout.Utils.Padding(12, 12, 12, 12);
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(275, 188);
			this.layoutControlGroupMain.TextVisible = false;
			resources.ApplyResources(this.layoutControlItemPassword, "layoutControlItemPassword");
			this.layoutControlItemPassword.Control = this.textEditPassword;
			this.layoutControlItemPassword.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlItemPassword.ImageOptions.ImageIndex");
			this.layoutControlItemPassword.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlItemPassword.Name = "layoutControlItemPassword";
			this.layoutControlItemPassword.Size = new global::System.Drawing.Size(251, 45);
			this.layoutControlItemPassword.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemPassword.TextSize = new global::System.Drawing.Size(89, 16);
			resources.ApplyResources(this.layoutControlItemToken, "layoutControlItemToken");
			this.layoutControlItemToken.Control = this.textEditToken;
			this.layoutControlItemToken.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlItemToken.ImageOptions.ImageIndex");
			this.layoutControlItemToken.Location = new global::System.Drawing.Point(0, 84);
			this.layoutControlItemToken.Name = "layoutControlItemToken";
			this.layoutControlItemToken.Size = new global::System.Drawing.Size(251, 80);
			this.layoutControlItemToken.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemToken.TextSize = new global::System.Drawing.Size(89, 16);
			resources.ApplyResources(this.layoutControlItemCreateToken, "layoutControlItemCreateToken");
			this.layoutControlItemCreateToken.Control = this.buttonCreateToken;
			this.layoutControlItemCreateToken.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlItemCreateToken.ImageOptions.ImageIndex");
			this.layoutControlItemCreateToken.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlItemCreateToken.Name = "layoutControlItemCreateToken";
			this.layoutControlItemCreateToken.Padding = new global::DevExpress.XtraLayout.Utils.Padding(2, 2, 6, 6);
			this.layoutControlItemCreateToken.Size = new global::System.Drawing.Size(251, 39);
			this.layoutControlItemCreateToken.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItemCreateToken.TextVisible = false;
			resources.ApplyResources(this.pictureBoxLogo, "pictureBoxLogo");
			this.pictureBoxLogo.Image = global::OpiekunWEB.Console.Properties.Resources.opiekun_logo_120x125;
			this.pictureBoxLogo.Name = "pictureBoxLogo";
			this.pictureBoxLogo.TabStop = false;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.pictureBoxLogo);
			base.Controls.Add(this.layoutControlMain);
			base.Controls.Add(this.labelInfo);
			base.Controls.Add(this.buttonOk);
			base.Name = "CreateAppTokenForm";
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditToken.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemPassword).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemToken).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemCreateToken).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBoxLogo).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000239 RID: 569
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400023A RID: 570
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x0400023B RID: 571
		private global::DevExpress.XtraEditors.LabelControl labelInfo;

		// Token: 0x0400023C RID: 572
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x0400023D RID: 573
		private global::DevExpress.XtraEditors.SimpleButton buttonCreateToken;

		// Token: 0x0400023E RID: 574
		private global::DevExpress.XtraEditors.TextEdit textEditToken;

		// Token: 0x0400023F RID: 575
		private global::DevExpress.XtraEditors.TextEdit textEditPassword;

		// Token: 0x04000240 RID: 576
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x04000241 RID: 577
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemPassword;

		// Token: 0x04000242 RID: 578
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemToken;

		// Token: 0x04000243 RID: 579
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemCreateToken;

		// Token: 0x04000244 RID: 580
		private global::System.Windows.Forms.PictureBox pictureBoxLogo;
	}
}
