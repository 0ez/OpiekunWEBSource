﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using CryptoObfuscatorHelper.ExceptionReporting;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006A RID: 106
	public partial class ExceptionReportForm : BaseForm
	{
		// Token: 0x0600059C RID: 1436 RVA: 0x00024024 File Offset: 0x00022224
		public ExceptionReportForm(IFormCreator formCreator, ApiClient apiClient, AppConfiguration appConfiguration, Exception ex) : base(null, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._appConfiguration = appConfiguration;
			this._exception = ex;
			this._exceptionId = DateTime.Now.ToUniversalTime().ToString("yy-MM-dd-HH-mm-ss-") + SsStringUtils.GetRandomString(2);
			this.memoEditExceptionReport.Lines = new string[]
			{
				ex.ToString()
			};
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x0002409C File Offset: 0x0002229C
		private void btnSend_Click(object sender, EventArgs e)
		{
			ExceptionReportForm.<btnSend_Click>d__5 <btnSend_Click>d__;
			<btnSend_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<btnSend_Click>d__.<>4__this = this;
			<btnSend_Click>d__.<>1__state = -1;
			<btnSend_Click>d__.<>t__builder.Start<ExceptionReportForm.<btnSend_Click>d__5>(ref <btnSend_Click>d__);
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x000240D4 File Offset: 0x000222D4
		private Task<bool> SendCryptoObfuscatorReport()
		{
			ExceptionHandler.UserEmail = this._apiClient.Login;
			ExceptionHandler.AddBinaryDataFromScreenshot(this._exception, "screenshot");
			ExceptionHandler.AddCustomData(this._exception, "customerId", this._apiClient.CustomerId);
			ExceptionHandler.AddCustomData(this._exception, "email", this._apiClient.Login);
			ExceptionHandler.AddCustomData(this._exception, "exId", this._exceptionId);
			string reportFileName = string.Concat(new string[]
			{
				this._appConfiguration.ExceptionLogsDir,
				this._exceptionId,
				"--",
				this._apiClient.AppVersion,
				".exlog"
			});
			ExceptionHandler.SaveReportToFile(this._exception, reportFileName);
			return Task.FromResult<bool>(true);
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x000241A4 File Offset: 0x000223A4
		private Task<bool> SendSentryReport()
		{
			ExceptionReportForm.<SendSentryReport>d__7 <SendSentryReport>d__;
			<SendSentryReport>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<SendSentryReport>d__.<>4__this = this;
			<SendSentryReport>d__.<>1__state = -1;
			<SendSentryReport>d__.<>t__builder.Start<ExceptionReportForm.<SendSentryReport>d__7>(ref <SendSentryReport>d__);
			return <SendSentryReport>d__.<>t__builder.Task;
		}

		// Token: 0x040002FE RID: 766
		private readonly ApiClient _apiClient;

		// Token: 0x040002FF RID: 767
		private readonly AppConfiguration _appConfiguration;

		// Token: 0x04000300 RID: 768
		private readonly Exception _exception;

		// Token: 0x04000301 RID: 769
		private readonly string _exceptionId;
	}
}
