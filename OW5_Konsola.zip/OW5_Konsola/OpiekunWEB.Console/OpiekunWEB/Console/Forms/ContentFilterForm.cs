﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000083 RID: 131
	public partial class ContentFilterForm : CRUDBaseForm
	{
		// Token: 0x060006F9 RID: 1785 RVA: 0x0003D624 File Offset: 0x0003B824
		public ContentFilterForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, ContentFilter contentFilter) : base(formsSettings, formCreator, action, apiClient)
		{
			this.InitializeComponent();
			this._contentFilter = contentFilter;
			this._selectedCategories = new List<string>();
			foreach (string category in contentFilter.CategoriesId)
			{
				this._selectedCategories.Add(category);
			}
			if (action == FormAction.Update)
			{
				this.textEditUrl.Text = this._contentFilter.Data;
			}
			this.Text = string.Format(this.Text, contentFilter.FilterType.GetDescription());
			this.layoutControlItemUrl.Text = contentFilter.FilterType.GetDescription() + ":";
			this.labelHelp.Text = Resources.ResourceManager.GetString(string.Format("ContentFilterForm_{0}Help", contentFilter.FilterType));
			this.gridUserCategories.DataSource = apiClient.URLCategories;
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x0003D730 File Offset: 0x0003B930
		protected override bool IsDataValid()
		{
			if (this._selectedCategories.Count == 0)
			{
				this._formCreator.ShowError(Resources.ContentFilterForm_MustSelectCategory);
				return false;
			}
			if ((this._contentFilter.FilterType == ContentFilterType.UrlFilter || this._contentFilter.FilterType == ContentFilterType.UrlRegexFilter) && this._selectedCategories.Count > 3)
			{
				this._formCreator.ShowError(Resources.ContentFilterForm_CanSelectMax3Categories);
				return false;
			}
			if (this._contentFilter.FilterType == ContentFilterType.PhraseFilter && this._selectedCategories.Count > 1)
			{
				this._formCreator.ShowError(Resources.ContentFilterForm_ForPhraseCanSelectMax1Category);
				return false;
			}
			return true;
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x0003D7C8 File Offset: 0x0003B9C8
		protected override Task<bool> OnActionCreate()
		{
			ContentFilterForm.<OnActionCreate>d__4 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<ContentFilterForm.<OnActionCreate>d__4>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x0003D80C File Offset: 0x0003BA0C
		protected override Task<bool> OnActionUpdate()
		{
			ContentFilterForm.<OnActionUpdate>d__5 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<ContentFilterForm.<OnActionUpdate>d__5>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x0003D850 File Offset: 0x0003BA50
		private void gridViewCategories_CustomUnboundColumnData(object sender, CustomColumnDataEventArgs e)
		{
			if (e.Column.FieldName == "CategoryState")
			{
				URLCategory category = e.Row as URLCategory;
				if (category == null)
				{
					return;
				}
				if (e.IsGetData)
				{
					e.Value = (this._selectedCategories.IndexOf(category.Id) > -1);
					return;
				}
				if (e.IsSetData && e.Value != null)
				{
					bool? selected = e.Value as bool?;
					this._selectedCategories.Remove(category.Id);
					if (selected.Value)
					{
						this._selectedCategories.Add(category.Id);
					}
				}
			}
		}

		// Token: 0x040004F2 RID: 1266
		private readonly ContentFilter _contentFilter;

		// Token: 0x040004F3 RID: 1267
		private readonly List<string> _selectedCategories;
	}
}
