﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006A RID: 106
	public partial class ExceptionReportForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060005A0 RID: 1440 RVA: 0x000241E7 File Offset: 0x000223E7
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00024208 File Offset: 0x00022408
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ExceptionReportForm));
			this.buttonSendExceptionReport = new global::DevExpress.XtraEditors.SimpleButton();
			this.labelCriticalError = new global::DevExpress.XtraEditors.LabelControl();
			this.memoEditExceptionReport = new global::DevExpress.XtraEditors.MemoEdit();
			((global::System.ComponentModel.ISupportInitialize)this.memoEditExceptionReport.Properties).BeginInit();
			base.SuspendLayout();
			this.buttonSendExceptionReport.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.refresh_16x16;
			resources.ApplyResources(this.buttonSendExceptionReport, "buttonSendExceptionReport");
			this.buttonSendExceptionReport.Name = "buttonSendExceptionReport";
			this.buttonSendExceptionReport.Click += new global::System.EventHandler(this.btnSend_Click);
			this.labelCriticalError.Appearance.Font = (global::System.Drawing.Font)resources.GetObject("labelCriticalError.Appearance.Font");
			this.labelCriticalError.Appearance.Options.UseFont = true;
			this.labelCriticalError.Appearance.Options.UseTextOptions = true;
			this.labelCriticalError.Appearance.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.labelCriticalError, "labelCriticalError");
			this.labelCriticalError.Name = "labelCriticalError";
			resources.ApplyResources(this.memoEditExceptionReport, "memoEditExceptionReport");
			this.memoEditExceptionReport.Name = "memoEditExceptionReport";
			this.memoEditExceptionReport.Properties.NullValuePrompt = resources.GetString("memoEditExceptionReport.Properties.NullValuePrompt");
			this.memoEditExceptionReport.Properties.ReadOnly = true;
			this.memoEditExceptionReport.Properties.ScrollBars = global::System.Windows.Forms.ScrollBars.Both;
			resources.ApplyResources(this, "$this");
			base.Controls.Add(this.memoEditExceptionReport);
			base.Controls.Add(this.labelCriticalError);
			base.Controls.Add(this.buttonSendExceptionReport);
			base.Name = "ExceptionReportForm";
			((global::System.ComponentModel.ISupportInitialize)this.memoEditExceptionReport.Properties).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000302 RID: 770
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000303 RID: 771
		private global::DevExpress.XtraEditors.SimpleButton buttonSendExceptionReport;

		// Token: 0x04000304 RID: 772
		private global::DevExpress.XtraEditors.LabelControl labelCriticalError;

		// Token: 0x04000305 RID: 773
		private global::DevExpress.XtraEditors.MemoEdit memoEditExceptionReport;
	}
}
