﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;
using DevExpress.Data;
using DevExpress.LookAndFeel;
using DevExpress.Skins;
using DevExpress.Utils;
using DevExpress.Utils.Drawing;
using DevExpress.Utils.Svg;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Alerter;
using DevExpress.XtraBars.Helpers;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraBars.Ribbon.Gallery;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraTab;
using Google.Protobuf.Collections;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Controls;
using OpiekunWEB.Console.Events;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Forms.Views;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000087 RID: 135
	public partial class MainForm : RibbonBaseForm, ICommandTarget, IPopupMenuCreator
	{
		// Token: 0x0600074E RID: 1870 RVA: 0x0003F374 File Offset: 0x0003D574
		public MainForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient, DevicesTree devicesTree, ObservableAgregator observableAgregator, IIconsProvider iconsProvider) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			base.CanCloseByEsc = false;
			base.Icon = AppUtils.GetAppIcon();
			this._apiClient = apiClient;
			this._devicesTree = devicesTree;
			this._observableAgregator = observableAgregator;
			this._commandsAlwaysEnabled = new List<ConsoleEventType>
			{
				ConsoleEventType.RpcStartVnc,
				ConsoleEventType.SetDeviceLockDisabled,
				ConsoleEventType.SetDeviceLockKeyboard,
				ConsoleEventType.SetDeviceLockMouseKeyboardMonitor,
				ConsoleEventType.SetDeviceInetAllow,
				ConsoleEventType.SetDeviceInetBlock,
				ConsoleEventType.SetDeviceInetStrict,
				ConsoleEventType.SetDeviceInetCheck
			};
			this._commandsDisabledByRole = new List<ConsoleEventType>();
			this.AssignOperationKindToButtonTags();
			this._commandExecutor = new CommandExecutor(this._formCreator, this._apiClient, this, this._commandsDisabledByRole, this._commandsAlwaysEnabled);
			this._viewsManager = new ViewsManager(this._formCreator, this._observableAgregator, this.tabWorkspaceFull, this.tabWorkspaceTree, this.splitterDiagnosticWnd.Panel1);
			SkinHelper.InitSkinGallery(this.skinRibbonGallery, false);
			string fontName = this._formsSettings.UserIniFile.ReadString("DefaultFont", string.Empty);
			if (!string.IsNullOrEmpty(fontName))
			{
				WindowsFormsSettings.DefaultFont = (new FontConverter().ConvertFromInvariantString(fontName) as Font);
			}
			string skinName = this._formsSettings.UserIniFile.ReadString("Skin", string.Empty);
			if (!string.IsNullOrEmpty(skinName))
			{
				UserLookAndFeel.Default.SetSkinStyle(skinName);
			}
			UserLookAndFeel.Default.StyleChanged += delegate(object sender, EventArgs args)
			{
				this._formsSettings.UserIniFile.WriteString("Skin", UserLookAndFeel.Default.SkinName);
			};
			this.SetAppTitle();
			this.tabControlWorkspaces.ShowTabHeader = DefaultBoolean.False;
			this.devicesTreePanel.InitializeTree(apiClient, devicesTree, formsSettings, observableAgregator, this, iconsProvider);
			this.FillUrlAllowedCategoriesPopup();
			this.FillConsoleDefPopups();
			this.FillDesktopsPopup();
			this.FillAppDeviceCheckPopup();
			this.splitterDiagnosticWnd.SplitterPosition = 40;
			this.splitterDiagnosticWnd.PanelVisibility = SplitPanelVisibility.Panel1;
			this.gridDiagnostic.DataSource = this._observableAgregator.DeviceEventsLog;
			this._objectsToSaveState.Add(this);
			this._objectsToSaveState.Add(this.splitterDevicesTree);
			this._objectsToSaveState.Add(this.splitterDiagnosticWnd);
			this._objectsToSaveState.Add(this.barCheckDiagnosticWnd);
			this._apiClient.ConnectedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<bool>(this.OnApiConnected));
			this._apiClient.CollectionUpdatedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<int>(this.OnApiCollectionUpdated));
			this._apiClient.DeviceEventsLog.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<DeviceEvent>(this.OnApiDeviceEventsLog));
			this._observableAgregator.AgentConnectionChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<AgentClient>(this.OnAgentConnectionChanged));
			this._observableAgregator.SelectedDeviceChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<DevicesAndGroupsSelection>(this.OnSelectedDeviceChanged));
			this._observableAgregator.ViewChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<ViewChangedEvent>(this.OnViewChanged));
			this.OnApiConnected(this._apiClient.IsConnected);
			this._formNamesExcludedFromconsoleEventsLog = new List<string>();
			this._formNamesExcludedFromconsoleEventsLog.Add("WaitForTaskForm");
			this._formNamesExcludedFromconsoleEventsLog.Add("FileOverrideQuestionForm");
			this._formCreator.FormShowStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<string>(this.OnFormCreatorFormShow));
			this.ApplyRoleSettings();
			if (this._hasAdminPermission)
			{
				this.CheckAppUpdates(true);
			}
		}

		// Token: 0x0600074F RID: 1871 RVA: 0x0003F704 File Offset: 0x0003D904
		public void FillPopupMenu(PopupMenu popupMenu, PopupMenuKind menuKind, ICommandTarget commandTarget)
		{
			CommandExecutor commandExecutor = new CommandExecutor(this._formCreator, this._apiClient, commandTarget, this._commandsDisabledByRole, this._commandsAlwaysEnabled);
			popupMenu.AddItem(MainForm.<FillPopupMenu>g__createNewBarManagerItem|15_0(this.miShowFileManager, popupMenu.Manager, commandExecutor));
			popupMenu.LinksPersistInfo.Add(new LinkPersistInfo(MainForm.<FillPopupMenu>g__createBarManagerSubmenu|15_1(this.miShowRemoteDesktop, Resources.MainForm_RemoteDesktopMenu, popupMenu.Manager, new BarButtonItem[]
			{
				this.miStartVNC,
				this.miStartRDP
			}, null, commandExecutor)));
			popupMenu.AddItem(MainForm.<FillPopupMenu>g__createNewBarManagerItem|15_0(this.miShowProcessesDef, popupMenu.Manager, commandExecutor));
			popupMenu.AddItem(MainForm.<FillPopupMenu>g__createNewBarManagerItem|15_0(this.miShowMessagesDef, popupMenu.Manager, commandExecutor));
			popupMenu.LinksPersistInfo.Add(new LinkPersistInfo(MainForm.<FillPopupMenu>g__createBarManagerSubmenu|15_1(this.miSetDeviceInetCheck, Resources.MainForm_InetAccessControlMenu, popupMenu.Manager, new BarButtonItem[]
			{
				this.miSetDeviceInetAllow,
				this.miSetDeviceInetCheck,
				this.miSetDeviceInetBlock,
				this.miSetDeviceInetStrict
			}, null, commandExecutor)));
			popupMenu.LinksPersistInfo.Add(new LinkPersistInfo(MainForm.<FillPopupMenu>g__createBarManagerSubmenu|15_1(this.miSetDeviceLockKeyboard, Resources.MainForm_DeviceAccessControlMenu, popupMenu.Manager, new BarButtonItem[]
			{
				this.miSetDeviceLockDisabled,
				this.miSetDeviceLockKeyboard,
				this.miSetDeviceLockMouseKeyboardMonitor
			}, null, commandExecutor)));
			popupMenu.LinksPersistInfo.Add(new LinkPersistInfo(MainForm.<FillPopupMenu>g__createBarManagerSubmenu|15_1(this.miRpcWakeOnLan, Resources.MainForm_OnOffDeviceMenu, popupMenu.Manager, new BarButtonItem[]
			{
				this.miRpcWakeOnLan,
				this.miRpcSystemShutdown,
				this.miRpcSystemReboot,
				this.miRpcSessionLogoff,
				this.miRpcSessionLogon,
				this.miRpcSessionLock
			}, new BarButtonItem[]
			{
				this.miRpcSessionLogoff
			}, commandExecutor)));
			popupMenu.Tag = commandExecutor;
			popupMenu.BeforePopup += commandExecutor.BeforePopup;
		}

		// Token: 0x06000750 RID: 1872 RVA: 0x0003F8E5 File Offset: 0x0003DAE5
		public List<AgentItem> GetCommandTargetAsAgentItems()
		{
			return this._devicesTree.Selection.GetAgentItemList(false);
		}

		// Token: 0x06000751 RID: 1873 RVA: 0x0003F8F8 File Offset: 0x0003DAF8
		public List<DeviceItem> GetCommandTargetAsDeviceItems()
		{
			return this._devicesTree.Selection.DevicesList;
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x0003F90A File Offset: 0x0003DB0A
		public DeviceAndDisplayList GetCommandTargetAsDevicesAndDisplays()
		{
			return this._devicesTree.Selection.DeviceAndDisplayList;
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x0001815B File Offset: 0x0001635B
		public bool IsCommandEnabled(ConsoleEventType consoleEvent)
		{
			return true;
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x0003F91C File Offset: 0x0003DB1C
		protected virtual void OnApiDeviceEventsLog(DeviceEvent deviceEvent)
		{
			if (!new List<ConsoleEventType>
			{
				ConsoleEventType.AddItemToLog,
				ConsoleEventType.AgentConnectedDirect,
				ConsoleEventType.AgentConnectedByProxy,
				ConsoleEventType.AgentDisconnected,
				ConsoleEventType.TopicDeviceConnectedReceived
			}.Contains(deviceEvent.ConsoleEvent))
			{
				if (deviceEvent.Success)
				{
					this.barCheckDiagnosticWnd.Caption = Resources.MainForm_DiagnosticWndCaption;
					this.barCheckDiagnosticWnd.ImageOptions.Image = null;
				}
				else
				{
					this.barCheckDiagnosticWnd.Caption = Resources.MainForm_DiagnosticWndErrorCaption;
					this.barCheckDiagnosticWnd.ImageOptions.Image = Resources.warning_16x16;
				}
				this._apiClient.AddToConsoleEventsLog(deviceEvent.ConsoleEvent, deviceEvent.DeviceId, deviceEvent.Success, deviceEvent.Message);
			}
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x0003F9D2 File Offset: 0x0003DBD2
		protected virtual void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
			this.barStaticSelectionInfo.Caption = this._devicesTree.Selection.Description;
			this.gridViewDiagnostic.RefreshData();
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x0003F9FA File Offset: 0x0003DBFA
		protected override void SetVisibleCore(bool value)
		{
			base.SetVisibleCore(!this._hideMainWindow);
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x0003FA0B File Offset: 0x0003DC0B
		private void alertControlAgentUpdate_AlertClick(object sender, AlertClickEventArgs e)
		{
			this.alertControlAgentUpdate.AlertFormList[0].Hide();
			this.miShowUpdateAgents.PerformClick();
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x0003FA30 File Offset: 0x0003DC30
		private void alertControlAgentUpdate_BeforeFormShow(object sender, AlertFormEventArgs e)
		{
			int x = base.Left + base.Width - e.AlertForm.Width;
			int y = base.Top + base.Height - e.AlertForm.Height;
			e.Location = new Point(x, y);
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x0003FA80 File Offset: 0x0003DC80
		private void ApplyRoleSettings()
		{
			this._hasAdminPermission = this._apiClient.IsLoggedUserHasAdminPermission();
			this.miRoles.Enabled = this._hasAdminPermission;
			this.miUrlCategories.Enabled = this.<ApplyRoleSettings>g__hasApiPermission|25_0("ApiFilters");
			this.pageDevices.Enabled = this.<ApplyRoleSettings>g__hasApiPermission|25_0("ApiDevices");
			this.miHistoryView.Enabled = this.<ApplyRoleSettings>g__hasApiPermission|25_0("ApiWebHistory");
			this.miAppHistoryView.Enabled = this.<ApplyRoleSettings>g__hasApiPermission|25_0("ApiAppHistory");
			this.miCheckAppUpdates.Enabled = this._hasAdminPermission;
			this.miRules.Enabled = this._hasAdminPermission;
			this.miProcessesView.Enabled = this._apiClient.IsLoggedUserHasRemotePermission("ProcessList");
			if (!this.miProcessesView.Enabled)
			{
				this.miServicesView.Down = true;
			}
			this.miServicesView.Enabled = this._apiClient.IsLoggedUserHasRemotePermission("Services");
			if (!this.miServicesView.Enabled)
			{
				this.miProcessesView.Down = true;
			}
			this.pageGroupApplications.Visible = (this.miProcessesView.Enabled || this.miServicesView.Enabled);
			if (!this.miHistoryView.Enabled || !this.miAppHistoryView.Enabled)
			{
				this.miScreenshotsView.Down = true;
			}
			this._commandsDisabledByRole.Clear();
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.ShowDistributeFiles, this._apiClient.IsLoggedUserHasRemotePermission("FileDistribution"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.ShowCollectFiles, this._apiClient.IsLoggedUserHasRemotePermission("FileDistribution"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcWakeOnLan, this._apiClient.IsLoggedUserHasRemotePermission("WakeOnLan"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcSessionLogoff, this._apiClient.IsLoggedUserHasRemotePermission("LogoffSession"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcSessionLogon, this._apiClient.IsLoggedUserHasRemotePermission("UserLogon"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcShowMessage, this._apiClient.IsLoggedUserHasRemotePermission("ShowMessage"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.ShowMessagesDef, this._apiClient.IsLoggedUserHasRemotePermission("ShowMessage"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcStartProcess, this._apiClient.IsLoggedUserHasRemotePermission("StartProcess"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.ShowProcessesDef, this._apiClient.IsLoggedUserHasRemotePermission("StartProcess"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcStartVnc, this._apiClient.IsLoggedUserHasRemotePermission("RemoteDesktop"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcSystemReboot, this._apiClient.IsLoggedUserHasRemotePermission("SystemShutdown"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcSystemShutdown, this._apiClient.IsLoggedUserHasRemotePermission("SystemShutdown"));
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.RpcUpdateAgent, this._hasAdminPermission);
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.ShowFileManager, this._apiClient.IsLoggedUserHasRemotePermission("FileManager"));
			bool enabled = this._apiClient.IsLoggedUserHasRemotePermission("InetAccess");
			this.pageInternetAccess.Enabled = enabled;
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.SetDeviceInetAllow, enabled);
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.SetDeviceInetCheck, enabled);
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.SetDeviceInetBlock, enabled);
			enabled = this._apiClient.IsLoggedUserHasRemotePermission("DeviceLock");
			this.pageDeviceLock.Enabled = enabled;
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.SetDeviceLockDisabled, enabled);
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.SetDeviceLockKeyboard, enabled);
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.SetDeviceLockMouseKeyboardMonitor, enabled);
			enabled = this._apiClient.IsLoggedUserHasRemotePermission("AppAccess");
			this.pageAppAccess.Enabled = enabled;
			this.miDesktops.Enabled = enabled;
			this.miAppCategories.Enabled = enabled;
			this.<ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType.SetDeviceAppStrictToDesktop, enabled);
			this.miCreateAppToken.Enabled = this._hasAdminPermission;
			foreach (BarButtonItem buttonItem in this.ribbonControl.Items.OfType<BarButtonItem>())
			{
				object tag = buttonItem.Tag;
				if (tag is ConsoleEventType)
				{
					ConsoleEventType command = (ConsoleEventType)tag;
					buttonItem.Enabled = !this._commandsDisabledByRole.Contains(command);
				}
			}
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x0003FE78 File Offset: 0x0003E078
		private void AssignOperationKindToButtonTags()
		{
			foreach (object obj in this.ribbonControl.Items)
			{
				BarButtonItem barButton = obj as BarButtonItem;
				ConsoleEventType eventType;
				if (barButton != null && barButton.Name.Length >= 3 && Enum.TryParse<ConsoleEventType>(barButton.Name.Substring(2), out eventType))
				{
					barButton.Tag = eventType;
				}
			}
			this.miShowRemoteDesktop.Tag = ConsoleEventType.RpcStartVnc;
			this.miStartVNC.Tag = ConsoleEventType.RpcStartVnc;
			this.miStartRDP.Tag = ConsoleEventType.RpcStartRdp;
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x0003FF40 File Offset: 0x0003E140
		private void barCheckDiagnosticWnd_CheckedChanged(object sender, ItemClickEventArgs e)
		{
			this.splitterDiagnosticWnd.PanelVisibility = (this.barCheckDiagnosticWnd.Checked ? SplitPanelVisibility.Both : SplitPanelVisibility.Panel1);
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x0003FF5E File Offset: 0x0003E15E
		private void barStaticSelectionInfo_ItemDoubleClick(object sender, ItemClickEventArgs e)
		{
			int count = this._devicesTree.Selection.DevicesList.Count;
		}

		// Token: 0x0600075D RID: 1885 RVA: 0x0003FF78 File Offset: 0x0003E178
		private void ChangeViewClick(object sender, ItemClickEventArgs e)
		{
			this._viewsManager.ChangeViewForCurrentGroup(e.Item.Name.Substring(2));
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x0003FF98 File Offset: 0x0003E198
		private void CheckAppUpdates(bool isCalledFromAppStart)
		{
			if (this.GetAppInstallersInfo())
			{
				InstallerFileInfo latest = this._appInstallersInfo.ConsoleFiles.GetLatest();
				if (isCalledFromAppStart)
				{
					long rt = this._formsSettings.UserIniFile.ReadLong("AppRemindLaterTime", 0L);
					if (rt > 0L)
					{
						DateTime remindLaterTime = ApiUtils.UnixTimeToDateTime(rt);
						if (DateTime.Now.ToUniversalTime() - remindLaterTime < TimeSpan.FromHours(6.0))
						{
							return;
						}
					}
				}
				if (SsStringUtils.IsAppVersionNeverThat(this._apiClient.AppVersion, (latest != null) ? latest.Version : null))
				{
					AppUpdateFormParams @params = new AppUpdateFormParams(this._appInstallersInfo.ConsoleFiles.Last<InstallerFileInfo>(), this._apiClient.AppVersion);
					if (this._formCreator.Show<AppUpdateForm, AppUpdateFormParams>(@params))
					{
						if (@params.Result == AppUpdateMode.Update)
						{
							Process process = new Process
							{
								StartInfo = 
								{
									FileName = @params.DownloadedFile,
									Arguments = "/Silent /SuppressMsgBoxes /update",
									WindowStyle = ProcessWindowStyle.Maximized
								}
							};
							try
							{
								if (process.Start())
								{
									this._hideMainWindow = true;
									WindowsApi.PostMessage(base.Handle, WindowsApi.WM_CLOSE, 0, 0);
								}
								else
								{
									this._formCreator.ShowError(string.Format(Resources.MainForm_AppUpdateRunError, "-1"));
								}
							}
							catch (Exception ex)
							{
								this._formCreator.ShowError(string.Format(Resources.MainForm_AppUpdateRunError, ex.Message));
							}
							process.Dispose();
							return;
						}
						if (@params.Result == AppUpdateMode.RemindLater)
						{
							this._formsSettings.UserIniFile.WriteLong("AppRemindLaterTime", (long)ApiUtils.DateTimeToUnixTime(DateTime.Now.ToUniversalTime()));
							return;
						}
					}
				}
				else if (!isCalledFromAppStart)
				{
					this._formCreator.ShowInfo(Resources.MainForm_AppIsUptoDate);
				}
			}
		}

		// Token: 0x0600075F RID: 1887 RVA: 0x00040168 File Offset: 0x0003E368
		private void FillAppDeviceCheckPopup()
		{
			this.miDeviceAppCheckUseBlackList.ItemLinks.Clear();
			this.miDeviceAppCheckUseBlackList.Tag = ConsoleEventType.SetDeviceAppUseBlackList;
			this.miDeviceAppCheckUseWhiteList.ItemLinks.Clear();
			this.miDeviceAppCheckUseWhiteList.Tag = ConsoleEventType.SetDeviceAppUseWhiteList;
			this.miDeviceAppCheck.Tag = ConsoleEventType.SetDeviceAppCheck;
			foreach (AppCategory appCategory in this._apiClient.AppCategories)
			{
				BarButtonItem item = new BarButtonItem(this.ribbonControl.Manager, appCategory.Name)
				{
					Tag = appCategory.Id
				};
				if (appCategory.CategoryType == AppCategoryType.AppWhiteList)
				{
					item.ItemClick += this.miDeviceAppCheckWhiteLists_ItemClick;
					this.miDeviceAppCheckUseWhiteList.ItemLinks.Add(item);
				}
				else if (appCategory.CategoryType == AppCategoryType.AppBlackList)
				{
					item.ItemClick += this.miDeviceAppCheckBlackLists_ItemClick;
					this.miDeviceAppCheckUseBlackList.ItemLinks.Add(item);
				}
			}
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x00040290 File Offset: 0x0003E490
		private void FillConsoleDefPopups()
		{
			this.popupMenuFavoriteProcesses.ItemLinks.Clear();
			this.popupMenuFavoriteMessages.ItemLinks.Clear();
			List<StartProcessDef> favoriteProcessDefs = new List<StartProcessDef>();
			List<ShowMessageDef> favoriteMessagesDefs = new List<ShowMessageDef>();
			foreach (ConsoleDef consoleDef in this._apiClient.ConsoleDefs)
			{
				ConsoleDefType type = consoleDef.Type;
				if (type != ConsoleDefType.ShowMessage)
				{
					if (type == ConsoleDefType.StartProcess)
					{
						StartProcessDef processDef = consoleDef.AsProcessDef();
						if (processDef != null && processDef.IsFavorite && processDef.IsAvailableForUser(this._apiClient.UserId))
						{
							favoriteProcessDefs.Add(processDef);
						}
					}
				}
				else
				{
					ShowMessageDef showMessageDef = consoleDef.AsShowMessageDef();
					if (showMessageDef != null && showMessageDef.IsFavorite && showMessageDef.IsAvailableForUser(this._apiClient.UserId))
					{
						favoriteMessagesDefs.Add(showMessageDef);
					}
				}
			}
			foreach (StartProcessDef processDef2 in from x in favoriteProcessDefs
			orderby x.DisplayName
			select x)
			{
				BarButtonItem item = new BarButtonItem(this.ribbonControl.Manager, processDef2.DisplayName)
				{
					Tag = processDef2
				};
				item.ImageOptions.Image = Resources.media_16x16;
				item.ItemClick += this.OnStartProcessItemClick;
				this.popupMenuFavoriteProcesses.ItemLinks.Add(item);
			}
			this.miShowProcessesDef.ButtonStyle = (this.popupMenuFavoriteProcesses.ItemLinks.Any<BarItemLink>() ? BarButtonStyle.DropDown : BarButtonStyle.Default);
			foreach (ShowMessageDef showMessageDef2 in from x in favoriteMessagesDefs
			orderby x.DisplayName
			select x)
			{
				BarButtonItem item2 = new BarButtonItem(this.ribbonControl.Manager, showMessageDef2.DisplayName)
				{
					Tag = showMessageDef2
				};
				item2.ImageOptions.Image = Resources.newcomment_16x16;
				item2.ItemClick += this.OnShowMessageItemClick;
				this.popupMenuFavoriteMessages.ItemLinks.Add(item2);
			}
			this.miShowMessagesDef.ButtonStyle = (this.popupMenuFavoriteMessages.ItemLinks.Any<BarItemLink>() ? BarButtonStyle.DropDown : BarButtonStyle.Default);
		}

		// Token: 0x06000761 RID: 1889 RVA: 0x00040528 File Offset: 0x0003E728
		private void FillDesktopsPopup()
		{
			this.popupMenuDesktops.ItemLinks.Clear();
			foreach (Desktop desktop in this._apiClient.Desktops)
			{
				BarButtonItem item = new BarButtonItem(this.ribbonControl.Manager, desktop.Name)
				{
					Tag = desktop.Id
				};
				item.ItemClick += this.OnSetDeviceAppStrictToDesktopClick;
				this.popupMenuDesktops.ItemLinks.Add(item);
			}
		}

		// Token: 0x06000762 RID: 1890 RVA: 0x000405CC File Offset: 0x0003E7CC
		private void FillUrlAllowedCategoriesPopup()
		{
			this.popupMenuUrlAllowedCategories.ItemLinks.Clear();
			foreach (URLCategory urlCategory in this._apiClient.URLCategories)
			{
				if (this._apiClient.GetURLCategoryControlState(urlCategory.Id) == ControlState.Allow)
				{
					BarButtonItem item = new BarButtonItem(this.ribbonControl.Manager, urlCategory.Name)
					{
						Tag = urlCategory.Id
					};
					item.ItemClick += this.OnSetInetStrictCategoryItemClick;
					this.popupMenuUrlAllowedCategories.ItemLinks.Add(item);
				}
			}
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x00040684 File Offset: 0x0003E884
		private bool GetAppInstallersInfo()
		{
			CancellationTokenSource cts = new CancellationTokenSource();
			Task<AppInstallersInfo> task = this._apiClient.GetAppInstallersInfo();
			if (this._formCreator.Show<WaitForTaskForm, WaitForTaskFormParams>(new WaitForTaskFormParams(Resources.MainForm_CheckAppUpdatesTitle, task, cts)))
			{
				this._appInstallersInfo = task.Result;
				RepeatedField<InstallerFileInfo> agentFiles = this._appInstallersInfo.AgentFiles;
				string latestAgentVersion;
				if (agentFiles == null)
				{
					latestAgentVersion = null;
				}
				else
				{
					InstallerFileInfo latest = agentFiles.GetLatest();
					latestAgentVersion = ((latest != null) ? latest.Version : null);
				}
				this._latestAgentVersion = latestAgentVersion;
				return true;
			}
			return false;
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x000406F4 File Offset: 0x0003E8F4
		private DeviceTreeItemBase GetFocusedGroupOrDevice()
		{
			DeviceTreeItemBase focusedItem = this._devicesTree.FocusedItem;
			if (focusedItem == null || focusedItem is DevicesGroupItem || focusedItem is DeviceItem)
			{
				return focusedItem;
			}
			if (focusedItem is DisplayItem || focusedItem is AgentItem)
			{
				return this._devicesTree.FindDeviceById(focusedItem.ParentId);
			}
			return null;
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x00040748 File Offset: 0x0003E948
		private void gridViewDiagnostic_CustomRowFilter(object sender, RowFilterEventArgs e)
		{
			if (this._devicesTree.Selection.IsAllDevicesGroupSelected)
			{
				return;
			}
			DeviceEvent operation = this._observableAgregator.DeviceEventsLog[e.ListSourceRow];
			e.Visible = this._devicesTree.Selection.ShouldShowSelectedDeviceLog(operation.DeviceId, operation.SessionNo);
			e.Handled = true;
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x000407A8 File Offset: 0x0003E9A8
		private void gridViewDiagnostic_RowCountChanged(object sender, EventArgs e)
		{
			if (this.gridDiagnosticColumnDate.SortOrder == ColumnSortOrder.Ascending)
			{
				this.gridViewDiagnostic.FocusedRowHandle = this.gridViewDiagnostic.RowCount - 1;
			}
			if (this.gridDiagnosticColumnDate.SortOrder == ColumnSortOrder.Descending)
			{
				this.gridViewDiagnostic.FocusedRowHandle = 0;
			}
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x000407F5 File Offset: 0x0003E9F5
		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			this._formClosing = true;
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x00040800 File Offset: 0x0003EA00
		private void MainForm_Load(object sender, EventArgs e)
		{
			this.RibbonSelectedPageChanged(this.ribbonControl.SelectedPage, null);
			this._formsSettings.RestoreObjectsState(base.Name, this._objectsToSaveState);
			try
			{
				this.ribbonControl.Toolbar.RestoreLayoutFromXml(this.QuickAccessToolbarLayoutFile());
			}
			catch (Exception)
			{
			}
			this.Ribbon.Toolbar.ItemLinks.CollectionChanged += this.QuickToolbarItemLinksCollectionChanged;
			this.barCheckDiagnosticWnd.Checked = (this.splitterDiagnosticWnd.PanelVisibility == SplitPanelVisibility.Both);
			this._apiClient.StartEventStream();
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x000408A8 File Offset: 0x0003EAA8
		private void MainView_FormClosed(object sender, FormClosedEventArgs e)
		{
			this._apiClient.CloseConnection();
			this._viewsManager.DoneViews();
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x000408C0 File Offset: 0x0003EAC0
		private void miAppCategories_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<AppCategoriesForm>();
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x000408CE File Offset: 0x0003EACE
		private void miChangePassword_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<ChangePasswordForm>();
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x000408DC File Offset: 0x0003EADC
		private void miCheckAppUpdates_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.CheckAppUpdates(false);
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x000408E5 File Offset: 0x0003EAE5
		private void miCommandMenuItemClick(object sender, ItemClickEventArgs e)
		{
			this._commandExecutor.ExecuteCommand(e.Item, null);
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x000408F9 File Offset: 0x0003EAF9
		private void miCreateAppToken_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<CreateAppTokenForm>();
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x00040908 File Offset: 0x0003EB08
		private void miCreateDevicesGroup_ItemClick(object sender, ItemClickEventArgs e)
		{
			DeviceTreeItemBase item = new DeviceTreeItemBase();
			if (this._formCreator.Show<DevicesGroupForm, DeviceTreeItemBase>(FormAction.Create, item))
			{
				this.devicesTreePanel.RefreshDataSource();
				this.devicesTreePanel.FocusItem(item.Id);
			}
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x00040947 File Offset: 0x0003EB47
		private void miCustomerInfo_ItemClick(object sender, ItemClickEventArgs e)
		{
			if (this._formCreator.Show<CustomerInfoForm>(FormAction.Update))
			{
				this.SetAppTitle();
			}
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00040960 File Offset: 0x0003EB60
		private void miDefaultFonts_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.fontDialog.Font = WindowsFormsSettings.DefaultFont;
			if (this.fontDialog.ShowDialog() == DialogResult.OK)
			{
				WindowsFormsSettings.DefaultFont = this.fontDialog.Font;
				FontConverter fontConverter = new FontConverter();
				this._formsSettings.UserIniFile.WriteString("DefaultFont", fontConverter.ConvertToInvariantString(WindowsFormsSettings.DefaultFont));
			}
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x000409C4 File Offset: 0x0003EBC4
		private void miDeleteDevicesGroup_ItemClick(object sender, ItemClickEventArgs e)
		{
			MainForm.<miDeleteDevicesGroup_ItemClick>d__50 <miDeleteDevicesGroup_ItemClick>d__;
			<miDeleteDevicesGroup_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<miDeleteDevicesGroup_ItemClick>d__.<>4__this = this;
			<miDeleteDevicesGroup_ItemClick>d__.<>1__state = -1;
			<miDeleteDevicesGroup_ItemClick>d__.<>t__builder.Start<MainForm.<miDeleteDevicesGroup_ItemClick>d__50>(ref <miDeleteDevicesGroup_ItemClick>d__);
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x000409FB File Offset: 0x0003EBFB
		private void miDesktops_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<DesktopsListForm>();
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x00040A09 File Offset: 0x0003EC09
		private void miDeviceAppCheckBlackLists_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._commandExecutor.ExecuteCommand(this.miDeviceAppCheckUseBlackList, e.Item.Tag);
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x00040A27 File Offset: 0x0003EC27
		private void miDeviceAppCheckWhiteLists_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._commandExecutor.ExecuteCommand(this.miDeviceAppCheckUseWhiteList, e.Item.Tag);
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x00040A48 File Offset: 0x0003EC48
		private void miDeviceEdit_ItemClick(object sender, ItemClickEventArgs e)
		{
			DeviceTreeItemBase focusedItem = this.GetFocusedGroupOrDevice();
			if (focusedItem == null)
			{
				this._formCreator.ShowInfo(Resources.MainForm_MustSelectDeviceOrGroupToEdit);
				return;
			}
			if (focusedItem.IsGroup)
			{
				this._formCreator.Show<DevicesGroupForm, DeviceTreeItemBase>(FormAction.Update, focusedItem);
				return;
			}
			this._formCreator.Show<DeviceForm, DeviceItem>(FormAction.Update, focusedItem as DeviceItem);
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x00040A9C File Offset: 0x0003EC9C
		private void miMoveDevice_ItemClick(object sender, ItemClickEventArgs e)
		{
			MainForm.<miMoveDevice_ItemClick>d__55 <miMoveDevice_ItemClick>d__;
			<miMoveDevice_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<miMoveDevice_ItemClick>d__.<>4__this = this;
			<miMoveDevice_ItemClick>d__.<>1__state = -1;
			<miMoveDevice_ItemClick>d__.<>t__builder.Start<MainForm.<miMoveDevice_ItemClick>d__55>(ref <miMoveDevice_ItemClick>d__);
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x00040AD3 File Offset: 0x0003ECD3
		private void miRoles_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<RolesForm>();
		}

		// Token: 0x06000779 RID: 1913 RVA: 0x00040AE1 File Offset: 0x0003ECE1
		private void miRules_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<RulesDefListForm>();
		}

		// Token: 0x0600077A RID: 1914 RVA: 0x00040AEF File Offset: 0x0003ECEF
		private void miUrlCategories_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<UrlCategoriesForm>();
		}

		// Token: 0x0600077B RID: 1915 RVA: 0x00040B00 File Offset: 0x0003ED00
		private Task MoveItemsToGroup(List<DevicesGroupItem> groupsList, List<DeviceItem> devicesList, DevicesGroupItem newGroup)
		{
			MainForm.<MoveItemsToGroup>d__59 <MoveItemsToGroup>d__;
			<MoveItemsToGroup>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<MoveItemsToGroup>d__.<>4__this = this;
			<MoveItemsToGroup>d__.groupsList = groupsList;
			<MoveItemsToGroup>d__.devicesList = devicesList;
			<MoveItemsToGroup>d__.newGroup = newGroup;
			<MoveItemsToGroup>d__.<>1__state = -1;
			<MoveItemsToGroup>d__.<>t__builder.Start<MainForm.<MoveItemsToGroup>d__59>(ref <MoveItemsToGroup>d__);
			return <MoveItemsToGroup>d__.<>t__builder.Task;
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x00040B5C File Offset: 0x0003ED5C
		private void OnAgentConnectionChanged(AgentClient agentClient)
		{
			if (!string.IsNullOrEmpty(this._latestAgentVersion) && this._hasAdminPermission && agentClient.IsConnected && SsStringUtils.IsAppVersionNeverThat(agentClient.AppVersion, this._latestAgentVersion))
			{
				string msg = string.Format(Resources.MainForm_NewVersionOfAgentAvaliableMessage, this._latestAgentVersion);
				this._latestAgentVersion = string.Empty;
				AlertInfo info = new AlertInfo(Resources.MainForm_NewVersionOfAgentAvaliableCaption, msg)
				{
					Image = Resources.settings_update_agents_32x32
				};
				this.alertControlAgentUpdate.Show(this, info);
			}
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x00040BDC File Offset: 0x0003EDDC
		private void OnApiCollectionUpdated(int collectionId)
		{
			if (collectionId == 10 || collectionId == 11)
			{
				this.ApplyRoleSettings();
			}
			if (collectionId == 9 || collectionId == 8)
			{
				this.FillUrlAllowedCategoriesPopup();
			}
			if (collectionId == 15 || collectionId == 8)
			{
				this.FillDesktopsPopup();
			}
			if (collectionId == 12)
			{
				this.FillConsoleDefPopups();
			}
			if (collectionId == 17)
			{
				this.FillAppDeviceCheckPopup();
			}
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x00040C2D File Offset: 0x0003EE2D
		private void OnApiConnected(bool isConnected)
		{
			this.barStaticItemServerConnection.Caption = (isConnected ? Resources.MainForm_ApiServerConnected : Resources.MainForm_ApiServerDisconnected);
			this.barStaticItemServerConnection.Enabled = isConnected;
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x00040C55 File Offset: 0x0003EE55
		private void OnFormCreatorFormShow(string formName)
		{
			if (!this._formNamesExcludedFromconsoleEventsLog.Contains(formName))
			{
				this._apiClient.AddToSystemEventsLog(SystemEventType.ConsoleShowForm, formName.Replace("Form", ""), null);
			}
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x00040C83 File Offset: 0x0003EE83
		private void OnSetDeviceAppStrictToDesktopClick(object o, ItemClickEventArgs itemArgs)
		{
			this._commandExecutor.ExecuteCommand(this.miSetDeviceAppStrictToDesktop, itemArgs.Item.Tag);
		}

		// Token: 0x06000781 RID: 1921 RVA: 0x00040CA1 File Offset: 0x0003EEA1
		private void OnSetInetStrictCategoryItemClick(object o, ItemClickEventArgs itemArgs)
		{
			this._commandExecutor.ExecuteCommand(this.miSetDeviceInetStrict, itemArgs.Item.Tag);
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x00040CBF File Offset: 0x0003EEBF
		private void OnShowMessageItemClick(object o, ItemClickEventArgs itemArgs)
		{
			this._commandExecutor.ExecuteCommand(this.miShowMessagesDef, itemArgs.Item.Tag);
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x00040CDD File Offset: 0x0003EEDD
		private void OnStartProcessItemClick(object o, ItemClickEventArgs itemArgs)
		{
			this._commandExecutor.ExecuteCommand(this.miShowProcessesDef, itemArgs.Item.Tag);
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x00040CFB File Offset: 0x0003EEFB
		private void OnViewChanged(ViewChangedEvent @event)
		{
			this._apiClient.AddToSystemEventsLog(SystemEventType.ConsoleViewChanged, @event.CurrentView.ViewTypeName, null);
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x00040D16 File Offset: 0x0003EF16
		private string QuickAccessToolbarLayoutFile()
		{
			return this._formsSettings.UserDataDir + "quicktoolbar.xml";
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x00040D2D File Offset: 0x0003EF2D
		private void QuickToolbarItemLinksCollectionChanged(object sender, CollectionChangeEventArgs e)
		{
			if (!this._formClosing)
			{
				this.ribbonControl.Toolbar.SaveLayoutToXml(this.QuickAccessToolbarLayoutFile());
			}
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x00040D50 File Offset: 0x0003EF50
		private void RibbonSelectedPageChanged(object sender, EventArgs e)
		{
			if (this._viewsManager != null && !string.IsNullOrEmpty(this.ribbonControl.SelectedPage.Name))
			{
				this._viewsManager.ShowViewGroup(this.ribbonControl.SelectedPage.Name.Substring(9));
			}
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00040DA0 File Offset: 0x0003EFA0
		private void SetAppTitle()
		{
			this.Text = string.Concat(new string[]
			{
				"OpiekunWEB ",
				this._apiClient.AppVersion,
				"  (",
				this._apiClient.Login,
				" ",
				this._apiClient.KeyDescriptionOrName,
				")"
			});
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x00040E08 File Offset: 0x0003F008
		private void timerCheckIdle_Tick(object sender, EventArgs e)
		{
			if (IdleTime.IsIdleTime())
			{
				if (!this._isIdle)
				{
					this._isIdle = true;
					this.miIsIdle.Visibility = BarItemVisibility.Always;
					this.timerCheckIdle.Interval = 500;
					return;
				}
			}
			else if (this._isIdle)
			{
				this._isIdle = false;
				this.miIsIdle.Visibility = BarItemVisibility.Never;
				this.timerCheckIdle.Interval = 3000;
				this._viewsManager.RefreshCurrentView();
			}
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x000455A0 File Offset: 0x000437A0
		[CompilerGenerated]
		internal static BarButtonItem <FillPopupMenu>g__createNewBarManagerItem|15_0(BarButtonItem sourceItem, BarManager barManager, CommandExecutor cmdExecutor)
		{
			BarButtonItem result = new BarButtonItem
			{
				Caption = sourceItem.Caption
			};
			result.ImageOptions.Image = sourceItem.ImageOptions.Image;
			result.ImageOptions.LargeImage = sourceItem.ImageOptions.LargeImage;
			result.Name = sourceItem.Name;
			result.Hint = sourceItem.Hint;
			result.ButtonStyle = sourceItem.ButtonStyle;
			result.DropDownControl = sourceItem.DropDownControl;
			result.Tag = sourceItem.Tag;
			result.ItemClick += cmdExecutor.OnMenuItemClick;
			barManager.Items.Add(result);
			return result;
		}

		// Token: 0x0600078E RID: 1934 RVA: 0x00045648 File Offset: 0x00043848
		[CompilerGenerated]
		internal static BarSubItem <FillPopupMenu>g__createBarManagerSubmenu|15_1(BarButtonItem imagesItem, string caption, BarManager barManager, BarButtonItem[] sourceSubItems, BarButtonItem[] beginGroupSubItems, CommandExecutor cmdExecutor)
		{
			BarSubItem result = new BarSubItem
			{
				Caption = caption
			};
			result.ImageOptions.Image = imagesItem.ImageOptions.Image;
			result.ImageOptions.LargeImage = imagesItem.ImageOptions.LargeImage;
			for (int i = 0; i < sourceSubItems.Length; i++)
			{
				BarButtonItem item = sourceSubItems[i];
				LinkPersistInfo link = new LinkPersistInfo(MainForm.<FillPopupMenu>g__createNewBarManagerItem|15_0(item, barManager, cmdExecutor));
				if (beginGroupSubItems != null && Array.Find<BarButtonItem>(beginGroupSubItems, (BarButtonItem x) => x == item) != null)
				{
					link.BeginGroup = true;
				}
				result.LinksPersistInfo.Add(link);
			}
			barManager.Items.Add(result);
			return result;
		}

		// Token: 0x0600078F RID: 1935 RVA: 0x000456FF File Offset: 0x000438FF
		[CompilerGenerated]
		private bool <ApplyRoleSettings>g__hasApiPermission|25_0(string permissionId)
		{
			return this._apiClient.IsLoggedUserHasPermissionSetToValue(permissionId, "1");
		}

		// Token: 0x06000790 RID: 1936 RVA: 0x00045712 File Offset: 0x00043912
		[CompilerGenerated]
		private void <ApplyRoleSettings>g__addToDisabledCommands|25_1(ConsoleEventType consoleEvent, bool isAllowed)
		{
			if (!isAllowed)
			{
				this._commandsDisabledByRole.Add(consoleEvent);
			}
		}

		// Token: 0x0400051F RID: 1311
		private readonly ApiClient _apiClient;

		// Token: 0x04000520 RID: 1312
		private readonly CommandExecutor _commandExecutor;

		// Token: 0x04000521 RID: 1313
		private readonly List<ConsoleEventType> _commandsAlwaysEnabled;

		// Token: 0x04000522 RID: 1314
		private readonly List<ConsoleEventType> _commandsDisabledByRole;

		// Token: 0x04000523 RID: 1315
		private readonly DevicesTree _devicesTree;

		// Token: 0x04000524 RID: 1316
		private readonly List<string> _formNamesExcludedFromconsoleEventsLog;

		// Token: 0x04000525 RID: 1317
		private readonly ObservableAgregator _observableAgregator;

		// Token: 0x04000526 RID: 1318
		private readonly ViewsManager _viewsManager;

		// Token: 0x04000527 RID: 1319
		private AppInstallersInfo _appInstallersInfo;

		// Token: 0x04000528 RID: 1320
		private bool _formClosing;

		// Token: 0x04000529 RID: 1321
		private bool _hasAdminPermission;

		// Token: 0x0400052A RID: 1322
		private bool _hideMainWindow;

		// Token: 0x0400052B RID: 1323
		private bool _isIdle;

		// Token: 0x0400052C RID: 1324
		private string _latestAgentVersion;
	}
}
