﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Mask;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using DevExpress.XtraTab;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000055 RID: 85
	public partial class RdpParamsForm : BaseForm
	{
		// Token: 0x06000499 RID: 1177 RVA: 0x00016087 File Offset: 0x00014287
		public RdpParamsForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x00016098 File Offset: 0x00014298
		public RdpParamsForm(FormsSettings formsSettings, IFormCreator formCreator, RdpParams @params) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this._params = @params;
			this.InitializeComponent();
			EnumHelpers.InitializeComboBoxAsStringKeyAndValue<RemoteDesktopSize>(this.comboBoxDesktopSize, RemoteDesktopSize.FitToWindow, Resources.ResourceManager);
			this._formsSettings.RestoreObjectState(base.Name, this.comboBoxDesktopSize, null);
			EnumHelpers.InitializeComboBoxAsStringKeyAndValue<RemoteDesktopColorsDepth>(this.comboBoxColorsDepth, RemoteDesktopColorsDepth.Bits16, Resources.ResourceManager);
			this._formsSettings.RestoreObjectState(base.Name, this.comboBoxDesktopSize, null);
			this._objectsToSaveState.Add(this.textEditUserName);
			this._objectsToSaveState.Add(this.textEditDomainName);
			this._objectsToSaveState.Add(this.spinEditPort);
			this._objectsToSaveState.Add(this.checkEditConnectToConsole);
			this._objectsToSaveState.Add(this.comboBoxDesktopSize);
			this._objectsToSaveState.Add(this.comboBoxColorsDepth);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x00016174 File Offset: 0x00014374
		private void buttonOk_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this.textEditUserName.Text))
			{
				this._formCreator.ShowError(Resources.LogonSessionFormParams_MustEnterUserName);
				base.ActiveControl = this.textEditUserName;
				return;
			}
			this._params.DomainName = this.textEditDomainName.Text;
			this._params.UserName = this.textEditUserName.Text;
			this._params.Password = this.textEditPassword.Text;
			this._params.Port = (int)this.spinEditPort.Value;
			this._params.ConnectToConsole = this.checkEditConnectToConsole.Checked;
			this._params.ColorsDepth = EnumHelpers.GetComboEnumValueFromKeyAndValue<RemoteDesktopColorsDepth>(this.comboBoxColorsDepth);
			this._params.DesktopSize = EnumHelpers.GetComboEnumValueFromKeyAndValue<RemoteDesktopSize>(this.comboBoxDesktopSize);
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00016256 File Offset: 0x00014456
		private void RdpParamsForm_Load(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(this.textEditUserName.Text))
			{
				base.ActiveControl = this.textEditPassword;
				return;
			}
			base.ActiveControl = this.textEditUserName;
		}

		// Token: 0x040001EB RID: 491
		private readonly RdpParams _params;
	}
}
