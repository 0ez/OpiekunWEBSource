﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000057 RID: 87
	public class BaseUserControl : XtraUserControl
	{
		// Token: 0x060004AD RID: 1197 RVA: 0x00017CED File Offset: 0x00015EED
		public BaseUserControl()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x00017CFB File Offset: 0x00015EFB
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x00017D1A File Offset: 0x00015F1A
		private void InitializeComponent()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BaseUserControl));
			base.SuspendLayout();
			componentResourceManager.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Name = "BaseUserControl";
			base.ResumeLayout(false);
		}

		// Token: 0x04000212 RID: 530
		private IContainer components;
	}
}
