﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils;
using DevExpress.XtraBars;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000071 RID: 113
	public partial class RulesDefListForm : ConsoleDefBaseForm
	{
		// Token: 0x060005F5 RID: 1525 RVA: 0x00029DD7 File Offset: 0x00027FD7
		public RulesDefListForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00029DE5 File Offset: 0x00027FE5
		public RulesDefListForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient) : base(formsSettings, formCreator, apiClient)
		{
			this.InitializeComponent();
			this.gridRules.DataSource = this._apiClient.Rules;
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x00029E0C File Offset: 0x0002800C
		private void barButtonAdd_ItemClick(object sender, ItemClickEventArgs e)
		{
			this._formCreator.Show<SelectConsoleGroupsOnDeviceRuleForm>(FormAction.Create);
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x00029E1C File Offset: 0x0002801C
		private void barButtonDelete_ItemClick(object sender, ItemClickEventArgs e)
		{
			RulesDefListForm.<barButtonDelete_ItemClick>d__3 <barButtonDelete_ItemClick>d__;
			<barButtonDelete_ItemClick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<barButtonDelete_ItemClick>d__.<>4__this = this;
			<barButtonDelete_ItemClick>d__.<>1__state = -1;
			<barButtonDelete_ItemClick>d__.<>t__builder.Start<RulesDefListForm.<barButtonDelete_ItemClick>d__3>(ref <barButtonDelete_ItemClick>d__);
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x00029E54 File Offset: 0x00028054
		private void barButtonEdit_ItemClick(object sender, ItemClickEventArgs e)
		{
			Rule rule = this.GetFocusedRule();
			if (rule != null)
			{
				SelectConsoleGroupsOnDeviceRuleFormParams @params = new SelectConsoleGroupsOnDeviceRuleFormParams
				{
					Rule = rule
				};
				SelectConsoleGroupsOnDeviceRuleFormParams selectConsoleGroupsOnDeviceRuleFormParams;
				this._formCreator.Show<SelectConsoleGroupsOnDeviceRuleForm, SelectConsoleGroupsOnDeviceRuleFormParams>(FormAction.Update, @params, out selectConsoleGroupsOnDeviceRuleFormParams);
			}
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00029E88 File Offset: 0x00028088
		private Rule GetFocusedRule()
		{
			return this.gridViewRules.GetFocusedRow() as Rule;
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x00029E9C File Offset: 0x0002809C
		private void gridViewRules_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this.barButtonDelete.Enabled = this.gridViewRules.IsDataRow(e.FocusedRowHandle);
			this.barButtonEdit.Enabled = this.gridViewRules.IsDataRow(e.FocusedRowHandle);
			this.barButtonLaunch.Enabled = this.gridViewRules.IsDataRow(e.FocusedRowHandle);
		}
	}
}
