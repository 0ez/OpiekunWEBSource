﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;
using DevExpress.XtraEditors;
using OpiekunWEB.Console.Events;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Observable;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000086 RID: 134
	public class BaseView : XtraUserControl
	{
		// Token: 0x0600073D RID: 1853 RVA: 0x0003F0F8 File Offset: 0x0003D2F8
		public BaseView()
		{
			this._objectsToSaveState = new List<object>();
			this.InitializeComponent();
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x0003F114 File Offset: 0x0003D314
		public BaseView(FormsSettings formsSettings, IFormCreator formCreator, ObservableAgregator observableAgregator, DevicesTree devicesTree) : this()
		{
			this._formsSettings = formsSettings;
			this._formCreator = formCreator;
			this._observableAgregator = observableAgregator;
			this._devicesTree = devicesTree;
			this._observableAgregator.ViewChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<ViewChangedEvent>(this.OnViewChanged));
			this._observableAgregator.SelectedDeviceChangedStream.ObserveOn(Dispatcher.CurrentDispatcher).Subscribe(new Action<DevicesAndGroupsSelection>(this.OnSelectedDeviceChanged));
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x0600073F RID: 1855 RVA: 0x0003F194 File Offset: 0x0003D394
		// (set) Token: 0x06000740 RID: 1856 RVA: 0x0003F19C File Offset: 0x0003D39C
		protected bool IsCurrentView { get; set; }

		// Token: 0x06000741 RID: 1857 RVA: 0x0003F1A8 File Offset: 0x0003D3A8
		public IEnumerable<Control> GetAllControls(Control control)
		{
			IEnumerable<Control> controls = control.Controls.Cast<Control>();
			return controls.SelectMany(new Func<Control, IEnumerable<Control>>(this.GetAllControls)).Concat(controls);
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void AfterRestoreState()
		{
		}

		// Token: 0x06000743 RID: 1859 RVA: 0x0003F1D9 File Offset: 0x0003D3D9
		protected virtual void BeforeDispose()
		{
			FormsSettings formsSettings = this._formsSettings;
			if (formsSettings == null)
			{
				return;
			}
			formsSettings.SaveObjectsState(base.Name, this._objectsToSaveState);
		}

		// Token: 0x06000744 RID: 1860 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void BeforeRestoreState()
		{
		}

		// Token: 0x06000745 RID: 1861 RVA: 0x0003F1F8 File Offset: 0x0003D3F8
		protected Task<bool> DoTaskInSplash(Task task, bool catchException)
		{
			BaseView.<DoTaskInSplash>d__15 <DoTaskInSplash>d__;
			<DoTaskInSplash>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<DoTaskInSplash>d__.<>4__this = this;
			<DoTaskInSplash>d__.task = task;
			<DoTaskInSplash>d__.catchException = catchException;
			<DoTaskInSplash>d__.<>1__state = -1;
			<DoTaskInSplash>d__.<>t__builder.Start<BaseView.<DoTaskInSplash>d__15>(ref <DoTaskInSplash>d__);
			return <DoTaskInSplash>d__.<>t__builder.Task;
		}

		// Token: 0x06000746 RID: 1862 RVA: 0x0003F24C File Offset: 0x0003D44C
		protected Task<bool> DoTaskInSplash(Task[] tasks, bool catchException)
		{
			BaseView.<DoTaskInSplash>d__16 <DoTaskInSplash>d__;
			<DoTaskInSplash>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<DoTaskInSplash>d__.<>4__this = this;
			<DoTaskInSplash>d__.tasks = tasks;
			<DoTaskInSplash>d__.catchException = catchException;
			<DoTaskInSplash>d__.<>1__state = -1;
			<DoTaskInSplash>d__.<>t__builder.Start<BaseView.<DoTaskInSplash>d__16>(ref <DoTaskInSplash>d__);
			return <DoTaskInSplash>d__.<>t__builder.Task;
		}

		// Token: 0x06000747 RID: 1863 RVA: 0x0003F29F File Offset: 0x0003D49F
		protected override void OnFirstLoad()
		{
			base.OnFirstLoad();
			this.BeforeRestoreState();
			FormsSettings formsSettings = this._formsSettings;
			if (formsSettings != null)
			{
				formsSettings.RestoreObjectsState(base.Name, this._objectsToSaveState);
			}
			this.AfterRestoreState();
		}

		// Token: 0x06000748 RID: 1864 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void OnSelectedDeviceChanged(DevicesAndGroupsSelection selection)
		{
		}

		// Token: 0x06000749 RID: 1865 RVA: 0x0003F2D0 File Offset: 0x0003D4D0
		protected virtual void OnViewChanged(ViewChangedEvent @event)
		{
			bool isCurrentBefore = this.IsCurrentView;
			this.IsCurrentView = @event.IsCurrentView(this);
			if (!isCurrentBefore && this.IsCurrentView)
			{
				this.ViewActivate();
				return;
			}
			if (isCurrentBefore && !this.IsCurrentView)
			{
				this.ViewDeactivate();
			}
		}

		// Token: 0x0600074A RID: 1866 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void ViewActivate()
		{
		}

		// Token: 0x0600074B RID: 1867 RVA: 0x00003A2C File Offset: 0x00001C2C
		protected virtual void ViewDeactivate()
		{
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x0003F314 File Offset: 0x0003D514
		protected override void Dispose(bool disposing)
		{
			this.BeforeDispose();
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600074D RID: 1869 RVA: 0x0003F339 File Offset: 0x0003D539
		private void InitializeComponent()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(BaseView));
			base.SuspendLayout();
			componentResourceManager.ApplyResources(this, "$this");
			base.AutoScaleMode = AutoScaleMode.Font;
			base.Name = "BaseView";
			base.ResumeLayout(false);
		}

		// Token: 0x04000518 RID: 1304
		protected readonly IFormCreator _formCreator;

		// Token: 0x04000519 RID: 1305
		protected readonly FormsSettings _formsSettings;

		// Token: 0x0400051A RID: 1306
		protected DevicesTree _devicesTree;

		// Token: 0x0400051B RID: 1307
		protected List<object> _objectsToSaveState;

		// Token: 0x0400051C RID: 1308
		protected ObservableAgregator _observableAgregator;

		// Token: 0x0400051E RID: 1310
		private IContainer components;
	}
}
