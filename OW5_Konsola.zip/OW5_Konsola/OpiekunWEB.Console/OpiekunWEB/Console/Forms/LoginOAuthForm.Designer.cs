﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000053 RID: 83
	public partial class LoginOAuthForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000492 RID: 1170 RVA: 0x00015723 File Offset: 0x00013923
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x00015744 File Offset: 0x00013944
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.LoginOAuthForm));
			this.webBrowser = new global::System.Windows.Forms.WebBrowser();
			base.SuspendLayout();
			this.webBrowser.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.webBrowser.Location = new global::System.Drawing.Point(0, 0);
			this.webBrowser.MinimumSize = new global::System.Drawing.Size(20, 20);
			this.webBrowser.Name = "webBrowser";
			this.webBrowser.Size = new global::System.Drawing.Size(800, 450);
			this.webBrowser.TabIndex = 1;
			this.webBrowser.Url = new global::System.Uri("", global::System.UriKind.Relative);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(800, 450);
			base.Controls.Add(this.webBrowser);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("LoginOAuthForm.IconOptions.Icon");
			base.MaximizeBox = true;
			base.MinimizeBox = true;
			base.Name = "LoginOAuthForm";
			this.Text = "LoginOAuthForm";
			base.ResumeLayout(false);
		}

		// Token: 0x040001DC RID: 476
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040001DD RID: 477
		private global::System.Windows.Forms.WebBrowser webBrowser;
	}
}
