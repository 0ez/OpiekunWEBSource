﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005A RID: 90
	public partial class NonModalBaseForm : BaseForm
	{
		// Token: 0x060004CE RID: 1230 RVA: 0x00018298 File Offset: 0x00016498
		public NonModalBaseForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x000182A6 File Offset: 0x000164A6
		public NonModalBaseForm(FormsSettings formsSettings, IFormCreator formCreator) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x000182B7 File Offset: 0x000164B7
		protected override void BeforeRestoreState()
		{
			if (!base.DesignMode)
			{
				base.BeforeRestoreState();
				base.CenterInParent();
			}
		}
	}
}
