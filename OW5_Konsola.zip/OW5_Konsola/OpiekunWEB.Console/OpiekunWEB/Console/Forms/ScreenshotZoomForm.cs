﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007F RID: 127
	public partial class ScreenshotZoomForm : BaseForm
	{
		// Token: 0x060006CD RID: 1741 RVA: 0x0003A748 File Offset: 0x00038948
		public ScreenshotZoomForm(ApiClient apiClient, ScreenshotZoomFormParams @params)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
			this._params = @params;
			this._cts = new CancellationTokenSource();
			this.timerRefresh.Interval = ((@params.RefreshInterval >= 1000) ? @params.RefreshInterval : 5000);
			ScreenshotZoomForm._isClosed = false;
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x0003A7A5 File Offset: 0x000389A5
		private void FormScreenshotZoom_FormClosing(object sender, FormClosingEventArgs e)
		{
			this.timerRefresh.Enabled = false;
			this._cts.Cancel();
			ScreenshotZoomForm._isClosed = true;
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x0003A7C4 File Offset: 0x000389C4
		private void FormScreenshotZoom_Shown(object sender, EventArgs e)
		{
			ScreenshotZoomForm.<FormScreenshotZoom_Shown>d__9 <FormScreenshotZoom_Shown>d__;
			<FormScreenshotZoom_Shown>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<FormScreenshotZoom_Shown>d__.<>4__this = this;
			<FormScreenshotZoom_Shown>d__.<>1__state = -1;
			<FormScreenshotZoom_Shown>d__.<>t__builder.Start<ScreenshotZoomForm.<FormScreenshotZoom_Shown>d__9>(ref <FormScreenshotZoom_Shown>d__);
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x0000228D File Offset: 0x0000048D
		private void pictureScreenshot_MouseClick(object sender, MouseEventArgs e)
		{
			base.Close();
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x0003A7FB File Offset: 0x000389FB
		private void pictureScreenshot_MouseLeave(object sender, EventArgs e)
		{
			if (!this._needResize && base.Visible)
			{
				base.Close();
			}
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x0003A814 File Offset: 0x00038A14
		private void ResizeForImage(Size screenshootSize)
		{
			WindowsApi.DEVMODE devMode = default(WindowsApi.DEVMODE);
			Screen screen = Screen.FromControl(this);
			float ratio = 1f;
			if (WindowsApi.GetDisplaySettings(screen, ref devMode))
			{
				ratio = (float)devMode.dmPelsWidth / (float)screen.Bounds.Width;
			}
			int desktopWidth = (int)((float)screen.WorkingArea.Width * ratio);
			int desktopHeight = (int)((float)screen.WorkingArea.Height * ratio);
			this._screenshotWidth = ((screenshootSize.Width < desktopWidth) ? screenshootSize.Width : desktopWidth);
			this._screenshotHeight = ((screenshootSize.Height < desktopHeight) ? screenshootSize.Height : desktopHeight);
			base.Width = (int)((float)this._screenshotWidth / ratio);
			base.Height = (int)((float)this._screenshotHeight / ratio);
			base.CenterToScreen();
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x0003A8E0 File Offset: 0x00038AE0
		private Task Screenshot()
		{
			ScreenshotZoomForm.<Screenshot>d__13 <Screenshot>d__;
			<Screenshot>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Screenshot>d__.<>4__this = this;
			<Screenshot>d__.<>1__state = -1;
			<Screenshot>d__.<>t__builder.Start<ScreenshotZoomForm.<Screenshot>d__13>(ref <Screenshot>d__);
			return <Screenshot>d__.<>t__builder.Task;
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x0003A924 File Offset: 0x00038B24
		private void timerRefresh_Tick(object sender, EventArgs e)
		{
			ScreenshotZoomForm.<timerRefresh_Tick>d__14 <timerRefresh_Tick>d__;
			<timerRefresh_Tick>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<timerRefresh_Tick>d__.<>4__this = this;
			<timerRefresh_Tick>d__.<>1__state = -1;
			<timerRefresh_Tick>d__.<>t__builder.Start<ScreenshotZoomForm.<timerRefresh_Tick>d__14>(ref <timerRefresh_Tick>d__);
		}

		// Token: 0x040004B4 RID: 1204
		private static bool _isClosed;

		// Token: 0x040004B5 RID: 1205
		private readonly CancellationTokenSource _cts;

		// Token: 0x040004B6 RID: 1206
		private readonly ScreenshotZoomFormParams _params;

		// Token: 0x040004B7 RID: 1207
		private ApiClient _apiClient;

		// Token: 0x040004B8 RID: 1208
		private bool _needResize;

		// Token: 0x040004B9 RID: 1209
		private int _screenshotHeight;

		// Token: 0x040004BA RID: 1210
		private int _screenshotWidth;
	}
}
