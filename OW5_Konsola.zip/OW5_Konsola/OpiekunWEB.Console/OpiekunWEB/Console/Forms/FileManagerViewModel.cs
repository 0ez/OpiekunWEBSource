﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using DevExpress.Mvvm.DataAnnotations;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000084 RID: 132
	[POCOViewModel]
	public class FileManagerViewModel
	{
		// Token: 0x06000700 RID: 1792 RVA: 0x0003E224 File Offset: 0x0003C424
		public FileManagerViewModel()
		{
			this.LocalFiles = new BindingList<Owpb.FileInfo>();
			this.LocalDrives = new BindingList<Owpb.FileInfo>();
			this.RemoteFiles = new BindingList<Owpb.FileInfo>();
			this.RemoteDrives = new BindingList<Owpb.FileInfo>();
			this.Log = new BindingList<string>();
			this._localDirMacros = new Dictionary<string, string>();
			this._remoteDirMacros = new Dictionary<string, string>();
			this._localDirMacros[Resources.MacroShortDescription_DOCUMENTS_DIR] = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
			this._localDirMacros[Resources.MacroShortDescription_DESKTOP_DIR] = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			this._remoteDirMacros[Resources.MacroShortDescription_DOCUMENTS_DIR] = "{DOCUMENTS_DIR}";
			this._remoteDirMacros[Resources.MacroShortDescription_DESKTOP_DIR] = "{DESKTOP_DIR}";
			this.LocalDrives = this.ReadLocalDrives();
			this.ChangeLocalDir(null);
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x06000701 RID: 1793 RVA: 0x0003E2F0 File Offset: 0x0003C4F0
		// (remove) Token: 0x06000702 RID: 1794 RVA: 0x0003E328 File Offset: 0x0003C528
		public event EventHandler<string> AfterLocalDirChanged;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x06000703 RID: 1795 RVA: 0x0003E360 File Offset: 0x0003C560
		// (remove) Token: 0x06000704 RID: 1796 RVA: 0x0003E398 File Offset: 0x0003C598
		public event EventHandler AfterLogChanged;

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000705 RID: 1797 RVA: 0x0003E3D0 File Offset: 0x0003C5D0
		// (remove) Token: 0x06000706 RID: 1798 RVA: 0x0003E408 File Offset: 0x0003C608
		public event EventHandler<string> AfterRemoteDirChanged;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000707 RID: 1799 RVA: 0x0003E440 File Offset: 0x0003C640
		// (remove) Token: 0x06000708 RID: 1800 RVA: 0x0003E478 File Offset: 0x0003C678
		public event EventHandler AfterTask;

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x06000709 RID: 1801 RVA: 0x0003E4B0 File Offset: 0x0003C6B0
		// (remove) Token: 0x0600070A RID: 1802 RVA: 0x0003E4E8 File Offset: 0x0003C6E8
		public event EventHandler BeforeTask;

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x0600070B RID: 1803 RVA: 0x0003E51D File Offset: 0x0003C71D
		// (set) Token: 0x0600070C RID: 1804 RVA: 0x0003E525 File Offset: 0x0003C725
		public AgentClient AgentClient { get; set; }

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x0600070D RID: 1805 RVA: 0x0003E52E File Offset: 0x0003C72E
		// (set) Token: 0x0600070E RID: 1806 RVA: 0x0003E536 File Offset: 0x0003C736
		public string LocalDir
		{
			get
			{
				return this._localDir;
			}
			set
			{
				this.ChangeLocalDir(value);
			}
		}

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x0600070F RID: 1807 RVA: 0x0003E53F File Offset: 0x0003C73F
		public string LocalDirResolved
		{
			get
			{
				return this.ResolveLocalDir(this.LocalDir);
			}
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x06000710 RID: 1808 RVA: 0x0003E54D File Offset: 0x0003C74D
		// (set) Token: 0x06000711 RID: 1809 RVA: 0x0003E555 File Offset: 0x0003C755
		public virtual BindingList<Owpb.FileInfo> LocalDrives { get; set; }

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x06000712 RID: 1810 RVA: 0x0003E55E File Offset: 0x0003C75E
		// (set) Token: 0x06000713 RID: 1811 RVA: 0x0003E566 File Offset: 0x0003C766
		public virtual BindingList<Owpb.FileInfo> LocalFiles { get; set; }

		// Token: 0x1700026F RID: 623
		// (get) Token: 0x06000714 RID: 1812 RVA: 0x0003E56F File Offset: 0x0003C76F
		// (set) Token: 0x06000715 RID: 1813 RVA: 0x0003E577 File Offset: 0x0003C777
		public virtual BindingList<string> Log { get; set; }

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x06000716 RID: 1814 RVA: 0x0003E580 File Offset: 0x0003C780
		// (set) Token: 0x06000717 RID: 1815 RVA: 0x0003E588 File Offset: 0x0003C788
		public string RemoteDir { get; private set; }

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x06000718 RID: 1816 RVA: 0x0003E591 File Offset: 0x0003C791
		public string RemoteDirResolved
		{
			get
			{
				return this.ResolveRemoteDir(this.RemoteDir);
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06000719 RID: 1817 RVA: 0x0003E59F File Offset: 0x0003C79F
		// (set) Token: 0x0600071A RID: 1818 RVA: 0x0003E5A7 File Offset: 0x0003C7A7
		public virtual BindingList<Owpb.FileInfo> RemoteDrives { get; set; }

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x0600071B RID: 1819 RVA: 0x0003E5B0 File Offset: 0x0003C7B0
		// (set) Token: 0x0600071C RID: 1820 RVA: 0x0003E5B8 File Offset: 0x0003C7B8
		public virtual BindingList<Owpb.FileInfo> RemoteFiles { get; set; }

		// Token: 0x0600071D RID: 1821 RVA: 0x0003E5C4 File Offset: 0x0003C7C4
		public void AddToLog(string message)
		{
			this.Log.Add(DateTime.Now.ToString() + "\t" + this.DirWithMacroToDirDescription(message));
			EventHandler afterLogChanged = this.AfterLogChanged;
			if (afterLogChanged == null)
			{
				return;
			}
			afterLogChanged(this, null);
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x0003E60C File Offset: 0x0003C80C
		public void AddToLogF(string message, params object[] args)
		{
			this.Log.Add(DateTime.Now.ToString() + "\t" + this.DirWithMacroToDirDescription(string.Format(message, args)));
			EventHandler afterLogChanged = this.AfterLogChanged;
			if (afterLogChanged == null)
			{
				return;
			}
			afterLogChanged(this, null);
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x0003E65C File Offset: 0x0003C85C
		public void ChangeLocalDir(string localDir)
		{
			if (string.IsNullOrEmpty(localDir))
			{
				this.LocalFiles.Clear();
				this.LocalFiles.AddRange(this.LocalDrives);
				this._localDir = null;
			}
			else
			{
				EventHandler beforeTask = this.BeforeTask;
				if (beforeTask != null)
				{
					beforeTask(this, null);
				}
				try
				{
					BindingList<Owpb.FileInfo> files = this.ReadLocalFiles(this.ResolveLocalDir(localDir));
					if (files != null)
					{
						this.LocalFiles.Clear();
						this.LocalFiles.AddRange(files);
						this._localDir = localDir;
					}
				}
				finally
				{
					EventHandler afterTask = this.AfterTask;
					if (afterTask != null)
					{
						afterTask(this, null);
					}
				}
			}
			EventHandler<string> afterLocalDirChanged = this.AfterLocalDirChanged;
			if (afterLocalDirChanged == null)
			{
				return;
			}
			afterLocalDirChanged(this, this._localDir);
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x0003E718 File Offset: 0x0003C918
		public void ChangeLocalDirToParent()
		{
			this.ChangeLocalDir(Path.GetDirectoryName(this.LocalDir));
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x0003E72C File Offset: 0x0003C92C
		public Task ChangeRemoteDir(string remoteDir)
		{
			FileManagerViewModel.<ChangeRemoteDir>d__61 <ChangeRemoteDir>d__;
			<ChangeRemoteDir>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ChangeRemoteDir>d__.<>4__this = this;
			<ChangeRemoteDir>d__.remoteDir = remoteDir;
			<ChangeRemoteDir>d__.<>1__state = -1;
			<ChangeRemoteDir>d__.<>t__builder.Start<FileManagerViewModel.<ChangeRemoteDir>d__61>(ref <ChangeRemoteDir>d__);
			return <ChangeRemoteDir>d__.<>t__builder.Task;
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x0003E778 File Offset: 0x0003C978
		public Task ChangeRemoteDirToParent()
		{
			FileManagerViewModel.<ChangeRemoteDirToParent>d__62 <ChangeRemoteDirToParent>d__;
			<ChangeRemoteDirToParent>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ChangeRemoteDirToParent>d__.<>4__this = this;
			<ChangeRemoteDirToParent>d__.<>1__state = -1;
			<ChangeRemoteDirToParent>d__.<>t__builder.Start<FileManagerViewModel.<ChangeRemoteDirToParent>d__62>(ref <ChangeRemoteDirToParent>d__);
			return <ChangeRemoteDirToParent>d__.<>t__builder.Task;
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x0003E7BC File Offset: 0x0003C9BC
		public void CreateLocalDir(string dir)
		{
			string fullDirName = this.DirToFullDirName(this.LocalDir, dir);
			if (string.IsNullOrEmpty(fullDirName))
			{
				return;
			}
			try
			{
				Directory.CreateDirectory(this.ResolveLocalDir(fullDirName));
				this.AddToLogF(Resources.FileManagerViewModel_LocalFolderCreated, new object[]
				{
					fullDirName
				});
				this.RefreshLocalDir();
			}
			catch (Exception ex)
			{
				this.AddToLogF(Resources.FileManagerViewModel_LocalFolderCreatingError, new object[]
				{
					fullDirName,
					ex.Message
				});
			}
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x0003E83C File Offset: 0x0003CA3C
		public Task CreateRemoteDir(string dir)
		{
			FileManagerViewModel.<CreateRemoteDir>d__64 <CreateRemoteDir>d__;
			<CreateRemoteDir>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CreateRemoteDir>d__.<>4__this = this;
			<CreateRemoteDir>d__.dir = dir;
			<CreateRemoteDir>d__.<>1__state = -1;
			<CreateRemoteDir>d__.<>t__builder.Start<FileManagerViewModel.<CreateRemoteDir>d__64>(ref <CreateRemoteDir>d__);
			return <CreateRemoteDir>d__.<>t__builder.Task;
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x0003E888 File Offset: 0x0003CA88
		public void DeleteLocalFiles(List<string> filesList)
		{
			EventHandler beforeTask = this.BeforeTask;
			if (beforeTask != null)
			{
				beforeTask(this, null);
			}
			try
			{
				foreach (string fileName in filesList)
				{
					try
					{
						string resolvedFileName = this.ResolveLocalDir(fileName);
						if (resolvedFileName.EndsWith("*"))
						{
							Directory.Delete(resolvedFileName.TrimEnd(new char[]
							{
								'*'
							}), true);
							this.AddToLogF(Resources.FileManagerViewModel_LocalFolderDeleted, new object[]
							{
								fileName
							});
						}
						else
						{
							File.Delete(resolvedFileName);
							this.AddToLogF(Resources.FileManagerViewModel_LocalFileDeleted, new object[]
							{
								fileName
							});
						}
					}
					catch (Exception ex)
					{
						this.AddToLogF(Resources.FileManagerViewModel_LocalFileDeletionError, new object[]
						{
							fileName,
							ex.Message
						});
					}
				}
			}
			finally
			{
				EventHandler afterTask = this.AfterTask;
				if (afterTask != null)
				{
					afterTask(this, null);
				}
			}
			this.RefreshLocalDir();
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x0003E99C File Offset: 0x0003CB9C
		public Task DeleteRemoteFiles(List<string> filesList)
		{
			FileManagerViewModel.<DeleteRemoteFiles>d__66 <DeleteRemoteFiles>d__;
			<DeleteRemoteFiles>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<DeleteRemoteFiles>d__.<>4__this = this;
			<DeleteRemoteFiles>d__.filesList = filesList;
			<DeleteRemoteFiles>d__.<>1__state = -1;
			<DeleteRemoteFiles>d__.<>t__builder.Start<FileManagerViewModel.<DeleteRemoteFiles>d__66>(ref <DeleteRemoteFiles>d__);
			return <DeleteRemoteFiles>d__.<>t__builder.Task;
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x0003E9E8 File Offset: 0x0003CBE8
		public string DirWithMacroToDirDescription(string dir)
		{
			string result = dir;
			foreach (KeyValuePair<string, string> dirMacro in this._remoteDirMacros)
			{
				result = result.Replace(dirMacro.Value, dirMacro.Key);
			}
			return result;
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x0003EA4C File Offset: 0x0003CC4C
		public Task InitRemoteConnection()
		{
			FileManagerViewModel.<InitRemoteConnection>d__68 <InitRemoteConnection>d__;
			<InitRemoteConnection>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<InitRemoteConnection>d__.<>4__this = this;
			<InitRemoteConnection>d__.<>1__state = -1;
			<InitRemoteConnection>d__.<>t__builder.Start<FileManagerViewModel.<InitRemoteConnection>d__68>(ref <InitRemoteConnection>d__);
			return <InitRemoteConnection>d__.<>t__builder.Task;
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x0003EA8F File Offset: 0x0003CC8F
		public void RefreshLocalDir()
		{
			this.ChangeLocalDir(this._localDir);
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x0003EAA0 File Offset: 0x0003CCA0
		public Task RefreshRemoteDir()
		{
			FileManagerViewModel.<RefreshRemoteDir>d__70 <RefreshRemoteDir>d__;
			<RefreshRemoteDir>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<RefreshRemoteDir>d__.<>4__this = this;
			<RefreshRemoteDir>d__.<>1__state = -1;
			<RefreshRemoteDir>d__.<>t__builder.Start<FileManagerViewModel.<RefreshRemoteDir>d__70>(ref <RefreshRemoteDir>d__);
			return <RefreshRemoteDir>d__.<>t__builder.Task;
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0003EAE4 File Offset: 0x0003CCE4
		protected Task<bool> DoRemoteTask(Task task, string errorMessage, params object[] errorMessageArgs)
		{
			FileManagerViewModel.<DoRemoteTask>d__71 <DoRemoteTask>d__;
			<DoRemoteTask>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<DoRemoteTask>d__.<>4__this = this;
			<DoRemoteTask>d__.task = task;
			<DoRemoteTask>d__.errorMessage = errorMessage;
			<DoRemoteTask>d__.errorMessageArgs = errorMessageArgs;
			<DoRemoteTask>d__.<>1__state = -1;
			<DoRemoteTask>d__.<>t__builder.Start<FileManagerViewModel.<DoRemoteTask>d__71>(ref <DoRemoteTask>d__);
			return <DoRemoteTask>d__.<>t__builder.Task;
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x0003EB40 File Offset: 0x0003CD40
		private Owpb.FileInfo CreateFileInfoForDirectory(DirectoryInfo dirInfo)
		{
			return new Owpb.FileInfo
			{
				Name = dirInfo.Name,
				Attributes = (uint)dirInfo.Attributes,
				LastWriteTime = (ulong)dirInfo.LastWriteTime.ToUnixTimeSeconds()
			};
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x0003EB84 File Offset: 0x0003CD84
		private Owpb.FileInfo CreateFileInfoForFile(System.IO.FileInfo fileInfo)
		{
			return new Owpb.FileInfo
			{
				Name = fileInfo.Name,
				FileSize = (ulong)fileInfo.Length,
				Attributes = (uint)fileInfo.Attributes,
				LastWriteTime = (ulong)fileInfo.LastWriteTime.ToUnixTimeSeconds()
			};
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x0003EBD4 File Offset: 0x0003CDD4
		private Owpb.FileInfo CreateFileInfoForParentDirectory(DirectoryInfo dirInfo)
		{
			return new Owpb.FileInfo
			{
				Name = "..",
				Attributes = (uint)dirInfo.Attributes,
				LastWriteTime = (ulong)dirInfo.LastWriteTime.ToUnixTimeSeconds()
			};
		}

		// Token: 0x0600072F RID: 1839 RVA: 0x0003EC18 File Offset: 0x0003CE18
		private string DirToFullDirName(string parentDir, string dir)
		{
			string result = null;
			if (dir.Length > 2 && dir.Substring(1, 2) == ":\\")
			{
				result = dir;
			}
			else if (string.IsNullOrEmpty(parentDir))
			{
				this.AddToLogF(Resources.FileManagerViewModel_InvalidFolderNameDirNotSelected, new object[]
				{
					dir
				});
			}
			else
			{
				result = Path.Combine(parentDir, dir);
			}
			return result;
		}

		// Token: 0x06000730 RID: 1840 RVA: 0x0003EC70 File Offset: 0x0003CE70
		private bool IsRemoteConnected()
		{
			return this.AgentClient != null && this.AgentClient.IsConnected;
		}

		// Token: 0x06000731 RID: 1841 RVA: 0x0003EC88 File Offset: 0x0003CE88
		private BindingList<Owpb.FileInfo> ReadLocalDrives()
		{
			BindingList<Owpb.FileInfo> result = new BindingList<Owpb.FileInfo>();
			foreach (KeyValuePair<string, string> dirMacro in this._localDirMacros)
			{
				result.Add(new Owpb.FileInfo
				{
					Name = dirMacro.Key,
					Attributes = 32768U,
					FileSize = 3UL
				});
			}
			foreach (System.IO.DriveInfo drive in System.IO.DriveInfo.GetDrives())
			{
				Owpb.FileInfo fi = new Owpb.FileInfo
				{
					Name = drive.Name,
					Attributes = 32768U,
					FileSize = (ulong)((long)drive.DriveType)
				};
				result.Add(fi);
			}
			return result;
		}

		// Token: 0x06000732 RID: 1842 RVA: 0x0003ED5C File Offset: 0x0003CF5C
		private BindingList<Owpb.FileInfo> ReadLocalFiles(string localDir)
		{
			BindingList<Owpb.FileInfo> result = new BindingList<Owpb.FileInfo>();
			BindingList<Owpb.FileInfo> result2;
			try
			{
				DirectoryInfo dir = new DirectoryInfo(localDir);
				result.Add(this.CreateFileInfoForParentDirectory(dir));
				foreach (DirectoryInfo fileInfo in dir.GetDirectories())
				{
					result.Add(this.CreateFileInfoForDirectory(fileInfo));
				}
				foreach (System.IO.FileInfo fileInfo2 in dir.GetFiles())
				{
					result.Add(this.CreateFileInfoForFile(fileInfo2));
				}
				result2 = result;
			}
			catch (Exception ex)
			{
				this.AddToLogF(Resources.FileManagerViewModel_LocalFolderReadError, new object[]
				{
					localDir,
					ex.Message
				});
				result2 = null;
			}
			return result2;
		}

		// Token: 0x06000733 RID: 1843 RVA: 0x0003EE14 File Offset: 0x0003D014
		private Task ReadRemoteDrives()
		{
			FileManagerViewModel.<ReadRemoteDrives>d__79 <ReadRemoteDrives>d__;
			<ReadRemoteDrives>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ReadRemoteDrives>d__.<>4__this = this;
			<ReadRemoteDrives>d__.<>1__state = -1;
			<ReadRemoteDrives>d__.<>t__builder.Start<FileManagerViewModel.<ReadRemoteDrives>d__79>(ref <ReadRemoteDrives>d__);
			return <ReadRemoteDrives>d__.<>t__builder.Task;
		}

		// Token: 0x06000734 RID: 1844 RVA: 0x0003EE58 File Offset: 0x0003D058
		private Task<List<Owpb.FileInfo>> ReadRemoteFiles(string newDir)
		{
			FileManagerViewModel.<ReadRemoteFiles>d__80 <ReadRemoteFiles>d__;
			<ReadRemoteFiles>d__.<>t__builder = AsyncTaskMethodBuilder<List<Owpb.FileInfo>>.Create();
			<ReadRemoteFiles>d__.<>4__this = this;
			<ReadRemoteFiles>d__.newDir = newDir;
			<ReadRemoteFiles>d__.<>1__state = -1;
			<ReadRemoteFiles>d__.<>t__builder.Start<FileManagerViewModel.<ReadRemoteFiles>d__80>(ref <ReadRemoteFiles>d__);
			return <ReadRemoteFiles>d__.<>t__builder.Task;
		}

		// Token: 0x06000735 RID: 1845 RVA: 0x0003EEA4 File Offset: 0x0003D0A4
		private string ResolveDirsMacro(string str, Dictionary<string, string> macros)
		{
			foreach (KeyValuePair<string, string> macro in macros)
			{
				if (str.StartsWith(macro.Key))
				{
					return str.Replace(macro.Key, macro.Value);
				}
			}
			return str;
		}

		// Token: 0x06000736 RID: 1846 RVA: 0x0003EF14 File Offset: 0x0003D114
		private string ResolveLocalDir(string localDir)
		{
			return this.ResolveDirsMacro(localDir, this._localDirMacros);
		}

		// Token: 0x06000737 RID: 1847 RVA: 0x0003EF23 File Offset: 0x0003D123
		private string ResolveRemoteDir(string remoteDir)
		{
			return this.ResolveDirsMacro(remoteDir, this._remoteDirMacros);
		}

		// Token: 0x04000502 RID: 1282
		internal const uint _S_DRIVE = 32768U;

		// Token: 0x04000503 RID: 1283
		internal const uint _S_IFDIR = 16U;

		// Token: 0x04000504 RID: 1284
		internal const string PARENT_DIR_NAME = "..";

		// Token: 0x04000505 RID: 1285
		private readonly Dictionary<string, string> _localDirMacros;

		// Token: 0x04000506 RID: 1286
		private readonly Dictionary<string, string> _remoteDirMacros;

		// Token: 0x04000507 RID: 1287
		private string _localDir;
	}
}
