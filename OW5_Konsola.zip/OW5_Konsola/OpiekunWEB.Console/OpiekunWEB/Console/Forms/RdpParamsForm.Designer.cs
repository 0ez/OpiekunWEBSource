﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000055 RID: 85
	public partial class RdpParamsForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600049D RID: 1181 RVA: 0x00016283 File Offset: 0x00014483
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x000162A4 File Offset: 0x000144A4
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.RdpParamsForm));
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.xtraTabControlMain = new global::DevExpress.XtraTab.XtraTabControl();
			this.xtraTabPageGeneral = new global::DevExpress.XtraTab.XtraTabPage();
			this.layoutControlGeneral = new global::DevExpress.XtraLayout.LayoutControl();
			this.comboBoxColorsDepth = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.checkEditConnectToConsole = new global::DevExpress.XtraEditors.CheckEdit();
			this.spinEditPort = new global::DevExpress.XtraEditors.SpinEdit();
			this.comboBoxDesktopSize = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.textEditUserName = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditPassword = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditDomainName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlDomainName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlPassword = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlUserName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlPort = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlDesktopSize = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlConnectToConsole = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlColorsDepth = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.xtraTabPageAdvanced = new global::DevExpress.XtraTab.XtraTabPage();
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControlMain).BeginInit();
			this.xtraTabControlMain.SuspendLayout();
			this.xtraTabPageGeneral.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGeneral).BeginInit();
			this.layoutControlGeneral.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxColorsDepth.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditConnectToConsole.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.spinEditPort.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxDesktopSize.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDomainName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDomainName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPassword).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPort).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDesktopSize).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlConnectToConsole).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlColorsDepth).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			resources.ApplyResources(this.xtraTabControlMain, "xtraTabControlMain");
			this.xtraTabControlMain.Name = "xtraTabControlMain";
			this.xtraTabControlMain.SelectedTabPage = this.xtraTabPageGeneral;
			this.xtraTabControlMain.TabPages.AddRange(new global::DevExpress.XtraTab.XtraTabPage[]
			{
				this.xtraTabPageGeneral,
				this.xtraTabPageAdvanced
			});
			this.xtraTabPageGeneral.Controls.Add(this.layoutControlGeneral);
			this.xtraTabPageGeneral.Name = "xtraTabPageGeneral";
			resources.ApplyResources(this.xtraTabPageGeneral, "xtraTabPageGeneral");
			this.layoutControlGeneral.AllowCustomization = false;
			this.layoutControlGeneral.Controls.Add(this.comboBoxColorsDepth);
			this.layoutControlGeneral.Controls.Add(this.checkEditConnectToConsole);
			this.layoutControlGeneral.Controls.Add(this.spinEditPort);
			this.layoutControlGeneral.Controls.Add(this.comboBoxDesktopSize);
			this.layoutControlGeneral.Controls.Add(this.textEditUserName);
			this.layoutControlGeneral.Controls.Add(this.textEditPassword);
			this.layoutControlGeneral.Controls.Add(this.textEditDomainName);
			resources.ApplyResources(this.layoutControlGeneral, "layoutControlGeneral");
			this.layoutControlGeneral.Name = "layoutControlGeneral";
			this.layoutControlGeneral.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2630, 284, 609, 465));
			this.layoutControlGeneral.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.comboBoxColorsDepth, "comboBoxColorsDepth");
			this.comboBoxColorsDepth.Name = "comboBoxColorsDepth";
			this.comboBoxColorsDepth.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxColorsDepth.Properties.Buttons"))
			});
			this.comboBoxColorsDepth.StyleController = this.layoutControlGeneral;
			resources.ApplyResources(this.checkEditConnectToConsole, "checkEditConnectToConsole");
			this.checkEditConnectToConsole.Name = "checkEditConnectToConsole";
			this.checkEditConnectToConsole.Properties.Caption = resources.GetString("checkEditConnectToConsole.Properties.Caption");
			this.checkEditConnectToConsole.StyleController = this.layoutControlGeneral;
			resources.ApplyResources(this.spinEditPort, "spinEditPort");
			this.spinEditPort.Name = "spinEditPort";
			this.spinEditPort.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("spinEditPort.Properties.Buttons"))
			});
			this.spinEditPort.Properties.Mask.EditMask = resources.GetString("spinEditPort.Properties.Mask.EditMask");
			this.spinEditPort.StyleController = this.layoutControlGeneral;
			resources.ApplyResources(this.comboBoxDesktopSize, "comboBoxDesktopSize");
			this.comboBoxDesktopSize.Name = "comboBoxDesktopSize";
			this.comboBoxDesktopSize.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxDesktopSize.Properties.Buttons"))
			});
			this.comboBoxDesktopSize.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxDesktopSize.StyleController = this.layoutControlGeneral;
			resources.ApplyResources(this.textEditUserName, "textEditUserName");
			this.textEditUserName.Name = "textEditUserName";
			this.textEditUserName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditUserName.Properties.Mask.BeepOnError");
			this.textEditUserName.Properties.Mask.EditMask = resources.GetString("textEditUserName.Properties.Mask.EditMask");
			this.textEditUserName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditUserName.Properties.Mask.IgnoreMaskBlank");
			this.textEditUserName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditUserName.Properties.Mask.MaskType");
			this.textEditUserName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditUserName.Properties.Mask.ShowPlaceHolders");
			this.textEditUserName.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditUserName.StyleController = this.layoutControlGeneral;
			resources.ApplyResources(this.textEditPassword, "textEditPassword");
			this.textEditPassword.Name = "textEditPassword";
			this.textEditPassword.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditPassword.Properties.Mask.BeepOnError");
			this.textEditPassword.Properties.Mask.EditMask = resources.GetString("textEditPassword.Properties.Mask.EditMask");
			this.textEditPassword.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditPassword.Properties.Mask.IgnoreMaskBlank");
			this.textEditPassword.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditPassword.Properties.Mask.MaskType");
			this.textEditPassword.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditPassword.Properties.Mask.ShowPlaceHolders");
			this.textEditPassword.Properties.PasswordChar = '*';
			this.textEditPassword.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditPassword.StyleController = this.layoutControlGeneral;
			resources.ApplyResources(this.textEditDomainName, "textEditDomainName");
			this.textEditDomainName.Name = "textEditDomainName";
			this.textEditDomainName.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditDomainName.StyleController = this.layoutControlGeneral;
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlDomainName,
				this.layoutControlPassword,
				this.layoutControlUserName,
				this.layoutControlPort,
				this.layoutControlDesktopSize,
				this.layoutControlConnectToConsole,
				this.layoutControlColorsDepth
			});
			this.layoutControlGroupMain.Name = "Root";
			this.layoutControlGroupMain.Padding = new global::DevExpress.XtraLayout.Utils.Padding(12, 12, 12, 12);
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(418, 378);
			this.layoutControlGroupMain.TextVisible = false;
			this.layoutControlDomainName.Control = this.textEditDomainName;
			this.layoutControlDomainName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlDomainName.Name = "layoutControlDomainName";
			this.layoutControlDomainName.Size = new global::System.Drawing.Size(394, 45);
			resources.ApplyResources(this.layoutControlDomainName, "layoutControlDomainName");
			this.layoutControlDomainName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDomainName.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlPassword.Control = this.textEditPassword;
			this.layoutControlPassword.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlPassword.Name = "layoutControlPassword";
			this.layoutControlPassword.Size = new global::System.Drawing.Size(394, 45);
			resources.ApplyResources(this.layoutControlPassword, "layoutControlPassword");
			this.layoutControlPassword.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlPassword.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlUserName.Control = this.textEditUserName;
			this.layoutControlUserName.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlUserName.Name = "layoutControlUserName";
			this.layoutControlUserName.Size = new global::System.Drawing.Size(394, 45);
			resources.ApplyResources(this.layoutControlUserName, "layoutControlUserName");
			this.layoutControlUserName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUserName.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlPort.Control = this.spinEditPort;
			this.layoutControlPort.Location = new global::System.Drawing.Point(253, 135);
			this.layoutControlPort.Name = "layoutControlPort";
			this.layoutControlPort.Size = new global::System.Drawing.Size(141, 47);
			resources.ApplyResources(this.layoutControlPort, "layoutControlPort");
			this.layoutControlPort.TextAlignMode = global::DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
			this.layoutControlPort.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlPort.TextSize = new global::System.Drawing.Size(80, 16);
			this.layoutControlPort.TextToControlDistance = 5;
			this.layoutControlDesktopSize.Control = this.comboBoxDesktopSize;
			this.layoutControlDesktopSize.Location = new global::System.Drawing.Point(0, 182);
			this.layoutControlDesktopSize.Name = "layoutControlDesktopSize";
			this.layoutControlDesktopSize.Size = new global::System.Drawing.Size(192, 172);
			resources.ApplyResources(this.layoutControlDesktopSize, "layoutControlDesktopSize");
			this.layoutControlDesktopSize.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDesktopSize.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlConnectToConsole.Control = this.checkEditConnectToConsole;
			this.layoutControlConnectToConsole.Location = new global::System.Drawing.Point(0, 135);
			this.layoutControlConnectToConsole.Name = "layoutControlConnectToConsole";
			this.layoutControlConnectToConsole.Size = new global::System.Drawing.Size(253, 47);
			resources.ApplyResources(this.layoutControlConnectToConsole, "layoutControlConnectToConsole");
			this.layoutControlConnectToConsole.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlConnectToConsole.TextSize = new global::System.Drawing.Size(143, 16);
			this.layoutControlColorsDepth.Control = this.comboBoxColorsDepth;
			this.layoutControlColorsDepth.Location = new global::System.Drawing.Point(192, 182);
			this.layoutControlColorsDepth.Name = "layoutControlColorsDepth";
			this.layoutControlColorsDepth.Size = new global::System.Drawing.Size(202, 172);
			resources.ApplyResources(this.layoutControlColorsDepth, "layoutControlColorsDepth");
			this.layoutControlColorsDepth.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlColorsDepth.TextSize = new global::System.Drawing.Size(143, 16);
			this.xtraTabPageAdvanced.Name = "xtraTabPageAdvanced";
			resources.ApplyResources(this.xtraTabPageAdvanced, "xtraTabPageAdvanced");
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.xtraTabControlMain);
			base.Controls.Add(this.buttonOk);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("RdpParamsForm.IconOptions.Icon");
			base.Name = "RdpParamsForm";
			base.Load += new global::System.EventHandler(this.RdpParamsForm_Load);
			((global::System.ComponentModel.ISupportInitialize)this.xtraTabControlMain).EndInit();
			this.xtraTabControlMain.ResumeLayout(false);
			this.xtraTabPageGeneral.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGeneral).EndInit();
			this.layoutControlGeneral.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxColorsDepth.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditConnectToConsole.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.spinEditPort.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxDesktopSize.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditPassword.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDomainName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDomainName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPassword).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlPort).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDesktopSize).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlConnectToConsole).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlColorsDepth).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040001EC RID: 492
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040001ED RID: 493
		protected global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x040001EE RID: 494
		private global::DevExpress.XtraTab.XtraTabControl xtraTabControlMain;

		// Token: 0x040001EF RID: 495
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPageGeneral;

		// Token: 0x040001F0 RID: 496
		private global::DevExpress.XtraTab.XtraTabPage xtraTabPageAdvanced;

		// Token: 0x040001F1 RID: 497
		private global::DevExpress.XtraLayout.LayoutControl layoutControlGeneral;

		// Token: 0x040001F2 RID: 498
		private global::DevExpress.XtraEditors.TextEdit textEditUserName;

		// Token: 0x040001F3 RID: 499
		private global::DevExpress.XtraEditors.TextEdit textEditPassword;

		// Token: 0x040001F4 RID: 500
		private global::DevExpress.XtraEditors.TextEdit textEditDomainName;

		// Token: 0x040001F5 RID: 501
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040001F6 RID: 502
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDomainName;

		// Token: 0x040001F7 RID: 503
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlPassword;

		// Token: 0x040001F8 RID: 504
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserName;

		// Token: 0x040001F9 RID: 505
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxDesktopSize;

		// Token: 0x040001FA RID: 506
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDesktopSize;

		// Token: 0x040001FB RID: 507
		private global::DevExpress.XtraEditors.SpinEdit spinEditPort;

		// Token: 0x040001FC RID: 508
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlPort;

		// Token: 0x040001FD RID: 509
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxColorsDepth;

		// Token: 0x040001FE RID: 510
		private global::DevExpress.XtraEditors.CheckEdit checkEditConnectToConsole;

		// Token: 0x040001FF RID: 511
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlConnectToConsole;

		// Token: 0x04000200 RID: 512
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlColorsDepth;
	}
}
