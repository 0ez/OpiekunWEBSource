﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000059 RID: 89
	public partial class CRUDBaseForm : BaseForm
	{
		// Token: 0x060004C3 RID: 1219 RVA: 0x00018134 File Offset: 0x00016334
		public CRUDBaseForm()
		{
			this.InitializeComponent();
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x00018142 File Offset: 0x00016342
		public CRUDBaseForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient) : base(formsSettings, formCreator, action)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0001815B File Offset: 0x0001635B
		protected virtual bool IsDataUpdated()
		{
			return true;
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0001815B File Offset: 0x0001635B
		protected virtual bool IsDataValid()
		{
			return true;
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0001815E File Offset: 0x0001635E
		protected virtual Task<bool> OnActionCreate()
		{
			return Task.FromResult<bool>(false);
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x0001815E File Offset: 0x0001635E
		protected virtual Task<bool> OnActionDelete()
		{
			return Task.FromResult<bool>(false);
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x0001815E File Offset: 0x0001635E
		protected virtual Task<bool> OnActionUnknown()
		{
			return Task.FromResult<bool>(false);
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x0001815E File Offset: 0x0001635E
		protected virtual Task<bool> OnActionUpdate()
		{
			return Task.FromResult<bool>(false);
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x00018168 File Offset: 0x00016368
		private void buttonSave_Click(object sender, EventArgs e)
		{
			CRUDBaseForm.<buttonSave_Click>d__9 <buttonSave_Click>d__;
			<buttonSave_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonSave_Click>d__.<>4__this = this;
			<buttonSave_Click>d__.<>1__state = -1;
			<buttonSave_Click>d__.<>t__builder.Start<CRUDBaseForm.<buttonSave_Click>d__9>(ref <buttonSave_Click>d__);
		}

		// Token: 0x0400021A RID: 538
		protected readonly ApiClient _apiClient;
	}
}
