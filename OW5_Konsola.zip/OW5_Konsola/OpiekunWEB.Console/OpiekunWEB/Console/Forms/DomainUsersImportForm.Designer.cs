﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000065 RID: 101
	public partial class DomainUsersImportForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x06000550 RID: 1360 RVA: 0x0001F91F File Offset: 0x0001DB1F
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x0001F940 File Offset: 0x0001DB40
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.DomainUsersImportForm));
			this.buttonOk = new global::DevExpress.XtraEditors.SimpleButton();
			this.textEditDomainName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.lookUpRoles = new global::DevExpress.XtraEditors.LookUpEdit();
			this.labelHelp = new global::DevExpress.XtraEditors.LabelControl();
			this.comboBoxGroupNames = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.gridUsers = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewUsers = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.columnLogin = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnUserName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnDisplayName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlDomainName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroupNames = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlUsers = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlHelp = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlRoles = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.textEditDomainName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.lookUpRoles.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxGroupNames.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridUsers).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUsers).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDomainName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupNames).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUsers).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlHelp).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlRoles).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonOk, "buttonOk");
			this.buttonOk.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.buttonOk.ImageOptions.ImageIndex = (int)resources.GetObject("buttonOk.ImageOptions.ImageIndex");
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Click += new global::System.EventHandler(this.buttonOk_Click);
			resources.ApplyResources(this.textEditDomainName, "textEditDomainName");
			this.textEditDomainName.Name = "textEditDomainName";
			this.textEditDomainName.Properties.AccessibleDescription = resources.GetString("textEditDomainName.Properties.AccessibleDescription");
			this.textEditDomainName.Properties.AccessibleName = resources.GetString("textEditDomainName.Properties.AccessibleName");
			this.textEditDomainName.Properties.AutoHeight = (bool)resources.GetObject("textEditDomainName.Properties.AutoHeight");
			this.textEditDomainName.Properties.CharacterCasing = global::System.Windows.Forms.CharacterCasing.Lower;
			this.textEditDomainName.Properties.Mask.AutoComplete = (global::DevExpress.XtraEditors.Mask.AutoCompleteType)resources.GetObject("textEditDomainName.Properties.Mask.AutoComplete");
			this.textEditDomainName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditDomainName.Properties.Mask.BeepOnError");
			this.textEditDomainName.Properties.Mask.EditMask = resources.GetString("textEditDomainName.Properties.Mask.EditMask");
			this.textEditDomainName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditDomainName.Properties.Mask.IgnoreMaskBlank");
			this.textEditDomainName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditDomainName.Properties.Mask.MaskType");
			this.textEditDomainName.Properties.Mask.PlaceHolder = (char)resources.GetObject("textEditDomainName.Properties.Mask.PlaceHolder");
			this.textEditDomainName.Properties.Mask.SaveLiteral = (bool)resources.GetObject("textEditDomainName.Properties.Mask.SaveLiteral");
			this.textEditDomainName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditDomainName.Properties.Mask.ShowPlaceHolders");
			this.textEditDomainName.Properties.Mask.UseMaskAsDisplayFormat = (bool)resources.GetObject("textEditDomainName.Properties.Mask.UseMaskAsDisplayFormat");
			this.textEditDomainName.Properties.NullValuePrompt = resources.GetString("textEditDomainName.Properties.NullValuePrompt");
			this.textEditDomainName.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("textEditDomainName.Properties.NullValuePromptShowForEmptyValue");
			this.textEditDomainName.StyleController = this.layoutControlMain;
			this.textEditDomainName.KeyUp += new global::System.Windows.Forms.KeyEventHandler(this.textEditDomainName_KeyUp);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutGroupCaption.Image");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta = (int)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontSizeDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.FontStyleDelta");
			this.layoutControlMain.Appearance.DisabledLayoutItem.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.GradientMode");
			this.layoutControlMain.Appearance.DisabledLayoutItem.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.Appearance.DisabledLayoutItem.Image");
			this.layoutControlMain.Controls.Add(this.lookUpRoles);
			this.layoutControlMain.Controls.Add(this.labelHelp);
			this.layoutControlMain.Controls.Add(this.comboBoxGroupNames);
			this.layoutControlMain.Controls.Add(this.gridUsers);
			this.layoutControlMain.Controls.Add(this.textEditDomainName);
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceGroupCaption.Image");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta = (int)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontSizeDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.FontStyleDelta");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.GradientMode");
			this.layoutControlMain.OptionsPrint.AppearanceItemCaption.Image = (global::System.Drawing.Image)resources.GetObject("layoutControlMain.OptionsPrint.AppearanceItemCaption.Image");
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.lookUpRoles, "lookUpRoles");
			this.lookUpRoles.Name = "lookUpRoles";
			this.lookUpRoles.Properties.AccessibleDescription = resources.GetString("lookUpRoles.Properties.AccessibleDescription");
			this.lookUpRoles.Properties.AccessibleName = resources.GetString("lookUpRoles.Properties.AccessibleName");
			this.lookUpRoles.Properties.AutoHeight = (bool)resources.GetObject("lookUpRoles.Properties.AutoHeight");
			this.lookUpRoles.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("lookUpRoles.Properties.Buttons"))
			});
			this.lookUpRoles.Properties.Columns.AddRange(new global::DevExpress.XtraEditors.Controls.LookUpColumnInfo[]
			{
				new global::DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("lookUpRoles.Properties.Columns"), resources.GetString("lookUpRoles.Properties.Columns1"))
			});
			this.lookUpRoles.Properties.DisplayMember = "Name";
			this.lookUpRoles.Properties.NullText = resources.GetString("lookUpRoles.Properties.NullText");
			this.lookUpRoles.Properties.NullValuePrompt = resources.GetString("lookUpRoles.Properties.NullValuePrompt");
			this.lookUpRoles.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("lookUpRoles.Properties.NullValuePromptShowForEmptyValue");
			this.lookUpRoles.Properties.ValueMember = "Id";
			this.lookUpRoles.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.labelHelp, "labelHelp");
			this.labelHelp.Appearance.FontSizeDelta = (int)resources.GetObject("labelHelp.Appearance.FontSizeDelta");
			this.labelHelp.Appearance.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("labelHelp.Appearance.FontStyleDelta");
			this.labelHelp.Appearance.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("labelHelp.Appearance.GradientMode");
			this.labelHelp.Appearance.Image = (global::System.Drawing.Image)resources.GetObject("labelHelp.Appearance.Image");
			this.labelHelp.Appearance.Options.UseTextOptions = true;
			this.labelHelp.Appearance.TextOptions.WordWrap = global::DevExpress.Utils.WordWrap.Wrap;
			this.labelHelp.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftTop;
			this.labelHelp.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.question_32x32;
			this.labelHelp.Name = "labelHelp";
			this.labelHelp.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.comboBoxGroupNames, "comboBoxGroupNames");
			this.comboBoxGroupNames.Name = "comboBoxGroupNames";
			this.comboBoxGroupNames.Properties.AccessibleDescription = resources.GetString("comboBoxGroupNames.Properties.AccessibleDescription");
			this.comboBoxGroupNames.Properties.AccessibleName = resources.GetString("comboBoxGroupNames.Properties.AccessibleName");
			this.comboBoxGroupNames.Properties.AutoHeight = (bool)resources.GetObject("comboBoxGroupNames.Properties.AutoHeight");
			this.comboBoxGroupNames.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("comboBoxGroupNames.Properties.Buttons"))
			});
			this.comboBoxGroupNames.Properties.NullValuePrompt = resources.GetString("comboBoxGroupNames.Properties.NullValuePrompt");
			this.comboBoxGroupNames.Properties.NullValuePromptShowForEmptyValue = (bool)resources.GetObject("comboBoxGroupNames.Properties.NullValuePromptShowForEmptyValue");
			this.comboBoxGroupNames.Properties.TextEditStyle = global::DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.comboBoxGroupNames.StyleController = this.layoutControlMain;
			this.comboBoxGroupNames.SelectedValueChanged += new global::System.EventHandler(this.comboBoxGroupNames_SelectedValueChanged);
			resources.ApplyResources(this.gridUsers, "gridUsers");
			this.gridUsers.EmbeddedNavigator.AccessibleDescription = resources.GetString("gridUsers.EmbeddedNavigator.AccessibleDescription");
			this.gridUsers.EmbeddedNavigator.AccessibleName = resources.GetString("gridUsers.EmbeddedNavigator.AccessibleName");
			this.gridUsers.EmbeddedNavigator.AllowHtmlTextInToolTip = (global::DevExpress.Utils.DefaultBoolean)resources.GetObject("gridUsers.EmbeddedNavigator.AllowHtmlTextInToolTip");
			this.gridUsers.EmbeddedNavigator.Anchor = (global::System.Windows.Forms.AnchorStyles)resources.GetObject("gridUsers.EmbeddedNavigator.Anchor");
			this.gridUsers.EmbeddedNavigator.BackgroundImage = (global::System.Drawing.Image)resources.GetObject("gridUsers.EmbeddedNavigator.BackgroundImage");
			this.gridUsers.EmbeddedNavigator.BackgroundImageLayout = (global::System.Windows.Forms.ImageLayout)resources.GetObject("gridUsers.EmbeddedNavigator.BackgroundImageLayout");
			this.gridUsers.EmbeddedNavigator.ImeMode = (global::System.Windows.Forms.ImeMode)resources.GetObject("gridUsers.EmbeddedNavigator.ImeMode");
			this.gridUsers.EmbeddedNavigator.MaximumSize = (global::System.Drawing.Size)resources.GetObject("gridUsers.EmbeddedNavigator.MaximumSize");
			this.gridUsers.EmbeddedNavigator.TextLocation = (global::DevExpress.XtraEditors.NavigatorButtonsTextLocation)resources.GetObject("gridUsers.EmbeddedNavigator.TextLocation");
			this.gridUsers.EmbeddedNavigator.ToolTip = resources.GetString("gridUsers.EmbeddedNavigator.ToolTip");
			this.gridUsers.EmbeddedNavigator.ToolTipIconType = (global::DevExpress.Utils.ToolTipIconType)resources.GetObject("gridUsers.EmbeddedNavigator.ToolTipIconType");
			this.gridUsers.EmbeddedNavigator.ToolTipTitle = resources.GetString("gridUsers.EmbeddedNavigator.ToolTipTitle");
			this.gridUsers.MainView = this.gridViewUsers;
			this.gridUsers.Name = "gridUsers";
			this.gridUsers.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewUsers
			});
			resources.ApplyResources(this.gridViewUsers, "gridViewUsers");
			this.gridViewUsers.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.columnLogin,
				this.columnUserName,
				this.columnDisplayName
			});
			this.gridViewUsers.GridControl = this.gridUsers;
			this.gridViewUsers.Name = "gridViewUsers";
			this.gridViewUsers.OptionsSelection.CheckBoxSelectorColumnWidth = 40;
			this.gridViewUsers.OptionsSelection.MultiSelect = true;
			this.gridViewUsers.OptionsSelection.MultiSelectMode = global::DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
			this.gridViewUsers.OptionsView.ShowGroupPanel = false;
			this.gridViewUsers.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.columnLogin, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.columnLogin.AppearanceHeader.FontSizeDelta = (int)resources.GetObject("columnLogin.AppearanceHeader.FontSizeDelta");
			this.columnLogin.AppearanceHeader.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("columnLogin.AppearanceHeader.FontStyleDelta");
			this.columnLogin.AppearanceHeader.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("columnLogin.AppearanceHeader.GradientMode");
			this.columnLogin.AppearanceHeader.Image = (global::System.Drawing.Image)resources.GetObject("columnLogin.AppearanceHeader.Image");
			this.columnLogin.AppearanceHeader.Options.UseTextOptions = true;
			this.columnLogin.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnLogin, "columnLogin");
			this.columnLogin.FieldName = "Login";
			this.columnLogin.ImageOptions.ImageIndex = (int)resources.GetObject("columnLogin.ImageOptions.ImageIndex");
			this.columnLogin.Name = "columnLogin";
			this.columnLogin.OptionsColumn.AllowEdit = false;
			this.columnUserName.AppearanceHeader.FontSizeDelta = (int)resources.GetObject("columnUserName.AppearanceHeader.FontSizeDelta");
			this.columnUserName.AppearanceHeader.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("columnUserName.AppearanceHeader.FontStyleDelta");
			this.columnUserName.AppearanceHeader.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("columnUserName.AppearanceHeader.GradientMode");
			this.columnUserName.AppearanceHeader.Image = (global::System.Drawing.Image)resources.GetObject("columnUserName.AppearanceHeader.Image");
			this.columnUserName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnUserName, "columnUserName");
			this.columnUserName.FieldName = "UserName";
			this.columnUserName.ImageOptions.ImageIndex = (int)resources.GetObject("columnUserName.ImageOptions.ImageIndex");
			this.columnUserName.Name = "columnUserName";
			this.columnUserName.OptionsColumn.AllowEdit = false;
			this.columnDisplayName.AppearanceHeader.FontSizeDelta = (int)resources.GetObject("columnDisplayName.AppearanceHeader.FontSizeDelta");
			this.columnDisplayName.AppearanceHeader.FontStyleDelta = (global::System.Drawing.FontStyle)resources.GetObject("columnDisplayName.AppearanceHeader.FontStyleDelta");
			this.columnDisplayName.AppearanceHeader.GradientMode = (global::System.Drawing.Drawing2D.LinearGradientMode)resources.GetObject("columnDisplayName.AppearanceHeader.GradientMode");
			this.columnDisplayName.AppearanceHeader.Image = (global::System.Drawing.Image)resources.GetObject("columnDisplayName.AppearanceHeader.Image");
			this.columnDisplayName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnDisplayName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnDisplayName, "columnDisplayName");
			this.columnDisplayName.FieldName = "DisplayName";
			this.columnDisplayName.ImageOptions.ImageIndex = (int)resources.GetObject("columnDisplayName.ImageOptions.ImageIndex");
			this.columnDisplayName.MinWidth = 25;
			this.columnDisplayName.Name = "columnDisplayName";
			this.layoutControlGroupMain.BackgroundImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.BackgroundImageOptions.ImageIndex");
			this.layoutControlGroupMain.CaptionImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.CaptionImageOptions.ImageIndex");
			this.layoutControlGroupMain.ContentImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupMain.ContentImageOptions.ImageIndex");
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlDomainName,
				this.layoutControlGroupNames,
				this.layoutControlUsers,
				this.layoutControlHelp,
				this.emptySpaceItem1,
				this.layoutControlRoles
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(579, 455);
			this.layoutControlGroupMain.TextVisible = false;
			resources.ApplyResources(this.layoutControlDomainName, "layoutControlDomainName");
			this.layoutControlDomainName.Control = this.textEditDomainName;
			this.layoutControlDomainName.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlDomainName.ImageOptions.ImageIndex");
			this.layoutControlDomainName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlDomainName.Name = "layoutControlDomainName";
			this.layoutControlDomainName.Size = new global::System.Drawing.Size(559, 45);
			this.layoutControlDomainName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlDomainName.TextSize = new global::System.Drawing.Size(302, 16);
			resources.ApplyResources(this.layoutControlGroupNames, "layoutControlGroupNames");
			this.layoutControlGroupNames.Control = this.comboBoxGroupNames;
			this.layoutControlGroupNames.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlGroupNames.ImageOptions.ImageIndex");
			this.layoutControlGroupNames.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlGroupNames.Name = "layoutControlGroupNames";
			this.layoutControlGroupNames.Size = new global::System.Drawing.Size(559, 45);
			this.layoutControlGroupNames.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlGroupNames.TextSize = new global::System.Drawing.Size(302, 16);
			resources.ApplyResources(this.layoutControlUsers, "layoutControlUsers");
			this.layoutControlUsers.Control = this.gridUsers;
			this.layoutControlUsers.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlUsers.ImageOptions.ImageIndex");
			this.layoutControlUsers.Location = new global::System.Drawing.Point(0, 135);
			this.layoutControlUsers.Name = "layoutControlUsers";
			this.layoutControlUsers.Size = new global::System.Drawing.Size(559, 213);
			this.layoutControlUsers.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUsers.TextSize = new global::System.Drawing.Size(302, 16);
			resources.ApplyResources(this.layoutControlHelp, "layoutControlHelp");
			this.layoutControlHelp.Control = this.labelHelp;
			this.layoutControlHelp.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlHelp.ImageOptions.ImageIndex");
			this.layoutControlHelp.Location = new global::System.Drawing.Point(0, 367);
			this.layoutControlHelp.Name = "layoutControlHelp";
			this.layoutControlHelp.Size = new global::System.Drawing.Size(559, 68);
			this.layoutControlHelp.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlHelp.TextVisible = false;
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 348);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(559, 19);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			resources.ApplyResources(this.layoutControlRoles, "layoutControlRoles");
			this.layoutControlRoles.Control = this.lookUpRoles;
			this.layoutControlRoles.ImageOptions.ImageIndex = (int)resources.GetObject("layoutControlRoles.ImageOptions.ImageIndex");
			this.layoutControlRoles.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlRoles.Name = "layoutControlRoles";
			this.layoutControlRoles.Size = new global::System.Drawing.Size(559, 45);
			this.layoutControlRoles.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlRoles.TextSize = new global::System.Drawing.Size(302, 16);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.Controls.Add(this.buttonOk);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Sizable;
			base.Name = "DomainUsersImportForm";
			((global::System.ComponentModel.ISupportInitialize)this.textEditDomainName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.lookUpRoles.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxGroupNames.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridUsers).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUsers).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlDomainName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupNames).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUsers).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlHelp).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlRoles).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040002A6 RID: 678
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040002A7 RID: 679
		private global::DevExpress.XtraEditors.SimpleButton buttonOk;

		// Token: 0x040002A8 RID: 680
		private global::DevExpress.XtraEditors.TextEdit textEditDomainName;

		// Token: 0x040002A9 RID: 681
		private global::DevExpress.XtraGrid.GridControl gridUsers;

		// Token: 0x040002AA RID: 682
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewUsers;

		// Token: 0x040002AB RID: 683
		private global::DevExpress.XtraGrid.Columns.GridColumn columnLogin;

		// Token: 0x040002AC RID: 684
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserName;

		// Token: 0x040002AD RID: 685
		private global::DevExpress.XtraEditors.LabelControl labelHelp;

		// Token: 0x040002AE RID: 686
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxGroupNames;

		// Token: 0x040002AF RID: 687
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040002B0 RID: 688
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x040002B1 RID: 689
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlDomainName;

		// Token: 0x040002B2 RID: 690
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040002B3 RID: 691
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlGroupNames;

		// Token: 0x040002B4 RID: 692
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlHelp;

		// Token: 0x040002B5 RID: 693
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUsers;

		// Token: 0x040002B6 RID: 694
		private global::DevExpress.XtraEditors.LookUpEdit lookUpRoles;

		// Token: 0x040002B7 RID: 695
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlRoles;

		// Token: 0x040002B8 RID: 696
		private global::DevExpress.XtraGrid.Columns.GridColumn columnDisplayName;
	}
}
