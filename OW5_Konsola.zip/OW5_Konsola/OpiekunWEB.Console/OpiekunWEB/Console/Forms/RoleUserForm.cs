﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraLayout;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007B RID: 123
	public partial class RoleUserForm : CRUDBaseForm
	{
		// Token: 0x0600067D RID: 1661 RVA: 0x0003437C File Offset: 0x0003257C
		public RoleUserForm(FormsSettings formsSettings, IFormCreator formCreator, FormAction action, ApiClient apiClient, RoleUserFormParams @params) : base(formsSettings, formCreator, action, apiClient)
		{
			this._params = @params;
			this.InitializeComponent();
			this.labelHelp.Visible = (action == FormAction.Create);
			this.textEditUserIdenty.Enabled = (action == FormAction.Create);
			this.textEditUserName.Text = this._params.Name;
			this.textEditUserIdenty.Text = this._params.Identy;
			Role role = (from x in this._apiClient.Roles
			where x.Id == this._params.RoleId
			select x).FirstOrDefault<Role>();
			if (role != null)
			{
				this._roleType = role.RoleType;
				this._rolesList = (from x in this._apiClient.Roles
				where x.RoleType == role.RoleType
				select x).ToList<Role>();
				this.lookUpEditRoles.Properties.DataSource = this._rolesList;
				this.lookUpEditRoles.EditValue = role.Id;
			}
			if (this._roleType == RoleType.ApiUsers)
			{
				this.layoutControlUserIdenty.Text = "Email:";
				this.labelHelp.Text = Resources.RoleUserForm_HelpForCreatingApiUser;
				this.labelHelp.Visible = (base.Action == FormAction.Create);
			}
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x000344C4 File Offset: 0x000326C4
		protected override bool IsDataUpdated()
		{
			return this._params.Name != this.textEditUserName.Text || this._params.Identy != this.textEditUserIdenty.Text || this._params.RoleId != this.lookUpEditRoles.EditValue as string;
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x00034530 File Offset: 0x00032730
		protected override bool IsDataValid()
		{
			if (this._roleType == RoleType.ApiUsers)
			{
				if (!Regex.IsMatch(this.textEditUserIdenty.Text, "\\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\\Z", RegexOptions.IgnoreCase))
				{
					this._formCreator.ShowError(Resources.RoleUserForm_MustEnterValidEmail);
					base.ActiveControl = this.textEditUserIdenty;
					return false;
				}
			}
			else
			{
				if (this.textEditUserIdenty.Text.Contains(" ") || this.textEditUserIdenty.Text.Contains("/"))
				{
					this._formCreator.ShowError(Resources.RoleUserForm_UserIdHasIllegalCharacters);
					base.ActiveControl = this.textEditUserIdenty;
					return false;
				}
				if (Regex.Matches(this.textEditUserIdenty.Text, "\\*").Count > 1)
				{
					this._formCreator.ShowError(Resources.RoleUserForm_UserIdCanContainsOneAsterisk);
					base.ActiveControl = this.textEditUserIdenty;
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x00034608 File Offset: 0x00032808
		protected override Task<bool> OnActionCreate()
		{
			RoleUserForm.<OnActionCreate>d__6 <OnActionCreate>d__;
			<OnActionCreate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionCreate>d__.<>4__this = this;
			<OnActionCreate>d__.<>1__state = -1;
			<OnActionCreate>d__.<>t__builder.Start<RoleUserForm.<OnActionCreate>d__6>(ref <OnActionCreate>d__);
			return <OnActionCreate>d__.<>t__builder.Task;
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x0003464C File Offset: 0x0003284C
		protected override Task<bool> OnActionUpdate()
		{
			RoleUserForm.<OnActionUpdate>d__7 <OnActionUpdate>d__;
			<OnActionUpdate>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<OnActionUpdate>d__.<>4__this = this;
			<OnActionUpdate>d__.<>1__state = -1;
			<OnActionUpdate>d__.<>t__builder.Start<RoleUserForm.<OnActionUpdate>d__7>(ref <OnActionUpdate>d__);
			return <OnActionUpdate>d__.<>t__builder.Task;
		}

		// Token: 0x0400043F RID: 1087
		private readonly RoleUserFormParams _params;

		// Token: 0x04000440 RID: 1088
		private readonly List<Role> _rolesList;

		// Token: 0x04000441 RID: 1089
		private readonly RoleType _roleType;
	}
}
