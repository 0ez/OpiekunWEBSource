﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000051 RID: 81
	public partial class CustomerInfoForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x06000487 RID: 1159 RVA: 0x00014B1F File Offset: 0x00012D1F
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x00014B40 File Offset: 0x00012D40
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.CustomerInfoForm));
			global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions = new global::DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new global::DevExpress.Utils.SerializableAppearanceObject();
			global::DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new global::DevExpress.Utils.SerializableAppearanceObject();
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.textEditKeyDescription = new global::DevExpress.XtraEditors.TextEdit();
			this.dateEditExpiryDate = new global::DevExpress.XtraEditors.DateEdit();
			this.textEditMaxDevices = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditKeyName = new global::DevExpress.XtraEditors.TextEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlKeyName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			this.layoutControlMaxDevices = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlKeyDescription = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlExpiryDate = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditKeyDescription.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditExpiryDate.Properties.CalendarTimeProperties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditExpiryDate.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditMaxDevices.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditKeyName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlKeyName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMaxDevices).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlKeyDescription).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlExpiryDate).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Controls.Add(this.textEditKeyDescription);
			this.layoutControlMain.Controls.Add(this.dateEditExpiryDate);
			this.layoutControlMain.Controls.Add(this.textEditMaxDevices);
			this.layoutControlMain.Controls.Add(this.textEditKeyName);
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.Root = this.Root;
			resources.ApplyResources(this.textEditKeyDescription, "textEditKeyDescription");
			this.textEditKeyDescription.Name = "textEditKeyDescription";
			this.textEditKeyDescription.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.dateEditExpiryDate, "dateEditExpiryDate");
			this.dateEditExpiryDate.Name = "dateEditExpiryDate";
			this.dateEditExpiryDate.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("dateEditExpiryDate.Properties.Buttons"), resources.GetString("dateEditExpiryDate.Properties.Buttons1"), (int)resources.GetObject("dateEditExpiryDate.Properties.Buttons2"), (bool)resources.GetObject("dateEditExpiryDate.Properties.Buttons3"), (bool)resources.GetObject("dateEditExpiryDate.Properties.Buttons4"), (bool)resources.GetObject("dateEditExpiryDate.Properties.Buttons5"), editorButtonImageOptions, new global::DevExpress.Utils.KeyShortcut(global::System.Windows.Forms.Keys.None), serializableAppearanceObject, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, resources.GetString("dateEditExpiryDate.Properties.Buttons6"), resources.GetObject("dateEditExpiryDate.Properties.Buttons7"), (global::DevExpress.Utils.SuperToolTip)resources.GetObject("dateEditExpiryDate.Properties.Buttons8"), (global::DevExpress.Utils.ToolTipAnchor)resources.GetObject("dateEditExpiryDate.Properties.Buttons9"))
			});
			this.dateEditExpiryDate.Properties.CalendarTimeProperties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("dateEditExpiryDate.Properties.CalendarTimeProperties.Buttons"))
			});
			this.dateEditExpiryDate.Properties.CalendarTimeProperties.Mask.EditMask = resources.GetString("dateEditExpiryDate.Properties.CalendarTimeProperties.Mask.EditMask");
			this.dateEditExpiryDate.Properties.Mask.EditMask = resources.GetString("dateEditExpiryDate.Properties.Mask.EditMask");
			this.dateEditExpiryDate.Properties.ReadOnly = true;
			this.dateEditExpiryDate.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditMaxDevices, "textEditMaxDevices");
			this.textEditMaxDevices.Name = "textEditMaxDevices";
			this.textEditMaxDevices.Properties.ReadOnly = true;
			this.textEditMaxDevices.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditKeyName, "textEditKeyName");
			this.textEditKeyName.Name = "textEditKeyName";
			this.textEditKeyName.Properties.ReadOnly = true;
			this.textEditKeyName.StyleController = this.layoutControlMain;
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlKeyName,
				this.emptySpaceItem1,
				this.layoutControlMaxDevices,
				this.layoutControlKeyDescription,
				this.layoutControlExpiryDate
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(409, 359);
			this.Root.TextVisible = false;
			resources.ApplyResources(this.layoutControlKeyName, "layoutControlKeyName");
			this.layoutControlKeyName.Control = this.textEditKeyName;
			this.layoutControlKeyName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlKeyName.Name = "layoutControlKeyName";
			this.layoutControlKeyName.Size = new global::System.Drawing.Size(389, 45);
			this.layoutControlKeyName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlKeyName.TextSize = new global::System.Drawing.Size(100, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 135);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(389, 204);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			resources.ApplyResources(this.layoutControlMaxDevices, "layoutControlMaxDevices");
			this.layoutControlMaxDevices.Control = this.textEditMaxDevices;
			this.layoutControlMaxDevices.Location = new global::System.Drawing.Point(194, 45);
			this.layoutControlMaxDevices.Name = "layoutControlMaxDevices";
			this.layoutControlMaxDevices.Size = new global::System.Drawing.Size(195, 45);
			this.layoutControlMaxDevices.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlMaxDevices.TextSize = new global::System.Drawing.Size(100, 16);
			resources.ApplyResources(this.layoutControlKeyDescription, "layoutControlKeyDescription");
			this.layoutControlKeyDescription.Control = this.textEditKeyDescription;
			this.layoutControlKeyDescription.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlKeyDescription.Name = "layoutControlKeyDescription";
			this.layoutControlKeyDescription.Size = new global::System.Drawing.Size(389, 45);
			this.layoutControlKeyDescription.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlKeyDescription.TextSize = new global::System.Drawing.Size(100, 16);
			resources.ApplyResources(this.layoutControlExpiryDate, "layoutControlExpiryDate");
			this.layoutControlExpiryDate.Control = this.dateEditExpiryDate;
			this.layoutControlExpiryDate.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlExpiryDate.Name = "layoutControlExpiryDate";
			this.layoutControlExpiryDate.Size = new global::System.Drawing.Size(194, 45);
			this.layoutControlExpiryDate.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlExpiryDate.TextSize = new global::System.Drawing.Size(100, 16);
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("CustomerInfoForm.IconOptions.Icon");
			base.Name = "CustomerInfoForm";
			base.Activated += new global::System.EventHandler(this.CustomerInfoForm_Activated);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			base.Controls.SetChildIndex(this.buttonSave, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditKeyDescription.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditExpiryDate.Properties.CalendarTimeProperties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.dateEditExpiryDate.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditMaxDevices.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditKeyName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlKeyName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMaxDevices).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlKeyDescription).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlExpiryDate).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040001CA RID: 458
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040001CB RID: 459
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040001CC RID: 460
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x040001CD RID: 461
		private global::DevExpress.XtraEditors.TextEdit textEditKeyDescription;

		// Token: 0x040001CE RID: 462
		private global::DevExpress.XtraEditors.DateEdit dateEditExpiryDate;

		// Token: 0x040001CF RID: 463
		private global::DevExpress.XtraEditors.TextEdit textEditMaxDevices;

		// Token: 0x040001D0 RID: 464
		private global::DevExpress.XtraEditors.TextEdit textEditKeyName;

		// Token: 0x040001D1 RID: 465
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlKeyName;

		// Token: 0x040001D2 RID: 466
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x040001D3 RID: 467
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlMaxDevices;

		// Token: 0x040001D4 RID: 468
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlKeyDescription;

		// Token: 0x040001D5 RID: 469
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlExpiryDate;
	}
}
