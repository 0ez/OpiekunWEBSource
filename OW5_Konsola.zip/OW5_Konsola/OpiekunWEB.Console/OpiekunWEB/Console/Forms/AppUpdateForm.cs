﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000070 RID: 112
	public partial class AppUpdateForm : BaseForm
	{
		// Token: 0x060005EA RID: 1514 RVA: 0x000295C5 File Offset: 0x000277C5
		public AppUpdateForm(FormsSettings formsSettings, IFormCreator formCreator, AppUpdateFormParams appUpdateFormParams) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._appUpdateFormParams = appUpdateFormParams;
			base.ActiveControl = this.buttonDownload;
			this.SetUpdateInfo();
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x000295F0 File Offset: 0x000277F0
		private void buttonDownload_Click(object sender, EventArgs e)
		{
			try
			{
				this._appUpdateFormParams.Result = AppUpdateMode.Download;
				string dirPath;
				using (XtraFolderBrowserDialog dlg = new XtraFolderBrowserDialog())
				{
					dlg.Title = Resources.AppUpdateForm_FolderBrowserTitle;
					if (dlg.ShowDialog().Equals(DialogResult.Cancel))
					{
						return;
					}
					dirPath = dlg.SelectedPath;
				}
				base.Hide();
				this.StartDownload(dirPath);
			}
			catch (Exception ex)
			{
				string msg = ex.Message;
				if (ex.InnerException != null)
				{
					msg = ex.InnerException.Message;
				}
				this._formCreator.ShowError(msg);
				base.Show();
			}
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x000296AC File Offset: 0x000278AC
		private void buttonRemindLater_Click(object sender, EventArgs e)
		{
			this._appUpdateFormParams.Result = AppUpdateMode.RemindLater;
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x000296C4 File Offset: 0x000278C4
		private void buttonUpdate_Click(object sender, EventArgs e)
		{
			try
			{
				this._appUpdateFormParams.Result = AppUpdateMode.Update;
				Uri url = new Uri(this._appUpdateFormParams.InstallerFileInfo.Url);
				string fileName = Path.GetFileName(url.LocalPath);
				string tmp = Path.Combine(Path.GetTempPath(), fileName);
				base.Hide();
				using (HttpDownloadForm dlg = new HttpDownloadForm(this._formCreator, url, tmp))
				{
					if (dlg.ShowDialog() == DialogResult.OK)
					{
						this._appUpdateFormParams.DownloadedFile = tmp;
						base.DialogResult = DialogResult.OK;
					}
					else
					{
						base.Show();
					}
				}
			}
			catch (Exception ex)
			{
				string msg = ex.Message;
				if (ex.InnerException != null)
				{
					msg = ex.InnerException.Message;
				}
				this._formCreator.ShowError(msg);
				base.Show();
			}
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x000297A4 File Offset: 0x000279A4
		private void GetChangeLog(Uri urlLog)
		{
			this.webBrowserLogInfo.Url = urlLog;
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x000297B4 File Offset: 0x000279B4
		private void SetControlsProperties()
		{
			this.webBrowserLogInfo.Visible = false;
			base.Height = 200;
			base.Width = this.labelInfo.Width + 50;
			base.MaximizeBox = false;
			base.FormBorderStyle = FormBorderStyle.FixedDialog;
			this.labelCurrentVersion.Top += 10;
			this.labelNewVersion.Top += 10;
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x00029824 File Offset: 0x00027A24
		private void SetUpdateInfo()
		{
			try
			{
				LabelControl labelControl = this.labelCurrentVersion;
				labelControl.Text += this._appUpdateFormParams.CurrentAppVersion;
				LabelControl labelControl2 = this.labelNewVersion;
				labelControl2.Text += this._appUpdateFormParams.InstallerFileInfo.Version;
				if (string.IsNullOrEmpty(this._appUpdateFormParams.InstallerFileInfo.ChangeLogUrl))
				{
					this.SetControlsProperties();
				}
				else
				{
					this.GetChangeLog(new Uri(this._appUpdateFormParams.InstallerFileInfo.ChangeLogUrl));
				}
			}
			catch (Exception ex)
			{
				this._formCreator.ShowError(ex.Message);
			}
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x000298D8 File Offset: 0x00027AD8
		private void StartDownload(string dirPath)
		{
			Uri url = new Uri(this._appUpdateFormParams.InstallerFileInfo.Url);
			string fileName = Path.GetFileName(url.LocalPath);
			string localFilePath = Path.Combine(dirPath, fileName);
			using (HttpDownloadForm dlg = new HttpDownloadForm(this._formCreator, url, localFilePath))
			{
				dlg.MinimizeBox = true;
				if (dlg.ShowDialog() == DialogResult.OK)
				{
					this._formCreator.ShowInfo(Resources.AppUpdateForm_DownloadSucceeded);
					base.DialogResult = DialogResult.OK;
				}
				else
				{
					File.Delete(localFilePath);
					base.Show();
				}
			}
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x00029970 File Offset: 0x00027B70
		private void webBrowserLogInfo_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
		{
			AppUpdateFormParams appUpdateFormParams = this._appUpdateFormParams;
			string value;
			if (appUpdateFormParams == null)
			{
				value = null;
			}
			else
			{
				InstallerFileInfo installerFileInfo = appUpdateFormParams.InstallerFileInfo;
				value = ((installerFileInfo != null) ? installerFileInfo.ChangeLogUrl : null);
			}
			if (!string.IsNullOrEmpty(value) && e.Url == new Uri(this._appUpdateFormParams.InstallerFileInfo.ChangeLogUrl))
			{
				base.WindowState = FormWindowState.Maximized;
			}
		}

		// Token: 0x04000375 RID: 885
		private readonly AppUpdateFormParams _appUpdateFormParams;
	}
}
