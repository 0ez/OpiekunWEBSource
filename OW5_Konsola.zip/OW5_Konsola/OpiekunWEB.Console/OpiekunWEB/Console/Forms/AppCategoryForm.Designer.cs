﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200004E RID: 78
	public partial class AppCategoryForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x0600046C RID: 1132 RVA: 0x00011E0E File Offset: 0x0001000E
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x00011E30 File Offset: 0x00010030
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.AppCategoryForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.labelControlHelpCategoryType = new global::DevExpress.XtraEditors.LabelControl();
			this.textEditCategoryDescription = new global::DevExpress.XtraEditors.TextEdit();
			this.gridCategoryState = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewCategoryState = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnRoleName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRoleType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnRoleState = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxRoleState = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.imageCollectionIncluded = new global::DevExpress.Utils.ImageCollection(this.components);
			this.imageComboBoxCategoryType = new global::DevExpress.XtraEditors.ImageComboBoxEdit();
			this.textEditCategoryName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlCategoryName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlCategoryType = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGrid = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItemCategoryDescription = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlItem1 = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryDescription.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridCategoryState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewCategoryState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxRoleState).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionIncluded).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxCategoryType.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryType).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGrid).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemCategoryDescription).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.layoutControlMain.Controls.Add(this.labelControlHelpCategoryType);
			this.layoutControlMain.Controls.Add(this.textEditCategoryDescription);
			this.layoutControlMain.Controls.Add(this.gridCategoryState);
			this.layoutControlMain.Controls.Add(this.imageComboBoxCategoryType);
			this.layoutControlMain.Controls.Add(this.textEditCategoryName);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2551, 194, 812, 500));
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			this.labelControlHelpCategoryType.AllowHtmlString = true;
			this.labelControlHelpCategoryType.Appearance.Options.UseTextOptions = true;
			this.labelControlHelpCategoryType.Appearance.TextOptions.WordWrap = global::DevExpress.Utils.WordWrap.Wrap;
			resources.ApplyResources(this.labelControlHelpCategoryType, "labelControlHelpCategoryType");
			this.labelControlHelpCategoryType.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.labelControlHelpCategoryType.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.question_32x32;
			this.labelControlHelpCategoryType.Name = "labelControlHelpCategoryType";
			this.labelControlHelpCategoryType.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditCategoryDescription, "textEditCategoryDescription");
			this.textEditCategoryDescription.Name = "textEditCategoryDescription";
			this.textEditCategoryDescription.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.gridCategoryState, "gridCategoryState");
			this.gridCategoryState.MainView = this.gridViewCategoryState;
			this.gridCategoryState.Name = "gridCategoryState";
			this.gridCategoryState.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxRoleState
			});
			this.gridCategoryState.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewCategoryState
			});
			this.gridViewCategoryState.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnRoleName,
				this.gridColumnRoleType,
				this.gridColumnRoleState
			});
			this.gridViewCategoryState.GridControl = this.gridCategoryState;
			this.gridViewCategoryState.Name = "gridViewCategoryState";
			this.gridViewCategoryState.OptionsDetail.EnableMasterViewMode = false;
			this.gridViewCategoryState.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewCategoryState.OptionsSelection.UseIndicatorForSelection = false;
			this.gridViewCategoryState.OptionsView.ShowGroupPanel = false;
			this.gridViewCategoryState.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewCategoryState_CustomUnboundColumnData);
			this.gridColumnRoleName.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnRoleName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnRoleName, "gridColumnRoleName");
			this.gridColumnRoleName.FieldName = "Name";
			this.gridColumnRoleName.MinWidth = 25;
			this.gridColumnRoleName.Name = "gridColumnRoleName";
			this.gridColumnRoleName.OptionsColumn.AllowEdit = false;
			this.gridColumnRoleName.OptionsColumn.AllowFocus = false;
			this.gridColumnRoleType.FieldName = "RoleType";
			this.gridColumnRoleType.MinWidth = 25;
			this.gridColumnRoleType.Name = "gridColumnRoleType";
			resources.ApplyResources(this.gridColumnRoleType, "gridColumnRoleType");
			this.gridColumnRoleState.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnRoleState.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.gridColumnRoleState, "gridColumnRoleState");
			this.gridColumnRoleState.ColumnEdit = this.imageComboBoxRoleState;
			this.gridColumnRoleState.FieldName = "RoleState";
			this.gridColumnRoleState.MinWidth = 25;
			this.gridColumnRoleState.Name = "gridColumnRoleState";
			this.gridColumnRoleState.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			resources.ApplyResources(this.imageComboBoxRoleState, "imageComboBoxRoleState");
			this.imageComboBoxRoleState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxRoleState.Buttons"))
			});
			this.imageComboBoxRoleState.Items.AddRange(new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem[]
			{
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxRoleState.Items"), resources.GetObject("imageComboBoxRoleState.Items1"), (int)resources.GetObject("imageComboBoxRoleState.Items2")),
				new global::DevExpress.XtraEditors.Controls.ImageComboBoxItem(resources.GetString("imageComboBoxRoleState.Items3"), resources.GetObject("imageComboBoxRoleState.Items4"), (int)resources.GetObject("imageComboBoxRoleState.Items5"))
			});
			this.imageComboBoxRoleState.Name = "imageComboBoxRoleState";
			this.imageComboBoxRoleState.SmallImages = this.imageCollectionIncluded;
			this.imageComboBoxRoleState.EditValueChanging += new global::DevExpress.XtraEditors.Controls.ChangingEventHandler(this.imageComboBoxRoleState_EditValueChanging);
			this.imageCollectionIncluded.ImageStream = (global::DevExpress.Utils.ImageCollectionStreamer)resources.GetObject("imageCollectionIncluded.ImageStream");
			this.imageCollectionIncluded.Images.SetKeyName(0, "cancel_16x16.png");
			this.imageCollectionIncluded.Images.SetKeyName(1, "apply_16x16.png");
			resources.ApplyResources(this.imageComboBoxCategoryType, "imageComboBoxCategoryType");
			this.imageComboBoxCategoryType.Name = "imageComboBoxCategoryType";
			this.imageComboBoxCategoryType.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxCategoryType.Properties.Buttons"))
			});
			this.imageComboBoxCategoryType.Properties.UseReadOnlyAppearance = false;
			this.imageComboBoxCategoryType.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditCategoryName, "textEditCategoryName");
			this.textEditCategoryName.Name = "textEditCategoryName";
			this.textEditCategoryName.Properties.Mask.BeepOnError = (bool)resources.GetObject("textEditCategoryName.Properties.Mask.BeepOnError");
			this.textEditCategoryName.Properties.Mask.EditMask = resources.GetString("textEditCategoryName.Properties.Mask.EditMask");
			this.textEditCategoryName.Properties.Mask.IgnoreMaskBlank = (bool)resources.GetObject("textEditCategoryName.Properties.Mask.IgnoreMaskBlank");
			this.textEditCategoryName.Properties.Mask.MaskType = (global::DevExpress.XtraEditors.Mask.MaskType)resources.GetObject("textEditCategoryName.Properties.Mask.MaskType");
			this.textEditCategoryName.Properties.Mask.ShowPlaceHolders = (bool)resources.GetObject("textEditCategoryName.Properties.Mask.ShowPlaceHolders");
			this.textEditCategoryName.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlCategoryName,
				this.layoutControlCategoryType,
				this.layoutControlGrid,
				this.layoutControlItemCategoryDescription,
				this.layoutControlItem1
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.OptionsItemText.TextToControlDistance = 4;
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(535, 406);
			this.layoutControlGroupMain.TextVisible = false;
			this.layoutControlCategoryName.Control = this.textEditCategoryName;
			this.layoutControlCategoryName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlCategoryName.Name = "layoutControlCategoryName";
			this.layoutControlCategoryName.Size = new global::System.Drawing.Size(515, 46);
			resources.ApplyResources(this.layoutControlCategoryName, "layoutControlCategoryName");
			this.layoutControlCategoryName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlCategoryName.TextSize = new global::System.Drawing.Size(281, 16);
			this.layoutControlCategoryType.Control = this.imageComboBoxCategoryType;
			this.layoutControlCategoryType.Location = new global::System.Drawing.Point(0, 92);
			this.layoutControlCategoryType.Name = "layoutControlCategoryType";
			this.layoutControlCategoryType.Size = new global::System.Drawing.Size(515, 46);
			resources.ApplyResources(this.layoutControlCategoryType, "layoutControlCategoryType");
			this.layoutControlCategoryType.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlCategoryType.TextSize = new global::System.Drawing.Size(281, 16);
			this.layoutControlGrid.Control = this.gridCategoryState;
			this.layoutControlGrid.Location = new global::System.Drawing.Point(0, 178);
			this.layoutControlGrid.Name = "layoutControlGrid";
			this.layoutControlGrid.Size = new global::System.Drawing.Size(515, 208);
			resources.ApplyResources(this.layoutControlGrid, "layoutControlGrid");
			this.layoutControlGrid.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlGrid.TextSize = new global::System.Drawing.Size(281, 16);
			this.layoutControlItemCategoryDescription.Control = this.textEditCategoryDescription;
			this.layoutControlItemCategoryDescription.Location = new global::System.Drawing.Point(0, 46);
			this.layoutControlItemCategoryDescription.Name = "layoutControlItemCategoryDescription";
			this.layoutControlItemCategoryDescription.Size = new global::System.Drawing.Size(515, 46);
			resources.ApplyResources(this.layoutControlItemCategoryDescription, "layoutControlItemCategoryDescription");
			this.layoutControlItemCategoryDescription.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlItemCategoryDescription.TextSize = new global::System.Drawing.Size(281, 16);
			this.layoutControlItem1.Control = this.labelControlHelpCategoryType;
			this.layoutControlItem1.Location = new global::System.Drawing.Point(0, 138);
			this.layoutControlItem1.Name = "layoutControlItem1";
			this.layoutControlItem1.Size = new global::System.Drawing.Size(515, 40);
			this.layoutControlItem1.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlItem1.TextVisible = false;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("AppCategoryForm.IconOptions.Icon");
			base.Name = "AppCategoryForm";
			base.Controls.SetChildIndex(this.buttonSave, 0);
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryDescription.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridCategoryState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewCategoryState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxRoleState).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageCollectionIncluded).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxCategoryType.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditCategoryName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlCategoryType).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGrid).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItemCategoryDescription).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlItem1).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000189 RID: 393
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400018A RID: 394
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x0400018B RID: 395
		private global::DevExpress.XtraEditors.TextEdit textEditCategoryDescription;

		// Token: 0x0400018C RID: 396
		private global::DevExpress.XtraGrid.GridControl gridCategoryState;

		// Token: 0x0400018D RID: 397
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewCategoryState;

		// Token: 0x0400018E RID: 398
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleName;

		// Token: 0x0400018F RID: 399
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleType;

		// Token: 0x04000190 RID: 400
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnRoleState;

		// Token: 0x04000191 RID: 401
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxRoleState;

		// Token: 0x04000192 RID: 402
		private global::DevExpress.XtraEditors.ImageComboBoxEdit imageComboBoxCategoryType;

		// Token: 0x04000193 RID: 403
		private global::DevExpress.XtraEditors.TextEdit textEditCategoryName;

		// Token: 0x04000194 RID: 404
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x04000195 RID: 405
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlCategoryName;

		// Token: 0x04000196 RID: 406
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlCategoryType;

		// Token: 0x04000197 RID: 407
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlGrid;

		// Token: 0x04000198 RID: 408
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItemCategoryDescription;

		// Token: 0x04000199 RID: 409
		private global::DevExpress.Utils.ImageCollection imageCollectionIncluded;

		// Token: 0x0400019A RID: 410
		private global::DevExpress.XtraEditors.LabelControl labelControlHelpCategoryType;

		// Token: 0x0400019B RID: 411
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
	}
}
