﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000050 RID: 80
	public partial class ChocolateyFindPackageForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x0600047F RID: 1151 RVA: 0x0001375F File Offset: 0x0001195F
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x00013780 File Offset: 0x00011980
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.ChocolateyFindPackageForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.simpleButtonSearch = new global::DevExpress.XtraEditors.SimpleButton();
			this.comboBoxEditSorting = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.checkEditIncludePrerelease = new global::DevExpress.XtraEditors.CheckEdit();
			this.checkEditMatchQuery = new global::DevExpress.XtraEditors.CheckEdit();
			this.checkEditIncludeAllVersions = new global::DevExpress.XtraEditors.CheckEdit();
			this.textEditQuery = new global::DevExpress.XtraEditors.TextEdit();
			this.Root = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlGroup1 = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlQuery = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlButtonSearch = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlGroup2 = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlSorting = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlIncludePrerelease = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlIncludeAllVersions = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlMatchQuery = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.gridControlPackages = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewPackages = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.gridColumnTitle = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnAuthors = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnDescription = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.repositoryItemMemoDescription = new global::DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
			this.gridColumnVersion = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnTags = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridColumnDownloadCount = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.panelBottom = new global::DevExpress.XtraEditors.PanelControl();
			this.comboBoxResultsCount = new global::DevExpress.XtraEditors.ComboBoxEdit();
			this.layoutControlResultsCount = new global::DevExpress.XtraLayout.LayoutControlItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditSorting.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditIncludePrerelease.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditMatchQuery.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditIncludeAllVersions.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditQuery.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroup1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlQuery).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlButtonSearch).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroup2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSorting).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIncludePrerelease).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIncludeAllVersions).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMatchQuery).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridControlPackages).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewPackages).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemMemoDescription).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelBottom).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxResultsCount.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlResultsCount).BeginInit();
			base.SuspendLayout();
			this.layoutControlMain.Controls.Add(this.comboBoxResultsCount);
			this.layoutControlMain.Controls.Add(this.simpleButtonSearch);
			this.layoutControlMain.Controls.Add(this.comboBoxEditSorting);
			this.layoutControlMain.Controls.Add(this.checkEditIncludePrerelease);
			this.layoutControlMain.Controls.Add(this.checkEditMatchQuery);
			this.layoutControlMain.Controls.Add(this.checkEditIncludeAllVersions);
			this.layoutControlMain.Controls.Add(this.textEditQuery);
			this.layoutControlMain.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.layoutControlMain.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new global::System.Drawing.Rectangle?(new global::System.Drawing.Rectangle(2990, 185, 812, 500));
			this.layoutControlMain.Root = this.Root;
			this.layoutControlMain.Size = new global::System.Drawing.Size(907, 244);
			this.layoutControlMain.TabIndex = 0;
			this.layoutControlMain.Text = "layoutControl1";
			this.simpleButtonSearch.Location = new global::System.Drawing.Point(710, 43);
			this.simpleButtonSearch.Name = "simpleButtonSearch";
			this.simpleButtonSearch.Size = new global::System.Drawing.Size(173, 27);
			this.simpleButtonSearch.StyleController = this.layoutControlMain;
			this.simpleButtonSearch.TabIndex = 10;
			this.simpleButtonSearch.Text = "Search";
			this.simpleButtonSearch.Click += new global::System.EventHandler(this.simpleButtonSearch_Click);
			this.comboBoxEditSorting.Location = new global::System.Drawing.Point(12, 179);
			this.comboBoxEditSorting.Name = "comboBoxEditSorting";
			this.comboBoxEditSorting.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton(global::DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)
			});
			this.comboBoxEditSorting.Size = new global::System.Drawing.Size(883, 22);
			this.comboBoxEditSorting.StyleController = this.layoutControlMain;
			this.comboBoxEditSorting.TabIndex = 9;
			this.checkEditIncludePrerelease.Location = new global::System.Drawing.Point(457, 98);
			this.checkEditIncludePrerelease.Name = "checkEditIncludePrerelease";
			this.checkEditIncludePrerelease.Properties.Caption = "Include prerelease";
			this.checkEditIncludePrerelease.Size = new global::System.Drawing.Size(426, 20);
			this.checkEditIncludePrerelease.StyleController = this.layoutControlMain;
			this.checkEditIncludePrerelease.TabIndex = 8;
			this.checkEditMatchQuery.Location = new global::System.Drawing.Point(24, 98);
			this.checkEditMatchQuery.Name = "checkEditMatchQuery";
			this.checkEditMatchQuery.Properties.Caption = "Match word exactly";
			this.checkEditMatchQuery.Size = new global::System.Drawing.Size(245, 20);
			this.checkEditMatchQuery.StyleController = this.layoutControlMain;
			this.checkEditMatchQuery.TabIndex = 7;
			this.checkEditIncludeAllVersions.Location = new global::System.Drawing.Point(273, 98);
			this.checkEditIncludeAllVersions.Name = "checkEditIncludeAllVersions";
			this.checkEditIncludeAllVersions.Properties.Caption = "All versions";
			this.checkEditIncludeAllVersions.Size = new global::System.Drawing.Size(180, 20);
			this.checkEditIncludeAllVersions.StyleController = this.layoutControlMain;
			this.checkEditIncludeAllVersions.TabIndex = 6;
			this.textEditQuery.Location = new global::System.Drawing.Point(24, 43);
			this.textEditQuery.Name = "textEditQuery";
			this.textEditQuery.Size = new global::System.Drawing.Size(682, 22);
			this.textEditQuery.StyleController = this.layoutControlMain;
			this.textEditQuery.TabIndex = 4;
			this.Root.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.Root.GroupBordersVisible = false;
			this.Root.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlGroup1,
				this.layoutControlGroup2,
				this.layoutControlResultsCount,
				this.layoutControlSorting
			});
			this.Root.Name = "Root";
			this.Root.Size = new global::System.Drawing.Size(907, 244);
			this.Root.TextVisible = false;
			this.layoutControlGroup1.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlQuery,
				this.layoutControlButtonSearch
			});
			this.layoutControlGroup1.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlGroup1.Name = "layoutControlGroup1";
			this.layoutControlGroup1.Size = new global::System.Drawing.Size(887, 74);
			this.layoutControlGroup1.TextVisible = false;
			this.layoutControlQuery.Control = this.textEditQuery;
			this.layoutControlQuery.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlQuery.Name = "layoutControlQuery";
			this.layoutControlQuery.Size = new global::System.Drawing.Size(686, 50);
			this.layoutControlQuery.Text = "Search for:";
			this.layoutControlQuery.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlQuery.TextSize = new global::System.Drawing.Size(65, 16);
			this.layoutControlButtonSearch.Control = this.simpleButtonSearch;
			this.layoutControlButtonSearch.Location = new global::System.Drawing.Point(686, 0);
			this.layoutControlButtonSearch.Name = "layoutControlButtonSearch";
			this.layoutControlButtonSearch.Size = new global::System.Drawing.Size(177, 50);
			this.layoutControlButtonSearch.Text = " ";
			this.layoutControlButtonSearch.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlButtonSearch.TextSize = new global::System.Drawing.Size(65, 16);
			this.layoutControlGroup2.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlIncludePrerelease,
				this.layoutControlIncludeAllVersions,
				this.layoutControlMatchQuery
			});
			this.layoutControlGroup2.Location = new global::System.Drawing.Point(0, 74);
			this.layoutControlGroup2.Name = "layoutControlGroup2";
			this.layoutControlGroup2.Size = new global::System.Drawing.Size(887, 48);
			this.layoutControlGroup2.TextVisible = false;
			this.layoutControlSorting.Control = this.comboBoxEditSorting;
			this.layoutControlSorting.Location = new global::System.Drawing.Point(0, 148);
			this.layoutControlSorting.Name = "layoutControlSorting";
			this.layoutControlSorting.Size = new global::System.Drawing.Size(887, 76);
			this.layoutControlSorting.Text = "Sorting:";
			this.layoutControlSorting.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlSorting.TextSize = new global::System.Drawing.Size(65, 16);
			this.layoutControlIncludePrerelease.Control = this.checkEditIncludePrerelease;
			this.layoutControlIncludePrerelease.Location = new global::System.Drawing.Point(433, 0);
			this.layoutControlIncludePrerelease.Name = "layoutControlIncludePrerelease";
			this.layoutControlIncludePrerelease.Size = new global::System.Drawing.Size(430, 24);
			this.layoutControlIncludePrerelease.Text = "Include prerelease";
			this.layoutControlIncludePrerelease.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlIncludePrerelease.TextVisible = false;
			this.layoutControlIncludeAllVersions.Control = this.checkEditIncludeAllVersions;
			this.layoutControlIncludeAllVersions.Location = new global::System.Drawing.Point(249, 0);
			this.layoutControlIncludeAllVersions.Name = "layoutControlIncludeAllVersions";
			this.layoutControlIncludeAllVersions.Size = new global::System.Drawing.Size(184, 24);
			this.layoutControlIncludeAllVersions.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlIncludeAllVersions.TextVisible = false;
			this.layoutControlMatchQuery.Control = this.checkEditMatchQuery;
			this.layoutControlMatchQuery.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlMatchQuery.Name = "layoutControlMatchQuery";
			this.layoutControlMatchQuery.Size = new global::System.Drawing.Size(249, 24);
			this.layoutControlMatchQuery.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlMatchQuery.TextVisible = false;
			this.gridControlPackages.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.gridControlPackages.Location = new global::System.Drawing.Point(0, 244);
			this.gridControlPackages.MainView = this.gridViewPackages;
			this.gridControlPackages.Name = "gridControlPackages";
			this.gridControlPackages.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.repositoryItemMemoDescription
			});
			this.gridControlPackages.Size = new global::System.Drawing.Size(907, 247);
			this.gridControlPackages.TabIndex = 1;
			this.gridControlPackages.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewPackages
			});
			this.gridViewPackages.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.gridColumnTitle,
				this.gridColumnAuthors,
				this.gridColumnDescription,
				this.gridColumnVersion,
				this.gridColumnTags,
				this.gridColumnDownloadCount
			});
			this.gridViewPackages.GridControl = this.gridControlPackages;
			this.gridViewPackages.Name = "gridViewPackages";
			this.gridViewPackages.OptionsBehavior.ReadOnly = true;
			this.gridViewPackages.OptionsView.ShowGroupPanel = false;
			this.gridViewPackages.RowHeight = 80;
			this.gridColumnTitle.AppearanceCell.FontSizeDelta = 2;
			this.gridColumnTitle.AppearanceCell.FontStyleDelta = global::System.Drawing.FontStyle.Bold;
			this.gridColumnTitle.AppearanceCell.Options.UseFont = true;
			this.gridColumnTitle.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnTitle.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridColumnTitle.Caption = "Name";
			this.gridColumnTitle.FieldName = "Package.Title";
			this.gridColumnTitle.MinWidth = 25;
			this.gridColumnTitle.Name = "gridColumnTitle";
			this.gridColumnTitle.Visible = true;
			this.gridColumnTitle.VisibleIndex = 0;
			this.gridColumnTitle.Width = 196;
			this.gridColumnAuthors.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnAuthors.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridColumnAuthors.Caption = "Authors";
			this.gridColumnAuthors.FieldName = "Package.Authors";
			this.gridColumnAuthors.MinWidth = 25;
			this.gridColumnAuthors.Name = "gridColumnAuthors";
			this.gridColumnAuthors.Visible = true;
			this.gridColumnAuthors.VisibleIndex = 3;
			this.gridColumnAuthors.Width = 105;
			this.gridColumnDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridColumnDescription.Caption = "Description";
			this.gridColumnDescription.ColumnEdit = this.repositoryItemMemoDescription;
			this.gridColumnDescription.FieldName = "Package.Description";
			this.gridColumnDescription.MinWidth = 25;
			this.gridColumnDescription.Name = "gridColumnDescription";
			this.gridColumnDescription.Visible = true;
			this.gridColumnDescription.VisibleIndex = 2;
			this.gridColumnDescription.Width = 309;
			this.repositoryItemMemoDescription.Name = "repositoryItemMemoDescription";
			this.gridColumnVersion.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnVersion.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridColumnVersion.Caption = "Version";
			this.gridColumnVersion.FieldName = "Package.Version";
			this.gridColumnVersion.MinWidth = 25;
			this.gridColumnVersion.Name = "gridColumnVersion";
			this.gridColumnVersion.Visible = true;
			this.gridColumnVersion.VisibleIndex = 1;
			this.gridColumnVersion.Width = 73;
			this.gridColumnTags.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnTags.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridColumnTags.Caption = "Tags";
			this.gridColumnTags.FieldName = "Package.Tags";
			this.gridColumnTags.MinWidth = 25;
			this.gridColumnTags.Name = "gridColumnTags";
			this.gridColumnTags.Visible = true;
			this.gridColumnTags.VisibleIndex = 4;
			this.gridColumnTags.Width = 126;
			this.gridColumnDownloadCount.AppearanceHeader.Options.UseTextOptions = true;
			this.gridColumnDownloadCount.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.gridColumnDownloadCount.Caption = "Downloads";
			this.gridColumnDownloadCount.FieldName = "Package.DownloadCount";
			this.gridColumnDownloadCount.MinWidth = 25;
			this.gridColumnDownloadCount.Name = "gridColumnDownloadCount";
			this.gridColumnDownloadCount.Visible = true;
			this.gridColumnDownloadCount.VisibleIndex = 5;
			this.gridColumnDownloadCount.Width = 78;
			this.panelBottom.Dock = global::System.Windows.Forms.DockStyle.Bottom;
			this.panelBottom.Location = new global::System.Drawing.Point(0, 491);
			this.panelBottom.Name = "panelBottom";
			this.panelBottom.Size = new global::System.Drawing.Size(907, 55);
			this.panelBottom.TabIndex = 2;
			this.comboBoxResultsCount.Location = new global::System.Drawing.Point(80, 134);
			this.comboBoxResultsCount.Name = "comboBoxResultsCount";
			this.comboBoxResultsCount.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton(global::DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)
			});
			this.comboBoxResultsCount.Size = new global::System.Drawing.Size(815, 22);
			this.comboBoxResultsCount.StyleController = this.layoutControlMain;
			this.comboBoxResultsCount.TabIndex = 11;
			this.layoutControlResultsCount.Control = this.comboBoxResultsCount;
			this.layoutControlResultsCount.Location = new global::System.Drawing.Point(0, 122);
			this.layoutControlResultsCount.Name = "layoutControlResultsCount";
			this.layoutControlResultsCount.Size = new global::System.Drawing.Size(887, 26);
			this.layoutControlResultsCount.Text = "Results";
			this.layoutControlResultsCount.TextSize = new global::System.Drawing.Size(65, 16);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(7f, 16f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(907, 546);
			base.Controls.Add(this.gridControlPackages);
			base.Controls.Add(this.panelBottom);
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("ChocolateyFindPackageForm.IconOptions.Icon");
			base.MaximizeBox = true;
			base.MinimizeBox = true;
			base.Name = "ChocolateyFindPackageForm";
			this.Text = "Chocolatey select package";
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxEditSorting.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditIncludePrerelease.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditMatchQuery.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.checkEditIncludeAllVersions.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditQuery.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.Root).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroup1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlQuery).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlButtonSearch).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroup2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlSorting).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIncludePrerelease).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlIncludeAllVersions).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMatchQuery).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridControlPackages).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewPackages).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.repositoryItemMemoDescription).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.panelBottom).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.comboBoxResultsCount.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlResultsCount).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040001AC RID: 428
		private global::System.ComponentModel.IContainer components;

		// Token: 0x040001AD RID: 429
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x040001AE RID: 430
		private global::DevExpress.XtraLayout.LayoutControlGroup Root;

		// Token: 0x040001AF RID: 431
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxEditSorting;

		// Token: 0x040001B0 RID: 432
		private global::DevExpress.XtraEditors.CheckEdit checkEditIncludePrerelease;

		// Token: 0x040001B1 RID: 433
		private global::DevExpress.XtraEditors.CheckEdit checkEditMatchQuery;

		// Token: 0x040001B2 RID: 434
		private global::DevExpress.XtraEditors.CheckEdit checkEditIncludeAllVersions;

		// Token: 0x040001B3 RID: 435
		private global::DevExpress.XtraEditors.TextEdit textEditQuery;

		// Token: 0x040001B4 RID: 436
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlQuery;

		// Token: 0x040001B5 RID: 437
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlSorting;

		// Token: 0x040001B6 RID: 438
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlIncludeAllVersions;

		// Token: 0x040001B7 RID: 439
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlMatchQuery;

		// Token: 0x040001B8 RID: 440
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlIncludePrerelease;

		// Token: 0x040001B9 RID: 441
		private global::DevExpress.XtraGrid.GridControl gridControlPackages;

		// Token: 0x040001BA RID: 442
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewPackages;

		// Token: 0x040001BB RID: 443
		private global::DevExpress.XtraEditors.SimpleButton simpleButtonSearch;

		// Token: 0x040001BC RID: 444
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;

		// Token: 0x040001BD RID: 445
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlButtonSearch;

		// Token: 0x040001BE RID: 446
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;

		// Token: 0x040001BF RID: 447
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnAuthors;

		// Token: 0x040001C0 RID: 448
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDescription;

		// Token: 0x040001C1 RID: 449
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnVersion;

		// Token: 0x040001C2 RID: 450
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnTags;

		// Token: 0x040001C3 RID: 451
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnTitle;

		// Token: 0x040001C4 RID: 452
		private global::DevExpress.XtraGrid.Columns.GridColumn gridColumnDownloadCount;

		// Token: 0x040001C5 RID: 453
		private global::DevExpress.XtraEditors.PanelControl panelBottom;

		// Token: 0x040001C6 RID: 454
		private global::DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoDescription;

		// Token: 0x040001C7 RID: 455
		private global::DevExpress.XtraEditors.ComboBoxEdit comboBoxResultsCount;

		// Token: 0x040001C8 RID: 456
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlResultsCount;
	}
}
