﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200007B RID: 123
	public partial class RoleUserForm : global::OpiekunWEB.Console.Forms.CRUDBaseForm
	{
		// Token: 0x06000682 RID: 1666 RVA: 0x0003468F File Offset: 0x0003288F
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x000346B0 File Offset: 0x000328B0
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.RoleUserForm));
			this.layoutControlMain = new global::DevExpress.XtraLayout.LayoutControl();
			this.lookUpEditRoles = new global::DevExpress.XtraEditors.LookUpEdit();
			this.labelHelp = new global::DevExpress.XtraEditors.LabelControl();
			this.textEditUserIdenty = new global::DevExpress.XtraEditors.TextEdit();
			this.textEditUserName = new global::DevExpress.XtraEditors.TextEdit();
			this.layoutControlGroupMain = new global::DevExpress.XtraLayout.LayoutControlGroup();
			this.layoutControlUserName = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlUserIdenty = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlHelp = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.layoutControlRoles = new global::DevExpress.XtraLayout.LayoutControlItem();
			this.emptySpaceItem1 = new global::DevExpress.XtraLayout.EmptySpaceItem();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).BeginInit();
			this.layoutControlMain.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.lookUpEditRoles.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserIdenty.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserIdenty).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlHelp).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlRoles).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).BeginInit();
			base.SuspendLayout();
			this.buttonSave.ImageOptions.Image = (global::System.Drawing.Image)resources.GetObject("buttonSave.ImageOptions.Image");
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.layoutControlMain.Controls.Add(this.lookUpEditRoles);
			this.layoutControlMain.Controls.Add(this.labelHelp);
			this.layoutControlMain.Controls.Add(this.textEditUserIdenty);
			this.layoutControlMain.Controls.Add(this.textEditUserName);
			resources.ApplyResources(this.layoutControlMain, "layoutControlMain");
			this.layoutControlMain.Name = "layoutControlMain";
			this.layoutControlMain.Root = this.layoutControlGroupMain;
			resources.ApplyResources(this.lookUpEditRoles, "lookUpEditRoles");
			this.lookUpEditRoles.Name = "lookUpEditRoles";
			this.lookUpEditRoles.Properties.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("lookUpEditRoles.Properties.Buttons"))
			});
			this.lookUpEditRoles.Properties.Columns.AddRange(new global::DevExpress.XtraEditors.Controls.LookUpColumnInfo[]
			{
				new global::DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("lookUpEditRoles.Properties.Columns"), resources.GetString("lookUpEditRoles.Properties.Columns1"))
			});
			this.lookUpEditRoles.Properties.DisplayMember = "Name";
			this.lookUpEditRoles.Properties.NullValuePrompt = resources.GetString("lookUpEditRoles.Properties.NullValuePrompt");
			this.lookUpEditRoles.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.lookUpEditRoles.Properties.ValueMember = "Id";
			this.lookUpEditRoles.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.labelHelp, "labelHelp");
			this.labelHelp.ImageAlignToText = global::DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
			this.labelHelp.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.question_32x32;
			this.labelHelp.Name = "labelHelp";
			this.labelHelp.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditUserIdenty, "textEditUserIdenty");
			this.textEditUserIdenty.Name = "textEditUserIdenty";
			this.textEditUserIdenty.Properties.Mask.EditMask = resources.GetString("textEditUserIdenty.Properties.Mask.EditMask");
			this.textEditUserIdenty.Properties.NullValuePrompt = resources.GetString("textEditUserIdenty.Properties.NullValuePrompt");
			this.textEditUserIdenty.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditUserIdenty.StyleController = this.layoutControlMain;
			resources.ApplyResources(this.textEditUserName, "textEditUserName");
			this.textEditUserName.Name = "textEditUserName";
			this.textEditUserName.Properties.Mask.EditMask = resources.GetString("textEditUserName.Properties.Mask.EditMask");
			this.textEditUserName.Properties.NullValuePrompt = resources.GetString("textEditUserName.Properties.NullValuePrompt");
			this.textEditUserName.Properties.ShowNullValuePrompt = (global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorFocused | global::DevExpress.XtraEditors.ShowNullValuePromptOptions.EditorReadOnly);
			this.textEditUserName.StyleController = this.layoutControlMain;
			this.layoutControlGroupMain.EnableIndentsWithoutBorders = global::DevExpress.Utils.DefaultBoolean.True;
			this.layoutControlGroupMain.GroupBordersVisible = false;
			this.layoutControlGroupMain.Items.AddRange(new global::DevExpress.XtraLayout.BaseLayoutItem[]
			{
				this.layoutControlUserName,
				this.layoutControlUserIdenty,
				this.layoutControlHelp,
				this.layoutControlRoles,
				this.emptySpaceItem1
			});
			this.layoutControlGroupMain.Name = "layoutControlGroupMain";
			this.layoutControlGroupMain.Size = new global::System.Drawing.Size(409, 267);
			this.layoutControlGroupMain.TextVisible = false;
			this.layoutControlUserName.Control = this.textEditUserName;
			this.layoutControlUserName.Location = new global::System.Drawing.Point(0, 0);
			this.layoutControlUserName.Name = "layoutControlUserName";
			this.layoutControlUserName.Size = new global::System.Drawing.Size(389, 45);
			resources.ApplyResources(this.layoutControlUserName, "layoutControlUserName");
			this.layoutControlUserName.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUserName.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControlUserIdenty.Control = this.textEditUserIdenty;
			this.layoutControlUserIdenty.Location = new global::System.Drawing.Point(0, 45);
			this.layoutControlUserIdenty.Name = "layoutControlUserIdenty";
			this.layoutControlUserIdenty.Size = new global::System.Drawing.Size(389, 45);
			resources.ApplyResources(this.layoutControlUserIdenty, "layoutControlUserIdenty");
			this.layoutControlUserIdenty.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlUserIdenty.TextSize = new global::System.Drawing.Size(67, 16);
			this.layoutControlHelp.Control = this.labelHelp;
			this.layoutControlHelp.Location = new global::System.Drawing.Point(0, 195);
			this.layoutControlHelp.Name = "layoutControlHelp";
			this.layoutControlHelp.Size = new global::System.Drawing.Size(389, 52);
			this.layoutControlHelp.TextSize = new global::System.Drawing.Size(0, 0);
			this.layoutControlHelp.TextVisible = false;
			this.layoutControlRoles.Control = this.lookUpEditRoles;
			this.layoutControlRoles.Location = new global::System.Drawing.Point(0, 90);
			this.layoutControlRoles.Name = "layoutControlRoles";
			this.layoutControlRoles.Size = new global::System.Drawing.Size(389, 45);
			resources.ApplyResources(this.layoutControlRoles, "layoutControlRoles");
			this.layoutControlRoles.TextLocation = global::DevExpress.Utils.Locations.Top;
			this.layoutControlRoles.TextSize = new global::System.Drawing.Size(67, 16);
			this.emptySpaceItem1.AllowHotTrack = false;
			this.emptySpaceItem1.Location = new global::System.Drawing.Point(0, 135);
			this.emptySpaceItem1.Name = "emptySpaceItem1";
			this.emptySpaceItem1.Size = new global::System.Drawing.Size(389, 60);
			this.emptySpaceItem1.TextSize = new global::System.Drawing.Size(0, 0);
			base.AcceptButton = null;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.layoutControlMain);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("RoleUserForm.IconOptions.Icon");
			base.Name = "RoleUserForm";
			base.Controls.SetChildIndex(this.layoutControlMain, 0);
			base.Controls.SetChildIndex(this.buttonSave, 0);
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlMain).EndInit();
			this.layoutControlMain.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.lookUpEditRoles.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserIdenty.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.textEditUserName.Properties).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlGroupMain).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserName).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlUserIdenty).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlHelp).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.layoutControlRoles).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.emptySpaceItem1).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x04000442 RID: 1090
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000443 RID: 1091
		private global::DevExpress.XtraLayout.LayoutControl layoutControlMain;

		// Token: 0x04000444 RID: 1092
		private global::DevExpress.XtraEditors.TextEdit textEditUserName;

		// Token: 0x04000445 RID: 1093
		private global::DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupMain;

		// Token: 0x04000446 RID: 1094
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserName;

		// Token: 0x04000447 RID: 1095
		private global::DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;

		// Token: 0x04000448 RID: 1096
		private global::DevExpress.XtraEditors.TextEdit textEditUserIdenty;

		// Token: 0x04000449 RID: 1097
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlUserIdenty;

		// Token: 0x0400044A RID: 1098
		private global::DevExpress.XtraEditors.LabelControl labelHelp;

		// Token: 0x0400044B RID: 1099
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlHelp;

		// Token: 0x0400044C RID: 1100
		private global::DevExpress.XtraEditors.LookUpEdit lookUpEditRoles;

		// Token: 0x0400044D RID: 1101
		private global::DevExpress.XtraLayout.LayoutControlItem layoutControlRoles;
	}
}
