﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200004D RID: 77
	public partial class AppCategoriesForm : global::OpiekunWEB.Console.Forms.RibbonBaseForm
	{
		// Token: 0x06000460 RID: 1120 RVA: 0x0001087C File Offset: 0x0000EA7C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0001089C File Offset: 0x0000EA9C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.AppCategoriesForm));
			this.splitContainer = new global::DevExpress.XtraEditors.SplitContainerControl();
			this.gridUserCategories = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewUserCategories = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.columnUserCategoryName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnUserCategoryDescription = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnUserCategoryId = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnUserCategoryType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxUserCategoryType = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			this.columnUserCategoryCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.gridAppFilters = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewAppFilters = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.columnAppFilterType = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnAppFilterPath = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnAppFilterDescription = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnAppFilterCommand = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnAppFilterId = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.ribbonControl = new global::DevExpress.XtraBars.Ribbon.RibbonControl();
			this.barButtonExit = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddCategory = new global::DevExpress.XtraBars.BarButtonItem();
			this.barButtonAddAppPathFilter = new global::DevExpress.XtraBars.BarButtonItem();
			this.ribbonPageMain = new global::DevExpress.XtraBars.Ribbon.RibbonPage();
			this.ribbonPageGroupMain = new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup();
			this.tabControlCategories = new global::DevExpress.XtraTab.XtraTabControl();
			this.tabPageUserCategories = new global::DevExpress.XtraTab.XtraTabPage();
			this.tabPageSystemCategories = new global::DevExpress.XtraTab.XtraTabPage();
			this.gridSystemCategories = new global::DevExpress.XtraGrid.GridControl();
			this.gridViewSystemCategories = new global::DevExpress.XtraGrid.Views.Grid.GridView();
			this.columnSystemCategoryName = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.columnSystemCategoryState = new global::DevExpress.XtraGrid.Columns.GridColumn();
			this.imageComboBoxSystemCategoryState = new global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel1).BeginInit();
			this.splitContainer.Panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel2).BeginInit();
			this.splitContainer.Panel2.SuspendLayout();
			this.splitContainer.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridUserCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUserCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUserCategoryType).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridAppFilters).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewAppFilters).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.tabControlCategories).BeginInit();
			this.tabControlCategories.SuspendLayout();
			this.tabPageUserCategories.SuspendLayout();
			this.tabPageSystemCategories.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.gridSystemCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSystemCategories).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxSystemCategoryState).BeginInit();
			base.SuspendLayout();
			resources.ApplyResources(this.splitContainer, "splitContainer");
			this.splitContainer.Horizontal = false;
			this.splitContainer.Name = "splitContainer";
			this.splitContainer.Panel1.Controls.Add(this.gridUserCategories);
			this.splitContainer.Panel2.Controls.Add(this.gridAppFilters);
			this.splitContainer.SplitterPosition = 223;
			resources.ApplyResources(this.gridUserCategories, "gridUserCategories");
			this.gridUserCategories.MainView = this.gridViewUserCategories;
			this.gridUserCategories.Name = "gridUserCategories";
			this.gridUserCategories.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxUserCategoryType
			});
			this.gridUserCategories.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewUserCategories
			});
			this.gridViewUserCategories.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.columnUserCategoryName,
				this.columnUserCategoryDescription,
				this.columnUserCategoryId,
				this.columnUserCategoryType,
				this.columnUserCategoryCommand
			});
			this.gridViewUserCategories.GridControl = this.gridUserCategories;
			this.gridViewUserCategories.Name = "gridViewUserCategories";
			this.gridViewUserCategories.OptionsDetail.EnableMasterViewMode = false;
			this.gridViewUserCategories.OptionsMenu.EnableColumnMenu = false;
			this.gridViewUserCategories.OptionsNavigation.AutoFocusNewRow = true;
			this.gridViewUserCategories.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewUserCategories.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewUserCategories.OptionsView.ShowGroupPanel = false;
			this.gridViewUserCategories.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.columnUserCategoryName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.gridViewUserCategories.FocusedRowChanged += new global::DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gridViewUserCategories_FocusedRowChanged);
			this.gridViewUserCategories.RowCountChanged += new global::System.EventHandler(this.gridViewUserCategories_RowCountChanged);
			this.columnUserCategoryName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserCategoryName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnUserCategoryName, "columnUserCategoryName");
			this.columnUserCategoryName.FieldName = "Name";
			this.columnUserCategoryName.Name = "columnUserCategoryName";
			this.columnUserCategoryName.OptionsColumn.AllowEdit = false;
			this.columnUserCategoryDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserCategoryDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnUserCategoryDescription, "columnUserCategoryDescription");
			this.columnUserCategoryDescription.FieldName = "Description";
			this.columnUserCategoryDescription.MinWidth = 25;
			this.columnUserCategoryDescription.Name = "columnUserCategoryDescription";
			this.columnUserCategoryDescription.OptionsColumn.AllowEdit = false;
			resources.ApplyResources(this.columnUserCategoryId, "columnUserCategoryId");
			this.columnUserCategoryId.FieldName = "Id";
			this.columnUserCategoryId.Name = "columnUserCategoryId";
			this.columnUserCategoryId.OptionsColumn.ShowInCustomizationForm = false;
			this.columnUserCategoryId.OptionsColumn.ShowInExpressionEditor = false;
			this.columnUserCategoryId.UnboundType = global::DevExpress.Data.UnboundColumnType.Integer;
			this.columnUserCategoryType.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserCategoryType.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnUserCategoryType, "columnUserCategoryType");
			this.columnUserCategoryType.ColumnEdit = this.imageComboBoxUserCategoryType;
			this.columnUserCategoryType.FieldName = "CategoryType";
			this.columnUserCategoryType.Name = "columnUserCategoryType";
			this.columnUserCategoryType.OptionsColumn.AllowEdit = false;
			this.columnUserCategoryType.UnboundType = global::DevExpress.Data.UnboundColumnType.Integer;
			resources.ApplyResources(this.imageComboBoxUserCategoryType, "imageComboBoxUserCategoryType");
			this.imageComboBoxUserCategoryType.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxUserCategoryType.Buttons"))
			});
			this.imageComboBoxUserCategoryType.Name = "imageComboBoxUserCategoryType";
			this.columnUserCategoryCommand.AppearanceHeader.Options.UseTextOptions = true;
			this.columnUserCategoryCommand.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.columnUserCategoryCommand.MinWidth = 120;
			this.columnUserCategoryCommand.Name = "columnUserCategoryCommand";
			this.columnUserCategoryCommand.ShowButtonMode = global::DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowForFocusedRow;
			resources.ApplyResources(this.columnUserCategoryCommand, "columnUserCategoryCommand");
			resources.ApplyResources(this.gridAppFilters, "gridAppFilters");
			this.gridAppFilters.MainView = this.gridViewAppFilters;
			this.gridAppFilters.MenuManager = this.ribbonControl;
			this.gridAppFilters.Name = "gridAppFilters";
			this.gridAppFilters.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewAppFilters
			});
			this.gridViewAppFilters.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.columnAppFilterType,
				this.columnAppFilterPath,
				this.columnAppFilterDescription,
				this.columnAppFilterCommand,
				this.columnAppFilterId
			});
			this.gridViewAppFilters.GridControl = this.gridAppFilters;
			this.gridViewAppFilters.Name = "gridViewAppFilters";
			this.gridViewAppFilters.OptionsDetail.EnableMasterViewMode = false;
			this.gridViewAppFilters.OptionsMenu.EnableColumnMenu = false;
			this.gridViewAppFilters.OptionsNavigation.AutoFocusNewRow = true;
			this.gridViewAppFilters.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewAppFilters.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewAppFilters.OptionsView.ShowGroupPanel = false;
			this.gridViewAppFilters.CustomUnboundColumnData += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDataEventHandler(this.gridViewAppFilters_CustomUnboundColumnData);
			this.gridViewAppFilters.CustomRowFilter += new global::DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridViewAppFilters_CustomRowFilter);
			this.gridViewAppFilters.CustomColumnDisplayText += new global::DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridViewAppFilters_CustomColumnDisplayText);
			this.columnAppFilterType.AppearanceHeader.Options.UseTextOptions = true;
			this.columnAppFilterType.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnAppFilterType, "columnAppFilterType");
			this.columnAppFilterType.FieldName = "FilterType";
			this.columnAppFilterType.MinWidth = 25;
			this.columnAppFilterType.Name = "columnAppFilterType";
			this.columnAppFilterType.OptionsColumn.ShowInCustomizationForm = false;
			this.columnAppFilterType.OptionsColumn.ShowInExpressionEditor = false;
			this.columnAppFilterPath.AppearanceHeader.Options.UseTextOptions = true;
			this.columnAppFilterPath.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnAppFilterPath, "columnAppFilterPath");
			this.columnAppFilterPath.FieldName = "Path";
			this.columnAppFilterPath.MinWidth = 25;
			this.columnAppFilterPath.Name = "columnAppFilterPath";
			this.columnAppFilterPath.OptionsColumn.AllowEdit = false;
			this.columnAppFilterPath.UnboundType = global::DevExpress.Data.UnboundColumnType.String;
			this.columnAppFilterDescription.AppearanceHeader.Options.UseTextOptions = true;
			this.columnAppFilterDescription.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnAppFilterDescription, "columnAppFilterDescription");
			this.columnAppFilterDescription.FieldName = "Description";
			this.columnAppFilterDescription.MinWidth = 25;
			this.columnAppFilterDescription.Name = "columnAppFilterDescription";
			this.columnAppFilterDescription.OptionsColumn.AllowEdit = false;
			this.columnAppFilterCommand.AppearanceHeader.Options.UseTextOptions = true;
			this.columnAppFilterCommand.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			this.columnAppFilterCommand.MinWidth = 25;
			this.columnAppFilterCommand.Name = "columnAppFilterCommand";
			resources.ApplyResources(this.columnAppFilterCommand, "columnAppFilterCommand");
			resources.ApplyResources(this.columnAppFilterId, "columnAppFilterId");
			this.columnAppFilterId.FieldName = "Id";
			this.columnAppFilterId.MinWidth = 25;
			this.columnAppFilterId.Name = "columnAppFilterId";
			this.columnAppFilterId.OptionsColumn.ShowInCustomizationForm = false;
			this.columnAppFilterId.OptionsColumn.ShowInExpressionEditor = false;
			this.ribbonControl.AllowMinimizeRibbon = false;
			this.ribbonControl.ExpandCollapseItem.Id = 0;
			this.ribbonControl.Items.AddRange(new global::DevExpress.XtraBars.BarItem[]
			{
				this.ribbonControl.ExpandCollapseItem,
				this.ribbonControl.SearchEditItem,
				this.barButtonExit,
				this.barButtonAddCategory,
				this.barButtonAddAppPathFilter
			});
			resources.ApplyResources(this.ribbonControl, "ribbonControl");
			this.ribbonControl.MaxItemId = 9;
			this.ribbonControl.Name = "ribbonControl";
			this.ribbonControl.Pages.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPage[]
			{
				this.ribbonPageMain
			});
			this.ribbonControl.ShowApplicationButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonControl.ShowDisplayOptionsMenuButton = global::DevExpress.Utils.DefaultBoolean.False;
			this.ribbonControl.ShowPageHeadersMode = global::DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
			this.ribbonControl.ShowQatLocationSelector = false;
			this.ribbonControl.ShowToolbarCustomizeItem = false;
			this.ribbonControl.Toolbar.ShowCustomizeItem = false;
			resources.ApplyResources(this.barButtonExit, "barButtonExit");
			this.barButtonExit.Id = 1;
			this.barButtonExit.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.close_16x16;
			this.barButtonExit.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.close_32x32;
			this.barButtonExit.Name = "barButtonExit";
			this.barButtonExit.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonExit_ItemClick);
			resources.ApplyResources(this.barButtonAddCategory, "barButtonAddCategory");
			this.barButtonAddCategory.Id = 2;
			this.barButtonAddCategory.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.addheader_16x16;
			this.barButtonAddCategory.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.addheader_32x32;
			this.barButtonAddCategory.Name = "barButtonAddCategory";
			this.barButtonAddCategory.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddCategory_ItemClick);
			resources.ApplyResources(this.barButtonAddAppPathFilter, "barButtonAddAppPathFilter");
			this.barButtonAddAppPathFilter.Id = 3;
			this.barButtonAddAppPathFilter.ImageOptions.LargeImage = global::OpiekunWEB.Console.Properties.Resources.filter_add_32x32;
			this.barButtonAddAppPathFilter.Name = "barButtonAddAppPathFilter";
			this.barButtonAddAppPathFilter.ItemClick += new global::DevExpress.XtraBars.ItemClickEventHandler(this.barButtonAddAppPath_ItemClick);
			this.ribbonPageMain.Groups.AddRange(new global::DevExpress.XtraBars.Ribbon.RibbonPageGroup[]
			{
				this.ribbonPageGroupMain
			});
			this.ribbonPageMain.Name = "ribbonPageMain";
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonExit);
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonAddCategory, true);
			this.ribbonPageGroupMain.ItemLinks.Add(this.barButtonAddAppPathFilter);
			this.ribbonPageGroupMain.Name = "ribbonPageGroupMain";
			resources.ApplyResources(this.ribbonPageGroupMain, "ribbonPageGroupMain");
			resources.ApplyResources(this.tabControlCategories, "tabControlCategories");
			this.tabControlCategories.Name = "tabControlCategories";
			this.tabControlCategories.SelectedTabPage = this.tabPageUserCategories;
			this.tabControlCategories.TabPages.AddRange(new global::DevExpress.XtraTab.XtraTabPage[]
			{
				this.tabPageUserCategories,
				this.tabPageSystemCategories
			});
			this.tabPageUserCategories.Controls.Add(this.splitContainer);
			this.tabPageUserCategories.Name = "tabPageUserCategories";
			resources.ApplyResources(this.tabPageUserCategories, "tabPageUserCategories");
			this.tabPageSystemCategories.Controls.Add(this.gridSystemCategories);
			this.tabPageSystemCategories.Name = "tabPageSystemCategories";
			resources.ApplyResources(this.tabPageSystemCategories, "tabPageSystemCategories");
			resources.ApplyResources(this.gridSystemCategories, "gridSystemCategories");
			this.gridSystemCategories.MainView = this.gridViewSystemCategories;
			this.gridSystemCategories.Name = "gridSystemCategories";
			this.gridSystemCategories.RepositoryItems.AddRange(new global::DevExpress.XtraEditors.Repository.RepositoryItem[]
			{
				this.imageComboBoxSystemCategoryState
			});
			this.gridSystemCategories.ViewCollection.AddRange(new global::DevExpress.XtraGrid.Views.Base.BaseView[]
			{
				this.gridViewSystemCategories
			});
			this.gridViewSystemCategories.Columns.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumn[]
			{
				this.columnSystemCategoryName,
				this.columnSystemCategoryState
			});
			this.gridViewSystemCategories.GridControl = this.gridSystemCategories;
			this.gridViewSystemCategories.Name = "gridViewSystemCategories";
			this.gridViewSystemCategories.OptionsMenu.EnableColumnMenu = false;
			this.gridViewSystemCategories.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.gridViewSystemCategories.OptionsSelection.EnableAppearanceHideSelection = false;
			this.gridViewSystemCategories.OptionsView.ShowGroupPanel = false;
			this.gridViewSystemCategories.SortInfo.AddRange(new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo[]
			{
				new global::DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.columnSystemCategoryName, global::DevExpress.Data.ColumnSortOrder.Ascending)
			});
			this.columnSystemCategoryName.AppearanceHeader.Options.UseTextOptions = true;
			this.columnSystemCategoryName.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnSystemCategoryName, "columnSystemCategoryName");
			this.columnSystemCategoryName.FieldName = "Name";
			this.columnSystemCategoryName.Name = "columnSystemCategoryName";
			this.columnSystemCategoryName.OptionsColumn.AllowEdit = false;
			this.columnSystemCategoryState.AppearanceHeader.Options.UseTextOptions = true;
			this.columnSystemCategoryState.AppearanceHeader.TextOptions.HAlignment = global::DevExpress.Utils.HorzAlignment.Center;
			resources.ApplyResources(this.columnSystemCategoryState, "columnSystemCategoryState");
			this.columnSystemCategoryState.ColumnEdit = this.imageComboBoxSystemCategoryState;
			this.columnSystemCategoryState.FieldName = "SystemCategoryState";
			this.columnSystemCategoryState.Name = "columnSystemCategoryState";
			this.columnSystemCategoryState.UnboundType = global::DevExpress.Data.UnboundColumnType.Integer;
			resources.ApplyResources(this.imageComboBoxSystemCategoryState, "imageComboBoxSystemCategoryState");
			this.imageComboBoxSystemCategoryState.Buttons.AddRange(new global::DevExpress.XtraEditors.Controls.EditorButton[]
			{
				new global::DevExpress.XtraEditors.Controls.EditorButton((global::DevExpress.XtraEditors.Controls.ButtonPredefines)resources.GetObject("imageComboBoxSystemCategoryState.Buttons"))
			});
			this.imageComboBoxSystemCategoryState.Name = "imageComboBoxSystemCategoryState";
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.tabControlCategories);
			base.Controls.Add(this.ribbonControl);
			base.Name = "AppCategoriesForm";
			this.Ribbon = this.ribbonControl;
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel1).EndInit();
			this.splitContainer.Panel1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer.Panel2).EndInit();
			this.splitContainer.Panel2.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.splitContainer).EndInit();
			this.splitContainer.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridUserCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewUserCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxUserCategoryType).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridAppFilters).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewAppFilters).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.ribbonControl).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.tabControlCategories).EndInit();
			this.tabControlCategories.ResumeLayout(false);
			this.tabPageUserCategories.ResumeLayout(false);
			this.tabPageSystemCategories.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.gridSystemCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.gridViewSystemCategories).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.imageComboBoxSystemCategoryState).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000168 RID: 360
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000169 RID: 361
		private global::DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;

		// Token: 0x0400016A RID: 362
		private global::DevExpress.XtraBars.BarButtonItem barButtonExit;

		// Token: 0x0400016B RID: 363
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddCategory;

		// Token: 0x0400016C RID: 364
		private global::DevExpress.XtraBars.BarButtonItem barButtonAddAppPathFilter;

		// Token: 0x0400016D RID: 365
		private global::DevExpress.XtraBars.Ribbon.RibbonPage ribbonPageMain;

		// Token: 0x0400016E RID: 366
		private global::DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupMain;

		// Token: 0x0400016F RID: 367
		private global::DevExpress.XtraTab.XtraTabControl tabControlCategories;

		// Token: 0x04000170 RID: 368
		private global::DevExpress.XtraTab.XtraTabPage tabPageUserCategories;

		// Token: 0x04000171 RID: 369
		private global::DevExpress.XtraEditors.SplitContainerControl splitContainer;

		// Token: 0x04000172 RID: 370
		private global::DevExpress.XtraGrid.GridControl gridUserCategories;

		// Token: 0x04000173 RID: 371
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewUserCategories;

		// Token: 0x04000174 RID: 372
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryName;

		// Token: 0x04000175 RID: 373
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryId;

		// Token: 0x04000176 RID: 374
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryType;

		// Token: 0x04000177 RID: 375
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxUserCategoryType;

		// Token: 0x04000178 RID: 376
		private global::DevExpress.XtraTab.XtraTabPage tabPageSystemCategories;

		// Token: 0x04000179 RID: 377
		private global::DevExpress.XtraGrid.GridControl gridSystemCategories;

		// Token: 0x0400017A RID: 378
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewSystemCategories;

		// Token: 0x0400017B RID: 379
		private global::DevExpress.XtraGrid.Columns.GridColumn columnSystemCategoryName;

		// Token: 0x0400017C RID: 380
		private global::DevExpress.XtraGrid.Columns.GridColumn columnSystemCategoryState;

		// Token: 0x0400017D RID: 381
		private global::DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox imageComboBoxSystemCategoryState;

		// Token: 0x0400017E RID: 382
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryCommand;

		// Token: 0x0400017F RID: 383
		private global::DevExpress.XtraGrid.Columns.GridColumn columnUserCategoryDescription;

		// Token: 0x04000180 RID: 384
		private global::DevExpress.XtraGrid.GridControl gridAppFilters;

		// Token: 0x04000181 RID: 385
		private global::DevExpress.XtraGrid.Views.Grid.GridView gridViewAppFilters;

		// Token: 0x04000182 RID: 386
		private global::DevExpress.XtraGrid.Columns.GridColumn columnAppFilterType;

		// Token: 0x04000183 RID: 387
		private global::DevExpress.XtraGrid.Columns.GridColumn columnAppFilterDescription;

		// Token: 0x04000184 RID: 388
		private global::DevExpress.XtraGrid.Columns.GridColumn columnAppFilterCommand;

		// Token: 0x04000185 RID: 389
		private global::DevExpress.XtraGrid.Columns.GridColumn columnAppFilterId;

		// Token: 0x04000186 RID: 390
		private global::DevExpress.XtraGrid.Columns.GridColumn columnAppFilterPath;
	}
}
