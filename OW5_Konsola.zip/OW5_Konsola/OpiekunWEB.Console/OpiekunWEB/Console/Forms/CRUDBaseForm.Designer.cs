﻿namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000059 RID: 89
	public partial class CRUDBaseForm : global::OpiekunWEB.Console.Forms.BaseForm
	{
		// Token: 0x060004CC RID: 1228 RVA: 0x0001819F File Offset: 0x0001639F
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x000181C0 File Offset: 0x000163C0
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager resources = new global::System.ComponentModel.ComponentResourceManager(typeof(global::OpiekunWEB.Console.Forms.CRUDBaseForm));
			this.buttonSave = new global::DevExpress.XtraEditors.SimpleButton();
			base.SuspendLayout();
			resources.ApplyResources(this.buttonSave, "buttonSave");
			this.buttonSave.ImageOptions.Image = global::OpiekunWEB.Console.Properties.Resources.apply_16x16;
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Click += new global::System.EventHandler(this.buttonSave_Click);
			base.AcceptButton = this.buttonSave;
			resources.ApplyResources(this, "$this");
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.buttonSave);
			base.IconOptions.Icon = (global::System.Drawing.Icon)resources.GetObject("CRUDBaseForm.IconOptions.Icon");
			base.Name = "CRUDBaseForm";
			base.ResumeLayout(false);
		}

		// Token: 0x0400021B RID: 539
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400021C RID: 540
		protected global::DevExpress.XtraEditors.SimpleButton buttonSave;
	}
}
