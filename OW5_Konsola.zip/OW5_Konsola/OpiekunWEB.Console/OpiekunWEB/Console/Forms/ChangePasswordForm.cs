﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200005D RID: 93
	public partial class ChangePasswordForm : BaseForm
	{
		// Token: 0x06000504 RID: 1284 RVA: 0x000195F8 File Offset: 0x000177F8
		public ChangePasswordForm(FormsSettings formsSettings, IFormCreator formCreator, ApiClient apiClient) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this.InitializeComponent();
			this._apiClient = apiClient;
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x00019610 File Offset: 0x00017810
		private void buttonOk_Click(object sender, EventArgs e)
		{
			ChangePasswordForm.<buttonOk_Click>d__2 <buttonOk_Click>d__;
			<buttonOk_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<buttonOk_Click>d__.<>4__this = this;
			<buttonOk_Click>d__.<>1__state = -1;
			<buttonOk_Click>d__.<>t__builder.Start<ChangePasswordForm.<buttonOk_Click>d__2>(ref <buttonOk_Click>d__);
		}

		// Token: 0x0400022C RID: 556
		private readonly ApiClient _apiClient;
	}
}
