﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.XtraEditors;
using DevExpress.XtraLayout;
using DevExpress.XtraLayout.Utils;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x0200006F RID: 111
	public partial class LogonSessionForm : BaseForm
	{
		// Token: 0x060005E5 RID: 1509 RVA: 0x00028BB0 File Offset: 0x00026DB0
		public LogonSessionForm(FormsSettings formsSettings, IFormCreator formCreator, AppConfiguration appConfiguration, ApiClient apiClient, LogonSessionFormParams @params) : base(formsSettings, formCreator, FormAction.Unknown)
		{
			this._params = @params;
			this._appConfiguration = appConfiguration;
			this._passwordRegistryKey = apiClient.CustomerId + "LogonSessionFormPassword";
			this.InitializeComponent();
			this._objectsToSaveState.Add(this.textEditUserName);
			this._objectsToSaveState.Add(this.textEditDomainName);
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x00028C14 File Offset: 0x00026E14
		private void buttonOk_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this.textEditUserName.Text))
			{
				this._formCreator.ShowError(Resources.LogonSessionFormParams_MustEnterUserName);
				base.ActiveControl = this.textEditUserName;
				return;
			}
			this._params.DomainName = this.textEditDomainName.Text;
			this._params.UserName = this.textEditUserName.Text;
			this._params.Password = this.textEditPassword.Text;
			if (this.checkEditSavePassword.Checked)
			{
				this._appConfiguration.WriteEncryptedObjectToUserRegistry<string>(this._passwordRegistryKey, this.textEditPassword.Text);
			}
			else
			{
				this._appConfiguration.WriteEncryptedObjectToUserRegistry<string>(string.Empty, this._passwordRegistryKey);
			}
			base.DialogResult = DialogResult.OK;
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x00028CDC File Offset: 0x00026EDC
		private void FormLogonWindows_Load(object sender, EventArgs e)
		{
			if (!string.IsNullOrEmpty(this.textEditUserName.Text))
			{
				base.ActiveControl = this.textEditPassword;
				this.textEditPassword.Text = this._appConfiguration.ReadEncrytedObjectFromUserRegistry<string>(this._passwordRegistryKey);
				this.checkEditSavePassword.Checked = !string.IsNullOrEmpty(this.textEditPassword.Text);
			}
		}

		// Token: 0x04000364 RID: 868
		private readonly AppConfiguration _appConfiguration;

		// Token: 0x04000365 RID: 869
		private readonly LogonSessionFormParams _params;

		// Token: 0x04000366 RID: 870
		private string _passwordRegistryKey;
	}
}
