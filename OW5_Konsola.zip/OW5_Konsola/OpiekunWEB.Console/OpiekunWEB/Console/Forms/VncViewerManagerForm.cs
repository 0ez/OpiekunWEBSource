﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using DevExpress.XtraBars;
using DevExpress.XtraBars.Docking;
using DevExpress.XtraBars.Docking2010;
using DevExpress.XtraBars.Docking2010.Views;
using DevExpress.XtraBars.Docking2010.Views.Tabbed;
using OpiekunWEB.Console.Controls;
using OpiekunWEB.Console.Forms.FullScreenDockManager;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Forms
{
	// Token: 0x02000079 RID: 121
	public partial class VncViewerManagerForm : NonModalBaseForm
	{
		// Token: 0x06000653 RID: 1619 RVA: 0x000323D4 File Offset: 0x000305D4
		public VncViewerManagerForm(FormsSettings formsSettings, IFormCreator formCreator) : base(formsSettings, formCreator)
		{
			this.InitializeComponent();
			this.dockManager.OnCreateDockPanel += this.OnCreateDockPanel;
			this._inputMode = RemoteDesktopInputMode.AdminAndUser;
			try
			{
				this._screenStretchMode = (RemoteDesktopStretchMode)formsSettings.UserIniFile.ReadInt(base.Name, "ScreenStretchMode", 2);
			}
			catch (Exception)
			{
				this._screenStretchMode = RemoteDesktopStretchMode.AspecRatio;
			}
			this._objectsToSaveState.Add(this);
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x00032454 File Offset: 0x00030654
		public void AddDisplays(DeviceAndDisplayList deviceAndDisplayList, RemoteDesktopConnectionType connectionType, object connectionParams)
		{
			base.SuspendLayout();
			try
			{
				foreach (DeviceAndDisplay deviceAndDisplay in from x in deviceAndDisplayList
				orderby x.DeviceItem.Name
				select x)
				{
					this.AddDeviceAndDisplay(deviceAndDisplay.DeviceItem, deviceAndDisplay.DisplayItem, connectionType, connectionParams);
				}
			}
			finally
			{
				base.ResumeLayout();
			}
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x000324E8 File Offset: 0x000306E8
		public void FullScreenOff()
		{
			this.tabbedView.DocumentGroupProperties.ShowTabHeader = true;
			base.FormBorderStyle = FormBorderStyle.Sizable;
			base.WindowState = FormWindowState.Normal;
			this.timerMainMenuShow.Enabled = false;
			this.barMainMenu.CanDockStyle = BarCanDockStyle.Top;
			this.barMainMenu.DockStyle = BarDockStyle.Top;
			this.barMainMenu.Visible = true;
			this.AllDockPanelsAction(delegate(RemoteDesktopDockPanel panel)
			{
				panel.IsFullScreen = false;
			});
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x0003256C File Offset: 0x0003076C
		public void FullScreenOn()
		{
			this.tabbedView.DocumentGroupProperties.ShowTabHeader = false;
			base.WindowState = FormWindowState.Normal;
			base.FormBorderStyle = FormBorderStyle.None;
			base.WindowState = FormWindowState.Maximized;
			this.barMainMenu.CanDockStyle = BarCanDockStyle.All;
			this.barMainMenu.DockStyle = BarDockStyle.None;
			this.barMainMenu.FloatLocation = new Point((base.Size.Width - this.barMainMenu.Size.Width) / 2, 0);
			this.timerMainMenuShow.Enabled = true;
			this.AllDockPanelsAction(delegate(RemoteDesktopDockPanel panel)
			{
				panel.IsFullScreen = true;
			});
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x00032620 File Offset: 0x00030820
		protected override void SetVisibleCore(bool value)
		{
			this._controlToActivate = null;
			if (this.tabbedView.Documents.Count > 1)
			{
				this._controlToActivate = this.tabbedView.Documents[0].Control;
			}
			base.SetVisibleCore(value);
			if (value && this._controlToActivate != null)
			{
				this.tabbedView.ActivateDocument(this._controlToActivate);
			}
			this._controlToActivate = null;
		}

		// Token: 0x06000658 RID: 1624 RVA: 0x00032690 File Offset: 0x00030890
		private bool ActivateDeviceWindow(DeviceItem deviceItem, DisplayItem displayItem, RemoteDesktopConnectionType connectionType)
		{
			RemoteDesktopDockPanel panel = this.GetDevicePanel(deviceItem, displayItem, connectionType);
			if (panel == null)
			{
				return false;
			}
			if (panel.FloatForm == null)
			{
				base.Activate();
				this.tabbedView.ActivateDocument(panel);
			}
			else
			{
				panel.FloatForm.Activate();
			}
			return true;
		}

		// Token: 0x06000659 RID: 1625 RVA: 0x000326D4 File Offset: 0x000308D4
		private void ActiveDocumentRemoteAction(Action<IRemoteDesktopControler> remoteAction)
		{
			IRemoteDesktopControler controler = this.GetActiveDocumentControler();
			if (controler != null)
			{
				remoteAction(controler);
			}
		}

		// Token: 0x0600065A RID: 1626 RVA: 0x000326F4 File Offset: 0x000308F4
		private void AddDeviceAndDisplay(DeviceItem deviceItem, DisplayItem displayItem, RemoteDesktopConnectionType connectionType, object connectionParams)
		{
			VncViewerManagerForm.<AddDeviceAndDisplay>d__11 <AddDeviceAndDisplay>d__;
			<AddDeviceAndDisplay>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<AddDeviceAndDisplay>d__.<>4__this = this;
			<AddDeviceAndDisplay>d__.deviceItem = deviceItem;
			<AddDeviceAndDisplay>d__.displayItem = displayItem;
			<AddDeviceAndDisplay>d__.connectionType = connectionType;
			<AddDeviceAndDisplay>d__.connectionParams = connectionParams;
			<AddDeviceAndDisplay>d__.<>1__state = -1;
			<AddDeviceAndDisplay>d__.<>t__builder.Start<VncViewerManagerForm.<AddDeviceAndDisplay>d__11>(ref <AddDeviceAndDisplay>d__);
		}

		// Token: 0x0600065B RID: 1627 RVA: 0x0003274C File Offset: 0x0003094C
		private void AllDockPanelsAction(Action<RemoteDesktopDockPanel> panelAction)
		{
			foreach (BaseDocument doc in ((IEnumerable<BaseDocument>)this.tabbedView.Documents))
			{
				panelAction(doc.Control as RemoteDesktopDockPanel);
			}
		}

		// Token: 0x0600065C RID: 1628 RVA: 0x000327A8 File Offset: 0x000309A8
		private void AllDocummentsRemoteAction(Action<IRemoteDesktopControler> remoteAction)
		{
			foreach (BaseDocument doc in ((IEnumerable<BaseDocument>)this.tabbedView.Documents))
			{
				if (doc != null)
				{
					RemoteDesktopDockPanel remoteDesktopDockPanel = doc.Control as RemoteDesktopDockPanel;
					IRemoteDesktopControler controler = (remoteDesktopDockPanel != null) ? remoteDesktopDockPanel.Controler : null;
					if (controler != null)
					{
						remoteAction(controler);
					}
				}
			}
		}

		// Token: 0x0600065D RID: 1629 RVA: 0x00032818 File Offset: 0x00030A18
		private void barButtonDisconnect_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ActiveDocumentRemoteAction(delegate(IRemoteDesktopControler controler)
			{
				VncViewerManagerForm.<>c.<<barButtonDisconnect_ItemClick>b__14_0>d <<barButtonDisconnect_ItemClick>b__14_0>d;
				<<barButtonDisconnect_ItemClick>b__14_0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<barButtonDisconnect_ItemClick>b__14_0>d.controler = controler;
				<<barButtonDisconnect_ItemClick>b__14_0>d.<>1__state = -1;
				<<barButtonDisconnect_ItemClick>b__14_0>d.<>t__builder.Start<VncViewerManagerForm.<>c.<<barButtonDisconnect_ItemClick>b__14_0>d>(ref <<barButtonDisconnect_ItemClick>b__14_0>d);
			});
		}

		// Token: 0x0600065E RID: 1630 RVA: 0x0003283F File Offset: 0x00030A3F
		private void barButtonFullScreenOff_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.FullScreenOff();
		}

		// Token: 0x0600065F RID: 1631 RVA: 0x00032847 File Offset: 0x00030A47
		private void barButtonFullScreenOn_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.FullScreenOn();
		}

		// Token: 0x06000660 RID: 1632 RVA: 0x00032850 File Offset: 0x00030A50
		private void barButtonInputMode_CheckedChanged(object sender, ItemClickEventArgs e)
		{
			if (e.Item == this.barButtonInputModeAdmin)
			{
				this._inputMode = RemoteDesktopInputMode.Admin;
			}
			else if (e.Item == this.barButtonInputModeAdminAndUser)
			{
				this._inputMode = RemoteDesktopInputMode.AdminAndUser;
			}
			else if (e.Item == this.barButtonInputModeUser)
			{
				this._inputMode = RemoteDesktopInputMode.User;
			}
			this.ActiveDocumentRemoteAction(delegate(IRemoteDesktopControler controler)
			{
				controler.InputMode = this._inputMode;
			});
		}

		// Token: 0x06000661 RID: 1633 RVA: 0x000328B2 File Offset: 0x00030AB2
		private void barButtonNextWindow_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.tabbedView.Controller.SelectNextTab(true);
		}

		// Token: 0x06000662 RID: 1634 RVA: 0x000328C6 File Offset: 0x00030AC6
		private void barButtonPrevWindow_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.tabbedView.Controller.SelectNextTab(false);
		}

		// Token: 0x06000663 RID: 1635 RVA: 0x000328DA File Offset: 0x00030ADA
		private void barButtonRefresh_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ActiveDocumentRemoteAction(delegate(IRemoteDesktopControler controler)
			{
				VncViewerManagerForm.<>c.<<barButtonRefresh_ItemClick>b__20_0>d <<barButtonRefresh_ItemClick>b__20_0>d;
				<<barButtonRefresh_ItemClick>b__20_0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<barButtonRefresh_ItemClick>b__20_0>d.controler = controler;
				<<barButtonRefresh_ItemClick>b__20_0>d.<>1__state = -1;
				<<barButtonRefresh_ItemClick>b__20_0>d.<>t__builder.Start<VncViewerManagerForm.<>c.<<barButtonRefresh_ItemClick>b__20_0>d>(ref <<barButtonRefresh_ItemClick>b__20_0>d);
			});
		}

		// Token: 0x06000664 RID: 1636 RVA: 0x00032901 File Offset: 0x00030B01
		private void barButtonRemoteConnect_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ActiveDocumentRemoteAction(delegate(IRemoteDesktopControler controler)
			{
				VncViewerManagerForm.<>c.<<barButtonRemoteConnect_ItemClick>b__21_0>d <<barButtonRemoteConnect_ItemClick>b__21_0>d;
				<<barButtonRemoteConnect_ItemClick>b__21_0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
				<<barButtonRemoteConnect_ItemClick>b__21_0>d.controler = controler;
				<<barButtonRemoteConnect_ItemClick>b__21_0>d.<>1__state = -1;
				<<barButtonRemoteConnect_ItemClick>b__21_0>d.<>t__builder.Start<VncViewerManagerForm.<>c.<<barButtonRemoteConnect_ItemClick>b__21_0>d>(ref <<barButtonRemoteConnect_ItemClick>b__21_0>d);
			});
		}

		// Token: 0x06000665 RID: 1637 RVA: 0x00032928 File Offset: 0x00030B28
		private void barButtonSendCAD_ItemClick(object sender, ItemClickEventArgs e)
		{
			this.ActiveDocumentRemoteAction(delegate(IRemoteDesktopControler control)
			{
				control.SendCAD();
			});
		}

		// Token: 0x06000666 RID: 1638 RVA: 0x00032950 File Offset: 0x00030B50
		private void barButtonStretchMode_CheckedChanged(object sender, ItemClickEventArgs e)
		{
			if (e.Item == this.barButtonStretchModeAspectRatio)
			{
				this._screenStretchMode = RemoteDesktopStretchMode.AspecRatio;
			}
			else if (e.Item == this.barButtonStretchModeFitToWindow)
			{
				this._screenStretchMode = RemoteDesktopStretchMode.FitToWindow;
			}
			else if (e.Item == this.barButtonStretchModeDisabled)
			{
				this._screenStretchMode = RemoteDesktopStretchMode.Disabled;
			}
			this.ActiveDocumentRemoteAction(delegate(IRemoteDesktopControler controler)
			{
				controler.StretchMode = this._screenStretchMode;
			});
		}

		// Token: 0x06000667 RID: 1639 RVA: 0x000329B4 File Offset: 0x00030BB4
		private void FormVncViewerManager_FormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel = true;
			base.Hide();
			this.tabbedView.Controller.CloseAll();
			this._formsSettings.UserIniFile.WriteInt(base.Name, "ScreenStretchMode", (int)this._screenStretchMode);
		}

		// Token: 0x06000668 RID: 1640 RVA: 0x00032A00 File Offset: 0x00030C00
		private IRemoteDesktopControler GetActiveDocumentControler()
		{
			if (this.tabbedView.ActiveDocument == null)
			{
				return null;
			}
			RemoteDesktopDockPanel remoteDesktopDockPanel = this.tabbedView.ActiveDocument.Control as RemoteDesktopDockPanel;
			if (remoteDesktopDockPanel == null)
			{
				return null;
			}
			return remoteDesktopDockPanel.Controler;
		}

		// Token: 0x06000669 RID: 1641 RVA: 0x00032A34 File Offset: 0x00030C34
		private RemoteDesktopDockPanel GetDevicePanel(DeviceItem deviceItem, DisplayItem displayItem, RemoteDesktopConnectionType connectionType)
		{
			if (this.tabbedView.Documents != null)
			{
				foreach (BaseDocument document in ((IEnumerable<BaseDocument>)this.tabbedView.Documents))
				{
					if (document.Control is RemoteDesktopDockPanel && this.IsRemoteDesktopDockPanelForDevice(document.Control as RemoteDesktopDockPanel, deviceItem, displayItem, connectionType))
					{
						return document.Control as RemoteDesktopDockPanel;
					}
				}
			}
			if (this.tabbedView.FloatPanels != null)
			{
				foreach (BaseDocument document2 in ((IEnumerable<BaseDocument>)this.tabbedView.FloatPanels))
				{
					if (document2.Form.Controls[0] is RemoteDesktopDockPanel && this.IsRemoteDesktopDockPanelForDevice(document2.Form.Controls[0] as RemoteDesktopDockPanel, deviceItem, displayItem, connectionType))
					{
						return document2.Form.Controls[0] as RemoteDesktopDockPanel;
					}
				}
			}
			return null;
		}

		// Token: 0x0600066A RID: 1642 RVA: 0x00032B60 File Offset: 0x00030D60
		private bool IsRemoteDesktopDockPanelForDevice(RemoteDesktopDockPanel vncDockPanel, DeviceItem deviceItem, DisplayItem displayItem, RemoteDesktopConnectionType connectionType)
		{
			if (vncDockPanel != null)
			{
				if (connectionType == RemoteDesktopConnectionType.RDP)
				{
					if (vncDockPanel.Controler.DeviceItem == deviceItem)
					{
						return true;
					}
				}
				else
				{
					if (vncDockPanel.Controler.DeviceItem == deviceItem && vncDockPanel.Controler.DisplayItem == displayItem)
					{
						return true;
					}
					if (displayItem != null && vncDockPanel.Controler.DisplayItem != null)
					{
						AgentItem agentItem = displayItem.AgentItem;
						string a = (agentItem != null) ? agentItem.Id : null;
						AgentItem agentItem2 = vncDockPanel.Controler.DisplayItem.AgentItem;
						return a == ((agentItem2 != null) ? agentItem2.Id : null);
					}
				}
			}
			return false;
		}

		// Token: 0x0600066B RID: 1643 RVA: 0x00032BE8 File Offset: 0x00030DE8
		private DockPanel OnCreateDockPanel(object sender, DockingStyle dock, bool createControlContainer)
		{
			return new RemoteDesktopDockPanel(createControlContainer, dock, sender as DockManager);
		}

		// Token: 0x0600066C RID: 1644 RVA: 0x00032BF8 File Offset: 0x00030DF8
		private void tabbedView_DocumentActivated(object sender, DocumentEventArgs e)
		{
			VncViewerManagerForm.<tabbedView_DocumentActivated>d__29 <tabbedView_DocumentActivated>d__;
			<tabbedView_DocumentActivated>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<tabbedView_DocumentActivated>d__.<>4__this = this;
			<tabbedView_DocumentActivated>d__.e = e;
			<tabbedView_DocumentActivated>d__.<>1__state = -1;
			<tabbedView_DocumentActivated>d__.<>t__builder.Start<VncViewerManagerForm.<tabbedView_DocumentActivated>d__29>(ref <tabbedView_DocumentActivated>d__);
		}

		// Token: 0x0600066D RID: 1645 RVA: 0x00032C37 File Offset: 0x00030E37
		private void tabbedView_DocumentClosed(object sender, DocumentEventArgs e)
		{
			if (this.tabbedView.Documents.Count == 0)
			{
				base.Hide();
				base.Close();
			}
		}

		// Token: 0x0600066E RID: 1646 RVA: 0x00032C57 File Offset: 0x00030E57
		private void tabbedView_DocumentClosing(object sender, DocumentCancelEventArgs e)
		{
			BaseDocument document = e.Document;
			if (((document != null) ? document.Control : null) != null)
			{
				RemoteDesktopDockPanel remoteDesktopDockPanel = e.Document.Control as RemoteDesktopDockPanel;
				if (remoteDesktopDockPanel == null)
				{
					return;
				}
				remoteDesktopDockPanel.Controler.WindowClosing();
			}
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x00032C8C File Offset: 0x00030E8C
		private void tabbedView_EndFloating(object sender, DocumentEventArgs e)
		{
			e.Document.Form.Owner = null;
			e.Document.Form.ShowInTaskbar = true;
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x00032C8C File Offset: 0x00030E8C
		private void tabbedView_Floating(object sender, DocumentEventArgs e)
		{
			e.Document.Form.Owner = null;
			e.Document.Form.ShowInTaskbar = true;
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x00032CB0 File Offset: 0x00030EB0
		private void timerMainMenuShow_Tick(object sender, EventArgs e)
		{
			if (this.barMainMenu.Visible)
			{
				if (!this.barMainMenu.GetBarControl().Parent.Bounds.Contains(Cursor.Position))
				{
					this._mainMenuBounds = this.barMainMenu.GetBarControl().Parent.Bounds;
					this.barMainMenu.Visible = false;
					return;
				}
			}
			else if (!this.barMainMenu.Visible && this._mainMenuBounds.Contains(Cursor.Position))
			{
				this.barMainMenu.Visible = true;
			}
		}

		// Token: 0x04000408 RID: 1032
		private Control _controlToActivate;

		// Token: 0x04000409 RID: 1033
		private RemoteDesktopInputMode _inputMode;

		// Token: 0x0400040A RID: 1034
		private Rectangle _mainMenuBounds;

		// Token: 0x0400040B RID: 1035
		private RemoteDesktopStretchMode _screenStretchMode;
	}
}
