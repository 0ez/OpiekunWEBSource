﻿using System;

namespace OpiekunWEB.Console
{
	// Token: 0x02000008 RID: 8
	public class DeviceAndDisplay
	{
		// Token: 0x0600002C RID: 44 RVA: 0x00002D45 File Offset: 0x00000F45
		public DeviceAndDisplay(DeviceItem deviceItem, DisplayItem displayItem)
		{
			this.DeviceItem = deviceItem;
			this.DisplayItem = displayItem;
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600002D RID: 45 RVA: 0x00002D5B File Offset: 0x00000F5B
		public DeviceItem DeviceItem { get; }

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600002E RID: 46 RVA: 0x00002D63 File Offset: 0x00000F63
		public DisplayItem DisplayItem { get; }
	}
}
