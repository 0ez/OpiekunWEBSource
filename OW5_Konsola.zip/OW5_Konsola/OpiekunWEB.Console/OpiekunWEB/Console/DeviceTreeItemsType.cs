﻿using System;

namespace OpiekunWEB.Console
{
	// Token: 0x02000017 RID: 23
	[Flags]
	public enum DeviceTreeItemsType
	{
		// Token: 0x04000078 RID: 120
		Unknown = 0,
		// Token: 0x04000079 RID: 121
		Agent = 1,
		// Token: 0x0400007A RID: 122
		DeviceGroup = 2,
		// Token: 0x0400007B RID: 123
		Device = 4,
		// Token: 0x0400007C RID: 124
		Display = 8
	}
}
