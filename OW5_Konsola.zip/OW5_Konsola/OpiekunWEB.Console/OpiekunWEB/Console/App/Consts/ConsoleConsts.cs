﻿using System;

namespace OpiekunWEB.Console.App.Consts
{
	// Token: 0x020000BE RID: 190
	public static class ConsoleConsts
	{
		// Token: 0x04000773 RID: 1907
		public const int FILE_TRANSFER_CHUNK_SIZE = 30720;
	}
}
