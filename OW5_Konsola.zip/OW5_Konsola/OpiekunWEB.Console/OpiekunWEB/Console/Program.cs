﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using CryptoObfuscatorHelper.ExceptionReporting;
using DevExpress.LookAndFeel;
using DevExpress.Skins;
using DevExpress.UserSkins;
using DevExpress.XtraEditors;
using DevExpress.XtraLayout;
using Grpc.Core;
using OpiekunWEB.Api;
using OpiekunWEB.Api.Helpers;
using OpiekunWEB.Console.Forms;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Helpers;
using OpiekunWEB.Console.Interfaces;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x02000011 RID: 17
	internal static class Program
	{
		// Token: 0x06000071 RID: 113 RVA: 0x00003A94 File Offset: 0x00001C94
		private static void ApplicationOnThreadException(object sender, ThreadExceptionEventArgs e)
		{
			try
			{
				Program._formCreator.Show<ExceptionReportForm, Exception>(e.Exception);
			}
			catch (Exception)
			{
				string str = "Critical error:\r\n";
				string str2;
				if (e == null)
				{
					str2 = null;
				}
				else
				{
					Exception exception = e.Exception;
					str2 = ((exception != null) ? exception.ToString() : null);
				}
				MessageBox.Show(str + str2);
			}
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00003AF0 File Offset: 0x00001CF0
		private static void ApplicationOnUnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Program.ApplicationOnThreadException(sender, new ThreadExceptionEventArgs(e.ExceptionObject as Exception));
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00003B08 File Offset: 0x00001D08
		private static void CryptoObfuscatorExceptionHandler(object sender, ExceptionThrownEventArgs e)
		{
			Program.ApplicationOnThreadException(sender, new ThreadExceptionEventArgs(e.Exception));
			e.Handled = true;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00003B22 File Offset: 0x00001D22
		private static Assembly EmbeddedAssemblyResolver(object sender, ResolveEventArgs args)
		{
			if (args.Name.StartsWith("System.Interactive.Async"))
			{
				return Assembly.LoadFile(AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "System.Interactive.Async.dll");
			}
			return null;
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00003B56 File Offset: 0x00001D56
		private static void EnableGrpcTrace()
		{
			GrpcEnvironment.SetLogger(new GrpcLogger());
			Environment.SetEnvironmentVariable("GRPC_TRACE", "all");
			Environment.SetEnvironmentVariable("GRPC_VERBOSITY", "DEBUG");
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00003B80 File Offset: 0x00001D80
		[STAThread]
		private static void Main()
		{
			ExceptionHandler.ExceptionThrown += Program.CryptoObfuscatorExceptionHandler;
			Application.ThreadException += Program.ApplicationOnThreadException;
			Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
			AppDomain.CurrentDomain.UnhandledException += Program.ApplicationOnUnhandledException;
			AppDomain.CurrentDomain.AssemblyResolve += Program.EmbeddedAssemblyResolver;
			AppUtils.SetAppCulture("PL-pl");
			WindowsFormsSettings.ForceDirectXPaint();
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			SkinManager.EnableFormSkins();
			BonusSkins.Register();
			UserLookAndFeel.Default.SetSkinStyle("DevExpress Style");
			LayoutControl.AllowCustomizationDefaultValue = false;
			AppFactory appFactory = new AppFactory("https://grpc.opiekunweb.pl:443;grpc.opiekunweb.pl:80;grpc.opiekunweb.pl:8384;https://grpc.opiekunweb.pl:8383");
			Program._formCreator = appFactory.GetInstance<IFormCreator>();
			if (Program._formCreator.Show<LoginForm>())
			{
				ApiClient apiClient = appFactory.GetInstance<ApiClient>();
				if (apiClient.GetDeviceGroupsSelectMode() == DeviceGroupsSelectMode.DeviceGroupsSelectOneGroupByUser)
				{
					DeviceGroupsSelectionFormParams @params = new DeviceGroupsSelectionFormParams(apiClient.GetAvailableDeviceGroupsId(), new List<string>(), false)
					{
						DisableWindowsCanceling = true
					};
					if (@params.AllowedGroupsId.Count > 0)
					{
						Program._formCreator.Show<DeviceGroupsSelectionForm, DeviceGroupsSelectionFormParams>(FormAction.Unknown, @params, out @params);
						if (@params.SelectedGroupsId.Count > 0)
						{
							apiClient.DeviceGroupSelectedByUser = @params.SelectedGroupsId[0];
						}
					}
				}
				Application.Run(appFactory.GetInstance<MainForm>());
			}
		}

		// Token: 0x04000036 RID: 54
		private static IFormCreator _formCreator;
	}
}
