﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using OpiekunWEB.Api;
using Owpb;

namespace OpiekunWEB.Console
{
	// Token: 0x02000018 RID: 24
	public class DeviceTreeItemBase : INotifyPropertyChanged
	{
		// Token: 0x060000E9 RID: 233 RVA: 0x00006068 File Offset: 0x00004268
		public DeviceTreeItemBase()
		{
			this._connectionTypeIconIndexes = Enumerable.Repeat<int>(-1, 2).ToArray<int>();
			this._deviceIconIndexes = Enumerable.Repeat<int>(-1, 3).ToArray<int>();
			this._userIconIndexes = Enumerable.Repeat<int>(-1, 3).ToArray<int>();
			this.SetIconForDeviceInetAccess(DeviceTreeIconIndexes.GetInetControlStateIndex(this._inetAccess));
			this._connectionDescription = string.Empty;
		}

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x060000EA RID: 234 RVA: 0x000060DC File Offset: 0x000042DC
		// (remove) Token: 0x060000EB RID: 235 RVA: 0x00006114 File Offset: 0x00004314
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x060000EC RID: 236 RVA: 0x00006149 File Offset: 0x00004349
		// (set) Token: 0x060000ED RID: 237 RVA: 0x00006151 File Offset: 0x00004351
		public AppControlState AppAccess
		{
			get
			{
				return this._appAccess;
			}
			set
			{
				if (this._appAccess != value)
				{
					this.SetAppAccess(value);
				}
				this.CheckCurrentAppAccessDesktopOrCategoryId();
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x060000EE RID: 238 RVA: 0x00006169 File Offset: 0x00004369
		// (set) Token: 0x060000EF RID: 239 RVA: 0x00006171 File Offset: 0x00004371
		public string AppAccessDesktopOrCategoryId
		{
			get
			{
				return this._appAccessDesktopOrCategoryId;
			}
			set
			{
				if (this._appAccessDesktopOrCategoryId != value)
				{
					this.SetAppStrictDesktopId(value);
				}
				this.CheckCurrentAppAccessDesktopOrCategoryId();
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x0000618E File Offset: 0x0000438E
		// (set) Token: 0x060000F1 RID: 241 RVA: 0x00006196 File Offset: 0x00004396
		public string AppVersion
		{
			get
			{
				return this._appVersion;
			}
			set
			{
				if (value != this._appVersion)
				{
					this.SetAppVersion(value);
				}
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060000F2 RID: 242 RVA: 0x000061AD File Offset: 0x000043AD
		// (set) Token: 0x060000F3 RID: 243 RVA: 0x000061B5 File Offset: 0x000043B5
		public string ConnectionDescription
		{
			get
			{
				return this._connectionDescription;
			}
			set
			{
				if (value != this._connectionDescription)
				{
					this.SetConnectionDescription(value);
				}
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x000061CC File Offset: 0x000043CC
		public int ConnectionTypeIconIdex
		{
			get
			{
				return this._connectionTypeIconIndexes[0];
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060000F5 RID: 245 RVA: 0x000061D6 File Offset: 0x000043D6
		public int[] ConnectionTypeIconIndexes
		{
			get
			{
				return this._connectionTypeIconIndexes;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x000061DE File Offset: 0x000043DE
		// (set) Token: 0x060000F7 RID: 247 RVA: 0x000061E6 File Offset: 0x000043E6
		public string CurrentAppCategoryOrDesktopId
		{
			get
			{
				return this._currentAppCategoryOrDesktopId;
			}
			set
			{
				if (value != this._currentAppCategoryOrDesktopId)
				{
					this.SetCurrentAppCategoryOrDesktopId(value);
				}
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x000061FD File Offset: 0x000043FD
		// (set) Token: 0x060000F9 RID: 249 RVA: 0x00006205 File Offset: 0x00004405
		public string CurrentInetStrictCategoryId
		{
			get
			{
				return this._currentInetStrictCategoryId;
			}
			set
			{
				if (value != this._currentInetStrictCategoryId)
				{
					this.SetCurrentInetStrictCategoryId(value);
				}
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x060000FA RID: 250 RVA: 0x0000621C File Offset: 0x0000441C
		// (set) Token: 0x060000FB RID: 251 RVA: 0x00006224 File Offset: 0x00004424
		public string Description
		{
			get
			{
				return this._description;
			}
			set
			{
				if (value != this._description)
				{
					this.SetDescription(value);
				}
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x060000FC RID: 252 RVA: 0x0000623B File Offset: 0x0000443B
		public int[] DeviceIconIndexes
		{
			get
			{
				return this._deviceIconIndexes;
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x060000FD RID: 253 RVA: 0x00006244 File Offset: 0x00004444
		public int[] DeviceIconWithDefaultIndexes
		{
			get
			{
				int[] result = this.CreateDefaultIconsArray();
				for (int i = 0; i < this._deviceIconIndexes.Length; i++)
				{
					if (this._deviceIconIndexes[i] != -1)
					{
						result[i] = this._deviceIconIndexes[i];
					}
				}
				return result;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x060000FE RID: 254 RVA: 0x00006282 File Offset: 0x00004482
		// (set) Token: 0x060000FF RID: 255 RVA: 0x0000628A File Offset: 0x0000448A
		public int DeviceLockSettings
		{
			get
			{
				return this._deviceLockSettings;
			}
			set
			{
				if (this._deviceLockSettings != value)
				{
					this.SetDeviceLockSettings(value);
				}
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000100 RID: 256 RVA: 0x0000629C File Offset: 0x0000449C
		// (set) Token: 0x06000101 RID: 257 RVA: 0x000062A4 File Offset: 0x000044A4
		public DeviceType DeviceType { get; protected set; }

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000102 RID: 258 RVA: 0x000062AD File Offset: 0x000044AD
		// (set) Token: 0x06000103 RID: 259 RVA: 0x000062B5 File Offset: 0x000044B5
		public string DomainAndUserName
		{
			get
			{
				return this._domainAndUserName;
			}
			set
			{
				if (value != this._domainAndUserName)
				{
					this.SetDomainAndUserName(value);
				}
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000104 RID: 260 RVA: 0x000062CC File Offset: 0x000044CC
		// (set) Token: 0x06000105 RID: 261 RVA: 0x000062D4 File Offset: 0x000044D4
		public string DomainName
		{
			get
			{
				return this._domainName;
			}
			set
			{
				if (value != this._domainName)
				{
					this.SetDomainName(value);
				}
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000106 RID: 262 RVA: 0x000062EB File Offset: 0x000044EB
		// (set) Token: 0x06000107 RID: 263 RVA: 0x000062F3 File Offset: 0x000044F3
		public bool Excluded
		{
			get
			{
				return this._excluded;
			}
			set
			{
				if (value != this._excluded)
				{
					this.SetExcluded(value);
				}
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000108 RID: 264 RVA: 0x00006305 File Offset: 0x00004505
		// (set) Token: 0x06000109 RID: 265 RVA: 0x0000630D File Offset: 0x0000450D
		public bool HasWindowsUser
		{
			get
			{
				return this._hasWindowsUser;
			}
			set
			{
				if (value != this._hasWindowsUser)
				{
					this.SetHasWindowsUser(value);
				}
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600010A RID: 266 RVA: 0x0000631F File Offset: 0x0000451F
		// (set) Token: 0x0600010B RID: 267 RVA: 0x00006327 File Offset: 0x00004527
		public int IconIndex
		{
			get
			{
				return this._iconIndex;
			}
			set
			{
				if (value != this._iconIndex)
				{
					this.SetIconIndex(value);
				}
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600010C RID: 268 RVA: 0x00006339 File Offset: 0x00004539
		// (set) Token: 0x0600010D RID: 269 RVA: 0x00006341 File Offset: 0x00004541
		public string Id
		{
			get
			{
				return this._id;
			}
			set
			{
				if (string.IsNullOrEmpty(this._id))
				{
					this._id = value;
				}
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x0600010E RID: 270 RVA: 0x00006357 File Offset: 0x00004557
		// (set) Token: 0x0600010F RID: 271 RVA: 0x0000635F File Offset: 0x0000455F
		public InetControlState InetAccess
		{
			get
			{
				return this._inetAccess;
			}
			set
			{
				if (this._inetAccess != value)
				{
					this.SetInetAccess(value);
					this.CheckCurrentInetStrictCategoryId();
				}
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000110 RID: 272 RVA: 0x00006377 File Offset: 0x00004577
		// (set) Token: 0x06000111 RID: 273 RVA: 0x0000637F File Offset: 0x0000457F
		public string InetStrictCategoryId
		{
			get
			{
				return this._inetStrictCategoryId;
			}
			set
			{
				if (value != this._inetStrictCategoryId)
				{
					this.SetInetStrictCategoryId(value);
					this.CheckCurrentInetStrictCategoryId();
				}
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000112 RID: 274 RVA: 0x0000639C File Offset: 0x0000459C
		// (set) Token: 0x06000113 RID: 275 RVA: 0x000063A4 File Offset: 0x000045A4
		public bool IsConnected
		{
			get
			{
				return this.GetIsConnected();
			}
			set
			{
				if (this._isConnected != value)
				{
					this.SetIsConnected(value);
				}
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000114 RID: 276 RVA: 0x000063B6 File Offset: 0x000045B6
		// (set) Token: 0x06000115 RID: 277 RVA: 0x000063BE File Offset: 0x000045BE
		public bool IsGroup
		{
			get
			{
				return this._isGroup;
			}
			set
			{
				if (this._isGroup != value)
				{
					this.SetIsGroup(value);
				}
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000116 RID: 278 RVA: 0x000063D0 File Offset: 0x000045D0
		// (set) Token: 0x06000117 RID: 279 RVA: 0x000063D8 File Offset: 0x000045D8
		public bool IsProxyConnection
		{
			get
			{
				return this._isProxyConnection;
			}
			set
			{
				if (value != this._isProxyConnection)
				{
					this.SetIsProxyConnection(value);
				}
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000118 RID: 280 RVA: 0x000063EA File Offset: 0x000045EA
		// (set) Token: 0x06000119 RID: 281 RVA: 0x000063F2 File Offset: 0x000045F2
		public bool IsSelected
		{
			get
			{
				return this._isSelected;
			}
			set
			{
				if (this._isSelected != value)
				{
					this.SetIsSelected(value);
				}
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x0600011A RID: 282 RVA: 0x00006404 File Offset: 0x00004604
		// (set) Token: 0x0600011B RID: 283 RVA: 0x0000640C File Offset: 0x0000460C
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				if (value != this._name)
				{
					this.SetName(value);
				}
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x0600011C RID: 284 RVA: 0x00006423 File Offset: 0x00004623
		// (set) Token: 0x0600011D RID: 285 RVA: 0x0000642B File Offset: 0x0000462B
		public string OsVersion
		{
			get
			{
				return this._osVersion;
			}
			set
			{
				if (value != this._osVersion)
				{
					this.SetOsVersion(value);
				}
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x0600011E RID: 286 RVA: 0x00006442 File Offset: 0x00004642
		// (set) Token: 0x0600011F RID: 287 RVA: 0x0000644A File Offset: 0x0000464A
		public string ParentId
		{
			get
			{
				return this._parentId;
			}
			set
			{
				if (value != this._parentId)
				{
					this.SetParentId(value);
				}
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000120 RID: 288 RVA: 0x00006461 File Offset: 0x00004661
		// (set) Token: 0x06000121 RID: 289 RVA: 0x00006469 File Offset: 0x00004669
		public string ProjectorLoginId
		{
			get
			{
				return this._projectorLoginId;
			}
			set
			{
				if (value != this._projectorLoginId)
				{
					this.SetProjectorLoginId(value);
				}
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000122 RID: 290 RVA: 0x00006480 File Offset: 0x00004680
		// (set) Token: 0x06000123 RID: 291 RVA: 0x00006488 File Offset: 0x00004688
		public int ProjectorStatus
		{
			get
			{
				return this._projectorStatus;
			}
			set
			{
				if (value != this._projectorStatus)
				{
					this.SetProjectorStatus(value);
				}
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000124 RID: 292 RVA: 0x0000649A File Offset: 0x0000469A
		public int SessionTypeIconIndex
		{
			get
			{
				return this._connectionTypeIconIndexes[1];
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000125 RID: 293 RVA: 0x000064A4 File Offset: 0x000046A4
		public string TypeName
		{
			get
			{
				return base.GetType().Name;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000126 RID: 294 RVA: 0x000064B1 File Offset: 0x000046B1
		// (set) Token: 0x06000127 RID: 295 RVA: 0x000064B9 File Offset: 0x000046B9
		public string UserFullName
		{
			get
			{
				return this._userFullName;
			}
			set
			{
				if (value != this._userFullName)
				{
					this.SetUserFullName(value);
				}
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000128 RID: 296 RVA: 0x000064D0 File Offset: 0x000046D0
		public int[] UserIconIndexes
		{
			get
			{
				return this._userIconIndexes;
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000129 RID: 297 RVA: 0x000064D8 File Offset: 0x000046D8
		public int[] UserIconWithDefaultIndexes
		{
			get
			{
				int[] result = this.CreateDefaultIconsArray();
				for (int i = 0; i < this._userIconIndexes.Length; i++)
				{
					if (this._userIconIndexes[i] != -1)
					{
						result[i] = this._userIconIndexes[i];
					}
				}
				return result;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x0600012A RID: 298 RVA: 0x00006516 File Offset: 0x00004716
		// (set) Token: 0x0600012B RID: 299 RVA: 0x0000651E File Offset: 0x0000471E
		public string UserName
		{
			get
			{
				return this._userName;
			}
			set
			{
				if (value != this._userName)
				{
					this.SetUserName(value);
				}
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x0600012C RID: 300 RVA: 0x00006535 File Offset: 0x00004735
		// (set) Token: 0x0600012D RID: 301 RVA: 0x0000653D File Offset: 0x0000473D
		public WindowsUserInfo WindowsUser
		{
			get
			{
				return this._windowsUser;
			}
			set
			{
				if (this._windowsUser != null && value != null)
				{
					if (!this._windowsUser.Equals(value))
					{
						this.SetWindowsUser(value);
						return;
					}
				}
				else if (this._windowsUser != value)
				{
					this.SetWindowsUser(value);
				}
			}
		}

		// Token: 0x0600012E RID: 302 RVA: 0x00006570 File Offset: 0x00004770
		public void CopyCommonProperities(DeviceTreeItemBase sourceItem)
		{
			this.AppAccess = sourceItem.AppAccess;
			this.DeviceLockSettings = sourceItem.DeviceLockSettings;
			this.InetAccess = sourceItem.InetAccess;
		}

		// Token: 0x0600012F RID: 303 RVA: 0x00003364 File Offset: 0x00001564
		public virtual string GetDeviceName()
		{
			return string.Empty;
		}

		// Token: 0x06000130 RID: 304 RVA: 0x00003A2C File Offset: 0x00001C2C
		public virtual void ItemsRemoved()
		{
		}

		// Token: 0x06000131 RID: 305 RVA: 0x00006596 File Offset: 0x00004796
		public virtual void SetIconForDeviceAppAccess(int iconIdx)
		{
			this.SetDeviceIcon(1, iconIdx);
		}

		// Token: 0x06000132 RID: 306 RVA: 0x000065A0 File Offset: 0x000047A0
		public virtual void SetIconForDeviceInetAccess(int iconIdx)
		{
			this.SetDeviceIcon(0, iconIdx);
		}

		// Token: 0x06000133 RID: 307 RVA: 0x000065AA File Offset: 0x000047AA
		public virtual void SetIconForDeviceLock(int iconIdx)
		{
			this.SetDeviceIcon(2, iconIdx);
		}

		// Token: 0x06000134 RID: 308 RVA: 0x000065B4 File Offset: 0x000047B4
		public virtual void SetIconForUserAppAccess(int iconIdx)
		{
			this.SetUserIcon(1, iconIdx);
		}

		// Token: 0x06000135 RID: 309 RVA: 0x000065BE File Offset: 0x000047BE
		public virtual void SetIconForUserInetAccess(int iconIdx)
		{
			this.SetUserIcon(0, iconIdx);
		}

		// Token: 0x06000136 RID: 310 RVA: 0x000065C8 File Offset: 0x000047C8
		public virtual void ShowProxyIcon(bool show)
		{
			this.SetConnectionTypeIcon(0, show ? 0 : -1);
		}

		// Token: 0x06000137 RID: 311 RVA: 0x000065D8 File Offset: 0x000047D8
		public virtual void ShowSessionRdpIcon(bool show)
		{
			this.SetConnectionTypeIcon(1, show ? 1 : -1);
		}

		// Token: 0x06000138 RID: 312 RVA: 0x000065E8 File Offset: 0x000047E8
		protected void CheckCurrentInetStrictCategoryId()
		{
			string value = null;
			if (this._hasWindowsUser)
			{
				WindowsUserSettings userSettings = this._windowsUser.UserSettings;
				value = ((userSettings != null) ? userSettings.InetStrictCategoryId : null);
			}
			else if (this._inetAccess == InetControlState.InetStrict)
			{
				value = this._inetStrictCategoryId;
			}
			this.CurrentInetStrictCategoryId = value;
		}

		// Token: 0x06000139 RID: 313 RVA: 0x00006630 File Offset: 0x00004830
		protected virtual bool GetIsConnected()
		{
			return this._isConnected;
		}

		// Token: 0x0600013A RID: 314 RVA: 0x00006638 File Offset: 0x00004838
		protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged == null)
			{
				return;
			}
			propertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}

		// Token: 0x0600013B RID: 315 RVA: 0x00006651 File Offset: 0x00004851
		protected virtual void SetAppAccess(AppControlState value)
		{
			this._appAccess = value;
			this.SetIconForDeviceAppAccess(DeviceTreeIconIndexes.GetAppControlStateIndex(value));
			this.OnPropertyChanged("AppAccess");
		}

		// Token: 0x0600013C RID: 316 RVA: 0x00006671 File Offset: 0x00004871
		protected virtual void SetAppStrictDesktopId(string value)
		{
			this._appAccessDesktopOrCategoryId = value;
			this.OnPropertyChanged("AppAccessDesktopOrCategoryId");
		}

		// Token: 0x0600013D RID: 317 RVA: 0x00006685 File Offset: 0x00004885
		protected virtual void SetAppVersion(string value)
		{
			this._appVersion = value;
			this.OnPropertyChanged("AppVersion");
		}

		// Token: 0x0600013E RID: 318 RVA: 0x00006699 File Offset: 0x00004899
		protected virtual void SetConnectedIcon()
		{
			this.IconIndex = (this.IsConnected ? this._iconConnectedIndex : this._iconDisconnectedIndex);
		}

		// Token: 0x0600013F RID: 319 RVA: 0x000066B7 File Offset: 0x000048B7
		protected virtual void SetConnectionDescription(string value)
		{
			this._connectionDescription = value;
			this.OnPropertyChanged("ConnectionDescription");
		}

		// Token: 0x06000140 RID: 320 RVA: 0x000066CB File Offset: 0x000048CB
		protected virtual void SetCurrentAppCategoryOrDesktopId(string value)
		{
			this._currentAppCategoryOrDesktopId = value;
			this.OnPropertyChanged("CurrentAppCategoryOrDesktopId");
		}

		// Token: 0x06000141 RID: 321 RVA: 0x000066DF File Offset: 0x000048DF
		protected virtual void SetDescription(string value)
		{
			this._description = value;
			this.OnPropertyChanged("Description");
		}

		// Token: 0x06000142 RID: 322 RVA: 0x000066F3 File Offset: 0x000048F3
		protected virtual void SetDeviceLockSettings(int value)
		{
			this._deviceLockSettings = value;
			this.SetIconForDeviceLock(DeviceTreeIconIndexes.DeviceLockIndex(value));
			this.OnPropertyChanged("DeviceLockSettings");
		}

		// Token: 0x06000143 RID: 323 RVA: 0x00006713 File Offset: 0x00004913
		protected virtual void SetDomainAndUserName(string value)
		{
			this._domainAndUserName = value;
			this.OnPropertyChanged("DomainAndUserName");
		}

		// Token: 0x06000144 RID: 324 RVA: 0x00006727 File Offset: 0x00004927
		protected virtual void SetDomainName(string value)
		{
			this._domainName = value;
			this.OnPropertyChanged("DomainName");
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0000673B File Offset: 0x0000493B
		protected virtual void SetExcluded(bool value)
		{
			this._excluded = value;
			this.OnPropertyChanged("Excluded");
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0000674F File Offset: 0x0000494F
		protected virtual void SetHasWindowsUser(bool value)
		{
			this._hasWindowsUser = value;
			this.OnPropertyChanged("HasWindowsUser");
		}

		// Token: 0x06000147 RID: 327 RVA: 0x00006763 File Offset: 0x00004963
		protected virtual void SetIconIndex(int value)
		{
			this._iconIndex = value;
			this.OnPropertyChanged("IconIndex");
		}

		// Token: 0x06000148 RID: 328 RVA: 0x00006777 File Offset: 0x00004977
		protected virtual void SetInetAccess(InetControlState value)
		{
			this._inetAccess = value;
			this.SetIconForDeviceInetAccess(DeviceTreeIconIndexes.GetInetControlStateIndex(value));
			this.OnPropertyChanged("InetAccess");
		}

		// Token: 0x06000149 RID: 329 RVA: 0x00006797 File Offset: 0x00004997
		protected virtual void SetInetStrictCategoryId(string value)
		{
			this._inetStrictCategoryId = value;
			this.OnPropertyChanged("InetStrictCategoryId");
		}

		// Token: 0x0600014A RID: 330 RVA: 0x000067AB File Offset: 0x000049AB
		protected virtual void SetIsConnected(bool value)
		{
			this._isConnected = value;
			this.SetConnectedIcon();
			this.OnPropertyChanged("IsConnected");
		}

		// Token: 0x0600014B RID: 331 RVA: 0x000067C5 File Offset: 0x000049C5
		protected virtual void SetIsGroup(bool value)
		{
			this._isGroup = value;
			this.OnPropertyChanged("IsGroup");
		}

		// Token: 0x0600014C RID: 332 RVA: 0x000067D9 File Offset: 0x000049D9
		protected virtual void SetIsProxyConnection(bool value)
		{
			this._isProxyConnection = value;
			this.OnPropertyChanged("IsProxyConnection");
			this.ShowProxyIcon(this._isProxyConnection);
		}

		// Token: 0x0600014D RID: 333 RVA: 0x000067F9 File Offset: 0x000049F9
		protected virtual void SetIsSelected(bool value)
		{
			this._isSelected = value;
			this.OnPropertyChanged("IsSelected");
		}

		// Token: 0x0600014E RID: 334 RVA: 0x0000680D File Offset: 0x00004A0D
		protected virtual void SetName(string value)
		{
			this._name = value;
			this.OnPropertyChanged("Name");
		}

		// Token: 0x0600014F RID: 335 RVA: 0x00006821 File Offset: 0x00004A21
		protected virtual void SetOsVersion(string value)
		{
			this._osVersion = value;
			this.OnPropertyChanged("OsVersion");
		}

		// Token: 0x06000150 RID: 336 RVA: 0x00006835 File Offset: 0x00004A35
		protected virtual void SetParentId(string value)
		{
			this._parentId = value;
			this.OnPropertyChanged("ParentId");
		}

		// Token: 0x06000151 RID: 337 RVA: 0x00006849 File Offset: 0x00004A49
		protected virtual void SetProjectorLoginId(string value)
		{
			this._projectorLoginId = value;
			this.OnPropertyChanged("ProjectorLoginId");
		}

		// Token: 0x06000152 RID: 338 RVA: 0x0000685D File Offset: 0x00004A5D
		protected virtual void SetProjectorStatus(int value)
		{
			this._projectorStatus = value;
			this.OnPropertyChanged("ProjectorStatus");
		}

		// Token: 0x06000153 RID: 339 RVA: 0x00006871 File Offset: 0x00004A71
		protected virtual void SetUserFullName(string value)
		{
			this._userFullName = value;
			this.OnPropertyChanged("UserFullName");
		}

		// Token: 0x06000154 RID: 340 RVA: 0x00006885 File Offset: 0x00004A85
		protected virtual void SetUserName(string value)
		{
			this._userName = value;
			this.OnPropertyChanged("UserName");
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0000689C File Offset: 0x00004A9C
		protected virtual void SetWindowsUser(WindowsUserInfo value)
		{
			WindowsUserInfo windowsUser = this._windowsUser;
			if (windowsUser != null && windowsUser.Equals(value))
			{
				return;
			}
			if (this._windowsUser == null && value == null)
			{
				return;
			}
			this._windowsUser = value;
			this.ClearUserIcons();
			if (this._windowsUser == null || (string.IsNullOrEmpty(this._windowsUser.DomainName) && string.IsNullOrEmpty(this._windowsUser.UserName)))
			{
				this.UserName = string.Empty;
				this.UserFullName = string.Empty;
				this.DomainName = string.Empty;
				this.DomainAndUserName = string.Empty;
				this.HasWindowsUser = false;
			}
			else
			{
				this.UserName = this._windowsUser.UserName;
				this.UserFullName = this._windowsUser.FullName;
				this.DomainName = this._windowsUser.DomainName;
				this.DomainAndUserName = this._windowsUser.DomainName + "\\" + this._windowsUser.UserName;
				this.HasWindowsUser = true;
				if (this._windowsUser.UserSettings != null)
				{
					if (!this._windowsUser.UserSettings.IsDeviceInetAccess)
					{
						this.SetIconForUserInetAccess(DeviceTreeIconIndexes.GetInetControlStateIndex(this._windowsUser.UserSettings.InetAccess));
					}
					if (!this._windowsUser.UserSettings.IsDeviceAppAccess)
					{
						this.SetIconForUserAppAccess(DeviceTreeIconIndexes.GetAppControlStateIndex(this._windowsUser.UserSettings.AppAccess));
					}
				}
			}
			this.OnPropertyChanged("WindowsUser");
			this.CheckCurrentInetStrictCategoryId();
			this.CheckCurrentAppAccessDesktopOrCategoryId();
		}

		// Token: 0x06000156 RID: 342 RVA: 0x00006A1C File Offset: 0x00004C1C
		private void CheckCurrentAppAccessDesktopOrCategoryId()
		{
			string value = null;
			if (this._hasWindowsUser)
			{
				if (this._windowsUser.UserSettings != null && this._windowsUser.UserSettings.AppAccess.IsDesktopOrCategoryAccess())
				{
					value = this._windowsUser.UserSettings.AppAccessDesktopOrCategoryId;
				}
			}
			else if (this._appAccess.IsDesktopOrCategoryAccess())
			{
				value = this._appAccessDesktopOrCategoryId;
			}
			this.CurrentAppCategoryOrDesktopId = value;
		}

		// Token: 0x06000157 RID: 343 RVA: 0x00006A88 File Offset: 0x00004C88
		private void ClearUserIcons()
		{
			for (int i = 0; i < this._userIconIndexes.Length; i++)
			{
				this._userIconIndexes[i] = -1;
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x00006AB1 File Offset: 0x00004CB1
		private int[] CreateDefaultIconsArray()
		{
			return new int[]
			{
				DeviceTreeIconIndexes.GetInetControlStateIndex(InetControlState.InetCheck),
				21,
				17
			};
		}

		// Token: 0x06000159 RID: 345 RVA: 0x00006ACC File Offset: 0x00004CCC
		private void SetConnectionTypeIcon(int iconNo, int iconIdx)
		{
			this._connectionTypeIconIndexes[iconNo] = iconIdx;
			this.OnPropertyChanged("ConnectionTypeIconIndexes");
		}

		// Token: 0x0600015A RID: 346 RVA: 0x00006AE2 File Offset: 0x00004CE2
		private void SetCurrentInetStrictCategoryId(string value)
		{
			this._currentInetStrictCategoryId = value;
			this.OnPropertyChanged("CurrentInetStrictCategoryId");
		}

		// Token: 0x0600015B RID: 347 RVA: 0x00006AF6 File Offset: 0x00004CF6
		private void SetDeviceIcon(int iconNo, int iconIdx)
		{
			this._deviceIconIndexes[iconNo] = iconIdx;
			this.OnPropertyChanged("DeviceIconIndexes");
		}

		// Token: 0x0600015C RID: 348 RVA: 0x00006B0C File Offset: 0x00004D0C
		private void SetUserIcon(int iconNo, int iconIdx)
		{
			this._userIconIndexes[iconNo] = iconIdx;
			this.OnPropertyChanged("UserIconIndexes");
		}

		// Token: 0x0400007D RID: 125
		protected string _appVersion;

		// Token: 0x0400007E RID: 126
		protected int[] _connectionTypeIconIndexes;

		// Token: 0x0400007F RID: 127
		protected int[] _deviceIconIndexes;

		// Token: 0x04000080 RID: 128
		protected int _iconConnectedIndex = -1;

		// Token: 0x04000081 RID: 129
		protected int _iconDisconnectedIndex = -1;

		// Token: 0x04000082 RID: 130
		protected InetControlState _inetAccess;

		// Token: 0x04000083 RID: 131
		protected bool _isConnected;

		// Token: 0x04000084 RID: 132
		protected int[] _userIconIndexes;

		// Token: 0x04000085 RID: 133
		protected WindowsUserInfo _windowsUser;

		// Token: 0x04000086 RID: 134
		private AppControlState _appAccess;

		// Token: 0x04000087 RID: 135
		private string _appAccessDesktopOrCategoryId;

		// Token: 0x04000088 RID: 136
		private string _connectionDescription;

		// Token: 0x04000089 RID: 137
		private string _currentAppCategoryOrDesktopId;

		// Token: 0x0400008A RID: 138
		private string _currentInetStrictCategoryId;

		// Token: 0x0400008B RID: 139
		private string _description;

		// Token: 0x0400008C RID: 140
		private int _deviceLockSettings;

		// Token: 0x0400008D RID: 141
		private string _domainAndUserName;

		// Token: 0x0400008E RID: 142
		private string _domainName;

		// Token: 0x0400008F RID: 143
		private bool _excluded;

		// Token: 0x04000090 RID: 144
		private bool _hasWindowsUser;

		// Token: 0x04000091 RID: 145
		private int _iconIndex;

		// Token: 0x04000092 RID: 146
		private string _id;

		// Token: 0x04000093 RID: 147
		private string _inetStrictCategoryId;

		// Token: 0x04000094 RID: 148
		private bool _isGroup;

		// Token: 0x04000095 RID: 149
		private bool _isProxyConnection;

		// Token: 0x04000096 RID: 150
		private bool _isSelected;

		// Token: 0x04000097 RID: 151
		private string _name;

		// Token: 0x04000098 RID: 152
		private string _osVersion;

		// Token: 0x04000099 RID: 153
		private string _parentId;

		// Token: 0x0400009A RID: 154
		private string _projectorLoginId;

		// Token: 0x0400009B RID: 155
		private int _projectorStatus;

		// Token: 0x0400009C RID: 156
		private string _userFullName;

		// Token: 0x0400009D RID: 157
		private string _userName;
	}
}
