﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console
{
	// Token: 0x02000013 RID: 19
	public class DevicesAndGroupsSelection
	{
		// Token: 0x06000077 RID: 119 RVA: 0x00003CB0 File Offset: 0x00001EB0
		public DevicesAndGroupsSelection()
		{
			this.AgentsList = new List<AgentItem>();
			this.GroupsList = new List<DevicesGroupItem>();
			this.DevicesList = new List<DeviceItem>();
			this.DevicesVisibledList = new List<DeviceItem>();
			this.DeviceAndDisplayList = new DeviceAndDisplayList();
			this.ItemsSelectedByUser = new List<DeviceTreeItemBase>();
			this.IsRootGroupSelected = false;
			this.IsAllDevicesGroupSelected = false;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00003D14 File Offset: 0x00001F14
		public DevicesAndGroupsSelection(bool onlyConnectedDevices, bool onlyConnectedSessions, List<DeviceTreeItemBase> sourceTreeItemsList, List<DevicesGroupItem> groupsList, List<DeviceItem> devicesList, List<DeviceItem> devicesVisibledList, DeviceAndDisplayList deviceAndDisplayList, bool isRootGroupSelected, bool isAllDevicesGroupSelected)
		{
			this.OnlyConnectedDevices = onlyConnectedDevices;
			this.OnlyConnetedSessions = onlyConnectedSessions;
			this.GroupsList = groupsList;
			this.DevicesList = devicesList;
			this.DevicesVisibledList = devicesVisibledList;
			this.DeviceAndDisplayList = deviceAndDisplayList;
			this.ItemsSelectedByUser = sourceTreeItemsList;
			this.IsRootGroupSelected = isRootGroupSelected;
			this.IsAllDevicesGroupSelected = isAllDevicesGroupSelected;
			this.AgentsList = this.GetAgentItemList(false);
			if (this.GroupsList.Count > 0)
			{
				this.Description = string.Format(Resources.DevicesTree_SelectionDescriptionForGroupsAndDevices, this.GroupsList.Count, this.DevicesList.Count);
				return;
			}
			if (this.DevicesList.Count == 1)
			{
				string devicesTree_SelectionDescriptionForOneDevice = Resources.DevicesTree_SelectionDescriptionForOneDevice;
				DeviceItem deviceItem = this.DevicesList[0];
				this.Description = string.Format(devicesTree_SelectionDescriptionForOneDevice, (deviceItem != null) ? deviceItem.Name : null);
				return;
			}
			this.Description = string.Format(Resources.DevicesTree_SelectionDescriptionForManyDevices, this.DevicesList.Count);
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000079 RID: 121 RVA: 0x00003E0F File Offset: 0x0000200F
		public List<AgentItem> AgentsList { get; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x0600007A RID: 122 RVA: 0x00003E17 File Offset: 0x00002017
		// (set) Token: 0x0600007B RID: 123 RVA: 0x00003E1F File Offset: 0x0000201F
		public string Description { get; private set; }

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x0600007C RID: 124 RVA: 0x00003E28 File Offset: 0x00002028
		public DeviceAndDisplayList DeviceAndDisplayList { get; }

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x0600007D RID: 125 RVA: 0x00003E30 File Offset: 0x00002030
		public List<DeviceItem> DevicesList { get; }

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x0600007E RID: 126 RVA: 0x00003E38 File Offset: 0x00002038
		public List<DeviceItem> DevicesVisibledList { get; }

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600007F RID: 127 RVA: 0x00003E40 File Offset: 0x00002040
		public List<DevicesGroupItem> GroupsList { get; }

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000080 RID: 128 RVA: 0x00003E48 File Offset: 0x00002048
		// (set) Token: 0x06000081 RID: 129 RVA: 0x00003E50 File Offset: 0x00002050
		public bool IsAllDevicesGroupSelected { get; set; }

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000082 RID: 130 RVA: 0x00003E59 File Offset: 0x00002059
		// (set) Token: 0x06000083 RID: 131 RVA: 0x00003E61 File Offset: 0x00002061
		public bool IsRootGroupSelected { get; set; }

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000084 RID: 132 RVA: 0x00003E6A File Offset: 0x0000206A
		// (set) Token: 0x06000085 RID: 133 RVA: 0x00003E72 File Offset: 0x00002072
		public List<DeviceTreeItemBase> ItemsSelectedByUser { get; set; }

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000086 RID: 134 RVA: 0x00003E7B File Offset: 0x0000207B
		public bool OnlyConnectedDevices { get; }

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000087 RID: 135 RVA: 0x00003E83 File Offset: 0x00002083
		public bool OnlyConnetedSessions { get; }

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000088 RID: 136 RVA: 0x00003E8B File Offset: 0x0000208B
		// (set) Token: 0x06000089 RID: 137 RVA: 0x00003E93 File Offset: 0x00002093
		public DevicesAndGroupsSelectionChanges SelectionChanges { get; private set; }

		// Token: 0x0600008A RID: 138 RVA: 0x00003E9C File Offset: 0x0000209C
		public bool ComputeChanges(DevicesAndGroupsSelection oldSelection)
		{
			bool groupsNotChanged = this.GroupsList.All(new Func<DevicesGroupItem, bool>(oldSelection.GroupsList.Contains));
			List<AgentItem> agentsAdded = this.AgentsList.Except(oldSelection.AgentsList).ToList<AgentItem>();
			List<AgentItem> agentsRemoved = oldSelection.AgentsList.Except(this.AgentsList).ToList<AgentItem>();
			List<DeviceItem> devicesAdded = this.DevicesList.Except(oldSelection.DevicesList).ToList<DeviceItem>();
			List<DeviceItem> devicesRemoved = oldSelection.DevicesList.Except(this.DevicesList).ToList<DeviceItem>();
			List<DeviceItem> devicesVisibledAdded = this.DevicesVisibledList.Except(oldSelection.DevicesVisibledList).ToList<DeviceItem>();
			List<DeviceItem> devicesVisibledRemoved = oldSelection.DevicesVisibledList.Except(this.DevicesVisibledList).ToList<DeviceItem>();
			DeviceAndDisplayComparer comparer = new DeviceAndDisplayComparer();
			List<DeviceAndDisplay> deviceAndDisplayAdded = this.DeviceAndDisplayList.Except(oldSelection.DeviceAndDisplayList, comparer).ToList<DeviceAndDisplay>();
			List<DeviceAndDisplay> deviceAndDisplayRemoved = oldSelection.DeviceAndDisplayList.Except(this.DeviceAndDisplayList, comparer).ToList<DeviceAndDisplay>();
			if (groupsNotChanged && devicesRemoved.Count <= 0 && devicesAdded.Count <= 0 && devicesVisibledAdded.Count <= 0 && devicesVisibledRemoved.Count <= 0 && deviceAndDisplayAdded.Count <= 0 && deviceAndDisplayRemoved.Count <= 0)
			{
				this.SelectionChanges = new DevicesAndGroupsSelectionChanges();
				return false;
			}
			this.SelectionChanges = new DevicesAndGroupsSelectionChanges(!groupsNotChanged, agentsAdded, agentsRemoved, devicesVisibledAdded, devicesVisibledRemoved, devicesAdded, devicesRemoved, new DeviceAndDisplayList(deviceAndDisplayAdded), new DeviceAndDisplayList(deviceAndDisplayRemoved));
			return true;
		}

		// Token: 0x0600008B RID: 139 RVA: 0x00004008 File Offset: 0x00002208
		public List<AgentItem> GetAgentItemList(bool onlyOneAgentForDevice)
		{
			List<AgentItem> result = (from x in this.DeviceAndDisplayList
			where x.DisplayItem != null
			select x.DisplayItem.AgentItem into x
			where x != null
			select x).Distinct<AgentItem>().ToList<AgentItem>();
			if (onlyOneAgentForDevice)
			{
				List<AgentItem> distinctResult = new List<AgentItem>();
				using (List<AgentItem>.Enumerator enumerator = result.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						AgentItem agentItem = enumerator.Current;
						if (distinctResult.Find((AgentItem x) => x.DeviceItem.Id == agentItem.DeviceItem.Id) == null)
						{
							distinctResult.Add(agentItem);
						}
					}
				}
				result = distinctResult;
			}
			return result;
		}

		// Token: 0x0600008C RID: 140 RVA: 0x00004104 File Offset: 0x00002304
		public List<string> GetDevicesIdList()
		{
			return (from x in this.DevicesList
			select x.Id).ToList<string>();
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00004135 File Offset: 0x00002335
		public string GetDevicesIdListCommaSeparated()
		{
			return string.Join(",", from x in this.GetDevicesIdList()
			select "'" + x + "'");
		}

		// Token: 0x0600008E RID: 142 RVA: 0x0000416C File Offset: 0x0000236C
		public string GetSelectedNames()
		{
			if (this.GroupsList.Count > 0)
			{
				if (this.GroupsList.Count != 1)
				{
					return string.Join(",", from x in this.GroupsList
					select x.Name);
				}
				DevicesGroupItem devicesGroupItem = this.GroupsList[0];
				if (devicesGroupItem == null)
				{
					return null;
				}
				return devicesGroupItem.Name;
			}
			else
			{
				if (this.DevicesList.Count != 1)
				{
					return string.Join(",", from x in this.DevicesList
					select x.Name);
				}
				DeviceItem deviceItem = this.DevicesList[0];
				if (deviceItem == null)
				{
					return null;
				}
				return deviceItem.Name;
			}
		}

		// Token: 0x0600008F RID: 143 RVA: 0x0000423C File Offset: 0x0000243C
		public bool IsDeviceAndSessionSelected(string deviceId, int sessionId)
		{
			return this.DeviceAndDisplayList.Any(delegate(DeviceAndDisplay x)
			{
				if (!(x.DeviceItem.Id == deviceId))
				{
					return false;
				}
				DisplayItem displayItem = x.DisplayItem;
				if (displayItem == null)
				{
					return false;
				}
				AgentItem agentItem = displayItem.AgentItem;
				int? num;
				if (agentItem == null)
				{
					num = null;
				}
				else
				{
					AgentClient agentClient = agentItem.AgentClient;
					num = ((agentClient != null) ? new int?(agentClient.SessionNo) : null);
				}
				int? num2 = num;
				int sessionId2 = sessionId;
				return num2.GetValueOrDefault() == sessionId2 & num2 != null;
			});
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00004274 File Offset: 0x00002474
		public bool IsDeviceSelected(string deviceId)
		{
			return this.DevicesList.Find((DeviceItem x) => x.Id == deviceId) != null;
		}

		// Token: 0x06000091 RID: 145 RVA: 0x000042A8 File Offset: 0x000024A8
		public bool ShouldShowSelectedDeviceLog(string deviceId, int sessionId)
		{
			DeviceItem device = this.DevicesList.Find((DeviceItem x) => x.Id == deviceId);
			return device != null && (this.IsDeviceAndSessionSelected(deviceId, sessionId) || sessionId == 0 || !device.IsConnected);
		}
	}
}
