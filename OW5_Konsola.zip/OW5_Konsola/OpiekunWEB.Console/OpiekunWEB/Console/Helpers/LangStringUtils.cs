﻿using System;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000041 RID: 65
	public static class LangStringUtils
	{
		// Token: 0x0600040A RID: 1034 RVA: 0x0000F3B8 File Offset: 0x0000D5B8
		public static string StringRepresentingFileSize(ulong byteCount)
		{
			return LangStringUtils.StringRepresentingFileSize((long)byteCount);
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0000F3C0 File Offset: 0x0000D5C0
		public static string StringRepresentingFileSize(long byteCount)
		{
			string[] suf = new string[]
			{
				" B",
				"KB",
				"MB",
				"GB",
				"TB",
				"PB",
				"EB"
			};
			if (byteCount == 0L)
			{
				return "0 " + suf[0];
			}
			long num2 = Math.Abs(byteCount);
			int place = Convert.ToInt32(Math.Floor(Math.Log((double)num2, 1024.0)));
			double num = Math.Round((double)num2 / Math.Pow(1024.0, (double)place), 1);
			return ((double)Math.Sign(byteCount) * num).ToString() + " " + suf[place];
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0000F478 File Offset: 0x0000D678
		public static string StringRepresentingHMSWorkTime(long? durationInSec)
		{
			if (durationInSec == null)
			{
				return "00:00:00";
			}
			return TimeSpan.FromSeconds((double)durationInSec.Value).ToString("hh\\:mm\\:ss");
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0000F4B0 File Offset: 0x0000D6B0
		public static string StringRepresentingRemainSec(int remainSec)
		{
			if (remainSec > 60)
			{
				int min = remainSec / 60;
				return min.ToString("####") + " " + Resources.TimeMinutes + " " + (remainSec - min * 60).ToString("00") + " " + Resources.TimeSeconds;
			}
			return remainSec.ToString("00 sek");
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0000F518 File Offset: 0x0000D718
		public static string StringRepresentingWorkTime(uint durationInSec)
		{
			TimeSpan time = TimeSpan.FromSeconds(durationInSec);
			if (durationInSec < 60U)
			{
				return time.ToString("%s") + " " + Resources.TimeSeconds;
			}
			if (durationInSec < 3600U)
			{
				return string.Format(time.ToString("%m' {0} '%s' {1}'"), Resources.TimeMinutes, Resources.TimeSeconds);
			}
			if (time.Days < 1)
			{
				return string.Format(time.ToString("hh' {0} 'mm' {1} 'ss' {2}'"), Resources.TimeHours, Resources.TimeMinutes, Resources.TimeSeconds);
			}
			return string.Format(time.ToString("d' {0} 'hh' {1} 'mm' {2} 'ss' {3}'"), new object[]
			{
				Resources.TimeDays,
				Resources.TimeHours,
				Resources.TimeMinutes,
				Resources.TimeSeconds
			});
		}
	}
}
