﻿using System;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000044 RID: 68
	public enum TimePeriods
	{
		// Token: 0x04000144 RID: 324
		CustomRange,
		// Token: 0x04000145 RID: 325
		Today,
		// Token: 0x04000146 RID: 326
		Yesterday,
		// Token: 0x04000147 RID: 327
		Last7Days,
		// Token: 0x04000148 RID: 328
		Last30Days,
		// Token: 0x04000149 RID: 329
		ThisWeek,
		// Token: 0x0400014A RID: 330
		LastWeek,
		// Token: 0x0400014B RID: 331
		ThisMonth,
		// Token: 0x0400014C RID: 332
		LastMonth,
		// Token: 0x0400014D RID: 333
		ThisYear,
		// Token: 0x0400014E RID: 334
		FromBeginningOfData
	}
}
