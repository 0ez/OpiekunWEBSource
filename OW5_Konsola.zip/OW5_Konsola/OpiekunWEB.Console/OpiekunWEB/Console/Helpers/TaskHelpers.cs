﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using OpiekunWEB.Console.Interfaces;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000049 RID: 73
	public static class TaskHelpers
	{
		// Token: 0x0600043D RID: 1085 RVA: 0x0000FF74 File Offset: 0x0000E174
		public static Task<bool> DoTaskInSplash(Control control, Task task)
		{
			TaskHelpers.<DoTaskInSplash>d__0 <DoTaskInSplash>d__;
			<DoTaskInSplash>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<DoTaskInSplash>d__.control = control;
			<DoTaskInSplash>d__.task = task;
			<DoTaskInSplash>d__.<>1__state = -1;
			<DoTaskInSplash>d__.<>t__builder.Start<TaskHelpers.<DoTaskInSplash>d__0>(ref <DoTaskInSplash>d__);
			return <DoTaskInSplash>d__.<>t__builder.Task;
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x0000FFC0 File Offset: 0x0000E1C0
		public static Task<bool> DoTaskInSplash(Control control, IFormCreator formCreator, Task task)
		{
			TaskHelpers.<DoTaskInSplash>d__1 <DoTaskInSplash>d__;
			<DoTaskInSplash>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<DoTaskInSplash>d__.control = control;
			<DoTaskInSplash>d__.formCreator = formCreator;
			<DoTaskInSplash>d__.task = task;
			<DoTaskInSplash>d__.<>1__state = -1;
			<DoTaskInSplash>d__.<>t__builder.Start<TaskHelpers.<DoTaskInSplash>d__1>(ref <DoTaskInSplash>d__);
			return <DoTaskInSplash>d__.<>t__builder.Task;
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x00010014 File Offset: 0x0000E214
		public static Task<bool> DoTaskInSplash(this XtraForm form, IFormCreator formCreator, Task task)
		{
			TaskHelpers.<DoTaskInSplash>d__2 <DoTaskInSplash>d__;
			<DoTaskInSplash>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<DoTaskInSplash>d__.form = form;
			<DoTaskInSplash>d__.formCreator = formCreator;
			<DoTaskInSplash>d__.task = task;
			<DoTaskInSplash>d__.<>1__state = -1;
			<DoTaskInSplash>d__.<>t__builder.Start<TaskHelpers.<DoTaskInSplash>d__2>(ref <DoTaskInSplash>d__);
			return <DoTaskInSplash>d__.<>t__builder.Task;
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x00010068 File Offset: 0x0000E268
		public static Task DoThrotledTasks<T>(IEnumerable<T> items, Func<T, Task> createTask, int maxConcurrency = 10)
		{
			TaskHelpers.<DoThrotledTasks>d__3<T> <DoThrotledTasks>d__;
			<DoThrotledTasks>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<DoThrotledTasks>d__.items = items;
			<DoThrotledTasks>d__.createTask = createTask;
			<DoThrotledTasks>d__.maxConcurrency = maxConcurrency;
			<DoThrotledTasks>d__.<>1__state = -1;
			<DoThrotledTasks>d__.<>t__builder.Start<TaskHelpers.<DoThrotledTasks>d__3<T>>(ref <DoThrotledTasks>d__);
			return <DoThrotledTasks>d__.<>t__builder.Task;
		}
	}
}
