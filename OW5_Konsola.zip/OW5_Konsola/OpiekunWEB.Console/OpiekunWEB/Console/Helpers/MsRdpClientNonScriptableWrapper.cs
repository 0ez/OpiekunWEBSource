﻿using System;
using System.Runtime.InteropServices;
using MSTSCLib;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000036 RID: 54
	internal class MsRdpClientNonScriptableWrapper
	{
		// Token: 0x060003C6 RID: 966 RVA: 0x0000E014 File Offset: 0x0000C214
		public MsRdpClientNonScriptableWrapper(object ocx)
		{
			this.m_ComInterface = (MsRdpClientNonScriptableWrapper.IMsRdpClientNonScriptable_Sendkeys)ocx;
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0000E028 File Offset: 0x0000C228
		public unsafe void SendKeys(int[] keyScanCodes, bool[] keyReleased)
		{
			if (keyScanCodes.Length != keyReleased.Length)
			{
				throw new ArgumentException("MsRdpClientNonScriptableWrapper.SendKeys: Arraysize must match");
			}
			int[] temp = new int[keyReleased.Length];
			for (int i = 0; i < temp.Length; i++)
			{
				temp[i] = (keyReleased[i] ? 1 : 0);
			}
			fixed (int[] array = keyScanCodes)
			{
				int* pScanCodes;
				if (keyScanCodes == null || array.Length == 0)
				{
					pScanCodes = null;
				}
				else
				{
					pScanCodes = &array[0];
				}
				int[] array2;
				int* pKeyReleased;
				if ((array2 = temp) == null || array2.Length == 0)
				{
					pKeyReleased = null;
				}
				else
				{
					pKeyReleased = &array2[0];
				}
				this.m_ComInterface.SendKeys(keyScanCodes.Length, pKeyReleased, pScanCodes);
				array2 = null;
			}
		}

		// Token: 0x0400012F RID: 303
		private MsRdpClientNonScriptableWrapper.IMsRdpClientNonScriptable_Sendkeys m_ComInterface;

		// Token: 0x020000E2 RID: 226
		[InterfaceType(1)]
		[Guid("2F079C4C-87B2-4AFD-97AB-20CDB43038AE")]
		private interface IMsRdpClientNonScriptable_Sendkeys : IMsTscNonScriptable
		{
			// Token: 0x170002DB RID: 731
			// (get) Token: 0x060009FD RID: 2557
			// (set) Token: 0x060009FE RID: 2558
			[DispId(4)]
			string BinaryPassword { get; set; }

			// Token: 0x170002DC RID: 732
			// (get) Token: 0x060009FF RID: 2559
			// (set) Token: 0x06000A00 RID: 2560
			[DispId(5)]
			string BinarySalt { get; set; }

			// Token: 0x170002DD RID: 733
			// (set) Token: 0x06000A01 RID: 2561
			[DispId(1)]
			string ClearTextPassword { set; }

			// Token: 0x170002DE RID: 734
			// (get) Token: 0x06000A02 RID: 2562
			// (set) Token: 0x06000A03 RID: 2563
			[DispId(2)]
			string PortablePassword { get; set; }

			// Token: 0x170002DF RID: 735
			// (get) Token: 0x06000A04 RID: 2564
			// (set) Token: 0x06000A05 RID: 2565
			[DispId(3)]
			string PortableSalt { get; set; }

			// Token: 0x06000A06 RID: 2566
			void NotifyRedirectDeviceChange(uint wParam, int lParam);

			// Token: 0x06000A07 RID: 2567
			void ResetPassword();

			// Token: 0x06000A08 RID: 2568
			unsafe void SendKeys(int numKeys, int* pbArrayKeyUp, int* plKeyData);
		}
	}
}
