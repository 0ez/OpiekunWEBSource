﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200003E RID: 62
	public static class DataProtection
	{
		// Token: 0x060003FD RID: 1021 RVA: 0x0000F20C File Offset: 0x0000D40C
		public static string Protect(string clearText, DataProtectionScope scope = DataProtectionScope.CurrentUser)
		{
			if (string.IsNullOrEmpty(clearText))
			{
				return clearText;
			}
			return Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(clearText), DataProtection._entropyBytes, scope));
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0000F234 File Offset: 0x0000D434
		public static string Unprotect(string encryptedText, DataProtectionScope scope = DataProtectionScope.CurrentUser)
		{
			if (string.IsNullOrEmpty(encryptedText))
			{
				return encryptedText;
			}
			byte[] clearBytes = ProtectedData.Unprotect(Convert.FromBase64String(encryptedText), DataProtection._entropyBytes, scope);
			return Encoding.UTF8.GetString(clearBytes);
		}

		// Token: 0x0400013C RID: 316
		private static readonly byte[] _entropyBytes = new byte[]
		{
			1,
			32,
			34,
			45,
			56,
			67,
			22,
			0,
			44,
			77,
			88,
			22,
			1
		};
	}
}
