﻿using System;
using System.Runtime.InteropServices;
using OpiekunWEB.Api;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000046 RID: 70
	public static class IdleTime
	{
		// Token: 0x0600041D RID: 1053 RVA: 0x0000FB50 File Offset: 0x0000DD50
		public static uint GetIdleTime()
		{
			IdleTime.LASTINPUTINFO lastInPut = default(IdleTime.LASTINPUTINFO);
			lastInPut.cbSize = (uint)Marshal.SizeOf<IdleTime.LASTINPUTINFO>(lastInPut);
			if (!IdleTime.GetLastInputInfo(ref lastInPut))
			{
				return 0U;
			}
			return SystemHelpers.GetTickCount() - lastInPut.dwTime;
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x0000FB89 File Offset: 0x0000DD89
		public static bool IsIdleTime()
		{
			return IdleTime.GetIdleTime() > 300000U;
		}

		// Token: 0x0600041F RID: 1055
		[DllImport("User32.dll")]
		private static extern bool GetLastInputInfo(ref IdleTime.LASTINPUTINFO plii);

		// Token: 0x020000FF RID: 255
		private struct LASTINPUTINFO
		{
			// Token: 0x04000828 RID: 2088
			public uint cbSize;

			// Token: 0x04000829 RID: 2089
			public uint dwTime;
		}
	}
}
