﻿using System;
using System.Collections.Generic;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200003F RID: 63
	public class KeyAndValue<X, Y>
	{
		// Token: 0x06000400 RID: 1024 RVA: 0x00002D3D File Offset: 0x00000F3D
		public KeyAndValue(object item)
		{
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x0000F281 File Offset: 0x0000D481
		public KeyAndValue(X key, Y value)
		{
			this.Key = key;
			this.Value = value;
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x06000402 RID: 1026 RVA: 0x0000F297 File Offset: 0x0000D497
		// (set) Token: 0x06000403 RID: 1027 RVA: 0x0000F29F File Offset: 0x0000D49F
		public X Key { get; set; }

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x06000404 RID: 1028 RVA: 0x0000F2A8 File Offset: 0x0000D4A8
		// (set) Token: 0x06000405 RID: 1029 RVA: 0x0000F2B0 File Offset: 0x0000D4B0
		public Y Value { get; set; }

		// Token: 0x06000406 RID: 1030 RVA: 0x0000F2BC File Offset: 0x0000D4BC
		public static List<KeyAndValue<X, Y>> DictionaryToKeyValueList(Dictionary<X, Y> dictionary)
		{
			List<KeyAndValue<X, Y>> result = new List<KeyAndValue<!0, !1>>();
			foreach (KeyValuePair<X, Y> kv in dictionary)
			{
				result.Add(new KeyAndValue<!0, !1>(kv.Key, kv.Value));
			}
			return result;
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x0000F324 File Offset: 0x0000D524
		public override string ToString()
		{
			Y value = this.Value;
			return value.ToString();
		}
	}
}
