﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using DevExpress.XtraCharts;
using DevExpress.XtraGrid.Views.Grid;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000035 RID: 53
	public static class DataExporter
	{
		// Token: 0x060003C4 RID: 964 RVA: 0x0000DF64 File Offset: 0x0000C164
		public static void Export(GridView grid)
		{
			SaveFileDialog fileDialog = new SaveFileDialog();
			fileDialog.Filter = "Adobe Acrobat(*.pdf)|*.pdf|Microsoft Excel xls (*.xls)|*.xls|Microsoft Excel xlsx (*.xlsx)|*.xlsx|Microsoft Word docx (*.docx)|*.docx|Plik HTLM|*.html|Plik CSV|*.csv";
			fileDialog.FileOk += delegate(object sender, CancelEventArgs args)
			{
				string ext = Path.GetExtension(fileDialog.FileName).ToLower();
				if (ext == ".pdf")
				{
					grid.ExportToPdf(fileDialog.FileName);
					return;
				}
				if (ext == ".xls")
				{
					grid.ExportToXls(fileDialog.FileName);
					return;
				}
				if (ext == ".xlsx")
				{
					grid.ExportToXlsx(fileDialog.FileName);
					return;
				}
				if (ext == ".docx")
				{
					grid.ExportToDocx(fileDialog.FileName);
					return;
				}
				if (ext == ".html")
				{
					grid.ExportToHtml(fileDialog.FileName);
					return;
				}
				if (ext == ".csv")
				{
					grid.ExportToCsv(fileDialog.FileName);
				}
			};
			fileDialog.ShowDialog();
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0000DFBC File Offset: 0x0000C1BC
		public static void Export(ChartControl chart)
		{
			SaveFileDialog fileDialog = new SaveFileDialog();
			fileDialog.Filter = "Adobe Acrobat(*.pdf)|*.pdf|Microsoft Excel xls (*.xls)|*.xls|Microsoft Excel xlsx (*.xlsx)|*.xlsx|Microsoft Word docx (*.docx)|*.docx|Plik HTLM|*.html";
			fileDialog.FileOk += delegate(object sender, CancelEventArgs args)
			{
				string ext = Path.GetExtension(fileDialog.FileName).ToLower();
				if (ext == ".pdf")
				{
					chart.ExportToPdf(fileDialog.FileName);
					return;
				}
				if (ext == ".xls")
				{
					chart.ExportToXls(fileDialog.FileName);
					return;
				}
				if (ext == ".xlsx")
				{
					chart.ExportToXlsx(fileDialog.FileName);
					return;
				}
				if (ext == ".docx")
				{
					chart.ExportToDocx(fileDialog.FileName);
					return;
				}
				if (ext == ".html")
				{
					chart.ExportToHtml(fileDialog.FileName);
				}
			};
			fileDialog.ShowDialog();
		}
	}
}
