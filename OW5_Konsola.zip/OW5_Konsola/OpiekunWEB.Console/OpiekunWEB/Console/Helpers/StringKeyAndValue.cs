﻿using System;
using System.Collections.Generic;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000040 RID: 64
	public class StringKeyAndValue : KeyAndValue<string, string>
	{
		// Token: 0x06000408 RID: 1032 RVA: 0x0000F345 File Offset: 0x0000D545
		public StringKeyAndValue(string key, string value) : base(key, value)
		{
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0000F350 File Offset: 0x0000D550
		public new static List<StringKeyAndValue> DictionaryToKeyValueList(Dictionary<string, string> dictionary)
		{
			List<StringKeyAndValue> result = new List<StringKeyAndValue>();
			foreach (KeyValuePair<string, string> kv in dictionary)
			{
				result.Add(new StringKeyAndValue(kv.Key, kv.Value));
			}
			return result;
		}
	}
}
