﻿using System;
using System.Drawing;
using System.Globalization;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;
using DevExpress.XtraEditors.Controls;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000039 RID: 57
	public static class AppUtils
	{
		// Token: 0x060003D6 RID: 982 RVA: 0x0000E674 File Offset: 0x0000C874
		public static void FillDeviceTypesImageComboBoxItemCollection(ImageComboBoxItemCollection items)
		{
			items.Clear();
			foreach (DeviceType deviceType in (DeviceType[])Enum.GetValues(typeof(DeviceType)))
			{
				items.Add(new ImageComboBoxItem(deviceType.GetDescription(), (int)deviceType, (int)deviceType));
			}
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0000E6C7 File Offset: 0x0000C8C7
		public static Icon GetAppIcon()
		{
			Icon result;
			if ((result = AppUtils._appIcon) == null)
			{
				result = (AppUtils._appIcon = Icon.ExtractAssociatedIcon(Application.ExecutablePath));
			}
			return result;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0000E6E2 File Offset: 0x0000C8E2
		public static string GetDescription(this FormAction formAction)
		{
			return SsStringUtils.GetEnumDescriptionFromResource<FormAction>(formAction, Resources.ResourceManager, null);
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0000E6F0 File Offset: 0x0000C8F0
		public static bool HasWindowsAdminRights()
		{
			return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0000E708 File Offset: 0x0000C908
		public static void SetAppCulture(string cultureId)
		{
			CultureInfo culture = CultureInfo.CreateSpecificCulture(cultureId);
			Thread.CurrentThread.CurrentUICulture = culture;
			Thread.CurrentThread.CurrentCulture = culture;
			CultureInfo.DefaultThreadCurrentCulture = culture;
			CultureInfo.DefaultThreadCurrentUICulture = culture;
		}

		// Token: 0x04000135 RID: 309
		private static Icon _appIcon;
	}
}
