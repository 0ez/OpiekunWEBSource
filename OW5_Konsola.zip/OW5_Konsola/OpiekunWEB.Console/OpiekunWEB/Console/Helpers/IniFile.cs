﻿using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000047 RID: 71
	public class IniFile
	{
		// Token: 0x06000420 RID: 1056 RVA: 0x0000FB97 File Offset: 0x0000DD97
		public IniFile(string fileName, string defaultSection)
		{
			this._fileName = new FileInfo(fileName).FullName;
			this._defaultSection = defaultSection;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x0000FBB7 File Offset: 0x0000DDB7
		public void DeleteKey(string key)
		{
			this.WriteString(key, null);
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x0000FBC1 File Offset: 0x0000DDC1
		public bool KeyExists(string key)
		{
			return this.ReadString(key, null).Length > 0;
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x0000FBD3 File Offset: 0x0000DDD3
		public bool ReadBool(string section, string key, bool defaultValue)
		{
			return this.ReadString(section, key, defaultValue.ToString()) == "1";
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0000FBEE File Offset: 0x0000DDEE
		public bool ReadBool(string key, bool defaultValue)
		{
			return this.ReadBool(this._defaultSection, key, defaultValue);
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0000FC00 File Offset: 0x0000DE00
		public int ReadInt(string section, string key, int defaultValue)
		{
			int result;
			if (!int.TryParse(this.ReadString(section, key, defaultValue.ToString()), NumberStyles.Integer, CultureInfo.InvariantCulture.NumberFormat, out result))
			{
				result = defaultValue;
			}
			return result;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0000FC33 File Offset: 0x0000DE33
		public int ReadInt(string key, int defaultValue)
		{
			return this.ReadInt(this._defaultSection, key, defaultValue);
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x0000FC44 File Offset: 0x0000DE44
		public long ReadLong(string section, string key, long defaultValue)
		{
			long result;
			if (!long.TryParse(this.ReadString(section, key, defaultValue.ToString()), NumberStyles.Integer, CultureInfo.InvariantCulture.NumberFormat, out result))
			{
				result = defaultValue;
			}
			return result;
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0000FC77 File Offset: 0x0000DE77
		public long ReadLong(string key, long defaultValue)
		{
			return this.ReadLong(this._defaultSection, key, defaultValue);
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x0000FC88 File Offset: 0x0000DE88
		public string ReadString(string section, string key, string defaultValue)
		{
			StringBuilder result = new StringBuilder(255);
			IniFile.GetPrivateProfileString(section, key, defaultValue, result, 255, this._fileName);
			return result.ToString();
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0000FCBB File Offset: 0x0000DEBB
		public string ReadString(string key, string defaultValue)
		{
			return this.ReadString(this._defaultSection, key, defaultValue);
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0000FCCC File Offset: 0x0000DECC
		public string[] ReadStringArray(string key, string[] defaultValue)
		{
			string str = this.ReadString(key, (defaultValue != null) ? string.Join("\t", defaultValue) : "");
			if (string.IsNullOrEmpty(str))
			{
				return defaultValue;
			}
			return str.Split(new char[]
			{
				'\t'
			});
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0000FD11 File Offset: 0x0000DF11
		public void WriteBool(string section, string key, bool value)
		{
			this.WriteString(section, key, value ? "1" : "0");
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x0000FD2A File Offset: 0x0000DF2A
		public void WriteBool(string key, bool value)
		{
			this.WriteString(this._defaultSection, key, value ? "1" : "0");
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x0000FD48 File Offset: 0x0000DF48
		public void WriteInt(string section, string key, int value)
		{
			this.WriteString(section, key, value.ToString(CultureInfo.InvariantCulture.NumberFormat));
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x0000FD63 File Offset: 0x0000DF63
		public void WriteInt(string key, int value)
		{
			this.WriteString(this._defaultSection, key, value.ToString(CultureInfo.InvariantCulture.NumberFormat));
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x0000FD83 File Offset: 0x0000DF83
		public void WriteLong(string section, string key, long value)
		{
			this.WriteString(section, key, value.ToString(CultureInfo.InvariantCulture.NumberFormat));
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x0000FD9E File Offset: 0x0000DF9E
		public void WriteLong(string key, long value)
		{
			this.WriteString(this._defaultSection, key, value.ToString(CultureInfo.InvariantCulture.NumberFormat));
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x0000FDBE File Offset: 0x0000DFBE
		public void WriteString(string section, string key, string value)
		{
			IniFile.WritePrivateProfileString(section, key, value, this._fileName);
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x0000FDCF File Offset: 0x0000DFCF
		public void WriteString(string key, string value)
		{
			IniFile.WritePrivateProfileString(this._defaultSection, key, value, this._fileName);
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x0000FDE5 File Offset: 0x0000DFE5
		public void WriteStringArray(string key, string[] array)
		{
			IniFile.WritePrivateProfileString(this._defaultSection, key, string.Join("\t", array), this._fileName);
		}

		// Token: 0x06000435 RID: 1077
		[DllImport("kernel32", CharSet = CharSet.Unicode)]
		private static extern int GetPrivateProfileString(string Section, string Key, string Default, StringBuilder RetVal, int Size, string FilePath);

		// Token: 0x06000436 RID: 1078
		[DllImport("kernel32", CharSet = CharSet.Unicode)]
		private static extern long WritePrivateProfileString(string Section, string Key, string Value, string FilePath);

		// Token: 0x0400014F RID: 335
		private readonly string _defaultSection;

		// Token: 0x04000150 RID: 336
		private readonly string _fileName;
	}
}
