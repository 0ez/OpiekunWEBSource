﻿using System;
using System.Collections.Generic;
using System.Linq;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000048 RID: 72
	public static class RefreshTimes
	{
		// Token: 0x06000437 RID: 1079 RVA: 0x0000FE08 File Offset: 0x0000E008
		public static string GetDefaultText()
		{
			return RefreshTimes.RefreshTimeDictionary.ElementAt(3).Key;
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0000FE28 File Offset: 0x0000E028
		public static int GetDefaultValue()
		{
			return RefreshTimes.RefreshTimeDictionary.ElementAt(3).Value;
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0000FE48 File Offset: 0x0000E048
		public static int GetRefreshTime(string text)
		{
			if (RefreshTimes.RefreshTimeDictionary.ContainsKey(text))
			{
				return RefreshTimes.RefreshTimeDictionary[text];
			}
			int result;
			int.TryParse(text, out result);
			return result;
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0000FE78 File Offset: 0x0000E078
		public static int GetRefreshTime(ComboBoxEdit combo)
		{
			return RefreshTimes.GetRefreshTime(combo.Text);
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0000FE88 File Offset: 0x0000E088
		public static void InitializeComboBoxRefreshTimes(RepositoryItemComboBox combo)
		{
			combo.Items.Clear();
			foreach (KeyValuePair<string, int> refreshTime in RefreshTimes.RefreshTimeDictionary)
			{
				combo.Items.Add(refreshTime.Key);
			}
		}

		// Token: 0x04000151 RID: 337
		private const int DefaultElementNo = 3;

		// Token: 0x04000152 RID: 338
		private static readonly Dictionary<string, int> RefreshTimeDictionary = new Dictionary<string, int>
		{
			{
				Resources.RefreshTime_Disabled,
				0
			},
			{
				Resources.RefreshTime_5s,
				5
			},
			{
				Resources.RefreshTime_10s,
				10
			},
			{
				Resources.RefreshTime_15s,
				15
			},
			{
				Resources.RefreshTime_30s,
				30
			},
			{
				Resources.RefreshTime_45s,
				45
			},
			{
				Resources.RefreshTime_60s,
				60
			},
			{
				Resources.RefreshTime_90s,
				90
			}
		};
	}
}
