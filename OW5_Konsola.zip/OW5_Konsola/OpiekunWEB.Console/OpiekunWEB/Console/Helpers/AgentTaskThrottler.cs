﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Schedulers;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000038 RID: 56
	public class AgentTaskThrottler
	{
		// Token: 0x060003D0 RID: 976 RVA: 0x0000E508 File Offset: 0x0000C708
		public AgentTaskThrottler(int maxDegreeOfParallelism)
		{
			this._taskSheduler = new LimitedConcurrencyLevelTaskScheduler(maxDegreeOfParallelism);
			this._taskFactory = new TaskFactory(this._taskSheduler);
			this._mapAgentToCts = new ConcurrentDictionary<AgentItem, CancellationTokenSource>();
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x0000E538 File Offset: 0x0000C738
		public void CancelAgentTask(AgentItem agentItem)
		{
			CancellationTokenSource cts = null;
			if (this._mapAgentToCts.TryRemove(agentItem, out cts))
			{
				cts.Cancel();
			}
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x0000E560 File Offset: 0x0000C760
		public void CancelAgentTask(List<AgentItem> agentItemList)
		{
			foreach (AgentItem agentItem in agentItemList)
			{
				this.CancelAgentTask(agentItem);
			}
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0000E5B0 File Offset: 0x0000C7B0
		public void CancelAllTask()
		{
			foreach (KeyValuePair<AgentItem, CancellationTokenSource> kv in this._mapAgentToCts)
			{
				CancellationTokenSource cts = null;
				if (this._mapAgentToCts.TryRemove(kv.Key, out cts))
				{
					kv.Value.Cancel();
				}
			}
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0000E61C File Offset: 0x0000C81C
		public CancellationToken GetCancellationToken(AgentItem agentItem)
		{
			CancellationTokenSource cts = null;
			if (this._mapAgentToCts.TryGetValue(agentItem, out cts) && !cts.IsCancellationRequested)
			{
				return cts.Token;
			}
			cts = new CancellationTokenSource();
			this._mapAgentToCts[agentItem] = cts;
			return cts.Token;
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0000E663 File Offset: 0x0000C863
		public Task<TResult> StartNewTask<TResult>(Func<TResult> function)
		{
			return this._taskFactory.StartNew<TResult>(function);
		}

		// Token: 0x04000132 RID: 306
		private ConcurrentDictionary<AgentItem, CancellationTokenSource> _mapAgentToCts;

		// Token: 0x04000133 RID: 307
		private TaskFactory _taskFactory;

		// Token: 0x04000134 RID: 308
		private LimitedConcurrencyLevelTaskScheduler _taskSheduler;
	}
}
