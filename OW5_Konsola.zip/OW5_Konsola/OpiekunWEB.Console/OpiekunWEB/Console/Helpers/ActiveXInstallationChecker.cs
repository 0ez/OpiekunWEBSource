﻿using System;
using System.Diagnostics;
using Microsoft.Win32;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000033 RID: 51
	public static class ActiveXInstallationChecker
	{
		// Token: 0x060003BC RID: 956 RVA: 0x0000DD7C File Offset: 0x0000BF7C
		public static string GetInstalledFileName(string sid, bool asUser = false)
		{
			object r = Registry.GetValue((asUser ? "HKEY_CURRENT_USER\\Software" : "HKEY_CLASSES_ROOT") + "\\CLSID\\{" + sid + "}\\InprocServer32", "", null);
			if (r != null)
			{
				return r as string;
			}
			return string.Empty;
		}

		// Token: 0x060003BD RID: 957 RVA: 0x0000DDC4 File Offset: 0x0000BFC4
		public static bool Install(string sid, string fileToRegister, bool asUser = false)
		{
			ProcessStartInfo startInfo = new ProcessStartInfo("regsvr32");
			startInfo.UseShellExecute = true;
			startInfo.Verb = "runas";
			startInfo.Arguments = "/s \"" + fileToRegister + "\"";
			if (asUser)
			{
				startInfo.Arguments = "/n /i:user " + startInfo.Arguments;
				startInfo.Verb = "open";
			}
			Process p = Process.Start(startInfo);
			if (p == null)
			{
				return false;
			}
			p.WaitForExit();
			return ActiveXInstallationChecker.IsInstalled(sid);
		}

		// Token: 0x060003BE RID: 958 RVA: 0x0000DE40 File Offset: 0x0000C040
		public static bool IsInstalled(string sid)
		{
			return !string.IsNullOrEmpty(ActiveXInstallationChecker.GetInstalledFileName(sid, false));
		}

		// Token: 0x060003BF RID: 959 RVA: 0x0000DE51 File Offset: 0x0000C051
		public static bool IsInstalledAsUser(string sid)
		{
			return !string.IsNullOrEmpty(ActiveXInstallationChecker.GetInstalledFileName(sid, true));
		}
	}
}
