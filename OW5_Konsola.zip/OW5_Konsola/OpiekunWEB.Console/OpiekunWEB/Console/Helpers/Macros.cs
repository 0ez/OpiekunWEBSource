﻿using System;
using System.Collections.Generic;
using System.IO;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000043 RID: 67
	public static class Macros
	{
		// Token: 0x0600040F RID: 1039 RVA: 0x0000F5D8 File Offset: 0x0000D7D8
		public static string GetDescriptionForDirMacro(string macro)
		{
			string result;
			Macros.GetDirMacrosAsDescriptionDictionary(true).TryGetValue(macro, out result);
			return result;
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x0000F5F8 File Offset: 0x0000D7F8
		public static string GetDirMacroFromDescription(string macroDescription)
		{
			foreach (KeyValuePair<string, string> keyValue in Macros.GetDirMacrosAsDescriptionDictionary(true))
			{
				if (keyValue.Value == macroDescription)
				{
					return keyValue.Key;
				}
			}
			return string.Empty;
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x0000F664 File Offset: 0x0000D864
		public static string GetDirMacroFromFileName(string fileName)
		{
			int idx = fileName.IndexOf('}');
			if (fileName.Length > 2 && fileName[0] == '{' && idx > 0)
			{
				return fileName.Substring(0, idx + 1);
			}
			return string.Empty;
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0000F6A8 File Offset: 0x0000D8A8
		public static Dictionary<string, string> GetDirMacrosAsDescriptionDictionary(bool addAnyDirectory)
		{
			Dictionary<string, string> result = new Dictionary<string, string>();
			if (addAnyDirectory)
			{
				result.Add("{?}", Resources.MacroDescription_AnyDirectory);
			}
			result.Add("{DESKTOP_DIR}", Resources.MacroDescription_DESKTOP_DIR);
			result.Add("{DOCUMENTS_DIR}", Resources.MacroDescription_DOCUMENTS_DIR);
			result.Add("{DOWNLOAD_DIR}", Resources.MacroDescription_DOWNLOAD_DIR);
			result.Add("{USERPROFILE_DIR}", Resources.MacroDescription_USERPROFILE_DIR);
			result.Add("{WIN_DIR}", Resources.MacroDescription_WIN_DIR);
			result.Add("{SYS_DIR}", Resources.MacroDescription_SYS_DIR);
			result.Add("{PF_DIR}", Resources.MacroDescription_PF_DIR);
			result.Add("{PF86_DIR}", Resources.MacroDescription_PF86_DIR);
			return result;
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0000F74F File Offset: 0x0000D94F
		public static List<StringKeyAndValue> GetDirMacrosAsStringKeyValueList(bool addAnyDirectory)
		{
			return StringKeyAndValue.DictionaryToKeyValueList(Macros.GetDirMacrosAsDescriptionDictionary(addAnyDirectory));
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x0000F75C File Offset: 0x0000D95C
		public static bool IsAnyDirectoryMacro(string macro)
		{
			return macro == "{?}";
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x0000F769 File Offset: 0x0000D969
		public static bool IsAnyDirectoryMacro(StringKeyAndValue keyValueMacro)
		{
			return Macros.IsAnyDirectoryMacro(keyValueMacro.Key);
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x0000F776 File Offset: 0x0000D976
		public static bool IsUserDependMacro(string macro)
		{
			return macro == "{DESKTOP_DIR}" || macro == "{DOCUMENTS_DIR}" || macro == "{DOWNLOAD_DIR}" || macro == "{USERPROFILE_DIR}";
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0000F7AC File Offset: 0x0000D9AC
		public static string MacroAndFileNameToString(string macro, string fileName)
		{
			if (macro == "{?}")
			{
				return fileName;
			}
			return macro + fileName;
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x0000F7C4 File Offset: 0x0000D9C4
		public static System.ValueTuple<StringKeyAndValue, string> SplitFileNameToMacroAndFileName(List<StringKeyAndValue> macroList, string fileName)
		{
			int idx = fileName.IndexOf('}');
			if (fileName.Length <= 2 || fileName[0] != '{' || idx <= 0)
			{
				return new System.ValueTuple<StringKeyAndValue, string>(macroList.Find((StringKeyAndValue x) => x.Key == "{?}"), fileName);
			}
			string macroKey = fileName.Substring(0, idx + 1);
			return new System.ValueTuple<StringKeyAndValue, string>(macroList.Find((StringKeyAndValue x) => x.Key == macroKey), fileName.Substring(idx + 1));
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x0000F85C File Offset: 0x0000DA5C
		public static bool ValidateMacroAndPath(string macro, string userPath, out string modifiedUserPath, FileOrFolder fileOrFolder)
		{
			modifiedUserPath = userPath;
			string pathToCheck;
			if (macro == "{?}")
			{
				pathToCheck = userPath;
			}
			else
			{
				if (userPath.IndexOf(':') > -1)
				{
					return false;
				}
				if (userPath.Length > 0 && userPath[0] != '\\' && userPath[0] != '/')
				{
					modifiedUserPath = "\\" + userPath;
				}
				pathToCheck = "c:" + ((modifiedUserPath.Length == 0) ? "\\" : modifiedUserPath);
			}
			bool result;
			try
			{
				string fullPath = Path.GetFullPath(pathToCheck);
				int minPathLength = (fileOrFolder == FileOrFolder.Folder) ? 3 : 4;
				if (fullPath.Length == pathToCheck.Length && fullPath.Length >= minPathLength)
				{
					string lastChar = fullPath.Substring(fullPath.Length - 1);
					if (lastChar == ".")
					{
						result = false;
					}
					else if ((lastChar == "\\" || lastChar == "/") && fileOrFolder == FileOrFolder.File)
					{
						result = false;
					}
					else
					{
						result = true;
					}
				}
				else
				{
					result = false;
				}
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x04000142 RID: 322
		public const string AnyDirectory = "{?}";
	}
}
