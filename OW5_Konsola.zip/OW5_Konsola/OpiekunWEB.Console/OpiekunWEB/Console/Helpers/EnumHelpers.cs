﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Resources;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using OpiekunWEB.Api;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200003D RID: 61
	public static class EnumHelpers
	{
		// Token: 0x060003F5 RID: 1013 RVA: 0x0000F040 File Offset: 0x0000D240
		public static T GetComboEnumValueFromKeyAndValue<T>(ComboBoxEdit comboBox)
		{
			return ((KeyAndValue<!!0, string>)comboBox.EditValue).Key;
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x0000F054 File Offset: 0x0000D254
		public static List<KeyAndValue<T, string>> GetEnumValuesAsStringKeyAndValue<T>(ResourceManager resourceManager = null) where T : struct, IConvertible
		{
			if (!typeof(!!0).IsEnum)
			{
				throw new ArgumentException("Invalid type (enum expected)");
			}
			List<KeyAndValue<T, string>> result = new List<KeyAndValue<!!0, string>>();
			foreach (object obj in Enum.GetValues(typeof(!!0)))
			{
				T value = (!!0)((object)obj);
				result.Add(new KeyAndValue<!!0, string>(value, SsStringUtils.GetEnumDescriptionFromResource<T>(value, resourceManager, null)));
			}
			return result;
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x0000F0E8 File Offset: 0x0000D2E8
		public static void InitializeComboBoxAsStringKeyAndValue<T>(BarEditItem barItem, List<KeyAndValue<T, string>> list, T defaultValue) where T : struct, IConvertible
		{
			RepositoryItemComboBox itemComboBox = barItem.Edit as RepositoryItemComboBox;
			if (itemComboBox != null)
			{
				itemComboBox.Items.AddRange(list);
				if ((KeyAndValue<!!0, string>)barItem.EditValue == null)
				{
					barItem.EditValue = list.Find(delegate(KeyAndValue<T, string> x)
					{
						T key = x.Key;
						return key.ToInt32(CultureInfo.CurrentCulture) == defaultValue.ToInt32(CultureInfo.CurrentCulture);
					});
				}
			}
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x0000F142 File Offset: 0x0000D342
		public static void InitializeComboBoxAsStringKeyAndValue<T>(BarEditItem barItem, T defaultValue, ResourceManager resourceManager = null) where T : struct, IConvertible
		{
			EnumHelpers.InitializeComboBoxAsStringKeyAndValue<T>(barItem, EnumHelpers.GetEnumValuesAsStringKeyAndValue<T>(resourceManager), defaultValue);
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x0000F154 File Offset: 0x0000D354
		public static void InitializeComboBoxAsStringKeyAndValue<T>(ComboBoxEdit comboBox, List<KeyAndValue<T, string>> list, T defaultValue) where T : struct, IConvertible
		{
			comboBox.Properties.Items.AddRange(list);
			if ((KeyAndValue<!!0, string>)comboBox.EditValue == null)
			{
				comboBox.EditValue = list.Find(delegate(KeyAndValue<T, string> x)
				{
					T key = x.Key;
					return key.ToInt32(CultureInfo.CurrentCulture) == defaultValue.ToInt32(CultureInfo.CurrentCulture);
				});
			}
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x0000F1A4 File Offset: 0x0000D3A4
		public static void InitializeComboBoxAsStringKeyAndValue<T>(ComboBoxEdit comboBox, T defaultValue, ResourceManager resourceManager = null) where T : struct, IConvertible
		{
			EnumHelpers.InitializeComboBoxAsStringKeyAndValue<T>(comboBox, EnumHelpers.GetEnumValuesAsStringKeyAndValue<T>(resourceManager), defaultValue);
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0000F1B3 File Offset: 0x0000D3B3
		public static bool IsItemTypeIncluded(this DeviceTreeItemsType itemTypeFlags, DeviceTreeItemsType itemType)
		{
			return (itemTypeFlags & itemType) == itemType;
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x0000F1BC File Offset: 0x0000D3BC
		public static bool IsItemTypeIncluded(this DeviceTreeItemsType itemTypeFlags, DeviceTreeItemBase item)
		{
			if (item is AgentItem)
			{
				return itemTypeFlags.IsItemTypeIncluded(DeviceTreeItemsType.Agent);
			}
			if (item is DevicesGroupItem)
			{
				return itemTypeFlags.IsItemTypeIncluded(DeviceTreeItemsType.DeviceGroup);
			}
			if (!(item is DeviceItem))
			{
				return item is DisplayItem && itemTypeFlags.IsItemTypeIncluded(DeviceTreeItemsType.Display);
			}
			return itemTypeFlags.IsItemTypeIncluded(DeviceTreeItemsType.Device);
		}
	}
}
