﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200004B RID: 75
	public static class WindowsApi
	{
		// Token: 0x06000447 RID: 1095
		[DllImport("user32.dll")]
		public static extern bool EnableMenuItem(IntPtr hMenu, uint itemId, uint uEnable);

		// Token: 0x06000448 RID: 1096 RVA: 0x00010460 File Offset: 0x0000E660
		public static bool GetDisplaySettings(Screen screen, ref WindowsApi.DEVMODE devMode)
		{
			return WindowsApi.EnumDisplaySettings(screen.DeviceName, -1, ref devMode);
		}

		// Token: 0x06000449 RID: 1097
		[DllImport("user32.dll")]
		public static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

		// Token: 0x0600044A RID: 1098
		[DllImport("user32.dll")]
		public static extern bool MessageBeep(uint uType);

		// Token: 0x0600044B RID: 1099
		[DllImport("user32.dll")]
		public static extern bool PostMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

		// Token: 0x0600044C RID: 1100
		[DllImport("User32.dll")]
		public static extern int SetForegroundWindow(int hWnd);

		// Token: 0x0600044D RID: 1101
		[DllImport("user32.dll")]
		private static extern bool EnumDisplaySettings(string deviceName, int modeNum, ref WindowsApi.DEVMODE devMode);

		// Token: 0x04000158 RID: 344
		public static uint WM_CLOSE = 16U;

		// Token: 0x04000159 RID: 345
		private const int ENUM_CURRENT_SETTINGS = -1;

		// Token: 0x02000105 RID: 261
		public struct DEVMODE
		{
			// Token: 0x04000845 RID: 2117
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
			public string dmDeviceName;

			// Token: 0x04000846 RID: 2118
			public short dmSpecVersion;

			// Token: 0x04000847 RID: 2119
			public short dmDriverVersion;

			// Token: 0x04000848 RID: 2120
			public short dmSize;

			// Token: 0x04000849 RID: 2121
			public short dmDriverExtra;

			// Token: 0x0400084A RID: 2122
			public int dmFields;

			// Token: 0x0400084B RID: 2123
			public short dmOrientation;

			// Token: 0x0400084C RID: 2124
			public short dmPaperSize;

			// Token: 0x0400084D RID: 2125
			public short dmPaperLength;

			// Token: 0x0400084E RID: 2126
			public short dmPaperWidth;

			// Token: 0x0400084F RID: 2127
			public short dmScale;

			// Token: 0x04000850 RID: 2128
			public short dmCopies;

			// Token: 0x04000851 RID: 2129
			public short dmDefaultSource;

			// Token: 0x04000852 RID: 2130
			public short dmPrintQuality;

			// Token: 0x04000853 RID: 2131
			public short dmColor;

			// Token: 0x04000854 RID: 2132
			public short dmDuplex;

			// Token: 0x04000855 RID: 2133
			public short dmYResolution;

			// Token: 0x04000856 RID: 2134
			public short dmTTOption;

			// Token: 0x04000857 RID: 2135
			public short dmCollate;

			// Token: 0x04000858 RID: 2136
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
			public string dmFormName;

			// Token: 0x04000859 RID: 2137
			public short dmLogPixels;

			// Token: 0x0400085A RID: 2138
			public short dmBitsPerPel;

			// Token: 0x0400085B RID: 2139
			public int dmPelsWidth;

			// Token: 0x0400085C RID: 2140
			public int dmPelsHeight;

			// Token: 0x0400085D RID: 2141
			public int dmDisplayFlags;

			// Token: 0x0400085E RID: 2142
			public int dmDisplayFrequency;

			// Token: 0x0400085F RID: 2143
			public int dmICMMethod;

			// Token: 0x04000860 RID: 2144
			public int dmICMIntent;

			// Token: 0x04000861 RID: 2145
			public int dmMediaType;

			// Token: 0x04000862 RID: 2146
			public int dmDitherType;

			// Token: 0x04000863 RID: 2147
			public int dmReserved1;

			// Token: 0x04000864 RID: 2148
			public int dmReserved2;

			// Token: 0x04000865 RID: 2149
			public int dmPanningWidth;

			// Token: 0x04000866 RID: 2150
			public int dmPanningHeight;
		}
	}
}
