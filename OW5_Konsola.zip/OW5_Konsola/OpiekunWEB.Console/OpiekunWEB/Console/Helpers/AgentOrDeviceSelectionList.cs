﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000037 RID: 55
	public class AgentOrDeviceSelectionList
	{
		// Token: 0x060003C8 RID: 968 RVA: 0x0000E0B6 File Offset: 0x0000C2B6
		public AgentOrDeviceSelectionList()
		{
			this._agentItemList = new List<AgentItem>();
			this._deviceItemList = new List<DeviceItem>();
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x0000E0D4 File Offset: 0x0000C2D4
		public List<DeviceTreeItemBase> GetItems(DevicesTree devicesTree, DeviceTreeItemsType itemsType)
		{
			List<DeviceTreeItemBase> result = new List<DeviceTreeItemBase>();
			if (itemsType != DeviceTreeItemsType.Agent)
			{
				if (itemsType != DeviceTreeItemsType.Device)
				{
					result.AddRange(this._agentItemList);
					result.AddRange(this._deviceItemList);
					return result;
				}
				result.AddRange(this._deviceItemList);
				using (List<AgentItem>.Enumerator enumerator = this._agentItemList.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						AgentItem agent = enumerator.Current;
						DeviceItem device = devicesTree.FindDeviceById(agent.ParentId);
						if (device != null && !result.Contains(device))
						{
							result.Add(device);
						}
					}
					return result;
				}
			}
			result.AddRange(this._agentItemList);
			return result;
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0000E184 File Offset: 0x0000C384
		public bool IsItemSelected(DeviceTreeItemBase item)
		{
			bool result = false;
			AgentItem <agentItem>5__2 = item as AgentItem;
			if (<agentItem>5__2 == null)
			{
				DeviceItem <deviceItem>5__3 = item as DeviceItem;
				if (<deviceItem>5__3 != null)
				{
					result = this._deviceItemList.Contains(<deviceItem>5__3);
					if (!result)
					{
						AgentItem deviceAgent = this._agentItemList.Find((AgentItem x) => x.ParentId == <deviceItem>5__3.Id);
						result = <deviceItem>5__3.IsOnlyOneDeviceAgentItem(deviceAgent);
					}
				}
			}
			else
			{
				result = this._agentItemList.Contains(<agentItem>5__2);
				if (!result)
				{
					DeviceItem deviceItem = this._deviceItemList.Find((DeviceItem x) => x.Id == <agentItem>5__2.ParentId);
					result = (deviceItem != null && deviceItem.IsOnlyOneDeviceAgentItem(<agentItem>5__2));
				}
			}
			return result;
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0000E240 File Offset: 0x0000C440
		public void RemoveNotConnected()
		{
			List<DeviceTreeItemBase> list = new List<DeviceTreeItemBase>();
			list.AddRange(from x in this._agentItemList
			where !x.IsConnected
			select x);
			list.AddRange(from x in this._deviceItemList
			where !x.IsConnected
			select x);
			foreach (DeviceTreeItemBase item in list)
			{
				this.UnselectItem(item);
			}
		}

		// Token: 0x060003CC RID: 972 RVA: 0x0000E2F4 File Offset: 0x0000C4F4
		public void SelectItem(DeviceTreeItemBase item)
		{
			AgentItem agentItem = item as AgentItem;
			if (agentItem == null)
			{
				DeviceItem deviceItem = item as DeviceItem;
				if (deviceItem == null)
				{
					return;
				}
				AgentItem ai = deviceItem.GetOnlyOneAgentItem();
				if (ai != null)
				{
					if (!this._agentItemList.Contains(ai))
					{
						this._agentItemList.Add(ai);
						return;
					}
				}
				else if (!this._deviceItemList.Contains(deviceItem))
				{
					this._deviceItemList.Add(deviceItem);
				}
			}
			else if (!this._agentItemList.Contains(agentItem))
			{
				this._agentItemList.Add(agentItem);
				return;
			}
		}

		// Token: 0x060003CD RID: 973 RVA: 0x0000E370 File Offset: 0x0000C570
		public void SelectItems(List<DeviceTreeItemBase> itemList)
		{
			foreach (DeviceTreeItemBase item in itemList)
			{
				this.SelectItem(item);
			}
		}

		// Token: 0x060003CE RID: 974 RVA: 0x0000E3C0 File Offset: 0x0000C5C0
		public void UnselectItem(DeviceTreeItemBase item)
		{
			AgentItem <agentItem>5__2 = item as AgentItem;
			if (<agentItem>5__2 == null)
			{
				DeviceItem <deviceItem>5__3 = item as DeviceItem;
				if (<deviceItem>5__3 == null)
				{
					return;
				}
				if (this._deviceItemList.Contains(<deviceItem>5__3))
				{
					this._deviceItemList.Remove(<deviceItem>5__3);
					return;
				}
				AgentItem ai = this._agentItemList.Find((AgentItem x) => x.ParentId == <deviceItem>5__3.Id);
				if (ai != null && <deviceItem>5__3.IsOnlyOneDeviceAgentItem(ai))
				{
					this._agentItemList.Remove(ai);
				}
			}
			else
			{
				if (this._agentItemList.Contains(<agentItem>5__2))
				{
					this._agentItemList.Remove(<agentItem>5__2);
					return;
				}
				DeviceItem di = this._deviceItemList.Find((DeviceItem x) => x.Id == <agentItem>5__2.ParentId);
				if (di != null && di.IsOnlyOneDeviceAgentItem(<agentItem>5__2))
				{
					this._deviceItemList.Remove(di);
					return;
				}
			}
		}

		// Token: 0x060003CF RID: 975 RVA: 0x0000E4B8 File Offset: 0x0000C6B8
		public void UnselectItems(List<DeviceTreeItemBase> itemList)
		{
			foreach (DeviceTreeItemBase item in itemList)
			{
				this.UnselectItem(item);
			}
		}

		// Token: 0x04000130 RID: 304
		private readonly List<AgentItem> _agentItemList;

		// Token: 0x04000131 RID: 305
		private readonly List<DeviceItem> _deviceItemList;
	}
}
