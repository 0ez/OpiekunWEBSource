﻿using System;
using System.Collections;
using System.Linq;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraTreeList.Nodes.Operations;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200004A RID: 74
	public class TreeListViewState
	{
		// Token: 0x06000441 RID: 1089 RVA: 0x000100BB File Offset: 0x0000E2BB
		public TreeListViewState(TreeList treeList)
		{
			this._treeList = treeList;
			this._expanded = new ArrayList();
			this._selected = new ArrayList();
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x000100E0 File Offset: 0x0000E2E0
		public void Clear()
		{
			this._expanded.Clear();
			this._selected.Clear();
			this._focused = null;
			this._topNode = null;
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x00010108 File Offset: 0x0000E308
		public void LoadState(string fileName)
		{
			this.Clear();
			IniFile iniFile = new IniFile(fileName, this._treeList.Name);
			string[] savedArray = iniFile.ReadStringArray("Expanded", null);
			string focusedKey = iniFile.ReadString("Focused", string.Empty);
			if (savedArray == null)
			{
				this._treeList.ExpandAll();
				return;
			}
			this._expanded.AddRange(savedArray);
			this._treeList.BeginUpdate();
			try
			{
				this._treeList.CollapseAll();
				foreach (object key in this._expanded)
				{
					TreeListNode node = this._treeList.FindNodeByKeyID(key);
					if (node != null)
					{
						node.Expanded = true;
					}
				}
				this._treeList.FocusedNode = this._treeList.FindNodeByKeyID(this._focused);
				foreach (object key2 in this._selected)
				{
					TreeListNode node = this._treeList.FindNodeByKeyID(key2);
					if (node != null)
					{
						this._treeList.Selection.Add(node);
					}
				}
			}
			finally
			{
				this._treeList.EndUpdate();
				TreeListNode topVisibleNode = this._treeList.FindNodeByKeyID(this._topNode);
				if (topVisibleNode == null)
				{
					topVisibleNode = this._treeList.FocusedNode;
				}
				this._treeList.TopVisibleNodeIndex = this._treeList.GetVisibleIndexByNode(topVisibleNode);
				if (focusedKey != string.Empty)
				{
					TreeListNode node2 = this._treeList.FindNodeByKeyID(focusedKey);
					if (node2 != null && node2.Visible)
					{
						this._treeList.FocusedNode = node2;
					}
				}
			}
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x000102E0 File Offset: 0x0000E4E0
		public void SaveState(string fileName)
		{
			if (this._treeList.FocusedNode != null)
			{
				this._expanded = this.GetExpanded();
				this._selected = this.GetSelected();
				TreeListNode focusedNode = this._treeList.FocusedNode;
				this._focused = ((focusedNode != null) ? focusedNode[this._treeList.KeyFieldName] : null);
				TreeListNode nodeByVisibleIndex = this._treeList.GetNodeByVisibleIndex(this._treeList.TopVisibleNodeIndex);
				this._topNode = ((nodeByVisibleIndex != null) ? nodeByVisibleIndex[this._treeList.KeyFieldName] : null);
			}
			else
			{
				this.Clear();
			}
			IniFile iniFile = new IniFile(fileName, this._treeList.Name);
			iniFile.WriteStringArray("Expanded", this._expanded.Cast<string>().ToArray<string>());
			iniFile.WriteString("Focused", (this._focused != null) ? this._focused.ToString() : string.Empty);
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x000103C8 File Offset: 0x0000E5C8
		private ArrayList GetExpanded()
		{
			TreeListViewState.OperationSaveExpanded op = new TreeListViewState.OperationSaveExpanded();
			this._treeList.NodesIterator.DoOperation(op);
			return op.Nodes;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x000103F4 File Offset: 0x0000E5F4
		private ArrayList GetSelected()
		{
			ArrayList al = new ArrayList();
			foreach (TreeListNode node in this._treeList.Selection)
			{
				al.Add(node.GetValue(this._treeList.KeyFieldName));
			}
			return al;
		}

		// Token: 0x04000153 RID: 339
		private ArrayList _expanded;

		// Token: 0x04000154 RID: 340
		private object _focused;

		// Token: 0x04000155 RID: 341
		private ArrayList _selected;

		// Token: 0x04000156 RID: 342
		private object _topNode;

		// Token: 0x04000157 RID: 343
		private TreeList _treeList;

		// Token: 0x02000104 RID: 260
		private class OperationSaveExpanded : TreeListOperation
		{
			// Token: 0x170002E0 RID: 736
			// (get) Token: 0x06000A57 RID: 2647 RVA: 0x00059F5A File Offset: 0x0005815A
			public ArrayList Nodes { get; } = new ArrayList();

			// Token: 0x06000A58 RID: 2648 RVA: 0x00059F62 File Offset: 0x00058162
			public override void Execute(TreeListNode node)
			{
				if (node.HasChildren && node.Expanded)
				{
					this.Nodes.Add(node.GetValue(node.TreeList.KeyFieldName));
				}
			}
		}
	}
}
