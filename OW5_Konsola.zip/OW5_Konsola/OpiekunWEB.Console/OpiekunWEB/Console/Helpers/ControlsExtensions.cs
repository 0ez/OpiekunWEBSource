﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Mask;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200003C RID: 60
	public static class ControlsExtensions
	{
		// Token: 0x060003F2 RID: 1010 RVA: 0x0000EF18 File Offset: 0x0000D118
		public static void GetControls(Control.ControlCollection controls, List<Control> controlList)
		{
			foreach (object obj in controls)
			{
				Control control = (Control)obj;
				controlList.Add(control);
				if (control.Controls.Count > 0)
				{
					ControlsExtensions.GetControls(control.Controls, controlList);
				}
			}
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x0000EF88 File Offset: 0x0000D188
		public static void InvokeIfRequired(this Control c, Action action)
		{
			if (c.InvokeRequired)
			{
				c.Invoke(new Action(delegate()
				{
					action();
				}));
				return;
			}
			action();
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0000EFCC File Offset: 0x0000D1CC
		public static void SetIsModifiedInDevExEdits(this Control c)
		{
			List<Control> controls = new List<Control>();
			ControlsExtensions.GetControls(c.Controls, controls);
			foreach (TextEdit textEdit in controls.OfType<TextEdit>())
			{
				if (textEdit.Properties.Mask.MaskType != MaskType.None)
				{
					textEdit.IsModified = true;
				}
			}
		}
	}
}
