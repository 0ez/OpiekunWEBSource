﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000034 RID: 52
	public static class ClassExtensions
	{
		// Token: 0x060003C0 RID: 960 RVA: 0x0000DE64 File Offset: 0x0000C064
		public static Bitmap ToBitmap(this byte[] bytes)
		{
			if (bytes == null)
			{
				return null;
			}
			Bitmap result;
			using (MemoryStream ms = new MemoryStream(bytes))
			{
				result = new Bitmap(ms);
			}
			return result;
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x0000DEA4 File Offset: 0x0000C0A4
		public static byte[] ToBytes(this Icon icon)
		{
			byte[] result;
			using (MemoryStream ms = new MemoryStream())
			{
				icon.Save(ms);
				result = ms.ToArray();
			}
			return result;
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x0000DEE4 File Offset: 0x0000C0E4
		public static byte[] ToBytes(this Image image, ImageFormat imageFormat)
		{
			byte[] result;
			using (MemoryStream ms = new MemoryStream())
			{
				image.Save(ms, imageFormat);
				result = ms.ToArray();
			}
			return result;
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x0000DF24 File Offset: 0x0000C124
		public static Icon ToIcon(this byte[] bytes)
		{
			if (bytes == null)
			{
				return null;
			}
			Icon result;
			using (MemoryStream ms = new MemoryStream(bytes))
			{
				result = new Icon(ms);
			}
			return result;
		}
	}
}
