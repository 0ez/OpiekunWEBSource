﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200003A RID: 58
	public static class BindingListExtensions
	{
		// Token: 0x060003DB RID: 987 RVA: 0x0000E740 File Offset: 0x0000C940
		public static void AddRange<T>(this BindingList<T> bindingList, IEnumerable<T> collection)
		{
			if (collection == null)
			{
				throw new ArgumentNullException("collection");
			}
			bool oldRaiseEventsValue = bindingList.RaiseListChangedEvents;
			try
			{
				bindingList.RaiseListChangedEvents = false;
				foreach (T value in collection)
				{
					bindingList.Add(value);
				}
			}
			finally
			{
				bindingList.RaiseListChangedEvents = oldRaiseEventsValue;
				if (bindingList.RaiseListChangedEvents)
				{
					bindingList.ResetBindings();
				}
			}
		}
	}
}
