﻿using System;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000042 RID: 66
	public enum FileOrFolder
	{
		// Token: 0x04000140 RID: 320
		File,
		// Token: 0x04000141 RID: 321
		Folder
	}
}
