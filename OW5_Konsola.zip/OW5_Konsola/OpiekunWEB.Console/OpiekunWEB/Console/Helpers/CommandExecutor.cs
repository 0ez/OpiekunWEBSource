﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraBars;
using OpiekunWEB.Api;
using OpiekunWEB.Console.Forms;
using OpiekunWEB.Console.Forms.Params;
using OpiekunWEB.Console.Interfaces;
using OpiekunWEB.Console.Properties;
using Owpb;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x0200003B RID: 59
	public class CommandExecutor
	{
		// Token: 0x060003DC RID: 988 RVA: 0x0000E7C8 File Offset: 0x0000C9C8
		public CommandExecutor(IFormCreator formCreator, ApiClient apiClient, ICommandTarget commandTarget, List<ConsoleEventType> commandsDisabledByRole, List<ConsoleEventType> commandsAlwaysEnabled)
		{
			this._formCreator = formCreator;
			this._apiClient = apiClient;
			this._commandTarget = commandTarget;
			this._commandsDisabledByRole = commandsDisabledByRole;
			this._commandsAlwaysEnabled = commandsAlwaysEnabled;
		}

		// Token: 0x060003DD RID: 989 RVA: 0x0000E7F8 File Offset: 0x0000C9F8
		public Task SessionLock(List<AgentItem> agentList)
		{
			CommandExecutor.<SessionLock>d__7 <SessionLock>d__;
			<SessionLock>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SessionLock>d__.<>4__this = this;
			<SessionLock>d__.agentList = agentList;
			<SessionLock>d__.<>1__state = -1;
			<SessionLock>d__.<>t__builder.Start<CommandExecutor.<SessionLock>d__7>(ref <SessionLock>d__);
			return <SessionLock>d__.<>t__builder.Task;
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0000E844 File Offset: 0x0000CA44
		public Task SessionLogoff(List<AgentItem> agentList)
		{
			CommandExecutor.<SessionLogoff>d__8 <SessionLogoff>d__;
			<SessionLogoff>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SessionLogoff>d__.<>4__this = this;
			<SessionLogoff>d__.agentList = agentList;
			<SessionLogoff>d__.<>1__state = -1;
			<SessionLogoff>d__.<>t__builder.Start<CommandExecutor.<SessionLogoff>d__8>(ref <SessionLogoff>d__);
			return <SessionLogoff>d__.<>t__builder.Task;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x0000E890 File Offset: 0x0000CA90
		public Task SessionLogon()
		{
			CommandExecutor.<SessionLogon>d__9 <SessionLogon>d__;
			<SessionLogon>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SessionLogon>d__.<>4__this = this;
			<SessionLogon>d__.<>1__state = -1;
			<SessionLogon>d__.<>t__builder.Start<CommandExecutor.<SessionLogon>d__9>(ref <SessionLogon>d__);
			return <SessionLogon>d__.<>t__builder.Task;
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x0000E8D3 File Offset: 0x0000CAD3
		public void ShowCollectFilesForm(List<AgentItem> agentList)
		{
			this._formCreator.ShowNonModal<DistributeFilesForm, DistributeFilesFormParams>(new DistributeFilesFormParams(AgentFileTransferDirection.Receive, agentList));
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x0000E8E7 File Offset: 0x0000CAE7
		public void ShowDistributeFilesForm(List<AgentItem> agentList)
		{
			this._formCreator.ShowNonModal<DistributeFilesForm, DistributeFilesFormParams>(new DistributeFilesFormParams(AgentFileTransferDirection.Send, agentList));
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x0000E8FC File Offset: 0x0000CAFC
		public void ShowFileManager(List<AgentItem> agentList)
		{
			AgentClient client = null;
			List<AgentItem> connectedAgents = (from x in agentList
			where x.IsConnected && x.AgentClient != null
			select x).ToList<AgentItem>();
			if (connectedAgents.Count == 1)
			{
				client = connectedAgents[0].AgentClient;
			}
			if (client != null)
			{
				this._formCreator.ShowNonModal<FileManagerForm, AgentClient>(client);
				return;
			}
			this._formCreator.ShowInfo(Resources.CommandExecutor_MustSelectConnectedDeviceForFileManager);
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x0000E96C File Offset: 0x0000CB6C
		public Task ShowMessagesDef(List<AgentItem> agentList, ShowMessageDef showMessageDef)
		{
			CommandExecutor.<ShowMessagesDef>d__13 <ShowMessagesDef>d__;
			<ShowMessagesDef>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ShowMessagesDef>d__.<>4__this = this;
			<ShowMessagesDef>d__.agentList = agentList;
			<ShowMessagesDef>d__.showMessageDef = showMessageDef;
			<ShowMessagesDef>d__.<>1__state = -1;
			<ShowMessagesDef>d__.<>t__builder.Start<CommandExecutor.<ShowMessagesDef>d__13>(ref <ShowMessagesDef>d__);
			return <ShowMessagesDef>d__.<>t__builder.Task;
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x0000E9C0 File Offset: 0x0000CBC0
		public Task ShowProcessesDef(List<AgentItem> agentList, StartProcessDef processDef)
		{
			CommandExecutor.<ShowProcessesDef>d__14 <ShowProcessesDef>d__;
			<ShowProcessesDef>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ShowProcessesDef>d__.<>4__this = this;
			<ShowProcessesDef>d__.agentList = agentList;
			<ShowProcessesDef>d__.processDef = processDef;
			<ShowProcessesDef>d__.<>1__state = -1;
			<ShowProcessesDef>d__.<>t__builder.Start<CommandExecutor.<ShowProcessesDef>d__14>(ref <ShowProcessesDef>d__);
			return <ShowProcessesDef>d__.<>t__builder.Task;
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x0000EA14 File Offset: 0x0000CC14
		public void ShowRemoteDesktopViewer(DeviceAndDisplayList deviceAndDisplayList, RemoteDesktopConnectionType connectionType)
		{
			RdpParams rdpParams = null;
			if (connectionType == RemoteDesktopConnectionType.RDP)
			{
				rdpParams = new RdpParams();
				if (!this._formCreator.Show<RdpParamsForm, RdpParams>(FormAction.Unknown, rdpParams, out rdpParams))
				{
					return;
				}
			}
			if (!this._isSmartActiveXInstallChecked)
			{
				if (!ActiveXInstallationChecker.IsInstalled("62FA83F7-20EC-4D62-AC86-BAB705EE1CCD") && !ActiveXInstallationChecker.IsInstalledAsUser("62FA83F7-20EC-4D62-AC86-BAB705EE1CCD"))
				{
					string fileName = SsStringUtils.GetAppDir() + (Environment.Is64BitProcess ? "scvncctrl64.dll" : "scvncctrl.dll");
					bool isInstalled;
					if (AppUtils.HasWindowsAdminRights())
					{
						isInstalled = ActiveXInstallationChecker.Install("62FA83F7-20EC-4D62-AC86-BAB705EE1CCD", fileName, false);
					}
					else
					{
						isInstalled = ActiveXInstallationChecker.Install("62FA83F7-20EC-4D62-AC86-BAB705EE1CCD", fileName, true);
					}
					if (!isInstalled)
					{
						this._formCreator.ShowError(Resources.CommandExecutor_ActiveXNotInstalled);
					}
				}
				this._isSmartActiveXInstallChecked = true;
			}
			VncViewerManagerForm vncViewerManager = this._formCreator.CreateControl<VncViewerManagerForm>();
			Cursor.Current = Cursors.WaitCursor;
			try
			{
				vncViewerManager.AddDisplays(deviceAndDisplayList, connectionType, rdpParams);
				if (!vncViewerManager.Visible)
				{
					this._apiClient.AddToSystemEventsLog(SystemEventType.ConsoleShowForm, vncViewerManager.Name.Replace("Form", ""), null);
					vncViewerManager.Show();
				}
			}
			finally
			{
				Cursor.Current = Cursors.Default;
			}
			vncViewerManager.Activate();
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x0000EB30 File Offset: 0x0000CD30
		public Task ShutdownSystem(List<AgentItem> agentList, bool rebootAfterShutdown)
		{
			CommandExecutor.<ShutdownSystem>d__16 <ShutdownSystem>d__;
			<ShutdownSystem>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ShutdownSystem>d__.<>4__this = this;
			<ShutdownSystem>d__.agentList = agentList;
			<ShutdownSystem>d__.rebootAfterShutdown = rebootAfterShutdown;
			<ShutdownSystem>d__.<>1__state = -1;
			<ShutdownSystem>d__.<>t__builder.Start<CommandExecutor.<ShutdownSystem>d__16>(ref <ShutdownSystem>d__);
			return <ShutdownSystem>d__.<>t__builder.Task;
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x0000EB84 File Offset: 0x0000CD84
		public Task UpdateSettings(string id, string value, string[] items)
		{
			CommandExecutor.<UpdateSettings>d__17 <UpdateSettings>d__;
			<UpdateSettings>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<UpdateSettings>d__.<>4__this = this;
			<UpdateSettings>d__.id = id;
			<UpdateSettings>d__.value = value;
			<UpdateSettings>d__.items = items;
			<UpdateSettings>d__.<>1__state = -1;
			<UpdateSettings>d__.<>t__builder.Start<CommandExecutor.<UpdateSettings>d__17>(ref <UpdateSettings>d__);
			return <UpdateSettings>d__.<>t__builder.Task;
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x0000EBE0 File Offset: 0x0000CDE0
		public Task WakeOnLan(List<DeviceItem> devicesList)
		{
			CommandExecutor.<WakeOnLan>d__18 <WakeOnLan>d__;
			<WakeOnLan>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<WakeOnLan>d__.<>4__this = this;
			<WakeOnLan>d__.devicesList = devicesList;
			<WakeOnLan>d__.<>1__state = -1;
			<WakeOnLan>d__.<>t__builder.Start<CommandExecutor.<WakeOnLan>d__18>(ref <WakeOnLan>d__);
			return <WakeOnLan>d__.<>t__builder.Task;
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x0000EC2C File Offset: 0x0000CE2C
		internal void BeforePopup(object sender, CancelEventArgs e)
		{
			if (e.Cancel)
			{
				return;
			}
			PopupMenu popupMenu = sender as PopupMenu;
			if (popupMenu == null)
			{
				return;
			}
			this.<BeforePopup>g__processItemsLinks|19_0(popupMenu.ItemLinks);
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x0000EC5C File Offset: 0x0000CE5C
		internal void ExecuteCommand(BarItem item, object param = null)
		{
			CommandExecutor.<ExecuteCommand>d__20 <ExecuteCommand>d__;
			<ExecuteCommand>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ExecuteCommand>d__.<>4__this = this;
			<ExecuteCommand>d__.item = item;
			<ExecuteCommand>d__.param = param;
			<ExecuteCommand>d__.<>1__state = -1;
			<ExecuteCommand>d__.<>t__builder.Start<CommandExecutor.<ExecuteCommand>d__20>(ref <ExecuteCommand>d__);
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x0000ECA3 File Offset: 0x0000CEA3
		internal void OnMenuItemClick(object sender, ItemClickEventArgs e)
		{
			this.ExecuteCommand(e.Item, null);
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x0000ECB4 File Offset: 0x0000CEB4
		private Task SetDevicesAppAccess(AppControlState access, string desktopOrAppCategoryId = null)
		{
			CommandExecutor.<SetDevicesAppAccess>d__22 <SetDevicesAppAccess>d__;
			<SetDevicesAppAccess>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SetDevicesAppAccess>d__.<>4__this = this;
			<SetDevicesAppAccess>d__.access = access;
			<SetDevicesAppAccess>d__.desktopOrAppCategoryId = desktopOrAppCategoryId;
			<SetDevicesAppAccess>d__.<>1__state = -1;
			<SetDevicesAppAccess>d__.<>t__builder.Start<CommandExecutor.<SetDevicesAppAccess>d__22>(ref <SetDevicesAppAccess>d__);
			return <SetDevicesAppAccess>d__.<>t__builder.Task;
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x0000ED08 File Offset: 0x0000CF08
		private Task SetDevicesInetAccess(InetControlState access)
		{
			CommandExecutor.<SetDevicesInetAccess>d__23 <SetDevicesInetAccess>d__;
			<SetDevicesInetAccess>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SetDevicesInetAccess>d__.<>4__this = this;
			<SetDevicesInetAccess>d__.access = access;
			<SetDevicesInetAccess>d__.<>1__state = -1;
			<SetDevicesInetAccess>d__.<>t__builder.Start<CommandExecutor.<SetDevicesInetAccess>d__23>(ref <SetDevicesInetAccess>d__);
			return <SetDevicesInetAccess>d__.<>t__builder.Task;
		}

		// Token: 0x060003EE RID: 1006 RVA: 0x0000ED54 File Offset: 0x0000CF54
		private Task SetDevicesInetStrictAccess(string categoryId)
		{
			CommandExecutor.<SetDevicesInetStrictAccess>d__24 <SetDevicesInetStrictAccess>d__;
			<SetDevicesInetStrictAccess>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SetDevicesInetStrictAccess>d__.<>4__this = this;
			<SetDevicesInetStrictAccess>d__.categoryId = categoryId;
			<SetDevicesInetStrictAccess>d__.<>1__state = -1;
			<SetDevicesInetStrictAccess>d__.<>t__builder.Start<CommandExecutor.<SetDevicesInetStrictAccess>d__24>(ref <SetDevicesInetStrictAccess>d__);
			return <SetDevicesInetStrictAccess>d__.<>t__builder.Task;
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x0000EDA0 File Offset: 0x0000CFA0
		private Task SetDevicesLock(int deviceLock)
		{
			CommandExecutor.<SetDevicesLock>d__25 <SetDevicesLock>d__;
			<SetDevicesLock>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<SetDevicesLock>d__.<>4__this = this;
			<SetDevicesLock>d__.deviceLock = deviceLock;
			<SetDevicesLock>d__.<>1__state = -1;
			<SetDevicesLock>d__.<>t__builder.Start<CommandExecutor.<SetDevicesLock>d__25>(ref <SetDevicesLock>d__);
			return <SetDevicesLock>d__.<>t__builder.Task;
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x0000EE38 File Offset: 0x0000D038
		[CompilerGenerated]
		private void <BeforePopup>g__processItemsLinks|19_0(IEnumerable<BarItemLink> items)
		{
			foreach (BarItemLink item in items)
			{
				BarBaseButtonItemLink buttonItemLink = item as BarBaseButtonItemLink;
				if (buttonItemLink != null)
				{
					object tag = buttonItemLink.Item.Tag;
					if (tag is ConsoleEventType)
					{
						ConsoleEventType command = (ConsoleEventType)tag;
						if (this._commandsDisabledByRole.Contains(command))
						{
							buttonItemLink.Item.Enabled = false;
						}
						else if (this._commandsAlwaysEnabled.Contains(command))
						{
							buttonItemLink.Item.Enabled = true;
						}
						else
						{
							buttonItemLink.Item.Enabled = this._commandTarget.IsCommandEnabled(command);
						}
					}
				}
				else
				{
					BarSubItemLink subItemLink = item as BarSubItemLink;
					if (subItemLink != null)
					{
						this.<BeforePopup>g__processItemsLinks|19_0(subItemLink.Item.ItemLinks);
					}
				}
			}
		}

		// Token: 0x04000136 RID: 310
		private readonly ApiClient _apiClient;

		// Token: 0x04000137 RID: 311
		private readonly List<ConsoleEventType> _commandsAlwaysEnabled;

		// Token: 0x04000138 RID: 312
		private readonly List<ConsoleEventType> _commandsDisabledByRole;

		// Token: 0x04000139 RID: 313
		private readonly ICommandTarget _commandTarget;

		// Token: 0x0400013A RID: 314
		private readonly IFormCreator _formCreator;

		// Token: 0x0400013B RID: 315
		private bool _isSmartActiveXInstallChecked;
	}
}
