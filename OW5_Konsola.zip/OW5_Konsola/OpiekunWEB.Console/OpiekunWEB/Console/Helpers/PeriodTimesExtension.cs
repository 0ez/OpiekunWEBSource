﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using OpiekunWEB.Console.Properties;

namespace OpiekunWEB.Console.Helpers
{
	// Token: 0x02000045 RID: 69
	public static class PeriodTimesExtension
	{
		// Token: 0x0600041A RID: 1050 RVA: 0x0000F968 File Offset: 0x0000DB68
		public static System.ValueTuple<DateTime, DateTime> GetDatesRange(this TimePeriods timePeriod)
		{
			switch (timePeriod)
			{
			case TimePeriods.Today:
				return PeriodTimesExtension.<GetDatesRange>g__GetDatesForLastDays|0_0(0);
			case TimePeriods.Yesterday:
				return new System.ValueTuple<DateTime, DateTime>(DateTime.Now.AddDays(-1.0), DateTime.Now.AddDays(-1.0));
			case TimePeriods.Last7Days:
				return PeriodTimesExtension.<GetDatesRange>g__GetDatesForLastDays|0_0(7);
			case TimePeriods.Last30Days:
				return PeriodTimesExtension.<GetDatesRange>g__GetDatesForLastDays|0_0(30);
			case TimePeriods.ThisWeek:
				return new System.ValueTuple<DateTime, DateTime>(DateTime.Today.AddDays((double)(-(double)DateTime.Today.DayOfWeek)), DateTime.Now);
			case TimePeriods.LastWeek:
			{
				DateTime prevSunday = DateTime.Today.AddDays((double)(-(double)DateTime.Today.DayOfWeek)).AddDays(-7.0);
				return new System.ValueTuple<DateTime, DateTime>(prevSunday, prevSunday.AddDays(7.0));
			}
			case TimePeriods.ThisMonth:
				return new System.ValueTuple<DateTime, DateTime>(new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1), DateTime.Now);
			case TimePeriods.LastMonth:
			{
				DateTime month = DateTime.Now.AddMonths(-1);
				month = new DateTime(month.Year, month.Month, 1);
				DateTime monthEnd = month.AddDays((double)(DateTime.DaysInMonth(month.Year, month.Month) - 1));
				return new System.ValueTuple<DateTime, DateTime>(month, monthEnd);
			}
			case TimePeriods.ThisYear:
				return new System.ValueTuple<DateTime, DateTime>(new DateTime(DateTime.Now.Year, 1, 1), DateTime.Now);
			default:
				return PeriodTimesExtension.<GetDatesRange>g__GetDatesForLastDays|0_0(1);
			}
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x0000FAF7 File Offset: 0x0000DCF7
		public static List<KeyAndValue<TimePeriods, string>> GetValuesAsStringKeyAndValue()
		{
			return EnumHelpers.GetEnumValuesAsStringKeyAndValue<TimePeriods>(Resources.ResourceManager);
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x0000FB04 File Offset: 0x0000DD04
		[CompilerGenerated]
		internal static System.ValueTuple<DateTime, DateTime> <GetDatesRange>g__GetDatesForLastDays|0_0(int daysCount)
		{
			DateTime now = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
			return new System.ValueTuple<DateTime, DateTime>(now.AddDays((double)(-1 * daysCount)), now);
		}
	}
}
