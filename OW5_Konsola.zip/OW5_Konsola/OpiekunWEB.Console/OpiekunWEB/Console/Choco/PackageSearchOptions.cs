﻿using System;

namespace OpiekunWEB.Console.Choco
{
	// Token: 0x020000BB RID: 187
	public struct PackageSearchOptions
	{
		// Token: 0x0600098D RID: 2445 RVA: 0x00056E41 File Offset: 0x00055041
		public PackageSearchOptions(int pageSize, int currentPage, string sortColumn, bool includePrerelease, bool includeAllVersions, bool matchWord, string source)
		{
			this = default(PackageSearchOptions);
			this.PageSize = pageSize;
			this.CurrentPage = currentPage;
			this.SortColumn = sortColumn;
			this.IncludeAllVersions = includeAllVersions;
			this.IncludePrerelease = includePrerelease;
			this.MatchQuery = matchWord;
			this.Source = source;
		}

		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x0600098E RID: 2446 RVA: 0x00056E7F File Offset: 0x0005507F
		// (set) Token: 0x0600098F RID: 2447 RVA: 0x00056E87 File Offset: 0x00055087
		public int CurrentPage { get; set; }

		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x06000990 RID: 2448 RVA: 0x00056E90 File Offset: 0x00055090
		// (set) Token: 0x06000991 RID: 2449 RVA: 0x00056E98 File Offset: 0x00055098
		public bool IncludeAllVersions { get; set; }

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x06000992 RID: 2450 RVA: 0x00056EA1 File Offset: 0x000550A1
		// (set) Token: 0x06000993 RID: 2451 RVA: 0x00056EA9 File Offset: 0x000550A9
		public bool IncludePrerelease { get; set; }

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x06000994 RID: 2452 RVA: 0x00056EB2 File Offset: 0x000550B2
		// (set) Token: 0x06000995 RID: 2453 RVA: 0x00056EBA File Offset: 0x000550BA
		public bool MatchQuery { get; set; }

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x06000996 RID: 2454 RVA: 0x00056EC3 File Offset: 0x000550C3
		// (set) Token: 0x06000997 RID: 2455 RVA: 0x00056ECB File Offset: 0x000550CB
		public int PageSize { get; set; }

		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x06000998 RID: 2456 RVA: 0x00056ED4 File Offset: 0x000550D4
		// (set) Token: 0x06000999 RID: 2457 RVA: 0x00056EDC File Offset: 0x000550DC
		public string SortColumn { get; set; }

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x0600099A RID: 2458 RVA: 0x00056EE5 File Offset: 0x000550E5
		// (set) Token: 0x0600099B RID: 2459 RVA: 0x00056EED File Offset: 0x000550ED
		public string Source { get; set; }

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x0600099C RID: 2460 RVA: 0x00056EF6 File Offset: 0x000550F6
		// (set) Token: 0x0600099D RID: 2461 RVA: 0x00056EFE File Offset: 0x000550FE
		public string[] TagsQuery { get; set; }
	}
}
