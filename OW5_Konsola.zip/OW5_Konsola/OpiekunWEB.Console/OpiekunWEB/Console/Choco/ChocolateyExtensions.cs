﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using chocolatey;
using chocolatey.infrastructure.results;

namespace OpiekunWEB.Console.Choco
{
	// Token: 0x020000B8 RID: 184
	public static class ChocolateyExtensions
	{
		// Token: 0x06000982 RID: 2434 RVA: 0x00056D50 File Offset: 0x00054F50
		public static Task<ICollection<T>> ListAsync<T>(this GetChocolatey chocolatey)
		{
			return Task.Run<ICollection<T>>(() => chocolatey.List<T>().ToList<T>());
		}

		// Token: 0x06000983 RID: 2435 RVA: 0x00056D6E File Offset: 0x00054F6E
		public static Task<ICollection<PackageResult>> ListPackagesAsync(this GetChocolatey chocolatey)
		{
			return Task.Run<ICollection<PackageResult>>(() => chocolatey.List<PackageResult>().ToList<PackageResult>());
		}

		// Token: 0x06000984 RID: 2436 RVA: 0x00056D8C File Offset: 0x00054F8C
		public static Task RunAsync(this GetChocolatey chocolatey)
		{
			return Task.Run(delegate()
			{
				chocolatey.Run();
			});
		}
	}
}
