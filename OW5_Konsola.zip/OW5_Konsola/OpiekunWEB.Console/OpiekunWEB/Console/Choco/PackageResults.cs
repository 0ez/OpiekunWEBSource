﻿using System;
using chocolatey.infrastructure.app.domain;

namespace OpiekunWEB.Console.Choco
{
	// Token: 0x020000BA RID: 186
	public class PackageResults
	{
		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x06000988 RID: 2440 RVA: 0x00056E1F File Offset: 0x0005501F
		// (set) Token: 0x06000989 RID: 2441 RVA: 0x00056E27 File Offset: 0x00055027
		public ChocolateyPackageInformation[] Packages { get; set; }

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x0600098A RID: 2442 RVA: 0x00056E30 File Offset: 0x00055030
		// (set) Token: 0x0600098B RID: 2443 RVA: 0x00056E38 File Offset: 0x00055038
		public int TotalCount { get; set; }
	}
}
