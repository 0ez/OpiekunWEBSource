﻿using System;
using System.Threading.Tasks;

namespace OpiekunWEB.Console.Choco
{
	// Token: 0x020000BC RID: 188
	public interface IChocolateyService
	{
		// Token: 0x0600099E RID: 2462
		Task<PackageResults> Search(string query, PackageSearchOptions options);
	}
}
