﻿using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using chocolatey;
using Microsoft.VisualStudio.Threading;

namespace OpiekunWEB.Console.Choco
{
	// Token: 0x020000B9 RID: 185
	public class ChocolateyService : IChocolateyService
	{
		// Token: 0x06000985 RID: 2437 RVA: 0x00056DAA File Offset: 0x00054FAA
		public ChocolateyService()
		{
			this._choco = Lets.GetChocolatey();
		}

		// Token: 0x06000986 RID: 2438 RVA: 0x00056DC0 File Offset: 0x00054FC0
		public Task<PackageResults> Search(string query, PackageSearchOptions options)
		{
			ChocolateyService.<Search>d__3 <Search>d__;
			<Search>d__.<>t__builder = AsyncTaskMethodBuilder<PackageResults>.Create();
			<Search>d__.<>4__this = this;
			<Search>d__.query = query;
			<Search>d__.options = options;
			<Search>d__.<>1__state = -1;
			<Search>d__.<>t__builder.Start<ChocolateyService.<Search>d__3>(ref <Search>d__);
			return <Search>d__.<>t__builder.Task;
		}

		// Token: 0x04000765 RID: 1893
		private static readonly AsyncReaderWriterLock _lock = new AsyncReaderWriterLock();

		// Token: 0x04000766 RID: 1894
		private readonly GetChocolatey _choco;
	}
}
