﻿using System;

namespace OpiekunWEB.Console.Consts
{
	// Token: 0x020000BD RID: 189
	public static class UserIniConsts
	{
		// Token: 0x04000771 RID: 1905
		public const string DefaultFont = "DefaultFont";

		// Token: 0x04000772 RID: 1906
		public const string Skin = "Skin";
	}
}
