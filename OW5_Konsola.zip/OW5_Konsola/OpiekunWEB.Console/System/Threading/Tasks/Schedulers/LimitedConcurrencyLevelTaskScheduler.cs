﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace System.Threading.Tasks.Schedulers
{
	// Token: 0x02000002 RID: 2
	public class LimitedConcurrencyLevelTaskScheduler : TaskScheduler
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public LimitedConcurrencyLevelTaskScheduler(int maxDegreeOfParallelism)
		{
			if (maxDegreeOfParallelism < 1)
			{
				throw new ArgumentOutOfRangeException("maxDegreeOfParallelism");
			}
			this._maxDegreeOfParallelism = maxDegreeOfParallelism;
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000002 RID: 2 RVA: 0x00002079 File Offset: 0x00000279
		public sealed override int MaximumConcurrencyLevel
		{
			get
			{
				return this._maxDegreeOfParallelism;
			}
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00002084 File Offset: 0x00000284
		protected sealed override IEnumerable<Task> GetScheduledTasks()
		{
			bool lockTaken = false;
			IEnumerable<Task> result;
			try
			{
				Monitor.TryEnter(this._tasks, ref lockTaken);
				if (!lockTaken)
				{
					throw new NotSupportedException();
				}
				result = this._tasks.ToArray<Task>();
			}
			finally
			{
				if (lockTaken)
				{
					Monitor.Exit(this._tasks);
				}
			}
			return result;
		}

		// Token: 0x06000004 RID: 4 RVA: 0x000020D8 File Offset: 0x000002D8
		protected sealed override void QueueTask(Task task)
		{
			LinkedList<Task> tasks = this._tasks;
			lock (tasks)
			{
				this._tasks.AddLast(task);
				if (this._delegatesQueuedOrRunning < this._maxDegreeOfParallelism)
				{
					this._delegatesQueuedOrRunning++;
					this.NotifyThreadPoolOfPendingWork();
				}
			}
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00002144 File Offset: 0x00000344
		protected sealed override bool TryDequeue(Task task)
		{
			LinkedList<Task> tasks = this._tasks;
			bool result;
			lock (tasks)
			{
				result = this._tasks.Remove(task);
			}
			return result;
		}

		// Token: 0x06000006 RID: 6 RVA: 0x0000218C File Offset: 0x0000038C
		protected sealed override bool TryExecuteTaskInline(Task task, bool taskWasPreviouslyQueued)
		{
			if (!LimitedConcurrencyLevelTaskScheduler._currentThreadIsProcessingItems)
			{
				return false;
			}
			if (taskWasPreviouslyQueued)
			{
				this.TryDequeue(task);
			}
			return base.TryExecuteTask(task);
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000021A9 File Offset: 0x000003A9
		private void NotifyThreadPoolOfPendingWork()
		{
			ThreadPool.UnsafeQueueUserWorkItem(delegate(object _)
			{
				LimitedConcurrencyLevelTaskScheduler._currentThreadIsProcessingItems = true;
				try
				{
					for (;;)
					{
						LinkedList<Task> tasks = this._tasks;
						Task item;
						lock (tasks)
						{
							if (this._tasks.Count == 0)
							{
								this._delegatesQueuedOrRunning--;
								break;
							}
							item = this._tasks.First.Value;
							this._tasks.RemoveFirst();
						}
						base.TryExecuteTask(item);
					}
				}
				finally
				{
					LimitedConcurrencyLevelTaskScheduler._currentThreadIsProcessingItems = false;
				}
			}, null);
		}

		// Token: 0x04000001 RID: 1
		[ThreadStatic]
		private static bool _currentThreadIsProcessingItems;

		// Token: 0x04000002 RID: 2
		private readonly int _maxDegreeOfParallelism;

		// Token: 0x04000003 RID: 3
		private readonly LinkedList<Task> _tasks = new LinkedList<Task>();

		// Token: 0x04000004 RID: 4
		private int _delegatesQueuedOrRunning;
	}
}
