﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("5.0.0.249")]
[assembly: AssemblyTitle("OpiekunWEB.Console")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("OpiekunWEB Konsola")]
[assembly: AssemblyCopyright("Copyright © 2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("c20b63ff-4512-4b80-90d8-b7e90d7a9328")]
[assembly: AssemblyFileVersion("5.0.0.249")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
